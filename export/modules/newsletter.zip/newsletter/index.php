<?php header('location: ./newsletter.php'); ?>
