<?php
	header('location:faq.php');
	exit;
?>