<?php

header('location:media.php');
exit;

?>