<?php

header('location:admin_media_config.php');
exit;

?>