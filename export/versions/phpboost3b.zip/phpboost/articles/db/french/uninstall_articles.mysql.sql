DROP TABLE IF EXISTS `phpboost_articles_cats`;
DROP TABLE IF EXISTS `phpboost_articles`;
