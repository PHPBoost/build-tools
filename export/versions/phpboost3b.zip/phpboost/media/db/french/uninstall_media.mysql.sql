DROP TABLE IF EXISTS `phpboost_media`;
DROP TABLE IF EXISTS `phpboost_media_cat`;