DROP TABLE IF EXISTS `phpboost_faq`;
DROP TABLE IF EXISTS `phpboost_faq_cats`;