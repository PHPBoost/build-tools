<?php header('location: ./pages.php'); ?>
