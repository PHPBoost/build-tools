<?php
/*##################################################
*                            template.class.php
*                            -------------------
*   begin                : Februar 12, 2006
*   copyright            : (C) 2006 R�gis Viarre, Lo�c Rouchon
*   email                : mickaelhemri@gmail.com, horn@phpboost.com
*
*
###################################################
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*
* The PHPboost template engine is actually based on sections of code from phpBB3 templates
###################################################*/

define('TEMPLATE_STRING_MODE', true);
define('AUTO_LOAD_FREQUENT_VARS', true);
define('DO_NOT_AUTO_LOAD_FREQUENT_VARS', false);

class Template
{
    ## Public Attribute ##
    var $_var = array(); //Tableau contenant les variables de remplacement des variables simples.
    var $_block = array(); //Tableau contenant les variables de remplacement des variables simples.

    // Constructeur
    function Template($tpl = '', $auto_load_vars = AUTO_LOAD_FREQUENT_VARS)
    {
        if (!empty($tpl))
        {
            global $User, $Session;
            $this->tpl = $this->_check_file($tpl);
            $this->files[$this->tpl] = $this->tpl;
            if ($auto_load_vars)
            {
                $member_connected = $User->check_level(MEMBER_LEVEL);
                $this->assign_vars(array(
                    'SID' => SID,
                    'THEME' => get_utheme(),
                    'LANG' => get_ulang(),
                    'C_USER_CONNECTED' => $member_connected,
                    'C_USER_NOTCONNECTED' => !$member_connected,
                    'PATH_TO_ROOT' => PATH_TO_ROOT,
                    'TOKEN' => !empty($Session) ? $Session->get_token() : ''
                ));
            }
        }
    }
    
    //Stock les diff�rents tpl en cours de traitement.
    function set_filenames($array_tpl)
    {
        foreach ($array_tpl as $parse_name => $filename)
            $this->files[$parse_name] = $this->_check_file($filename);
        
        global $Session;
        $this->assign_vars(array(
            'TOKEN' => !empty($Session) ? $Session->get_token() : ''
        ));
    }
    
    //R�cup�ration du chemin des donn�es du module.
    function get_module_data_path($module)
    {
        if (isset($this->module_data_path[$module]))
            return $this->module_data_path[$module];
        return '';
    }
    
    //Stock les variables simple.
    function assign_vars($array_vars)
    {
        foreach ($array_vars as $key => $val)
            $this->_var[$key] = $val;
    }
        
    //Stock les variables des diff�rents blocs.
    function assign_block_vars($block_name, $array_vars)
    {
        if (strpos($block_name, '.') !== false) //Bloc imbriqu�.
        {
            $blocks = explode('.', $block_name);
            $blockcount = count($blocks) - 1;

            $str = &$this->_block;
            for ($i = 0; $i < $blockcount; $i++)
            {
                $str = &$str[$blocks[$i]];
                $str = &$str[count($str) - 1];
            }
            $str[$blocks[$blockcount]][] = $array_vars;
        }
        else
            $this->_block[$block_name][] = $array_vars;
    }
    
    //Supprime un bloc.
    function unassign_block_vars($block_name)
    {
        if (isset($this->_block[$block_name]))
            unset($this->_block[$block_name]);
    }

    //
    function parse($stringMode = false)
    {
        if ( $stringMode )
            return $this->pparse($this->tpl, $stringMode);
        else $this->pparse($this->tpl, $stringMode);
    }
    
    //Affichage du traitement du tpl.
    function pparse($parse_name, $stringMode = false)
    {
		if (!isset($this->files[$parse_name]))
			return '';

		$this->stringMode = $stringMode;
		
        $file_cache_path = PATH_TO_ROOT . '/cache/tpl/' . trim(str_replace(array('/', '.', '..', 'tpl', 'templates'), array('_', '', '', '', 'tpl'), $this->files[$parse_name]), '_');
        if ($stringMode)
            $file_cache_path .= '_str';
        $file_cache_path .= '.php';

        //V�rification du statut du fichier de cache associ� au template.
        if (!$this->_check_cache_file($this->files[$parse_name], $file_cache_path))
        {
            //Chargement du template.
            if (!$this->_load($parse_name))
                return '';

            //Parse
            $this->_parse($parse_name, $stringMode);
            $this->_clean(); //On nettoie avant d'envoyer le flux.
            $this->_save($file_cache_path); //Enregistrement du fichier de cache.
        }
        
        include($file_cache_path);
        
        if ($this->stringMode)
            return $tplString;
    }

    // Object  cloner
    function copy()
    {
        $copy = new Template();
        
        $copy->tpl = $this->tpl;
        $copy->template = $this->template;
        $copy->files = $this->files;
        $copy->module_data_path = $this->module_data_path;
        $copy->stringMode = $this->stringMode;
        
        $copy->_var = $this->_var; //Tableau contenant les variables de remplacement des variables simples.
        $copy->_block = $this->_block; //Tableau contenant les variables de remplacement des variables simples.
        
        return $copy;
    }
    
    
    ## Private Methods ##
    //V�rification de l'existence du tpl perso, sinon tentative de chargement du tpl de base.
    function _check_file($filename)
    {
        global $CONFIG;
        
        /*
        Samples :
        $filename = /forum/forum_topic.tpl
             $filename = forum/forum_topic.tpl
             $module = forum
             $file_name = forum_topic.tpl
             $file = forum_topic.tpl
             $folder =
        
        
        $filename = /news/framework/content/syndication/last_news.tpl
             $filename = news/framework/content/syndication/menu.tpl
             $module = news
             $file_name = menu.tpl
             $file = framework/content/syndication/menu.tpl
             $folder = framework/content/syndication
        */
        
        $filename = trim($filename, '/');
        $i = strpos($filename, '/');
        $module = substr($filename, 0, $i);
        $file = trim(substr($filename, $i), '/');
        $folder = trim(substr($file, 0, strpos($file, '/')), '/');
        $file_name = trim(substr($filename, strrpos($filename, '/')));
        
        $default_templates_folder = PATH_TO_ROOT . '/templates/default/';
        $theme_templates_folder = PATH_TO_ROOT . '/templates/' . get_utheme() . '/';
        
        if (empty($module) || in_array($module, array('admin') ))
        {   // Kernel - Templates priority order
            //      /templates/$theme/.../$file.tpl
            //      /templates/default/.../$file.tpl
            if (file_exists($file_path = $theme_templates_folder . $filename))
                return $file_path;
            return $default_templates_folder . $filename;
        }
        elseif ($module == 'framework')
        {   // Framework - Templates priority order
            //      /templates/$theme/framework/.../$file.tpl
            //      /templates/default/framework/.../$file.tpl
            if (file_exists($file_path = $theme_templates_folder . $filename))
                return $file_path;
            
            return $default_templates_folder . $filename;
        }
        elseif ($module == 'menus')
        {   // Framework - Templates priority order
            //      /templates/$theme/menus/$menu/filename.tpl
            //      /menus/$menu/default/framework/.../$file.tpl
            $menu = substr($folder, 0, strpos($folder, '/'));
            if (empty($menu))
                $menu = $folder;
            if (file_exists($file_path = $theme_templates_folder . '/menus/' . $menu . '/' . $file_name))
                return $file_path;
            
            return PATH_TO_ROOT . '/menus/' . $menu . '/templates/' . $file_name;
        }
        else
        {   // Module - Templates
            $theme_module_templates_folder = $theme_templates_folder . 'modules/' . $module . '/';
            $module_templates_folder = PATH_TO_ROOT . '/' . $module . '/templates/';
            
            if ($folder == 'framework')
            {   // Framework - Templates priority order
                //      /templates/$theme/modules/$module/framework/.../$file.tpl
                //      /templates/$theme/framework/.../$file.tpl
                //      /$module/templates/framework/.../$file.tpl
                //      /templates/default/framework/.../$file.tpl
                if (file_exists($file_path = $theme_module_templates_folder . $file))
                    return $file_path;
                if (file_exists($file_path = $theme_templates_folder . $filename))
                    return $file_path;
                if (file_exists($file_path = ($module_templates_folder . 'framework/' . $file)))
                    return $file_path;
                return $default_templates_folder . $file;
            }
            
            //module data path
            if (!isset($this->module_data_path[$module]))
            {
                if (is_dir($theme_module_templates_folder . '/images'))
                    $this->module_data_path[$module] = trim($theme_module_templates_folder, '/');
                else
                    $this->module_data_path[$module] = trim($module_templates_folder, '/');
            }

            if (file_exists($file_path = $theme_module_templates_folder . $file))
                return $file_path;
            else
                return $module_templates_folder . $file;
        }
    }
    
    //V�rifie le statut du fichier en cache, il sera reg�n�r� s'il n'existe pas ou si il est p�rim�.
    function _check_cache_file($tpl_path, $file_cache_path)
    {
        //fichier expir�
        if (file_exists($file_cache_path))
        {
            if (@filemtime($tpl_path) > @filemtime($file_cache_path) || @filesize($file_cache_path) === 0)
                return false;
            else
                return true;
        }
        return false;
    }

    //Charge un tpl.
    function _load($parse_name)
    {
        if (!isset($this->files[$parse_name]))
            return false;
            
        $this->template = @file_get_contents_emulate($this->files[$parse_name]); //Charge le contenu du fichier tpl.
        if ($this->template === false)
            die('Template->_load(): Le chargement du fichier ' . $this->files[$parse_name] . ' pour parser ' . $parse_name . ' a �chou�');
        if (empty($this->template))
            die('Template->_load(): Le fichier ' . $this->files[$parse_name] . ' pour parser ' . $parse_name . ' est vide');
            
        return true;
    }
    
    //Inclusion d'un template dans un autre.
    function _include($parse_name)
    {
        if (isset($this->files[$parse_name]))
        {
            if ($this->stringMode)
                return $this->pparse($parse_name, $this->stringMode);
            else
                $this->pparse($parse_name, $this->stringMode);
        }
    }
    
    //Parse du tpl.
    function _parse($parse_name)
    {
        if ($this->stringMode)
        {
            $this->template = '<?php $tplString = \'' . str_replace(array('\\', '\''), array('\\\\', '\\\''), $this->template) . '\'; ?>';
            //Remplacement des variables simples.
            $this->template = preg_replace('`{([\w]+)}`i', '\'; if (isset($this->_var[\'$1\'])) $tplString .= $this->_var[\'$1\']; $tplString .=\'', $this->template);
            $this->template = preg_replace_callback('`{([\w\.]+)}`i', array($this, '_parse_blocks_vars'), $this->template);
            
            //Parse des blocs imbriqu�s ou non.
            $this->template = preg_replace_callback('`# START ([\w\.]+) #`', array($this, '_parse_blocks'), $this->template);
            $this->template = preg_replace('`# END [\w\.]+ #`', '\';'."\n".'}'."\n".'$tplString .= \'', $this->template);
            
            //Remplacement des blocs conditionnels.
            $this->template = preg_replace_callback('`# IF (NOT )?([\w\.]+) #`', array($this, '_parse_conditionnal_blocks'), $this->template);
            $this->template = preg_replace_callback('`# ELSEIF (NOT )?([\w\.]+) #`', array($this, '_parse_conditionnal_blocks_bis'), $this->template);
            $this->template = preg_replace('`# ELSE #`', '\';'."\n".'} else {'."\n".'$tplString .= \'', $this->template);
            $this->template = preg_replace('`# ENDIF #`', '\';'."\n".'}'."\n".'$tplString .= \'', $this->template);
            
            //Remplacement des includes.
            $this->template = preg_replace('`# INCLUDE ([\w]+) #`', '\';'."\n".'$tplString .= $this->_include(\'$1\');'."\n".'$tplString .= \'', $this->template);
        }
        else
        {
            // Protection des tags XML
            $this->template = preg_replace_callback('`\<\?(\s.*)\?\>`i', array($this, '_protect_from_inject'), $this->template);
            
            //Remplacement des variables simples.
            $this->template = preg_replace('`{([\w]+)}`i', '<?php if (isset($this->_var[\'$1\'])) echo $this->_var[\'$1\']; ?>', $this->template);
            $this->template = preg_replace_callback('`{([\w\.]+)}`i', array($this, '_parse_blocks_vars'), $this->template);
            
            //Parse des blocs imbriqu�s ou non.
            $this->template = preg_replace_callback('`# START ([\w\.]+) #`', array($this, '_parse_blocks'), $this->template);
            $this->template = preg_replace('`# END [\w\.]+ #`', '<?php } ?>', $this->template);
            
            //Remplacement des blocs conditionnels.
            $this->template = preg_replace_callback('`# IF (NOT )?([\w\.]+) #`', array($this, '_parse_conditionnal_blocks'), $this->template);
            $this->template = preg_replace_callback('`# ELSEIF (NOT )?([\w\.]+) #`', array($this, '_parse_conditionnal_blocks_bis'), $this->template);
            $this->template = preg_replace('`# ELSE #`', '<?php } else { ?>', $this->template);
            $this->template = preg_replace('`# ENDIF #`', '<?php } ?>', $this->template);
            
            //Remplacement des includes.
            $this->template = preg_replace('`# INCLUDE ([\w]+) #`', '<?php $this->_include(\'$1\'); ?>', $this->template);
        }
    }
    
    function _protect_from_inject($mask)
    {
        return '<?php echo \'<?' . str_replace(array('\\', '\''), array('\\\\', '\\\''), trim($mask[1])) . '?>\'; ?>';
    }
    //Remplacement des variables de type bloc.
    function _parse_blocks_vars($blocks)
    {
        if (isset($blocks[1]))
        {
            $array_block = explode('.', $blocks[1]);
            $varname = array_pop($array_block);
            $last_block = array_pop($array_block);

            if ($this->stringMode)
                return '\'; if (isset($_tmpb_' . $last_block . '[\'' . $varname . '\'])) $tplString .= $_tmpb_' . $last_block . '[\'' . $varname . '\']; $tplString .= \'';
            else
                return '<?php if (isset($_tmpb_' . $last_block . '[\'' . $varname . '\'])) echo $_tmpb_' . $last_block . '[\'' . $varname . '\']; ?>';
        }
        return '';
    }
    
    //Remplacement des blocs.
    function _parse_blocks($blocks)
    {
        if (isset($blocks[1]))
        {
            if (strpos($blocks[1], '.') !== false) //Contient un bloc imbriqu�.
            {
                $array_block = explode('.', $blocks[1]);
                $current_block = array_pop($array_block);
                $previous_block = array_pop($array_block);
                
                if ($this->stringMode)
                    return '\';'."\n".'if (!isset($_tmpb_' . $previous_block . '[\'' . $current_block . '\']) || !is_array($_tmpb_' . $previous_block . '[\'' . $current_block . '\'])) $_tmpb_' . $previous_block . '[\'' . $current_block . '\'] = array();' . "\n" . 'foreach ($_tmpb_' . $previous_block . '[\'' . $current_block . '\'] as $' . $current_block . '_key => $' . $current_block . '_value) {' . "\n" . '$_tmpb_' . $current_block . ' = &$_tmpb_' . $previous_block . '[\'' . $current_block . '\'][$' . $current_block . '_key];'."\n".'$tplString .= \'';
                else
                    return '<?php if (!isset($_tmpb_' . $previous_block . '[\'' . $current_block . '\']) || !is_array($_tmpb_' . $previous_block . '[\'' . $current_block . '\'])) $_tmpb_' . $previous_block . '[\'' . $current_block . '\'] = array();' . "\n" . 'foreach ($_tmpb_' . $previous_block . '[\'' . $current_block . '\'] as $' . $current_block . '_key => $' . $current_block . '_value) {' . "\n" . '$_tmpb_' . $current_block . ' = &$_tmpb_' . $previous_block . '[\'' . $current_block . '\'][$' . $current_block . '_key]; ?>';
            }
            else
            {
                if ($this->stringMode)
                    return '\';'."\n".'if (!isset($this->_block[\'' . $blocks[1] . '\']) || !is_array($this->_block[\'' . $blocks[1] . '\'])) $this->_block[\'' . $blocks[1] . '\'] = array();' . "\n" . 'foreach ($this->_block[\'' . $blocks[1] . '\'] as $' . $blocks[1] . '_key => $' . $blocks[1] . '_value) {' . "\n" . '$_tmpb_' . $blocks[1] . ' = &$this->_block[\'' . $blocks[1] . '\'][$' . $blocks[1] . '_key];'."\n".'$tplString .= \'';
                else
                    return '<?php if (!isset($this->_block[\'' . $blocks[1] . '\']) || !is_array($this->_block[\'' . $blocks[1] . '\'])) $this->_block[\'' . $blocks[1] . '\'] = array();' . "\n" . 'foreach ($this->_block[\'' . $blocks[1] . '\'] as $' . $blocks[1] . '_key => $' . $blocks[1] . '_value) {' . "\n" . '$_tmpb_' . $blocks[1] . ' = &$this->_block[\'' . $blocks[1] . '\'][$' . $blocks[1] . '_key]; ?>';
            }
        }
        return '';
    }
    
    //Remplacement des blocs conditionnels.
    function _parse_conditionnal_blocks($blocks)
    {
        if (isset($blocks[2]))
        {
            $not = ($blocks[1] == 'NOT ' ? '!' : '');
            if (strpos($blocks[2], '.') !== false) //Contient un bloc imbriqu�.
            {
                $array_block = explode('.', $blocks[2]);
                $varname = array_pop($array_block);
                $last_block = array_pop($array_block);

                if ($this->stringMode)
                    return '\';'."\n".'if (isset($_tmpb_' . $last_block . '[\'' . $varname . '\']) && ' . $not . '$_tmpb_' . $last_block . '[\'' . $varname . '\']) {'."\n".'$tplString .= \'';
                else
                    return '<?php if (isset($_tmpb_' . $last_block . '[\'' . $varname . '\']) && ' . $not . '$_tmpb_' . $last_block . '[\'' . $varname . '\']) { ?>';
            }
            else
            {
                if ($this->stringMode)
                    return '\';'."\n".'if (isset($this->_var[\'' . $blocks[2] . '\']) && ' . $not . '$this->_var[\'' . $blocks[2] . '\']) {'."\n".'$tplString .= \'';
                else
                    return '<?php if (isset($this->_var[\'' . $blocks[2] . '\']) && ' . $not . '$this->_var[\'' . $blocks[2] . '\']) { ?>';
            }
        }
        return '';
    }
	
    //Remplacement des blocs conditionnels.
    function _parse_conditionnal_blocks_bis($blocks)
    {
        if (isset($blocks[2]))
        {
            $not = ($blocks[1] == 'NOT ' ? '!' : '');
            if (strpos($blocks[2], '.') !== false) //Contient un bloc imbriqu�.
            {
                $array_block = explode('.', $blocks[2]);
                $varname = array_pop($array_block);
                $last_block = array_pop($array_block);

                if ($this->stringMode)
                    return '\';'."\n".'} elseif (isset($_tmpb_' . $last_block . '[\'' . $varname . '\']) && ' . $not . '$_tmpb_' . $last_block . '[\'' . $varname . '\']) {'."\n".'$tplString .= \'';
                else
                    return '<?php } elseif (isset($_tmpb_' . $last_block . '[\'' . $varname . '\']) && ' . $not . '$_tmpb_' . $last_block . '[\'' . $varname . '\']) { ?>';
            }
            else
            {
                if ($this->stringMode)
                    return '\';'."\n".'} elseif (isset($this->_var[\'' . $blocks[2] . '\']) && ' . $not . '$this->_var[\'' . $blocks[2] . '\']) {'."\n".'$tplString .= \'';
                else
                    return '<?php } elseif (isset($this->_var[\'' . $blocks[2] . '\']) && ' . $not . '$this->_var[\'' . $blocks[2] . '\']) { ?>';
            }
        }
        return '';
    }
	
    //Nettoyage des commentaires, et blocs et variables non utilis�s.
    function _clean()
    {
        $this->template = preg_replace(
            array('`# START [\w\.]+ #(.*)# END [\w\.]+ #`s', '`# START [\w\.]+ #`', '`# END [\w\.]+ #`', '`{[\w\.]+}`'),
            array('', '', '', ''),
        $this->template);

        //Evite � l'interpr�teur PHP du travail inutile.
        if ($this->stringMode)
        {
            $this->template = str_replace('$tplString .= \'\';', '', $this->template);
            $this->template = preg_replace(array('`[\n]{2,}`', '`[\r]{2,}`', '`[\t]{2,}`', '`[ ]{2,}`'), array('', '', '', ''), $this->template);
        }
        else
        {
            $this->template = preg_replace('` \?><\?php `', '', $this->template);
            $this->template = preg_replace('` \?>[\s]+<\?php `', "echo ' ';", $this->template);
            $this->template = preg_replace("`echo ' ';echo `", "echo ' ' . ", $this->template);
            $this->template = preg_replace("`''\);echo `", "'') . ", $this->template);
        }
    }
    
    //Enregistrement du fichier de cache, avec pose pr�alable d'un verrou.
    function _save($file_cache_path)
    {
    	import('io/filesystem/file');
    	$file = new File($file_cache_path);
    	$file->open(WRITE);
    	$file->lock();
    	$file->write($this->template);
    	$file->unlock();
    	$file->close();
    	$file->change_chmod(0666);
    }
    

    ## Private Attribute ##
    var $tpl = ''; // Nom du fichier de template
    var $template = ''; //Cha�ne contenant le tpl en cours de parsage.
    var $files = array(); //Tableau contenant le chemin vers le tpl (v�rifi�).
    var $module_data_path = array(); //Chemin vers les donn�es du module.
    var $stringMode; // Type de parsage � effectuer, inclusion du tpl pars� ou retourne une chaine.
}

?>
