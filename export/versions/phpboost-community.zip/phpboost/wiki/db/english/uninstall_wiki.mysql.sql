DROP TABLE IF EXISTS `phpboost_wiki_articles`;
DROP TABLE IF EXISTS `phpboost_wiki_cats`;
DROP TABLE IF EXISTS `phpboost_wiki_contents`;
DROP TABLE IF EXISTS `phpboost_wiki_favorites`;