DROP TABLE IF EXISTS `phpboost_download_cat`;
DROP TABLE IF EXISTS `phpboost_download`;