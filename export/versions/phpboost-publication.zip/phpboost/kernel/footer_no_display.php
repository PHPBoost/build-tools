<?php


























if(defined('PHPBOOST')!==true)
{
exit;
}

$Sql->close();
ob_end_flush();
?>