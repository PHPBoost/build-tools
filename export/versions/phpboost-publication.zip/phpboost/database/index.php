<?php

header('location:admin_database.php');
exit;

?>