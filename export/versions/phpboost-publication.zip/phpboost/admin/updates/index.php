<?php
header('location:updates.php');
?>