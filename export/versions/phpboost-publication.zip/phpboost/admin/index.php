<?php
	header('location: admin_index.php');
	exit;
?>
