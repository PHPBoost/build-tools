<?php


























define('URL__CLASS','url');
define('SERVER_URL',$_SERVER['PHP_SELF']);
define('URL_TAGS','src|data|value|href|son|flv');














class Url
{








function Url($url='.',$path_to_root=null,$server_url=null)
{
if(!empty($url))
{
if($path_to_root!==null)
{
$this->path_to_root=$path_to_root;
}
else
{
$this->path_to_root=Url::path_to_root();
}

if($server_url!==null)
{
$this->server_url=$server_url;
}
else
{
$this->server_url=Url::server_url();
}

if(strpos($url,'javascript:')===0)
{
$this->url=$url;
return;
}

if(strpos($url,'www.')===0)
{
$url='http://'.$url;
}

$url=str_replace(HOST.DIR.'/','/',Url::compress($url));
if(!strpos($url,'://'))
{
$this->is_relative=true;
if(substr($url,0,1)=='/')
{
$this->url=$url;
}
else
{
$this->url=$this->root_to_local().$url;
}
}
else
{
$this->is_relative=false;
$this->url=$url;
}
$this->url=Url::compress($this->url);
}
}




function is_relative()
{
return $this->is_relative;
}





function relative()
{
if($this->is_relative())
{
return $this->url;
}
else
{
return $this->absolute();
}
}





function absolute()
{
if($this->is_relative())
{
return Url::compress($this->get_absolute_root().$this->url);
}
else
{
return $this->url;
}
}








function compress($url)
{
$url=preg_replace(array('`([^:]|^)/+`','`(?<!\.)\./`'),array('$1/',''),$url);

do
{
$url=preg_replace('`/?[^/]+/\.\.`','',$url);

}
while(preg_match('`/?[^/]+/\.\.`',$url)>0);
return preg_replace('`^//`','/',$url);
}




function root_to_local()
{
global $CONFIG;

$local_path=$this->server_url;
$local_path=substr(trim($local_path,'/'),strlen(trim($CONFIG['server_path'],'/')));
$file_begun=strrpos($local_path,'/');
if($file_begun>=0)
{
$local_path=substr($local_path,0,$file_begun).'/';
}

return $local_path;
}






function get_absolute_root()
{
global $CONFIG;
return trim(trim($CONFIG['server_name'],'/').'/'.trim($CONFIG['server_path'],'/'),'/');
}










function html_convert_root_relative2absolute($html_text,$path_to_root=PATH_TO_ROOT,$server_url=SERVER_URL)
{
Url::path_to_root($path_to_root);
Url::server_url($server_url);
return preg_replace_callback(
'`(<script type="text/javascript">.*insert(?:Sound|Movie|Swf)Player\(")(/[^"]+)(".*</script>)`sU',
array('Url','_convert_url_to_absolute'),
preg_replace_callback(
'`((?:<[^>]+) (?:'.URL_TAGS.')=")(/[^"]+)("(?:[^<]*>))`',
array('Url','_convert_url_to_absolute'),
$html_text
)
);
}









function html_convert_absolute2relative($html_text,$path_to_root=PATH_TO_ROOT,$server_url=SERVER_URL)
{
Url::path_to_root($path_to_root);
Url::server_url($server_url);
return preg_replace_callback(
'`(<script type="text/javascript">.*insert(?:Sound|Movie|Swf)Player\(")([^"]+)(".*</script>)`sU',
array('Url','_convert_url_to_relative'),
preg_replace_callback(
'`((?:<[^>]+) (?:'.URL_TAGS.')(?:="))([^"]+)("(?:[^<]*>))`',
array('Url','_convert_url_to_relative'),
$html_text
)
);
}








function html_convert_root_relative2relative($html_text,$path_to_root=PATH_TO_ROOT)
{
return preg_replace(
'`((?:<[^>]+) (?:'.URL_TAGS.')(?:="))(/[^"]+)("(?:[^<]*>))`',
'$1'.$path_to_root.'$2$3',
$html_text);
}







function _convert_url_to_absolute($url_params)
{
$url=new Url($url_params[2]);
$url_params[2]=$url->absolute();
return $url_params[1].$url_params[2].$url_params[3];
}







function _convert_url_to_relative($url_params)
{
$url=new Url($url_params[2]);
$url_params[2]=$url->relative();
return $url_params[1].$url_params[2].$url_params[3];
}








function get_relative($url,$path_to_root=null,$server_url=null)
{
$o_url=new Url($url,$path_to_root,$server_url);
return $o_url->relative();
}








function path_to_root($path=null)
{
static $path_to_root=PATH_TO_ROOT;
if($path!=null)
{
$path_to_root=$path;
}
return $path_to_root;
}








function server_url($url=null)
{
static $server_url=SERVER_URL;
if($url!==null)
{
$server_url=$url;
}
return $server_url;
}



















function get_wellformness_regex($protocol=REGEX_MULTIPLICITY_OPTIONNAL,
$user=REGEX_MULTIPLICITY_OPTIONNAL,$domain=REGEX_MULTIPLICITY_OPTIONNAL,
$folders=REGEX_MULTIPLICITY_OPTIONNAL,$file=REGEX_MULTIPLICITY_OPTIONNAL,
$args=REGEX_MULTIPLICITY_OPTIONNAL,$anchor=REGEX_MULTIPLICITY_OPTIONNAL,$forbid_js=true)
{
static $forbid_js_regex='(?!javascript:)';
static $protocol_regex='[a-z0-9-_]+(?::[a-z0-9-_]+)*://';
static $user_regex='[a-z0-9-_]+(?::[a-z0-9-_]+)?@';
static $domain_regex='(?:[a-z0-9-_~]+\.)*[a-z0-9-_~]+(?::[0-9]{1,5})?/';
static $folders_regex='/*(?:[a-z0-9~_\.-]+/+)*';
static $file_regex='[a-z0-9-+_~:\.\%]+';
static $args_regex='\?[a-z0-9-+=_~:&\.\?\'\%]+';
static $anchor_regex='\#[a-z0-9-_]';

if($forbid_js)
{
$protocol_regex_secured=$forbid_js_regex.$protocol_regex;
}
else
{
$protocol_regex_secured=$protocol_regex;
}

return set_subregex_multiplicity($protocol_regex_secured,$protocol).
set_subregex_multiplicity($user_regex,$user).
set_subregex_multiplicity($domain_regex,$domain).
set_subregex_multiplicity($folders_regex,$folders).
set_subregex_multiplicity($file_regex,$file).
set_subregex_multiplicity($args_regex,$args).
set_subregex_multiplicity($anchor_regex,$anchor);
}



















function check_wellformness($url,$protocol=REGEX_MULTIPLICITY_OPTIONNAL,
$user=REGEX_MULTIPLICITY_OPTIONNAL,$domain=REGEX_MULTIPLICITY_OPTIONNAL,
$folders=REGEX_MULTIPLICITY_OPTIONNAL,$file=REGEX_MULTIPLICITY_OPTIONNAL,
$args=REGEX_MULTIPLICITY_OPTIONNAL,$anchor=REGEX_MULTIPLICITY_OPTIONNAL,$forbid_js=true)
{
return preg_match('`^'.Url::get_wellformness_regex($protocol,$user,$domain,
$folders,$file,$args,$anchor,$forbid_js).'$`i',$url);
}

var $url='';
var $is_relative=false;
var $path_to_root='';
var $server_url='';
}
?>