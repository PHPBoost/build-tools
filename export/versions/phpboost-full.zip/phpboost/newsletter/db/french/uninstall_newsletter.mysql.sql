DROP TABLE IF EXISTS `phpboost_newsletter`;
DROP TABLE IF EXISTS `phpboost_newsletter_arch`;
