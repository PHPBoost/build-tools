tinyMCE.addI18n('fr.searchreplace_dlg',{
searchnext_desc:"Chercher � nouveau",
notfound:"La recherche a �t� effectu�e. La cha�ne recherch�e n'a pas pu �tre trouv�e.",
search_title:"Chercher",
replace_title:"Chercher/Remplacer",
allreplaced:"Toutes les occurences de la recherche ont �t� remplac�es.",
findwhat:"Rechercher",
replacewith:"Replacer par",
direction:"Sens",
up:"Haut",
down:"Bas",
mcase:"Tenir compte de la casse",
findnext:"Chercher",
replace:"Remplacer",
replaceall:"Remplacer tout"
});