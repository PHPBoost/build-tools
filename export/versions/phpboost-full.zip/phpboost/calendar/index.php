<?php header('location: ./calendar.php'); ?>
