DROP TABLE IF EXISTS `phpboost_calendar`;
