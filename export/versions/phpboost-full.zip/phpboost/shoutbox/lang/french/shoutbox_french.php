<?php
/*##################################################
 *                             shoutobx_french.php
 *                            -------------------
 *   begin                :  July 29, 2005
 *   copyright          : (C) 2005 Viarre R�gis
 *   email                : crowkait@phpboost.com
 *
 *  
 ###################################################
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
###################################################*/


####################################################
#                                                          French                                                                        #
####################################################

//Admin
$LANG['shoutbox_max_msg'] = 'Nombre de messages maximum � conserver';
$LANG['shoutbox_max_msg_explain'] = 'Supprim�s tous les jours, mettre -1 pour d�sactiver';
$LANG['shoutbox_config'] = 'Configuration de la discussion rapide';
$LANG['rank_post'] = 'Rang pour pouvoir poster';
$LANG['shoutbox_refresh_delay'] = 'Delai de rafraichissement automatique de la discussion';
$LANG['shoutbox_refresh_delay_explain'] = 'Mettre 0 pour d�sactiver';
		
$LANG['title_shoutbox'] = 'Discussion';
$LANG['archives'] = 'Archives';
?>