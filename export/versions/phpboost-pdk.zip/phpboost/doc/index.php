<?php

header('Location:3.0/index.php');

?>
