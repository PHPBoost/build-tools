<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'db - Docs For Class Backup');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('db', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">db</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                
                                                                                                                                                                                                                                <a href="../classtrees_db.php" class="menu">class tree: db</a> - 
                <a href="../elementindex_db.php" class="menu">index: db</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../db/Backup.php">Backup</a>            </li>
                    <li>
                <a href="../db/Sql.php">Sql</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../db/_db---backup.class.php.php">                backup.class.php
                </a>            </li>
                    <li>
                <a href="../db/_db---mysql.class.php.php">                mysql.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Backup</h1><p>Source Location: /db/backup.class.php [line 33]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class helps you to generate the backup file of your data base.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel ben.popeye@gmail.com / R�gis Viarre crowkait@phpboost.com</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../db/Backup.php#methodBackup">Backup</a></li><li class="bb_li"><a href="../db/Backup.php#methodconcatenate_to_query">concatenate_to_query</a></li><li class="bb_li"><a href="../db/Backup.php#methodexport_file">export_file</a></li><li class="bb_li"><a href="../db/Backup.php#methodextract_table_structure">extract_table_structure</a></li><li class="bb_li"><a href="../db/Backup.php#methodgenerate_create_table_query">generate_create_table_query</a></li><li class="bb_li"><a href="../db/Backup.php#methodgenerate_drop_table_query">generate_drop_table_query</a></li><li class="bb_li"><a href="../db/Backup.php#methodgenerate_insert_values_query">generate_insert_values_query</a></li><li class="bb_li"><a href="../db/Backup.php#methodget_script">get_script</a></li><li class="bb_li"><a href="../db/Backup.php#methodget_tables_list">get_tables_list</a></li><li class="bb_li"><a href="../db/Backup.php#methodget_tables_number">get_tables_number</a></li><li class="bb_li"><a href="../db/Backup.php#methodget_tables_properties_list">get_tables_properties_list</a></li><li class="bb_li"><a href="../db/Backup.php#methodlist_db_tables">list_db_tables</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../db/Backup.php#var$backup_script">$backup_script</a></li><li class="bb_li"><a href="../db/Backup.php#var$tables">$tables</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class helps you to generate the backup file of your data base.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel ben.popeye@gmail.com / R�gis Viarre crowkait@phpboost.com</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodBackup"></a>
    <h3>constructor Backup <span class="smalllinenumber">[line 38]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Backup Backup(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a Backup object</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodconcatenate_to_query"></a>
    <h3>method concatenate_to_query <span class="smalllinenumber">[line 155]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void concatenate_to_query(
string
$string)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Concatenates a string at the end of the current script.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$string</strong>&nbsp;&nbsp;</td>
        <td>String to concatenate.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodexport_file"></a>
    <h3>method export_file <span class="smalllinenumber">[line 217]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void export_file(
string
$file_path)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Writes the backup script in a text file.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file_path</strong>&nbsp;&nbsp;</td>
        <td>Path of the file.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodextract_table_structure"></a>
    <h3>method extract_table_structure <span class="smalllinenumber">[line 231]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>unknown_type extract_table_structure(
[$tables
$tables = array()])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$tables&nbsp;&nbsp;</td>
        <td><strong>$tables</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_create_table_query"></a>
    <h3>method generate_create_table_query <span class="smalllinenumber">[line 83]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_create_table_query(
[string[]
$table_list = array()])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Concatenates the tables creation to the SQL backup script.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$table_list</strong>&nbsp;&nbsp;</td>
        <td>names of the tables which must be created by the backup script. If you want to generate the query which will create all the tables, don't use this parameter of let an empty array.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_drop_table_query"></a>
    <h3>method generate_drop_table_query <span class="smalllinenumber">[line 65]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_drop_table_query(
[string[]
$table_list = array()])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Concatenates the query which drops the PHPBoost tables only if they exist to the backup SQL script.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$table_list</strong>&nbsp;&nbsp;</td>
        <td>names of the tables which must be dropped by the query. If you want to generate the query which will drop all the tables, don't use this parameter of let an empty array.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_insert_values_query"></a>
    <h3>method generate_insert_values_query <span class="smalllinenumber">[line 107]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_insert_values_query(
[$tables
$tables = array()])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Concatenates the tables content insertion queries to the SQL backup script.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$tables&nbsp;&nbsp;</td>
        <td><strong>$tables</strong>&nbsp;&nbsp;</td>
        <td>names of the tables which must be filled by the backup script. If you want to generate the query which will fill all the tables, don't use this parameter of let an empty array.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_script"></a>
    <h3>method get_script <span class="smalllinenumber">[line 164]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_script(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the current backup script.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the whole script</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_tables_list"></a>
    <h3>method get_tables_list <span class="smalllinenumber">[line 197]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] get_tables_list(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Retrieves the list of the tables used by PHPBoost.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the table names.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_tables_number"></a>
    <h3>method get_tables_number <span class="smalllinenumber">[line 207]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_tables_number(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the number of tables used by PHPBoost.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> number of tables</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_tables_properties_list"></a>
    <h3>method get_tables_properties_list <span class="smalllinenumber">[line 187]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] get_tables_properties_list(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Lists the tables (name and informations relative to each table) of the data base at which is connected this SQL object. This method calls the SHOW TABLE STATUS MySQL query, to know more about it, see http://dev.mysql.com/doc/refman/5.1/en/show-table-status.html</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Map containing the following structure: for each table: table_name =&gt; array(     'name' =&gt; name of the table,     'engine' =&gt; storage engine of the table,     'row_format' =&gt; row storage format,     'rows' =&gt; number of rows,     'data_length' =&gt; the length of the data file,     'index_length' =&gt; the length of the index file,     'data_free' =&gt; the number of allocated but unused bytes,     'collation' =&gt; the table's character set and collation,     'auto_increment' =&gt; the next AUTO_INCREMENT value,     'create_time' =&gt; when the table was created,     'update_time' =&gt; when the data file was last updated )</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodlist_db_tables"></a>
    <h3>method list_db_tables <span class="smalllinenumber">[line 49]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void list_db_tables(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Retrieves the list of the tables present on the database used.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                    <div class="var">
                            <a name="var_backup_script"></a>
                <span class="line-number">[line 276]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$backup_script</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_tables"></a>
                <span class="line-number">[line 272]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$tables</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                    
                                                                                                                                                                <a href="../classtrees_db.php" class="menu">class tree: db</a> -
            <a href="../elementindex_db.php" class="menu">index: db</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:41 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>