<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'db - Docs For Class Sql');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('db', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">db</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                
                                                                                                                                                                                                                                <a href="../classtrees_db.php" class="menu">class tree: db</a> - 
                <a href="../elementindex_db.php" class="menu">index: db</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../db/Backup.php">Backup</a>            </li>
                    <li>
                <a href="../db/Sql.php">Sql</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../db/_db---backup.class.php.php">                backup.class.php
                </a>            </li>
                    <li>
                <a href="../db/_db---mysql.class.php.php">                mysql.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Sql</h1><p>Source Location: /db/mysql.class.php [line 55]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class manages all the database access done by PHPBoost. It currently manages only one DBMS, MySQL, but we made it as generic as we could. It doesn't support ORM (Object Relationnal Mapping). On PHPBoost, all the table which are used contain a prefix which enables for example to install several instances of the software on the same data base. When you execute a query in a table, concatenate the PREFIX constant before the name of your table. Notice also that the kernel tables can have their name changed. You must not use their name directly but the constants which are defined in the file /kernel/db/tables.php.
 If you encounter any problem when writing queries, you should search what you need in the MySQL documentation, which is very well done: http://dev.mysql.com/doc/</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�gis Viarre crowkait@phpboost.com, Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../db/Sql.php#methodSql">Sql</a></li><li class="bb_li"><a href="../db/Sql.php#methodaffected_rows">affected_rows</a></li><li class="bb_li"><a href="../db/Sql.php#methodauto_connect">auto_connect</a></li><li class="bb_li"><a href="../db/Sql.php#methodclean_database_name">clean_database_name</a></li><li class="bb_li"><a href="../db/Sql.php#methodclose">close</a></li><li class="bb_li"><a href="../db/Sql.php#methodconcat">concat</a></li><li class="bb_li"><a href="../db/Sql.php#methodconnect">connect</a></li><li class="bb_li"><a href="../db/Sql.php#methodcount_table">count_table</a></li><li class="bb_li"><a href="../db/Sql.php#methodcreate_database">create_database</a></li><li class="bb_li"><a href="../db/Sql.php#methoddate_diff">date_diff</a></li><li class="bb_li"><a href="../db/Sql.php#methoddrop_tables">drop_tables</a></li><li class="bb_li"><a href="../db/Sql.php#methodescape">escape</a></li><li class="bb_li"><a href="../db/Sql.php#methodfetch_assoc">fetch_assoc</a></li><li class="bb_li"><a href="../db/Sql.php#methodfetch_row">fetch_row</a></li><li class="bb_li"><a href="../db/Sql.php#methodget_data_base_name">get_data_base_name</a></li><li class="bb_li"><a href="../db/Sql.php#methodget_dbms_version">get_dbms_version</a></li><li class="bb_li"><a href="../db/Sql.php#methodget_executed_requests_number">get_executed_requests_number</a></li><li class="bb_li"><a href="../db/Sql.php#methodhighlight_query">highlight_query</a></li><li class="bb_li"><a href="../db/Sql.php#methodindent_query">indent_query</a></li><li class="bb_li"><a href="../db/Sql.php#methodinsert_id">insert_id</a></li><li class="bb_li"><a href="../db/Sql.php#methodlimit">limit</a></li><li class="bb_li"><a href="../db/Sql.php#methodlist_databases">list_databases</a></li><li class="bb_li"><a href="../db/Sql.php#methodlist_fields">list_fields</a></li><li class="bb_li"><a href="../db/Sql.php#methodlist_tables">list_tables</a></li><li class="bb_li"><a href="../db/Sql.php#methodnum_rows">num_rows</a></li><li class="bb_li"><a href="../db/Sql.php#methodoptimize_tables">optimize_tables</a></li><li class="bb_li"><a href="../db/Sql.php#methodparse">parse</a></li><li class="bb_li"><a href="../db/Sql.php#methodquery">query</a></li><li class="bb_li"><a href="../db/Sql.php#methodquery_array">query_array</a></li><li class="bb_li"><a href="../db/Sql.php#methodquery_close">query_close</a></li><li class="bb_li"><a href="../db/Sql.php#methodquery_inject">query_inject</a></li><li class="bb_li"><a href="../db/Sql.php#methodquery_while">query_while</a></li><li class="bb_li"><a href="../db/Sql.php#methodrepair_tables">repair_tables</a></li><li class="bb_li"><a href="../db/Sql.php#methodtruncate_tables">truncate_tables</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../db/Sql.php#var$base_name">$base_name</a></li><li class="bb_li"><a href="../db/Sql.php#var$connected">$connected</a></li><li class="bb_li"><a href="../db/Sql.php#var$link">$link</a></li><li class="bb_li"><a href="../db/Sql.php#var$req">$req</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class manages all the database access done by PHPBoost. It currently manages only one DBMS, MySQL, but we made it as generic as we could. It doesn't support ORM (Object Relationnal Mapping). On PHPBoost, all the table which are used contain a prefix which enables for example to install several instances of the software on the same data base. When you execute a query in a table, concatenate the PREFIX constant before the name of your table. Notice also that the kernel tables can have their name changed. You must not use their name directly but the constants which are defined in the file /kernel/db/tables.php.
 If you encounter any problem when writing queries, you should search what you need in the MySQL documentation, which is very well done: http://dev.mysql.com/doc/</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis Viarre crowkait@phpboost.com, Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodSql"></a>
    <h3>constructor Sql <span class="smalllinenumber">[line 60]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Sql Sql(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a MySQL connection.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodaffected_rows"></a>
    <h3>method affected_rows <span class="smalllinenumber">[line 340]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int affected_rows(
resource
$resource, [string
$query = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the number of the rows which have been affected by a request.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The number of the rows affected by the specified resource.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">resource&nbsp;&nbsp;</td>
        <td><strong>$resource</strong>&nbsp;&nbsp;</td>
        <td>Resource corresponding to the request. The resource is given by the method which execute some queries in the data base.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td>Deprecated field. Don't use it.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodauto_connect"></a>
    <h3>method auto_connect <span class="smalllinenumber">[line 129]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void auto_connect(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Connects automatically the application to the DBMS by reading the database configuration file whose path is /kernel/db/config.php. If an error occures while connecting to the server, the script execution will be stopped and the error will be written in the page.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodclose"></a>
    <h3>method close <span class="smalllinenumber">[line 392]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool close(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Closes the current MySQL connection if it is open.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the connection could be closed, false otherwise.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodconcat"></a>
    <h3>method concat <span class="smalllinenumber">[line 297]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string concat(
string
$param)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Generates the syntax to use the concatenation operator (CONCAT in MySQL). The MySQL fields names must be in a PHP string for instance between simple quotes: 'field_name' The PHP variables must be bordered by simple quotes, for example: '\'' . $my_var . '\''</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The MySQL syntax to use.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$param</strong>&nbsp;&nbsp;</td>
        <td>Element to concatenate. Repeat this argument for each element you want to contatenate, in the same order.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodconnect"></a>
    <h3>method connect <span class="smalllinenumber">[line 84]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int connect(
string
$sql_host, string
$sql_login, string
$sql_pass, $base_name
$base_name, [$errors_management
$errors_management = EXPLICIT_ERRORS_MANAGEMENT])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">This method enables you to connect to the DBMS when you have the data base access informations.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> If you chose to manage the errors by a return value (ERRORS_MANAGEMENT_BY_RETURN), it will return the state of the connection: <ul><li>CONNECTED_TO_DATABASE if the connection succed</li><li>UNEXISTING_DATABASE if the host could be joined but the data base on which PHPBoost must work doesn't exists</li><li>CONNECTION_FAILED if the host is unreachable or the login and the password weren't correct</li></ul> Otherwise, it won't return anything.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$sql_host</strong>&nbsp;&nbsp;</td>
        <td>Name or IP address of the server on which is the DBMS you want to use.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$sql_login</strong>&nbsp;&nbsp;</td>
        <td>Login enabling PHPBoost to connect itselft to the DBMS (the MySQL login).</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$sql_pass</strong>&nbsp;&nbsp;</td>
        <td>Password enabling PHPBoost to connect itself to the DMBS.</td>
      </tr>
          <tr>
        <td class="type">$base_name&nbsp;&nbsp;</td>
        <td><strong>$base_name</strong>&nbsp;&nbsp;</td>
        <td>string Name of the data base PHPBoost must join an work on.</td>
      </tr>
          <tr>
        <td class="type">$errors_management&nbsp;&nbsp;</td>
        <td><strong>$errors_management</strong>&nbsp;&nbsp;</td>
        <td>bool The way according to which you want to manage the data base connection errors : <ul><li>ERRORS_MANAGEMENT_BY_RETURN will return the error</li><li>EXPLICIT_ERRORS_MANAGEMENT will stop the script execution and display the error message</li></ul></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcount_table"></a>
    <h3>method count_table <span class="smalllinenumber">[line 268]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int count_table(
string
$table, int
$errline, int
$errfile)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Counts the number of the row contained in a table.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The rows number of the table.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$table</strong>&nbsp;&nbsp;</td>
        <td>Table name</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errline</strong>&nbsp;&nbsp;</td>
        <td>The number of the line at which you call this method. Use the __LINE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errfile</strong>&nbsp;&nbsp;</td>
        <td>The file in which you call this method. Use the __FILE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcreate_database"></a>
    <h3>method create_database <span class="smalllinenumber">[line 616]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string create_database(
string
$db_name)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Creates a data base on the DBMS at which is connected the current object.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The name of the database created</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$db_name</strong>&nbsp;&nbsp;</td>
        <td>Name of the data base to create</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddate_diff"></a>
    <h3>method date_diff <span class="smalllinenumber">[line 372]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string date_diff(
string
$field)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Generates the MySQL syntax which enables you to compute the number of years separating a date in a data base field and today.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the syntax which will compute the number of years.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$field</strong>&nbsp;&nbsp;</td>
        <td>Name of the field against which you want to compute the number of years.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddrop_tables"></a>
    <h3>method drop_tables <span class="smalllinenumber">[line 682]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void drop_tables(
string[]
$table_array)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Drops some tables in the data base.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$table_array</strong>&nbsp;&nbsp;</td>
        <td>List of the tables to drop.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodescape"></a>
    <h3>method escape <span class="smalllinenumber">[line 628]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string escape(
string
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Escapes the dangerous characters in the string you inject in your requests.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The protected string</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>String to escape</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodfetch_assoc"></a>
    <h3>method fetch_assoc <span class="smalllinenumber">[line 316]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] fetch_assoc(
resource
$result)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Browses a MySQL result resource row per row. When you call this method on a resource, you get the next row.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> An associative array whose keys are the name of each column and values are the value of the field. It returns false when you are at the end of the rows.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">resource&nbsp;&nbsp;</td>
        <td><strong>$result</strong>&nbsp;&nbsp;</td>
        <td>MySQL result resource to browse. The resource is provided by the query_while method.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodfetch_row"></a>
    <h3>method fetch_row <span class="smalllinenumber">[line 328]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] fetch_row(
resource
$result)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Browses a MySQL result resource row per row. When you call this method on a resource, you get the next row.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> An array whose values are the value of the field. The fields are indexed according to the order they had in the select query. It returns false when you are at the end of the rows.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">resource&nbsp;&nbsp;</td>
        <td><strong>$result</strong>&nbsp;&nbsp;</td>
        <td>MySQL result resource to browse. The resource is provided by the query_while method.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_data_base_name"></a>
    <h3>method get_data_base_name <span class="smalllinenumber">[line 589]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_data_base_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the name of the data base which with the object is connected.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the base name</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_dbms_version"></a>
    <h3>method get_dbms_version <span class="smalllinenumber">[line 580]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_dbms_version(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the version of MySQL used.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The version used.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_executed_requests_number"></a>
    <h3>method get_executed_requests_number <span class="smalllinenumber">[line 512]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_executed_requests_number(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the number of request executed by this object.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Number of request executed.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodinsert_id"></a>
    <h3>method insert_id <span class="smalllinenumber">[line 362]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int insert_id(
[$query
$query = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the ID generated from the previous INSERT operation.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The ID generated for an AUTO_INCREMENT column by the previous INSERT query on success, 0 if the previous query does not generate an AUTO_INCREMENT value.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$query&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodlimit"></a>
    <h3>method limit <span class="smalllinenumber">[line 284]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string limit(
int
$start, [int
$num_lines = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds the MySQL syntax used to impose a limit in your row selection.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The MySQL syntax for the limit instruction.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$start</strong>&nbsp;&nbsp;</td>
        <td>Number of the first row (0 is the first).</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$num_lines</strong>&nbsp;&nbsp;</td>
        <td>Number of the rows you want to retrieve.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodlist_databases"></a>
    <h3>method list_databases <span class="smalllinenumber">[line 599]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] list_databases(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Lists the existing data bases on the DBMS at which the object is connected. Only the data bases visible for the user connected will be returned.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the data bases</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodlist_fields"></a>
    <h3>method list_fields <span class="smalllinenumber">[line 410]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] list_fields(
string
$table)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Lists all the columns of a table.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> list of the fields of the table.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$table</strong>&nbsp;&nbsp;</td>
        <td>Name of the table.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodlist_tables"></a>
    <h3>method list_tables <span class="smalllinenumber">[line 445]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] list_tables(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Lists the tables (name and informations relative to each table) of the data base at which is connected this SQL object. This method calls the SHOW TABLE STATUS MySQL query, to know more about it, see http://dev.mysql.com/doc/refman/5.1/en/show-table-status.html</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Map containing the following structure: for each table: table_name =&gt; array(     'name' =&gt; name of the table,     'engine' =&gt; storage engine of the table,     'row_format' =&gt; row storage format,     'rows' =&gt; number of rows,     'data_length' =&gt; the length of the data file,     'index_length' =&gt; the length of the index file,     'data_free' =&gt; the number of allocated but unused bytes,     'collation' =&gt; the table's character set and collation,     'auto_increment' =&gt; the next AUTO_INCREMENT value,     'create_time' =&gt; when the table was created,     'update_time' =&gt; when the data file was last updated )</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodnum_rows"></a>
    <h3>method num_rows <span class="smalllinenumber">[line 351]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int num_rows(
resource
$resource, $query
$query)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the number of rows got by a selection query.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The number of rows contained in the resource.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">resource&nbsp;&nbsp;</td>
        <td><strong>$resource</strong>&nbsp;&nbsp;</td>
        <td>Resource corresponding to the result of the query.</td>
      </tr>
          <tr>
        <td class="type">$query&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td>Deprecated field. Don't use it.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodoptimize_tables"></a>
    <h3>method optimize_tables <span class="smalllinenumber">[line 648]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void optimize_tables(
string[]
$table_array)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Optimizes some tables in the data base.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$table_array</strong>&nbsp;&nbsp;</td>
        <td>List of the tables to optimize.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodparse"></a>
    <h3>method parse <span class="smalllinenumber">[line 474]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void parse(
string
$file_path, [string
$tableprefix = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Parses a SQL file. The SQL file contains the name of the tables with the prefix phpboost_.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file_path</strong>&nbsp;&nbsp;</td>
        <td>Path of the file.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$tableprefix</strong>&nbsp;&nbsp;</td>
        <td>prefix The prefix you want to work with.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodquery"></a>
    <h3>method query <span class="smalllinenumber">[line 156]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string query(
string
$query, int
$errline, int
$errfile)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sends a simple selection query to the DBMS and retrieves the result. A simple query selects only one field in one row.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The result of your query (the value at the row and column you chose).</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td>Selection query</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errline</strong>&nbsp;&nbsp;</td>
        <td>The number of the line at which you call this method. Use the __LINE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errfile</strong>&nbsp;&nbsp;</td>
        <td>The file in which you call this method. Use the __FILE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodquery_array"></a>
    <h3>method query_array <span class="smalllinenumber">[line 186]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void query_array(
string
$table, string
$field, string
$clause, int
$errline, int
$errfile)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">This method makes automatically a query on several fields of a row. You tell it in which table you want to select, which row you want to use, and it will return you the values. It takes a variable number of parameters.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$table</strong>&nbsp;&nbsp;</td>
        <td>Name of the table in which you want to select the values</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$field</strong>&nbsp;&nbsp;</td>
        <td>Name of the field for which you want to retrieve the value. If you want to work on several fields, you have to repeat this parameter for each field you want to select.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$clause</strong>&nbsp;&nbsp;</td>
        <td>Where clause which will enable the method to know in which row it must select the values. It must respect the MySQL syntax and start off with 'WHERE '.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errline</strong>&nbsp;&nbsp;</td>
        <td>The number of the line at which you call this method. Use the __LINE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errfile</strong>&nbsp;&nbsp;</td>
        <td>The file in which you call this method. Use the __FILE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodquery_close"></a>
    <h3>method query_close <span class="smalllinenumber">[line 382]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool query_close(
resource
$resource)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Frees the memory allocated for a resource.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the memory could be disallocated and false otherwise.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">resource&nbsp;&nbsp;</td>
        <td><strong>$resource</strong>&nbsp;&nbsp;</td>
        <td>Resource you want to desallocate.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodquery_inject"></a>
    <h3>method query_inject <span class="smalllinenumber">[line 234]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>resource query_inject(
string
$query, int
$errline, int
$errfile)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">This method enables you to execute CUD (Create Update Delete) queries in the database, and more generally, any query which has not any return value.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The MySQL resource corresponding to the result of the query.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td>The query you want to execute</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errline</strong>&nbsp;&nbsp;</td>
        <td>The number of the line at which you call this method. Use the __LINE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errfile</strong>&nbsp;&nbsp;</td>
        <td>The file in which you call this method. Use the __FILE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodquery_while"></a>
    <h3>method query_while <span class="smalllinenumber">[line 251]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>resource query_while(
$query
$query, int
$errline, int
$errfile)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">This method enables you to execute a Retrieve query on several rows in the data base.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> MySQL resource containing the results. You will browse it with the sql_fetch_assoc method.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errline</strong>&nbsp;&nbsp;</td>
        <td>The number of the line at which you call this method. Use the __LINE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errfile</strong>&nbsp;&nbsp;</td>
        <td>The file in which you call this method. Use the __FILE__ constant. It is very interesting when you debug your script and you want to know where is called the query which returns an error.</td>
      </tr>
          <tr>
        <td class="type">$query&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td>The query you want to execute</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodrepair_tables"></a>
    <h3>method repair_tables <span class="smalllinenumber">[line 660]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void repair_tables(
string[]
$table_array)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Repairs some tables in the data base.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$table_array</strong>&nbsp;&nbsp;</td>
        <td>List of the tables to repair.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodtruncate_tables"></a>
    <h3>method truncate_tables <span class="smalllinenumber">[line 672]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void truncate_tables(
string[]
$table_array)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Trucates some tables in the data base.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$table_array</strong>&nbsp;&nbsp;</td>
        <td>List of the tables to truncate.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodclean_database_name"></a>
	<h3>static method clean_database_name <span class="smalllinenumber">[line 714]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static The clean_database_name(
string
$db_name)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Cleans the data base name to be sure it's a correct name</div><div class="description"><p>Cleans the data base name to be sure it's a correct name</p></div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> clean name</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$db_name</strong>&nbsp;&nbsp;</td>
        <td>Name to clear</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodhighlight_query"></a>
	<h3>static method highlight_query <span class="smalllinenumber">[line 523]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string highlight_query(
string
$query)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Highlights a SQL query to be more readable by a human.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> HTML code corresponding to the highlighted query.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td>Query to highlight</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodindent_query"></a>
	<h3>static method indent_query <span class="smalllinenumber">[line 556]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string indent_query(
string
$query)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Indents a MySQL query.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The indented SQL query.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$query</strong>&nbsp;&nbsp;</td>
        <td>Query to indent.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                            <div class="var">
                            <a name="var_base_name"></a>
                <span class="line-number">[line 736]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$base_name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_connected"></a>
                <span class="line-number">[line 732]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">bool</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$connected</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;false</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_link"></a>
                <span class="line-number">[line 724]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">resource</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$link</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_req"></a>
                <span class="line-number">[line 728]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$req</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                    
                                                                                                                                                                <a href="../classtrees_db.php" class="menu">class tree: db</a> -
            <a href="../elementindex_db.php" class="menu">index: db</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:27 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>