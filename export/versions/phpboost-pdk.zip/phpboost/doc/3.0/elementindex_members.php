<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'members - Package members Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('members', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">members</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                    
                                                                                                                                            <a href="classtrees_members.php" class="menu">class tree: members</a> - 
                <a href="elementindex_members.php" class="menu">index: members</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="members/Authorizations.php">Authorizations</a>            </li>
                    <li>
                <a href="members/Group.php">Group</a>            </li>
                    <li>
                <a href="members/PrivateMsg.php">PrivateMsg</a>            </li>
                    <li>
                <a href="members/Session.php">Session</a>            </li>
                    <li>
                <a href="members/Uploads.php">Uploads</a>            </li>
                    <li>
                <a href="members/User.php">User</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="members/_members---authorizations.class.php.php">                authorizations.class.php
                </a>            </li>
                    <li>
                <a href="members/_members---groups.class.php.php">                groups.class.php
                </a>            </li>
                    <li>
                <a href="members/_members---pm.class.php.php">                pm.class.php
                </a>            </li>
                    <li>
                <a href="members/_members---session.class.php.php">                session.class.php
                </a>            </li>
                    <li>
                <a href="members/_members---uploads.class.php.php">                uploads.class.php
                </a>            </li>
                    <li>
                <a href="members/_members---user.class.php.php">                user.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package members</h1>
	[ <a href="elementindex_members.php#a">a</a> ]
	[ <a href="elementindex_members.php#b">b</a> ]
	[ <a href="elementindex_members.php#c">c</a> ]
	[ <a href="elementindex_members.php#d">d</a> ]
	[ <a href="elementindex_members.php#e">e</a> ]
	[ <a href="elementindex_members.php#f">f</a> ]
	[ <a href="elementindex_members.php#g">g</a> ]
	[ <a href="elementindex_members.php#l">l</a> ]
	[ <a href="elementindex_members.php#m">m</a> ]
	[ <a href="elementindex_members.php#n">n</a> ]
	[ <a href="elementindex_members.php#p">p</a> ]
	[ <a href="elementindex_members.php#r">r</a> ]
	[ <a href="elementindex_members.php#s">s</a> ]
	[ <a href="elementindex_members.php#u">u</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>$autoconnect</strong></dt>
				<dd>in file session.class.php, variable <a href="members/Session.php#var$autoconnect">Session::$autoconnect</a></dd>
							<dt><strong>act</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodact">Session::act()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Manage the actions for the session caused by the user (connection, disconnection).</dd>
							<dt><strong>Add_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodAdd_folder">Uploads::Add_folder()</a></dd>
							<dt><strong>add_member</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodadd_member">Group::add_member()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a member in a group</dd>
							<dt><strong>ADMIN_NOAUTH_DEFAULT</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineADMIN_NOAUTH_DEFAULT">ADMIN_NOAUTH_DEFAULT</a></dd>
							<dt><strong>ADMIN_NO_CHECK</strong></dt>
				<dd>in file uploads.class.php, constant <a href="members/_members---uploads.class.php.php#defineADMIN_NO_CHECK">ADMIN_NO_CHECK</a></dd>
							<dt><strong>ALREADY_HASHED</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineALREADY_HASHED">ALREADY_HASHED</a></dd>
							<dt><strong>Authorizations</strong></dt>
				<dd>in file authorizations.class.php, class <a href="members/Authorizations.php">Authorizations</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class contains only static methods, it souldn't be instantiated.</dd>
							<dt><strong>auth_array_simple</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodauth_array_simple">Authorizations::auth_array_simple()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns an array with the authorizations given by variable number of arrays passed in argument.</dd>
							<dt><strong>AUTH_CHILD_PRIORITY</strong></dt>
				<dd>in file authorizations.class.php, constant <a href="members/_members---authorizations.class.php.php#defineAUTH_CHILD_PRIORITY">AUTH_CHILD_PRIORITY</a></dd>
							<dt><strong>AUTH_PARENT_PRIORITY</strong></dt>
				<dd>in file authorizations.class.php, constant <a href="members/_members---authorizations.class.php.php#defineAUTH_PARENT_PRIORITY">AUTH_PARENT_PRIORITY</a></dd>
							<dt><strong>AUTOCONNECT</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineAUTOCONNECT">AUTOCONNECT</a></dd>
							<dt><strong>authorizations.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---authorizations.class.php.php">authorizations.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>$base_directory</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$base_directory">Uploads::$base_directory</a></dd>
							<dt><strong>build_auth_array_from_form</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodbuild_auth_array_from_form">Authorizations::build_auth_array_from_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns an array with the authorizations given by variable number of arrays passed in argument. This returned array is used to be serialized.</dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>capture_and_shift_bit_auth</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodcapture_and_shift_bit_auth">Authorizations::capture_and_shift_bit_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Capture authorizations and shift a particular bit to an another bit (1 is used by default).</dd>
							<dt><strong>check</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodcheck">Session::check()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check session validity, and update it</dd>
							<dt><strong>check_auth</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodcheck_auth">User::check_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the authorizations given by all the user groups. Then check the authorization.</dd>
							<dt><strong>check_auth</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodcheck_auth">Authorizations::check_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check authorizations for a member, a group or a rank</dd>
							<dt><strong>check_level</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodcheck_level">User::check_level()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the authorization level</dd>
							<dt><strong>check_max_value</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodcheck_max_value">User::check_max_value()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the maximum value of authorization in all user groups.</dd>
							<dt><strong>CHECK_PM_BOX</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineCHECK_PM_BOX">CHECK_PM_BOX</a></dd>
							<dt><strong>count_conversations</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methodcount_conversations">PrivateMsg::count_conversations()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Counts the user's number of conversation.</dd>
							<dt><strong>csrf_get_protect</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodcsrf_get_protect">Session::csrf_get_protect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the session against CSRF attacks by GET. Checks that GETs are done from this site with a correct token.</dd>
							<dt><strong>csrf_post_protect</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodcsrf_post_protect">Session::csrf_post_protect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the session against CSRF attacks by POST. Checks that POSTs are done from this site. 2 different cases are accepted but the first is safer: <ul><li>The request contains a parameter whose name is token and value is the value of the token of the current session.</li><li>If the token isn't in the request, we analyse the HTTP referer to be sure that the request comes from the current site and not from another which can be suspect</li></ul> If the request doesn't match any of these two cases, this method will consider that it's a CSRF attack.</dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>$data</strong></dt>
				<dd>in file session.class.php, variable <a href="members/Session.php#var$data">Session::$data</a></dd>
							<dt><strong>delete</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methoddelete">PrivateMsg::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a private message, until the recipient has not read it.</dd>
							<dt><strong>delete_conversation</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methoddelete_conversation">PrivateMsg::delete_conversation()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a conversation.</dd>
							<dt><strong>Del_file</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodDel_file">Uploads::Del_file()</a></dd>
							<dt><strong>Del_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodDel_folder">Uploads::Del_folder()</a></dd>
							<dt><strong>DEL_PM_CONVERS</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineDEL_PM_CONVERS">DEL_PM_CONVERS</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>$error</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$error">Uploads::$error</a></dd>
							<dt><strong>$extension</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$extension">Uploads::$extension</a></dd>
							<dt><strong>edit_member</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodedit_member">Group::edit_member()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Edits the user groups, compute difference between previous and new groups.</dd>
							<dt><strong>EMPTY_FOLDER</strong></dt>
				<dd>in file uploads.class.php, constant <a href="members/_members---uploads.class.php.php#defineEMPTY_FOLDER">EMPTY_FOLDER</a></dd>
							<dt><strong>Empty_folder_member</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodEmpty_folder_member">Uploads::Empty_folder_member()</a></dd>
							<dt><strong>end</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodend">Session::end()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Destroy the session</dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$filename</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$filename">Uploads::$filename</a></dd>
							<dt><strong>Find_subfolder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodFind_subfolder">Uploads::Find_subfolder()</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>$groups_auth</strong></dt>
				<dd>in file groups.class.php, variable <a href="members/Group.php#var$groups_auth">Group::$groups_auth</a></dd>
							<dt><strong>$groups_auth</strong></dt>
				<dd>in file user.class.php, variable <a href="members/User.php#var$groups_auth">User::$groups_auth</a></dd>
							<dt><strong>$groups_name</strong></dt>
				<dd>in file groups.class.php, variable <a href="members/Group.php#var$groups_name">Group::$groups_name</a></dd>
							<dt><strong>garbage_collector</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodgarbage_collector">Session::garbage_collector()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes all the existing sessions</dd>
							<dt><strong>generate_select</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodgenerate_select">Authorizations::generate_select()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generate a multiple select field for the form which create authorization for ranks, groups and members.</dd>
							<dt><strong>get_admin_url</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodget_admin_url">Uploads::get_admin_url()</a></dd>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_attribute">User::get_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor</dd>
							<dt><strong>get_groups</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_groups">User::get_groups()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get all user groups</dd>
							<dt><strong>get_groups_array</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodget_groups_array">Group::get_groups_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the array of user groups (id =&gt; name)</dd>
							<dt><strong>get_group_color</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_group_color">User::get_group_color()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the user group associated color.</dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_id">User::get_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the user id</dd>
							<dt><strong>get_img_mimetype</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodget_img_mimetype">Uploads::get_img_mimetype()</a></dd>
							<dt><strong>get_module_parameters</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodget_module_parameters">Session::get_module_parameters()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get module's parametres from session</dd>
							<dt><strong>get_token</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodget_token">Session::get_token()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the session token</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodget_url">Uploads::get_url()</a></dd>
							<dt><strong>Group</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodGroup">Group::Group()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Constructor. Loads informations groups.</dd>
							<dt><strong>Group</strong></dt>
				<dd>in file groups.class.php, class <a href="members/Group.php">Group</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides methods to manage user in groups.</dd>
							<dt><strong>GROUP_DEFAULT_IDSELECT</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineGROUP_DEFAULT_IDSELECT">GROUP_DEFAULT_IDSELECT</a></dd>
							<dt><strong>GROUP_DISABLED_ADVANCED_AUTH</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineGROUP_DISABLED_ADVANCED_AUTH">GROUP_DISABLED_ADVANCED_AUTH</a></dd>
							<dt><strong>GROUP_DISABLE_SELECT</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineGROUP_DISABLE_SELECT">GROUP_DISABLE_SELECT</a></dd>
							<dt><strong>GROUP_TYPE</strong></dt>
				<dd>in file user.class.php, constant <a href="members/_members---user.class.php.php#defineGROUP_TYPE">GROUP_TYPE</a></dd>
							<dt><strong>groups.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---groups.class.php.php">groups.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>load</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodload">Session::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get informations from the user, and set it for his session.</dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>Member_memory_used</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodMember_memory_used">Uploads::Member_memory_used()</a></dd>
							<dt><strong>merge_auth</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodmerge_auth">Authorizations::merge_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Merge two authorizations array, first is the parent, second is the inherited child.</dd>
							<dt><strong>Move_file</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodMove_file">Uploads::Move_file()</a></dd>
							<dt><strong>Move_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodMove_folder">Uploads::Move_folder()</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>NOCHECK_PM_BOX</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineNOCHECK_PM_BOX">NOCHECK_PM_BOX</a></dd>
							<dt><strong>NO_AUTOCONNECT</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineNO_AUTOCONNECT">NO_AUTOCONNECT</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>$pm_convers_id</strong></dt>
				<dd>in file pm.class.php, variable <a href="members/PrivateMsg.php#var$pm_convers_id">PrivateMsg::$pm_convers_id</a></dd>
							<dt><strong>$pm_msg_id</strong></dt>
				<dd>in file pm.class.php, variable <a href="members/PrivateMsg.php#var$pm_msg_id">PrivateMsg::$pm_msg_id</a></dd>
							<dt><strong>pm.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---pm.class.php.php">pm.class.php</a></dd>
							<dt><strong>PrivateMsg</strong></dt>
				<dd>in file pm.class.php, class <a href="members/PrivateMsg.php">PrivateMsg</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides methods to manage private message.</dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>RANK_TYPE</strong></dt>
				<dd>in file user.class.php, constant <a href="members/_members---user.class.php.php#defineRANK_TYPE">RANK_TYPE</a></dd>
							<dt><strong>remove_member</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodremove_member">Group::remove_member()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Removes a member in a group.</dd>
							<dt><strong>Rename_file</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodRename_file">Uploads::Rename_file()</a></dd>
							<dt><strong>Rename_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodRename_folder">Uploads::Rename_folder()</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>$session_mod</strong></dt>
				<dd>in file session.class.php, variable <a href="members/Session.php#var$session_mod">Session::$session_mod</a></dd>
							<dt><strong>session.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---session.class.php.php">session.class.php</a></dd>
							<dt><strong>SEASURF_ATTACK_ERROR_PAGE</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineSEASURF_ATTACK_ERROR_PAGE">SEASURF_ATTACK_ERROR_PAGE</a></dd>
							<dt><strong>send</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methodsend">PrivateMsg::send()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Answers to a conversation</dd>
							<dt><strong>Session</strong></dt>
				<dd>in file session.class.php, class <a href="members/Session.php">Session</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages all sessions for the users.</dd>
							<dt><strong>set_module_parameters</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodset_module_parameters">Session::set_module_parameters()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Save module's parameters into session</dd>
							<dt><strong>set_user_lang</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodset_user_lang">User::set_user_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the user lang.</dd>
							<dt><strong>set_user_theme</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodset_user_theme">User::set_user_theme()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the user theme.</dd>
							<dt><strong>start</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodstart">Session::start()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Start the session</dd>
							<dt><strong>start_conversation</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methodstart_conversation">PrivateMsg::start_conversation()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Starts a conversation with another member.</dd>
							<dt><strong>SYSTEM_PM</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineSYSTEM_PM">SYSTEM_PM</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>$user_data</strong></dt>
				<dd>in file user.class.php, variable <a href="members/User.php#var$user_data">User::$user_data</a></dd>
							<dt><strong>$user_groups</strong></dt>
				<dd>in file user.class.php, variable <a href="members/User.php#var$user_groups">User::$user_groups</a></dd>
							<dt><strong>uploads.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---uploads.class.php.php">uploads.class.php</a></dd>
							<dt><strong>user.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---user.class.php.php">user.class.php</a></dd>
							<dt><strong>UPDATE_MBR_PM</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineUPDATE_MBR_PM">UPDATE_MBR_PM</a></dd>
							<dt><strong>update_user_lang</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodupdate_user_lang">User::update_user_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the lang for guest in the database (sessions table).</dd>
							<dt><strong>update_user_theme</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodupdate_user_theme">User::update_user_theme()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the theme for guest in the database (sessions table).</dd>
							<dt><strong>Uploads</strong></dt>
				<dd>in file uploads.class.php, class <a href="members/Uploads.php">Uploads</a></dd>
							<dt><strong>User</strong></dt>
				<dd>in file user.class.php, class <a href="members/User.php">User</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage user, it provide you methods to get or modify user informations, moreover methods allow you to control user authorizations</dd>
							<dt><strong>User</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodUser">User::User()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets global authorizations which are given by all the user groups authorizations.</dd>
							<dt><strong>USER_TYPE</strong></dt>
				<dd>in file user.class.php, constant <a href="members/_members---user.class.php.php#defineUSER_TYPE">USER_TYPE</a></dd>
					</dl>
	</div>
	<a href="elementindex_members.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                
                                                                                                    <a href="classtrees_members.php" class="menu">class tree: members</a> -
            <a href="elementindex_members.php" class="menu">index: members</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:35 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>