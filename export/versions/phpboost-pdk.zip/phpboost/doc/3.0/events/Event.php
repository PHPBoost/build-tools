<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Docs For Class Event');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="../classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="../elementindex_events.php" class="menu">index: events</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/AdministratorAlert.php">AdministratorAlert</a>            </li>
                    <li>
                <a href="../events/AdministratorAlertService.php">AdministratorAlertService</a>            </li>
                    <li>
                <a href="../events/Contribution.php">Contribution</a>            </li>
                    <li>
                <a href="../events/ContributionService.php">ContributionService</a>            </li>
                    <li>
                <a href="../events/Event.php">Event</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/_events---administrator_alert.class.php.php">                administrator_alert.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---administrator_alert_service.class.php.php">                administrator_alert_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution.class.php.php">                contribution.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution_service.class.php.php">                contribution_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---event.class.php.php">                event.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Event</h1><p>Source Location: /events/event.class.php [line 50]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">It's the common part between two types of event existing now in PHPBoost: <ul><li>User contribution managed into the contribution panel</li><li>Administrator alert, triggered for example when a new update is available or when a new member account is to approbate</li></ul></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



				

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../events/Event.php#methodEvent">Event</a></li><li class="bb_li"><a href="../events/Event.php#methodbuild">build</a></li><li class="bb_li"><a href="../events/Event.php#methodget_creation_date">get_creation_date</a></li><li class="bb_li"><a href="../events/Event.php#methodget_entitled">get_entitled</a></li><li class="bb_li"><a href="../events/Event.php#methodget_fixing_url">get_fixing_url</a></li><li class="bb_li"><a href="../events/Event.php#methodget_id">get_id</a></li><li class="bb_li"><a href="../events/Event.php#methodget_identifier">get_identifier</a></li><li class="bb_li"><a href="../events/Event.php#methodget_id_in_module">get_id_in_module</a></li><li class="bb_li"><a href="../events/Event.php#methodget_must_regenerate_cache">get_must_regenerate_cache</a></li><li class="bb_li"><a href="../events/Event.php#methodget_status">get_status</a></li><li class="bb_li"><a href="../events/Event.php#methodget_status_name">get_status_name</a></li><li class="bb_li"><a href="../events/Event.php#methodget_type">get_type</a></li><li class="bb_li"><a href="../events/Event.php#methodset_creation_date">set_creation_date</a></li><li class="bb_li"><a href="../events/Event.php#methodset_entitled">set_entitled</a></li><li class="bb_li"><a href="../events/Event.php#methodset_fixing_url">set_fixing_url</a></li><li class="bb_li"><a href="../events/Event.php#methodset_id">set_id</a></li><li class="bb_li"><a href="../events/Event.php#methodset_identifier">set_identifier</a></li><li class="bb_li"><a href="../events/Event.php#methodset_id_in_module">set_id_in_module</a></li><li class="bb_li"><a href="../events/Event.php#methodset_must_regenerate_cache">set_must_regenerate_cache</a></li><li class="bb_li"><a href="../events/Event.php#methodset_status">set_status</a></li><li class="bb_li"><a href="../events/Event.php#methodset_type">set_type</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../events/Event.php#var$creation_date">$creation_date</a></li><li class="bb_li"><a href="../events/Event.php#var$current_status">$current_status</a></li><li class="bb_li"><a href="../events/Event.php#var$entitled">$entitled</a></li><li class="bb_li"><a href="../events/Event.php#var$fixing_url">$fixing_url</a></li><li class="bb_li"><a href="../events/Event.php#var$id">$id</a></li><li class="bb_li"><a href="../events/Event.php#var$identifier">$identifier</a></li><li class="bb_li"><a href="../events/Event.php#var$id_in_module">$id_in_module</a></li><li class="bb_li"><a href="../events/Event.php#var$must_regenerate_cache">$must_regenerate_cache</a></li><li class="bb_li"><a href="../events/Event.php#var$type">$type</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">It's the common part between two types of event existing now in PHPBoost: <ul><li>User contribution managed into the contribution panel</li><li>Administrator alert, triggered for example when a new update is available or when a new member account is to approbate</li></ul></div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li><li><strong>abstract:</strong> </li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodEvent"></a>
    <h3>constructor Event <span class="smalllinenumber">[line 55]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Event Event(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds an Event object.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodbuild"></a>
    <h3>method build <span class="smalllinenumber">[line 277]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void build(
int
$id, string
$entitled, string
$fixing_url, int
$current_status, <a href="../util/Date.php">Date</a>
$creation_date, int
$id_in_module, string
$identifier, string
$type)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds an event object from its whole parameters.</div>
    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../events/AdministratorAlert.php#methodbuild">AdministratorAlert::build()</a></dt>
        <dd>Builds an alert from its whole parameters.</dd>
    </dl>
        <dl>
    <dt><a href="../events/Contribution.php#methodbuild">Contribution::build()</a></dt>
        <dd>Builds a contribution object from its whole parameters.</dd>
    </dl>
    </p>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>The event id.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$entitled</strong>&nbsp;&nbsp;</td>
        <td>The event entitled.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fixing_url</strong>&nbsp;&nbsp;</td>
        <td>The URL corresponding to the event.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$current_status</strong>&nbsp;&nbsp;</td>
        <td>The event status.</td>
      </tr>
          <tr>
        <td class="type"><a href="../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$creation_date</strong>&nbsp;&nbsp;</td>
        <td>The creation date.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_in_module</strong>&nbsp;&nbsp;</td>
        <td>The id of the object associated to the event.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$identifier</strong>&nbsp;&nbsp;</td>
        <td>The event identifier.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>The event type.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_creation_date"></a>
    <h3>method get_creation_date <span class="smalllinenumber">[line 205]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../util/Date.php">Date</a> get_creation_date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the creation date of the event.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Creation date</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_entitled"></a>
    <h3>method get_entitled <span class="smalllinenumber">[line 173]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_entitled(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the entitled of the event.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The entitled.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_fixing_url"></a>
    <h3>method get_fixing_url <span class="smalllinenumber">[line 182]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_fixing_url(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the URL corresponding to the alert.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Relative URL whose first character is / for the website root.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_id"></a>
    <h3>method get_id <span class="smalllinenumber">[line 164]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_id(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the id of the event (in the event data base).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The id.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_identifier"></a>
    <h3>method get_identifier <span class="smalllinenumber">[line 224]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_identifier(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the identifier of the event. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The identifier of the event.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_id_in_module"></a>
    <h3>method get_id_in_module <span class="smalllinenumber">[line 214]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_id_in_module(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the id in the module. This value corresponds to the id of the daba base entry associated to the event.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The id in the module.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_must_regenerate_cache"></a>
    <h3>method get_must_regenerate_cache <span class="smalllinenumber">[line 242]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool get_must_regenerate_cache(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the value indicating if the cache must be generated.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the cache has to be generated, false else.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_status"></a>
    <h3>method get_status <span class="smalllinenumber">[line 196]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_status(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the status of the event. The status is one of those elements: ul&gt;     &lt;li&gt;EVENT_STATUS_UNREAD if it's not read.&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_BEING_PROCESSED if the event is beeing processed&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_PROCESSED if the event is processed. &lt;/ul&gt;</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Status</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_status_name"></a>
    <h3>method get_status_name <span class="smalllinenumber">[line 251]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>The get_status_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the event status name. It's automatically translated in the user language.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> name of the event status, ready to be displayed.</li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../events/Contribution.php#methodget_status_name">Contribution::get_status_name()</a></dt>
        <dd>Gets the contribution status name. It's automatically translated in the user language, ready to be displayed.</dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_type"></a>
    <h3>method get_type <span class="smalllinenumber">[line 233]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_type(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The type.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_creation_date"></a>
    <h3>method set_creation_date <span class="smalllinenumber">[line 115]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_creation_date(
<a href="../util/Date.php">Date</a>
$date)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the creation date of the event.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$date</strong>&nbsp;&nbsp;</td>
        <td>The creation date</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_entitled"></a>
    <h3>method set_entitled <span class="smalllinenumber">[line 75]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_entitled(
string
$entitled)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the entitled of the event. The entitled can be considered as the name, it must be explicit.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$entitled</strong>&nbsp;&nbsp;</td>
        <td>The event entitiled.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_fixing_url"></a>
    <h3>method set_fixing_url <span class="smalllinenumber">[line 84]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_fixing_url(
string
$fixing_url)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the URL corresponding to the event. For the contributions and the administrator alerts it's the number URL at which the problem can be solved.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fixing_url</strong>&nbsp;&nbsp;</td>
        <td>Relative URL (the first character must be / for the root of the site).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_id"></a>
    <h3>method set_id <span class="smalllinenumber">[line 65]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_id(
int
$id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the id of the event. The id is the corresponding data base entry one.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Id of the event.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_identifier"></a>
    <h3>method set_identifier <span class="smalllinenumber">[line 136]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_identifier(
string
$identifier)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the event identifier. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events. You don't have to use it, you can let it blank.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$identifier</strong>&nbsp;&nbsp;</td>
        <td>Identifier of the event.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_id_in_module"></a>
    <h3>method set_id_in_module <span class="smalllinenumber">[line 126]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_id_in_module(
int
$id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the id in module parameter. It corresponds to the id of the element corresponding to the event in your data base tables. For example, il you use the events to allow user to purpose some news in your web site, it will be the id of the news added.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Id in the module</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_must_regenerate_cache"></a>
    <h3>method set_must_regenerate_cache <span class="smalllinenumber">[line 154]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_must_regenerate_cache(
bool
$must)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets a private property indicating if the changes made on this event imply the regeneration of the events cache.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$must</strong>&nbsp;&nbsp;</td>
        <td>true if we must generate the events cache, otherwise false.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_status"></a>
    <h3>method set_status <span class="smalllinenumber">[line 98]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_status(
int
$new_current_status)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Set the status of the event.</div>
    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../events/Contribution.php#methodset_status">Contribution::set_status()</a></dt>
        <dd>Set the status of the contribution.</dd>
    </dl>
    </p>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$new_current_status</strong>&nbsp;&nbsp;</td>
        <td>One of those elements: <ul><li>EVENT_STATUS_UNREAD if it's not read.</li><li>EVENT_STATUS_BEING_PROCESSED if the event is beeing processed</li><li>EVENT_STATUS_PROCESSED if the event is processed.</li></ul></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_type"></a>
    <h3>method set_type <span class="smalllinenumber">[line 145]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_type(
string
$type)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>The type of your event.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                                <div class="var">
                            <a name="var_creation_date"></a>
                <span class="line-number">[line 319]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type"><a href="../util/Date.php">Date</a></span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$creation_date</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_current_status"></a>
                <span class="line-number">[line 313]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$current_status</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;EVENT_STATUS_UNREAD</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_entitled"></a>
                <span class="line-number">[line 301]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$entitled</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fixing_url"></a>
                <span class="line-number">[line 307]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fixing_url</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id"></a>
                <span class="line-number">[line 295]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_identifier"></a>
                <span class="line-number">[line 332]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$identifier</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id_in_module"></a>
                <span class="line-number">[line 326]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id_in_module</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_must_regenerate_cache"></a>
                <span class="line-number">[line 344]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">bool</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$must_regenerate_cache</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;true</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_type"></a>
                <span class="line-number">[line 338]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$type</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="../classtrees_events.php" class="menu">class tree: events</a> -
            <a href="../elementindex_events.php" class="menu">index: events</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:45 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>