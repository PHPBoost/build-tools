<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Docs For Class Contribution');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="../classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="../elementindex_events.php" class="menu">index: events</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/AdministratorAlert.php">AdministratorAlert</a>            </li>
                    <li>
                <a href="../events/AdministratorAlertService.php">AdministratorAlertService</a>            </li>
                    <li>
                <a href="../events/Contribution.php">Contribution</a>            </li>
                    <li>
                <a href="../events/ContributionService.php">ContributionService</a>            </li>
                    <li>
                <a href="../events/Event.php">Event</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/_events---administrator_alert.class.php.php">                administrator_alert.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---administrator_alert_service.class.php.php">                administrator_alert_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution.class.php.php">                contribution.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution_service.class.php.php">                contribution_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---event.class.php.php">                event.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Contribution</h1><p>Source Location: /events/contribution.class.php [line 42]</p>

<h2>Class Overview</a></h2>
<pre><a href="../events/Event.php">Event</a>
   |
   --Contribution</pre>
<div class="description">This class represents a contribution made by a user to complete the content of the website. All the contributions are managed in the contribution panel.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../events/Contribution.php#methodContribution">Contribution</a></li><li class="bb_li"><a href="../events/Contribution.php#methodbuild">build</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_auth">get_auth</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_description">get_description</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_fixer_id">get_fixer_id</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_fixer_login">get_fixer_login</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_fixing_date">get_fixing_date</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_module">get_module</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_module_name">get_module_name</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_poster_id">get_poster_id</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_poster_login">get_poster_login</a></li><li class="bb_li"><a href="../events/Contribution.php#methodget_status_name">get_status_name</a></li><li class="bb_li"><a href="../events/Contribution.php#methodset_auth">set_auth</a></li><li class="bb_li"><a href="../events/Contribution.php#methodset_description">set_description</a></li><li class="bb_li"><a href="../events/Contribution.php#methodset_fixer_id">set_fixer_id</a></li><li class="bb_li"><a href="../events/Contribution.php#methodset_fixing_date">set_fixing_date</a></li><li class="bb_li"><a href="../events/Contribution.php#methodset_module">set_module</a></li><li class="bb_li"><a href="../events/Contribution.php#methodset_poster_id">set_poster_id</a></li><li class="bb_li"><a href="../events/Contribution.php#methodset_status">set_status</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../events/Contribution.php#var$auth">$auth</a></li><li class="bb_li"><a href="../events/Contribution.php#var$description">$description</a></li><li class="bb_li"><a href="../events/Contribution.php#var$fixer_id">$fixer_id</a></li><li class="bb_li"><a href="../events/Contribution.php#var$fixer_login">$fixer_login</a></li><li class="bb_li"><a href="../events/Contribution.php#var$fixing_date">$fixing_date</a></li><li class="bb_li"><a href="../events/Contribution.php#var$module">$module</a></li><li class="bb_li"><a href="../events/Contribution.php#var$poster_id">$poster_id</a></li><li class="bb_li"><a href="../events/Contribution.php#var$poster_login">$poster_login</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class represents a contribution made by a user to complete the content of the website. All the contributions are managed in the contribution panel.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodContribution"></a>
    <h3>constructor Contribution <span class="smalllinenumber">[line 47]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Contribution Contribution(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a Contribution object.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodbuild"></a>
    <h3>method build <span class="smalllinenumber">[line 74]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void build(
int
$id, string
$entitled, 
$description, string
$fixing_url, int
$module, 
$status, <a href="../util/Date.php">Date</a>
$creation_date, <a href="../util/Date.php">Date</a>
$fixing_date, mixed[]
$auth, int
$poster_id, int
$fixer_id, int
$id_in_module, string
$identifier, string
$type, [string
$poster_login = ''], [string
$fixer_login = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a contribution object from its whole parameters.</div>
    Overrides <a href="../events/Event.php#methodbuild">Event::build()</a> (Builds an event object from its whole parameters.)
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Contribution id.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$entitled</strong>&nbsp;&nbsp;</td>
        <td>Contribution entitled.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fixing_url</strong>&nbsp;&nbsp;</td>
        <td>URL associated to the event.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td>status Contribution status.</td>
      </tr>
          <tr>
        <td class="type"><a href="../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$creation_date</strong>&nbsp;&nbsp;</td>
        <td>Contribution creation date.</td>
      </tr>
          <tr>
        <td class="type"><a href="../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$fixing_date</strong>&nbsp;&nbsp;</td>
        <td>Contribution fixing date.</td>
      </tr>
          <tr>
        <td class="type">mixed[]&nbsp;&nbsp;</td>
        <td><strong>$auth</strong>&nbsp;&nbsp;</td>
        <td>Auth array determining the people who can treat the contribution.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$poster_id</strong>&nbsp;&nbsp;</td>
        <td>Contribution creator id.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$fixer_id</strong>&nbsp;&nbsp;</td>
        <td>Contribution fixer id.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_in_module</strong>&nbsp;&nbsp;</td>
        <td>Id of the element associated to the contribution.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$identifier</strong>&nbsp;&nbsp;</td>
        <td>Contribution identifier.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>Contribution type.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$poster_login</strong>&nbsp;&nbsp;</td>
        <td>Login of the poster of the contribution.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fixer_login</strong>&nbsp;&nbsp;</td>
        <td>Login of the fixer of the contribution.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$description</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$status</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_auth"></a>
    <h3>method get_auth <span class="smalllinenumber">[line 228]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>mixed[] get_auth(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the authorization of treatment of this contribution.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The authorization array.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_description"></a>
    <h3>method get_description <span class="smalllinenumber">[line 201]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_description(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the description of the contribution.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the description</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_fixer_id"></a>
    <h3>method get_fixer_id <span class="smalllinenumber">[line 246]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_fixer_id(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the identifier of the fixer.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Its id.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_fixer_login"></a>
    <h3>method get_fixer_login <span class="smalllinenumber">[line 264]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_fixer_login(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the fixer login.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The fixer login.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_fixing_date"></a>
    <h3>method get_fixing_date <span class="smalllinenumber">[line 219]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>The get_fixing_date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the contribution fixing date.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> date at which the contribution has been treated.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_module"></a>
    <h3>method get_module <span class="smalllinenumber">[line 210]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_module(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the module in which the contribution is used.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The module identifier (for example the name of its folder).</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_module_name"></a>
    <h3>method get_module_name <span class="smalllinenumber">[line 292]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_module_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the name of the module in which the contribution is used.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The module name.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_poster_id"></a>
    <h3>method get_poster_id <span class="smalllinenumber">[line 237]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_poster_id(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the identifier of the poster.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Its id.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_poster_login"></a>
    <h3>method get_poster_login <span class="smalllinenumber">[line 255]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_poster_login(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the poster login.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The poster login.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_status_name"></a>
    <h3>method get_status_name <span class="smalllinenumber">[line 273]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_status_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the contribution status name. It's automatically translated in the user language, ready to be displayed.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The status name.</li></ul>
    </div>

    Overrides <a href="../events/Event.php#methodget_status_name">Event::get_status_name()</a> (Gets the event status name. It's automatically translated in the user language.)
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_auth"></a>
    <h3>method set_auth <span class="smalllinenumber">[line 149]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_auth(
mixed[]
$auth)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the authorization of the contribution. It will determine who will be able to treat the contribution.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed[]&nbsp;&nbsp;</td>
        <td><strong>$auth</strong>&nbsp;&nbsp;</td>
        <td>Auth array.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_description"></a>
    <h3>method set_description <span class="smalllinenumber">[line 191]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_description(
string
$description)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the description of the contribution.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$description</strong>&nbsp;&nbsp;</td>
        <td>Description (can be some HTML content).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_fixer_id"></a>
    <h3>method set_fixer_id <span class="smalllinenumber">[line 175]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_fixer_id(
int
$fixer_id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the id of the fixer.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$fixer_id</strong>&nbsp;&nbsp;</td>
        <td>Id.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_fixing_date"></a>
    <h3>method set_fixing_date <span class="smalllinenumber">[line 106]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_fixing_date(
<a href="../util/Date.php">Date</a>
$date)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the fixing date.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$date</strong>&nbsp;&nbsp;</td>
        <td>Date</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_module"></a>
    <h3>method set_module <span class="smalllinenumber">[line 97]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_module(
string
$module)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the module in which the contribution is used.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td>Module identifier (for example the name of the module folder).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_poster_id"></a>
    <h3>method set_poster_id <span class="smalllinenumber">[line 159]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_poster_id(
int
$poster_id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the id of the poster.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$poster_id</strong>&nbsp;&nbsp;</td>
        <td>Id.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_status"></a>
    <h3>method set_status <span class="smalllinenumber">[line 121]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_status(
int
$new_current_status)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Set the status of the contribution.</div>
    Overrides <a href="../events/Event.php#methodset_status">Event::set_status()</a> (Set the status of the event.)
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$new_current_status</strong>&nbsp;&nbsp;</td>
        <td>One of those elements: <ul><li>EVENT_STATUS_UNREAD if it's not read.</li><li>EVENT_STATUS_BEING_PROCESSED if the event is beeing processed</li><li>EVENT_STATUS_PROCESSED if the event is processed.</li></ul></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                            <div class="var">
                            <a name="var_auth"></a>
                <span class="line-number">[line 329]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">array</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$auth</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_description"></a>
                <span class="line-number">[line 311]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$description</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fixer_id"></a>
                <span class="line-number">[line 341]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fixer_id</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fixer_login"></a>
                <span class="line-number">[line 353]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fixer_login</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fixing_date"></a>
                <span class="line-number">[line 323]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type"><a href="../util/Date.php">Date</a></span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fixing_date</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_module"></a>
                <span class="line-number">[line 317]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$module</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_poster_id"></a>
                <span class="line-number">[line 335]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$poster_id</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_poster_login"></a>
                <span class="line-number">[line 347]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$poster_login</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>

    <hr />
    <table width="100%" border="0">
        <tr>
                                                    <!--
                        <td valign="top">
                <h3>Inherited Variables</h3>
                                    <div class="tags">
                        <h4>Class: <a href="../events/Event.php">Event</a></h4>
                        <dl>
                                                        <dt><a href="../events/Event.php#var$creation_date">Event::$creation_date</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$current_status">Event::$current_status</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$entitled">Event::$entitled</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$fixing_url">Event::$fixing_url</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$id">Event::$id</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$identifier">Event::$identifier</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$id_in_module">Event::$id_in_module</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$must_regenerate_cache">Event::$must_regenerate_cache</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$type">Event::$type</a></dt>
                            <dd></dd>
                                                    </dl>
                    </div>
                            </td>
                         -->
                            <td valign="top">
                    <h3>Inherited Methods</h3>
                                            <h4>Class: <a href="../events/Event.php">Event</a></h4>
                        <dl style="margin-left:10px;">
                                                        <dt><a href="../events/Event.php#methodEvent">Event::Event()</a></dt>
                            <dd>Builds an Event object.</dd>
                                                        <dt><a href="../events/Event.php#methodbuild">Event::build()</a></dt>
                            <dd>Builds an event object from its whole parameters.</dd>
                                                        <dt><a href="../events/Event.php#methodget_creation_date">Event::get_creation_date()</a></dt>
                            <dd>Returns the creation date of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodget_entitled">Event::get_entitled()</a></dt>
                            <dd>Returns the entitled of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodget_fixing_url">Event::get_fixing_url()</a></dt>
                            <dd>Returns the URL corresponding to the alert.</dd>
                                                        <dt><a href="../events/Event.php#methodget_id">Event::get_id()</a></dt>
                            <dd>Gets the id of the event (in the event data base).</dd>
                                                        <dt><a href="../events/Event.php#methodget_identifier">Event::get_identifier()</a></dt>
                            <dd>Gets the identifier of the event. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events.</dd>
                                                        <dt><a href="../events/Event.php#methodget_id_in_module">Event::get_id_in_module()</a></dt>
                            <dd>Gets the id in the module. This value corresponds to the id of the daba base entry associated to the event.</dd>
                                                        <dt><a href="../events/Event.php#methodget_must_regenerate_cache">Event::get_must_regenerate_cache()</a></dt>
                            <dd>Gets the value indicating if the cache must be generated.</dd>
                                                        <dt><a href="../events/Event.php#methodget_status">Event::get_status()</a></dt>
                            <dd>Gets the status of the event. The status is one of those elements: ul&gt;     &lt;li&gt;EVENT_STATUS_UNREAD if it's not read.&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_BEING_PROCESSED if the event is beeing processed&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_PROCESSED if the event is processed. &lt;/ul&gt;</dd>
                                                        <dt><a href="../events/Event.php#methodget_status_name">Event::get_status_name()</a></dt>
                            <dd>Gets the event status name. It's automatically translated in the user language.</dd>
                                                        <dt><a href="../events/Event.php#methodget_type">Event::get_type()</a></dt>
                            <dd>Gets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
                                                        <dt><a href="../events/Event.php#methodset_creation_date">Event::set_creation_date()</a></dt>
                            <dd>Sets the creation date of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodset_entitled">Event::set_entitled()</a></dt>
                            <dd>Sets the entitled of the event. The entitled can be considered as the name, it must be explicit.</dd>
                                                        <dt><a href="../events/Event.php#methodset_fixing_url">Event::set_fixing_url()</a></dt>
                            <dd>Sets the URL corresponding to the event. For the contributions and the administrator alerts it's the number URL at which the problem can be solved.</dd>
                                                        <dt><a href="../events/Event.php#methodset_id">Event::set_id()</a></dt>
                            <dd>Sets the id of the event. The id is the corresponding data base entry one.</dd>
                                                        <dt><a href="../events/Event.php#methodset_identifier">Event::set_identifier()</a></dt>
                            <dd>Sets the event identifier. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events. You don't have to use it, you can let it blank.</dd>
                                                        <dt><a href="../events/Event.php#methodset_id_in_module">Event::set_id_in_module()</a></dt>
                            <dd>Sets the id in module parameter. It corresponds to the id of the element corresponding to the event in your data base tables. For example, il you use the events to allow user to purpose some news in your web site, it will be the id of the news added.</dd>
                                                        <dt><a href="../events/Event.php#methodset_must_regenerate_cache">Event::set_must_regenerate_cache()</a></dt>
                            <dd>Sets a private property indicating if the changes made on this event imply the regeneration of the events cache.</dd>
                                                        <dt><a href="../events/Event.php#methodset_status">Event::set_status()</a></dt>
                            <dd>Set the status of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodset_type">Event::set_type()</a></dt>
                            <dd>Sets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
                                                    </dl>
                        <br />
                                    </td>
                    </tr>
    </table>
    <hr />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="../classtrees_events.php" class="menu">class tree: events</a> -
            <a href="../elementindex_events.php" class="menu">index: events</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:44 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>