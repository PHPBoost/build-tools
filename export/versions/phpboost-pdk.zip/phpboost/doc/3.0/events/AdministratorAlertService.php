<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Docs For Class AdministratorAlertService');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="../classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="../elementindex_events.php" class="menu">index: events</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/AdministratorAlert.php">AdministratorAlert</a>            </li>
                    <li>
                <a href="../events/AdministratorAlertService.php">AdministratorAlertService</a>            </li>
                    <li>
                <a href="../events/Contribution.php">Contribution</a>            </li>
                    <li>
                <a href="../events/ContributionService.php">ContributionService</a>            </li>
                    <li>
                <a href="../events/Event.php">Event</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/_events---administrator_alert.class.php.php">                administrator_alert.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---administrator_alert_service.class.php.php">                administrator_alert_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution.class.php.php">                contribution.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution_service.class.php.php">                contribution_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---event.class.php.php">                event.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: AdministratorAlertService</h1><p>Source Location: /events/administrator_alert_service.class.php [line 39]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This static class allows you to handler easily the administrator alerts which can be made in PHPBoost.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodcompute_number_unread_alerts">compute_number_unread_alerts</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methoddelete_alert">delete_alert</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodfind_by_criteria">find_by_criteria</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodfind_by_id">find_by_id</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodfind_by_identifier">find_by_identifier</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodget_all_alerts">get_all_alerts</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodget_number_alerts">get_number_alerts</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodget_number_unread_alerts">get_number_unread_alerts</a></li><li class="bb_li"><a href="../events/AdministratorAlertService.php#methodsave_alert">save_alert</a></li></ul>
    </div>
    </td>
<!--
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This static class allows you to handler easily the administrator alerts which can be made in PHPBoost.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methoddelete_alert"></a>
    <h3>method delete_alert <span class="smalllinenumber">[line 228]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete_alert(

&$alert, <a href="../events/AdministratorAlert.php">AdministratorAlert</a>
$alert)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes an alert from the database.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../events/AdministratorAlert.php">AdministratorAlert</a>&nbsp;&nbsp;</td>
        <td><strong>$alert</strong>&nbsp;&nbsp;</td>
        <td>The alert to delete.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$alert</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodcompute_number_unread_alerts"></a>
	<h3>static method compute_number_unread_alerts <span class="smalllinenumber">[line 251]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static int[] compute_number_unread_alerts(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Counts the number of unread alerts.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> An associative map: <ul><li>unread =&gt; the number of the unread alerts</li><li>all =&gt; the number of all the alerts of the site</li></ul></li></ul>
    </div>

	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodfind_by_criteria"></a>
	<h3>static method find_by_criteria <span class="smalllinenumber">[line 81]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static AdministratorAlert[] find_by_criteria(
[int
$id_in_module = null], [string
$type = null], [string
$identifier = null])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Builds a list of alerts matching the required criteria(s). You can specify many criterias. When you use several of them, it's a AND condition. It will only return the alert which match all the criterias.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the matching alerts.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_in_module</strong>&nbsp;&nbsp;</td>
        <td>Id in the module.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>Alert type.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$identifier</strong>&nbsp;&nbsp;</td>
        <td>Alert identifier.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodfind_by_id"></a>
	<h3>static method find_by_id <span class="smalllinenumber">[line 47]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static <a href="../events/AdministratorAlert.php">AdministratorAlert</a> find_by_id(
int
$alert_id)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Builds an alert knowing its id.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The wanted alert. If it's not found, it returns null.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$alert_id</strong>&nbsp;&nbsp;</td>
        <td>Id of the alert.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodfind_by_identifier"></a>
	<h3>static method find_by_identifier <span class="smalllinenumber">[line 133]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static AdministratorAlert[] find_by_identifier(
string
$identifier, [string
$type = ''])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Finds an alert knowing its identifier and maybe its type.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the matching alerts.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$identifier</strong>&nbsp;&nbsp;</td>
        <td>The identifier of the alerts you look for.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>The type of the alert you look for.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_all_alerts"></a>
	<h3>static method get_all_alerts <span class="smalllinenumber">[line 165]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static AdministratorAlerts[] get_all_alerts(
[string
$criteria = 'creation_date'], [string
$order = 'desc'], [int
$begin = 0], [int
$number = 20])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Lists all the alerts of the site. You can order them. You can also choose how much alerts you want.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the alerts.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$criteria</strong>&nbsp;&nbsp;</td>
        <td>The criteria according to which you want to order. It can be id, entitled, fixing_url, current_status, creation_date, identifier, id_in_module, type, priority, description.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$order</strong>&nbsp;&nbsp;</td>
        <td>asc or desc.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$begin</strong>&nbsp;&nbsp;</td>
        <td>You want all the alert from the ($begin+1)(th).</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$number</strong>&nbsp;&nbsp;</td>
        <td>The number of alerts you want.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_number_alerts"></a>
	<h3>static method get_number_alerts <span class="smalllinenumber">[line 276]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static int get_number_alerts(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns the number of alerts.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The number of alerts.</li></ul>
    </div>

	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_number_unread_alerts"></a>
	<h3>static method get_number_unread_alerts <span class="smalllinenumber">[line 265]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static int get_number_unread_alerts(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns the number of unread alerts.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The number of unread alerts.</li></ul>
    </div>

	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodsave_alert"></a>
	<h3>static method save_alert <span class="smalllinenumber">[line 194]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static void save_alert(

&$alert, <a href="../events/AdministratorAlert.php">AdministratorAlert</a>
$alert)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Create or updates an alert in the database. It creates it whether it doesn't exist or updates it if it already exists.</div>
	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../events/AdministratorAlert.php">AdministratorAlert</a>&nbsp;&nbsp;</td>
        <td><strong>$alert</strong>&nbsp;&nbsp;</td>
        <td>The alert to create or update.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$alert</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="../classtrees_events.php" class="menu">class tree: events</a> -
            <a href="../elementindex_events.php" class="menu">index: events</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:36 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>