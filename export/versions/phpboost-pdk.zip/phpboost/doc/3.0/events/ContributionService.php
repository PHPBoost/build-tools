<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Docs For Class ContributionService');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="../classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="../elementindex_events.php" class="menu">index: events</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/AdministratorAlert.php">AdministratorAlert</a>            </li>
                    <li>
                <a href="../events/AdministratorAlertService.php">AdministratorAlertService</a>            </li>
                    <li>
                <a href="../events/Contribution.php">Contribution</a>            </li>
                    <li>
                <a href="../events/ContributionService.php">ContributionService</a>            </li>
                    <li>
                <a href="../events/Event.php">Event</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/_events---administrator_alert.class.php.php">                administrator_alert.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---administrator_alert_service.class.php.php">                administrator_alert_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution.class.php.php">                contribution.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution_service.class.php.php">                contribution_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---event.class.php.php">                event.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: ContributionService</h1><p>Source Location: /events/contribution_service.class.php [line 39]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This service allows developers to manage their contributions.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../events/ContributionService.php#methodcompute_number_contrib_for_each_profile">compute_number_contrib_for_each_profile</a></li><li class="bb_li"><a href="../events/ContributionService.php#methoddelete_contribution">delete_contribution</a></li><li class="bb_li"><a href="../events/ContributionService.php#methodfind_by_criteria">find_by_criteria</a></li><li class="bb_li"><a href="../events/ContributionService.php#methodfind_by_id">find_by_id</a></li><li class="bb_li"><a href="../events/ContributionService.php#methodgenerate_cache">generate_cache</a></li><li class="bb_li"><a href="../events/ContributionService.php#methodget_all_contributions">get_all_contributions</a></li><li class="bb_li"><a href="../events/ContributionService.php#methodsave_contribution">save_contribution</a></li></ul>
    </div>
    </td>
<!--
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This service allows developers to manage their contributions.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methoddelete_contribution"></a>
    <h3>method delete_contribution <span class="smalllinenumber">[line 200]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete_contribution(

&$contribution, <a href="../events/Contribution.php">Contribution</a>
$contribution)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes a contribution in the database.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../events/Contribution.php">Contribution</a>&nbsp;&nbsp;</td>
        <td><strong>$contribution</strong>&nbsp;&nbsp;</td>
        <td>The contribution to delete in the data base.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$contribution</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodcompute_number_contrib_for_each_profile"></a>
	<h3>static method compute_number_contrib_for_each_profile <span class="smalllinenumber">[line 239]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static int[] compute_number_contrib_for_each_profile(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Computes the number of contributions available for each profile. It will count the contributions for the administrator, the moderators, the members, for each group and for each member who can have some special authorizations.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> A map containing the values for each profile: <ul><li>r2 =&gt; for the administrator</li><li>r1 =&gt; for the moderators</li><li>r0 =&gt; for the members</li><li>gi =&gt; for the group whose id is i</li><li>mi =&gt; for the member whose id is i</li></ul></li></ul>
    </div>

	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodfind_by_criteria"></a>
	<h3>static method find_by_criteria <span class="smalllinenumber">[line 117]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static Contribution[] find_by_criteria(
string
$module, [int
$id_in_module = null], [string
$type = null], [string
$identifier = null], [int
$poster_id = null], [int
$fixer_id = null])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Builds a list of the contributions matching the required criteria(s). All the parameters represent the criterias you can use. If you don't want to use a criteria, let the null value. The returned contribution match all the criterias (it's a AND condition).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the contributions matching all the criterias.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td>The module identifier.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_in_module</strong>&nbsp;&nbsp;</td>
        <td>The id in module field.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>The contribution type.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$identifier</strong>&nbsp;&nbsp;</td>
        <td>The contribution identifier.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$poster_id</strong>&nbsp;&nbsp;</td>
        <td>The poster.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$fixer_id</strong>&nbsp;&nbsp;</td>
        <td>The fixer.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodfind_by_id"></a>
	<h3>static method find_by_id <span class="smalllinenumber">[line 47]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static <a href="../events/Contribution.php">Contribution</a> find_by_id(
int
$id_contrib)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Finds a contribution with its identifier.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The contribution you wanted. If it doesn't exist, it will return null.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_contrib</strong>&nbsp;&nbsp;</td>
        <td>Id of the contribution.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodgenerate_cache"></a>
	<h3>static method generate_cache <span class="smalllinenumber">[line 220]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static void generate_cache(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Generates the contribution cache file.</div>
	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_all_contributions"></a>
	<h3>static method get_all_contributions <span class="smalllinenumber">[line 79]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static Contribution[] get_all_contributions(
[string
$criteria = 'creation_date'], [string
$order = 'desc'])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Gets all the contributions of the table. You can sort the list.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the contributions.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$criteria</strong>&nbsp;&nbsp;</td>
        <td>Criteria according to which they are ordered. It can be id, entitled, fixing_url, auth, current_status, module, creation_date, fixing_date, poster_id, fixer_id, poster_member.login poster_login, fixer_member.login fixer_login, identifier, id_in_module, type, description.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$order</strong>&nbsp;&nbsp;</td>
        <td>desc or asc.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodsave_contribution"></a>
	<h3>static method save_contribution <span class="smalllinenumber">[line 167]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static void save_contribution(

&$contribution, <a href="../events/Contribution.php">Contribution</a>
$contribution)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Create or update a contribution in the database.</div>
	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../events/Contribution.php">Contribution</a>&nbsp;&nbsp;</td>
        <td><strong>$contribution</strong>&nbsp;&nbsp;</td>
        <td>The contribution to synchronize with the data base.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$contribution</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="../classtrees_events.php" class="menu">class tree: events</a> -
            <a href="../elementindex_events.php" class="menu">index: events</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:45 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>