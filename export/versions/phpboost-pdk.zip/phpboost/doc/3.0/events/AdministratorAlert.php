<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Docs For Class AdministratorAlert');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="../classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="../elementindex_events.php" class="menu">index: events</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/AdministratorAlert.php">AdministratorAlert</a>            </li>
                    <li>
                <a href="../events/AdministratorAlertService.php">AdministratorAlertService</a>            </li>
                    <li>
                <a href="../events/Contribution.php">Contribution</a>            </li>
                    <li>
                <a href="../events/ContributionService.php">ContributionService</a>            </li>
                    <li>
                <a href="../events/Event.php">Event</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/_events---administrator_alert.class.php.php">                administrator_alert.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---administrator_alert_service.class.php.php">                administrator_alert_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution.class.php.php">                contribution.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution_service.class.php.php">                contribution_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---event.class.php.php">                event.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: AdministratorAlert</h1><p>Source Location: /events/administrator_alert.class.php [line 56]</p>

<h2>Class Overview</a></h2>
<pre><a href="../events/Event.php">Event</a>
   |
   --AdministratorAlert</pre>
<div class="description">This class represents an alert which must be sent to the administrator. It allows to the module developers to handle the administrator alerts. The administrator alerts can be in the administration panel and can be used when you want to signal an important event to the administrator(s).</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../events/AdministratorAlert.php#methodAdministratorAlert">AdministratorAlert</a></li><li class="bb_li"><a href="../events/AdministratorAlert.php#methodbuild">build</a></li><li class="bb_li"><a href="../events/AdministratorAlert.php#methodget_priority">get_priority</a></li><li class="bb_li"><a href="../events/AdministratorAlert.php#methodget_priority_name">get_priority_name</a></li><li class="bb_li"><a href="../events/AdministratorAlert.php#methodget_properties">get_properties</a></li><li class="bb_li"><a href="../events/AdministratorAlert.php#methodset_priority">set_priority</a></li><li class="bb_li"><a href="../events/AdministratorAlert.php#methodset_properties">set_properties</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../events/AdministratorAlert.php#var$priority">$priority</a></li><li class="bb_li"><a href="../events/AdministratorAlert.php#var$properties">$properties</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class represents an alert which must be sent to the administrator. It allows to the module developers to handle the administrator alerts. The administrator alerts can be in the administration panel and can be used when you want to signal an important event to the administrator(s).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodAdministratorAlert"></a>
    <h3>constructor AdministratorAlert <span class="smalllinenumber">[line 61]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>AdministratorAlert AdministratorAlert(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds an AdministratorAlert object.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodbuild"></a>
    <h3>method build <span class="smalllinenumber">[line 81]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void build(
int
$id, string
$entitled, string
$properties, string
$fixing_url, int
$current_status, <a href="../util/Date.php">Date</a>
$creation_date, int
$id_in_module, string
$identifier, string
$type, int
$priority)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds an alert from its whole parameters.</div>
    Overrides <a href="../events/Event.php#methodbuild">Event::build()</a> (Builds an event object from its whole parameters.)
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Identifier of the alert.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$entitled</strong>&nbsp;&nbsp;</td>
        <td>Entitled of the alert.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$properties</strong>&nbsp;&nbsp;</td>
        <td>Properties of the alert.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fixing_url</strong>&nbsp;&nbsp;</td>
        <td>Fixing url.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$current_status</strong>&nbsp;&nbsp;</td>
        <td>Alert status.</td>
      </tr>
          <tr>
        <td class="type"><a href="../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$creation_date</strong>&nbsp;&nbsp;</td>
        <td>Alert creation date?</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_in_module</strong>&nbsp;&nbsp;</td>
        <td>Id in module field.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$identifier</strong>&nbsp;&nbsp;</td>
        <td>Identifier of the alert.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>Type of the alert.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$priority</strong>&nbsp;&nbsp;</td>
        <td>Priority of the alert.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_priority"></a>
    <h3>method get_priority <span class="smalllinenumber">[line 99]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_priority(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the priority of the alert.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> One of those values: <ul><li>ADMIN_ALERT_VERY_LOW_PRIORITY Very low priority</li><li>ADMIN_ALERT_LOW_PRIORITY Low priority</li><li>ADMIN_ALERT_MEDIUM_PRIORITY Medium priority</li><li>ADMIN_ALERT_HIGH_PRIORITY High priority</li><li>ADMIN_ALERT_VERY_HIGH_PRIORITY Very high priority</li></ul></li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_priority_name"></a>
    <h3>method get_priority_name <span class="smalllinenumber">[line 154]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_priority_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the priority name. It's automatically translater to the user language, ready to be displayed.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The priority name.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_properties"></a>
    <h3>method get_properties <span class="smalllinenumber">[line 108]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_properties(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets the alert properties.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The properties.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_priority"></a>
    <h3>method set_priority <span class="smalllinenumber">[line 124]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_priority(
int
$priority)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the priority of the alert.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$priority</strong>&nbsp;&nbsp;</td>
        <td>The priority, it must be one of those values: <ul><li>ADMIN_ALERT_VERY_LOW_PRIORITY Very low priority</li><li>ADMIN_ALERT_LOW_PRIORITY Low priority</li><li>ADMIN_ALERT_MEDIUM_PRIORITY Medium priority</li><li>ADMIN_ALERT_HIGH_PRIORITY High priority</li><li>ADMIN_ALERT_VERY_HIGH_PRIORITY Very high priority</li></ul></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_properties"></a>
    <h3>method set_properties <span class="smalllinenumber">[line 141]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_properties(
string
$properties)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the properties of the alert.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$properties</strong>&nbsp;&nbsp;</td>
        <td>Properties.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                    <div class="var">
                            <a name="var_priority"></a>
                <span class="line-number">[line 184]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$priority</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;ADMIN_ALERT_MEDIUM_PRIORITY</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_properties"></a>
                <span class="line-number">[line 190]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$properties</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>

    <hr />
    <table width="100%" border="0">
        <tr>
                                                    <!--
                        <td valign="top">
                <h3>Inherited Variables</h3>
                                    <div class="tags">
                        <h4>Class: <a href="../events/Event.php">Event</a></h4>
                        <dl>
                                                        <dt><a href="../events/Event.php#var$creation_date">Event::$creation_date</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$current_status">Event::$current_status</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$entitled">Event::$entitled</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$fixing_url">Event::$fixing_url</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$id">Event::$id</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$identifier">Event::$identifier</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$id_in_module">Event::$id_in_module</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$must_regenerate_cache">Event::$must_regenerate_cache</a></dt>
                            <dd></dd>
                                                        <dt><a href="../events/Event.php#var$type">Event::$type</a></dt>
                            <dd></dd>
                                                    </dl>
                    </div>
                            </td>
                         -->
                            <td valign="top">
                    <h3>Inherited Methods</h3>
                                            <h4>Class: <a href="../events/Event.php">Event</a></h4>
                        <dl style="margin-left:10px;">
                                                        <dt><a href="../events/Event.php#methodEvent">Event::Event()</a></dt>
                            <dd>Builds an Event object.</dd>
                                                        <dt><a href="../events/Event.php#methodbuild">Event::build()</a></dt>
                            <dd>Builds an event object from its whole parameters.</dd>
                                                        <dt><a href="../events/Event.php#methodget_creation_date">Event::get_creation_date()</a></dt>
                            <dd>Returns the creation date of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodget_entitled">Event::get_entitled()</a></dt>
                            <dd>Returns the entitled of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodget_fixing_url">Event::get_fixing_url()</a></dt>
                            <dd>Returns the URL corresponding to the alert.</dd>
                                                        <dt><a href="../events/Event.php#methodget_id">Event::get_id()</a></dt>
                            <dd>Gets the id of the event (in the event data base).</dd>
                                                        <dt><a href="../events/Event.php#methodget_identifier">Event::get_identifier()</a></dt>
                            <dd>Gets the identifier of the event. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events.</dd>
                                                        <dt><a href="../events/Event.php#methodget_id_in_module">Event::get_id_in_module()</a></dt>
                            <dd>Gets the id in the module. This value corresponds to the id of the daba base entry associated to the event.</dd>
                                                        <dt><a href="../events/Event.php#methodget_must_regenerate_cache">Event::get_must_regenerate_cache()</a></dt>
                            <dd>Gets the value indicating if the cache must be generated.</dd>
                                                        <dt><a href="../events/Event.php#methodget_status">Event::get_status()</a></dt>
                            <dd>Gets the status of the event. The status is one of those elements: ul&gt;     &lt;li&gt;EVENT_STATUS_UNREAD if it's not read.&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_BEING_PROCESSED if the event is beeing processed&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_PROCESSED if the event is processed. &lt;/ul&gt;</dd>
                                                        <dt><a href="../events/Event.php#methodget_status_name">Event::get_status_name()</a></dt>
                            <dd>Gets the event status name. It's automatically translated in the user language.</dd>
                                                        <dt><a href="../events/Event.php#methodget_type">Event::get_type()</a></dt>
                            <dd>Gets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
                                                        <dt><a href="../events/Event.php#methodset_creation_date">Event::set_creation_date()</a></dt>
                            <dd>Sets the creation date of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodset_entitled">Event::set_entitled()</a></dt>
                            <dd>Sets the entitled of the event. The entitled can be considered as the name, it must be explicit.</dd>
                                                        <dt><a href="../events/Event.php#methodset_fixing_url">Event::set_fixing_url()</a></dt>
                            <dd>Sets the URL corresponding to the event. For the contributions and the administrator alerts it's the number URL at which the problem can be solved.</dd>
                                                        <dt><a href="../events/Event.php#methodset_id">Event::set_id()</a></dt>
                            <dd>Sets the id of the event. The id is the corresponding data base entry one.</dd>
                                                        <dt><a href="../events/Event.php#methodset_identifier">Event::set_identifier()</a></dt>
                            <dd>Sets the event identifier. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events. You don't have to use it, you can let it blank.</dd>
                                                        <dt><a href="../events/Event.php#methodset_id_in_module">Event::set_id_in_module()</a></dt>
                            <dd>Sets the id in module parameter. It corresponds to the id of the element corresponding to the event in your data base tables. For example, il you use the events to allow user to purpose some news in your web site, it will be the id of the news added.</dd>
                                                        <dt><a href="../events/Event.php#methodset_must_regenerate_cache">Event::set_must_regenerate_cache()</a></dt>
                            <dd>Sets a private property indicating if the changes made on this event imply the regeneration of the events cache.</dd>
                                                        <dt><a href="../events/Event.php#methodset_status">Event::set_status()</a></dt>
                            <dd>Set the status of the event.</dd>
                                                        <dt><a href="../events/Event.php#methodset_type">Event::set_type()</a></dt>
                            <dd>Sets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
                                                    </dl>
                        <br />
                                    </td>
                    </tr>
    </table>
    <hr />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="../classtrees_events.php" class="menu">class tree: events</a> -
            <a href="../elementindex_events.php" class="menu">index: events</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:36 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>