<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Docs for page administrator_alert_service.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="../classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="../elementindex_events.php" class="menu">index: events</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/AdministratorAlert.php">AdministratorAlert</a>            </li>
                    <li>
                <a href="../events/AdministratorAlertService.php">AdministratorAlertService</a>            </li>
                    <li>
                <a href="../events/Contribution.php">Contribution</a>            </li>
                    <li>
                <a href="../events/ContributionService.php">ContributionService</a>            </li>
                    <li>
                <a href="../events/Event.php">Event</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../events/_events---administrator_alert.class.php.php">                administrator_alert.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---administrator_alert_service.class.php.php">                administrator_alert_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution.class.php.php">                contribution.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---contribution_service.class.php.php">                contribution_service.class.php
                </a>            </li>
                    <li>
                <a href="../events/_events---event.class.php.php">                event.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: administrator_alert_service.class.php</h1><p>Source Location: /events/administrator_alert_service.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../events/AdministratorAlertService.php">AdministratorAlertService</a></dt>
	<dd>This static class allows you to handler easily the administrator alerts which can be made in PHPBoost.</dd>
</div><br /><br />

<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineADMINISTRATOR_ALERT_TYPE"></a>
	<h3>ADMINISTRATOR_ALERT_TYPE <span class="smalllinenumber">[line 31]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ADMINISTRATOR_ALERT_TYPE = 1</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="../classtrees_events.php" class="menu">class tree: events</a> -
            <a href="../elementindex_events.php" class="menu">index: events</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:27 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>