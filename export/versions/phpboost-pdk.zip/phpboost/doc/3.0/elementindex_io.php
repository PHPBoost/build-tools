<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Package io Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                            
                                                                                    <a href="classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="elementindex_io.php" class="menu">index: io</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="io/Template.php">Template</a>            </li>
                    <li>
                <a href="io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package io</h1>
	[ <a href="elementindex_io.php#a">a</a> ]
	[ <a href="elementindex_io.php#b">b</a> ]
	[ <a href="elementindex_io.php#c">c</a> ]
	[ <a href="elementindex_io.php#d">d</a> ]
	[ <a href="elementindex_io.php#e">e</a> ]
	[ <a href="elementindex_io.php#f">f</a> ]
	[ <a href="elementindex_io.php#g">g</a> ]
	[ <a href="elementindex_io.php#h">h</a> ]
	[ <a href="elementindex_io.php#i">i</a> ]
	[ <a href="elementindex_io.php#l">l</a> ]
	[ <a href="elementindex_io.php#m">m</a> ]
	[ <a href="elementindex_io.php#n">n</a> ]
	[ <a href="elementindex_io.php#o">o</a> ]
	[ <a href="elementindex_io.php#p">p</a> ]
	[ <a href="elementindex_io.php#r">r</a> ]
	[ <a href="elementindex_io.php#s">s</a> ]
	[ <a href="elementindex_io.php#t">t</a> ]
	[ <a href="elementindex_io.php#u">u</a> ]
	[ <a href="elementindex_io.php#v">v</a> ]
	[ <a href="elementindex_io.php#w">w</a> ]
	[ <a href="elementindex_io.php#_">_</a> ]

  <hr />
	<a name="_"></a>
	<div>
		<h2>_</h2>
		<dl>
							<dt><strong>_check_cache_file</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_check_cache_file">Template::_check_cache_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Allows you to know if the cache file is still valid or if it has to be removed because the source file has been updated.</dd>
							<dt><strong>_check_file</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_check_file">Template::_check_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the path of the file to load dinamycally according to the user theme and the kind of file (kernel, module, menu or framework file).</dd>
							<dt><strong>_generate_headers</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#method_generate_headers">Mail::_generate_headers()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the mail headers.</dd>
							<dt><strong>_include</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_include">Template::_include()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Include a file in another file. You can access to the same variables in the two variables, it's just as if you had copied the content of the included file in the includer.</dd>
							<dt><strong>_load</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_load">Template::_load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a template file.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>assign_block_vars</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodassign_block_vars">Template::assign_block_vars()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assigns a template block. A block represents a loop and has a name which be used in your template file to indicate which loop you want to browse. To know what syntax to use to browse a loop, see the class description, there are examples.</dd>
							<dt><strong>assign_vars</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodassign_vars">Template::assign_vars()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assigns some simple template vars.  Those variables will be accessed in your template with the {var_name} syntax.</dd>
							<dt><strong>AUTO_LOAD_FREQUENT_VARS</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineAUTO_LOAD_FREQUENT_VARS">AUTO_LOAD_FREQUENT_VARS</a></dd>
							<dt><strong>ADD</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineADD">ADD</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>$base_directory</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$base_directory">Upload::$base_directory</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>$content</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$content">Mail::$content</a></dd>
							<dt><strong>CHECK_EXIST</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineCHECK_EXIST">CHECK_EXIST</a></dd>
							<dt><strong>check_validity</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodcheck_validity">Mail::check_validity()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks that an email address has a correct form.</dd>
							<dt><strong>copy</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodcopy">Template::copy()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Clones this object.</dd>
							<dt><strong>CRLF</strong></dt>
				<dd>in file mail.class.php, constant <a href="io/_io---mail.class.php.php#defineCRLF">CRLF</a></dd>
							<dt><strong>$contents</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$contents">File::$contents</a></dd>
							<dt><strong>change_chmod</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodchange_chmod">FileSystemElement::change_chmod()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Changes the chmod of the element.</dd>
							<dt><strong>close</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodclose">File::close()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Closes a file and frees the allocated memory relative to the file.</dd>
							<dt><strong>CLOSEFILE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineCLOSEFILE">CLOSEFILE</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>DELETE_ON_ERROR</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineDELETE_ON_ERROR">DELETE_ON_ERROR</a></dd>
							<dt><strong>DO_NOT_AUTO_LOAD_FREQUENT_VARS</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineDO_NOT_AUTO_LOAD_FREQUENT_VARS">DO_NOT_AUTO_LOAD_FREQUENT_VARS</a></dd>
							<dt><strong>delete</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methoddelete">Folder::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes the folder and all what it contains.</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methoddelete">FileSystemElement::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes the element</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methoddelete">File::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes the file.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>$error</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$error">Upload::$error</a></dd>
							<dt><strong>$extension</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$extension">Upload::$extension</a></dd>
							<dt><strong>ERASE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineERASE">ERASE</a></dd>
							<dt><strong>exists</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodexists">FileSystemElement::exists()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Allows you to know if the file system element exists.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$filename</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$filename">Upload::$filename</a></dd>
							<dt><strong>$files</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$files">Template::$files</a></dd>
							<dt><strong>$format</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$format">Mail::$format</a></dd>
							<dt><strong>file</strong></dt>
				<dd>in file upload.class.php, method <a href="io/Upload.php#methodfile">Upload::file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Uploads a file.</dd>
							<dt><strong>$fd</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$fd">File::$fd</a></dd>
							<dt><strong>$files</strong></dt>
				<dd>in file folder.class.php, variable <a href="io/filesystem/Folder.php#var$files">Folder::$files</a></dd>
							<dt><strong>$folders</strong></dt>
				<dd>in file folder.class.php, variable <a href="io/filesystem/Folder.php#var$folders">Folder::$folders</a></dd>
							<dt><strong>File</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodFile">File::File()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a File object.</dd>
							<dt><strong>File</strong></dt>
				<dd>in file file.class.php, class <a href="io/filesystem/File.php">File</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a text file which can be read and written.</dd>
							<dt><strong>FileSystemElement</strong></dt>
				<dd>in file file_system_element.class.php, class <a href="io/filesystem/FileSystemElement.php">FileSystemElement</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents any file system element.</dd>
							<dt><strong>FileSystemElement</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodFileSystemElement">FileSystemElement::FileSystemElement()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FileSystemElement object from the path of the element.</dd>
							<dt><strong>finclude</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodfinclude">File::finclude()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Includes the file. Executes its PHP content here. Equivalent to the PHP include function.</dd>
							<dt><strong>flush</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodflush">File::flush()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;forces a write of all buffered output.</dd>
							<dt><strong>Folder</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodFolder">Folder::Folder()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Folder object.</dd>
							<dt><strong>Folder</strong></dt>
				<dd>in file folder.class.php, class <a href="io/filesystem/Folder.php">Folder</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to handle very easily a folder on the serveur.</dd>
							<dt><strong>frequire</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodfrequire">File::frequire()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Requires the file. Executes its PHP content here. Equivalent to the PHP require function.</dd>
							<dt><strong>file.class.php</strong></dt>
				<dd>procedural page <a href="io/filesystem/_io---filesystem---file.class.php.php">file.class.php</a></dd>
							<dt><strong>file_system_element.class.php</strong></dt>
				<dd>procedural page <a href="io/filesystem/_io---filesystem---file_system_element.class.php.php">file_system_element.class.php</a></dd>
							<dt><strong>folder.class.php</strong></dt>
				<dd>procedural page <a href="io/filesystem/_io---filesystem---folder.class.php.php">folder.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>get_content</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_content">Mail::get_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail content.</dd>
							<dt><strong>get_headers</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_headers">Mail::get_headers()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail headers.</dd>
							<dt><strong>get_mime</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_mime">Mail::get_mime()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the MIME type of the mail content</dd>
							<dt><strong>get_module_data_path</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodget_module_data_path">Template::get_module_data_path()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the path of the module. This path will be used to write the relative paths in your templates.</dd>
							<dt><strong>get_object</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_object">Mail::get_object()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail object.</dd>
							<dt><strong>get_recipients</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_recipients">Mail::get_recipients()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail recipients' addresses. They are separated by a comma.</dd>
							<dt><strong>get_sender_mail</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_sender_mail">Mail::get_sender_mail()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail address of the sender.</dd>
							<dt><strong>get_sender_name</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_sender_name">Mail::get_sender_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail sender's name.</dd>
							<dt><strong>get</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodget">FileSystemElement::get()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Initializes the file system element just before to be read.</dd>
							<dt><strong>get_all_content</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_all_content">Folder::get_all_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns all the file system elements contained by the folder.</dd>
							<dt><strong>get_contents</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_contents">File::get_contents()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the content of the file.</dd>
							<dt><strong>get_files</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_files">Folder::get_files()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the files contained in this folder.</dd>
							<dt><strong>get_first_folder</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_first_folder">Folder::get_first_folder()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the first folder present in this folder</dd>
							<dt><strong>get_folders</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_folders">Folder::get_folders()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the folders contained in this folder.</dd>
							<dt><strong>get_last_access_date</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_last_access_date">File::get_last_access_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the last access date of the file.</dd>
							<dt><strong>get_last_modification_date</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_last_modification_date">File::get_last_modification_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the date of the last modification of the file.</dd>
							<dt><strong>get_lines</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_lines">File::get_lines()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the content of the file grouped by lines.</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodget_name">FileSystemElement::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the element name.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>$headers</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$headers">Mail::$headers</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$is_open</strong></dt>
				<dd>in file file_system_element.class.php, variable <a href="io/filesystem/FileSystemElement.php#var$is_open">FileSystemElement::$is_open</a></dd>
							<dt><strong>is_open</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodis_open">File::is_open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Allows you to know if the file is already open.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>$lines</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$lines">File::$lines</a></dd>
							<dt><strong>lock</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodlock">File::lock()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Locks the file (it won't be readable by another thread which could try to access it).</dd>
							<dt><strong>LOCK</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineLOCK">LOCK</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>$module_data_path</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$module_data_path">Template::$module_data_path</a></dd>
							<dt><strong>mail.class.php</strong></dt>
				<dd>procedural page <a href="io/_io---mail.class.php.php">mail.class.php</a></dd>
							<dt><strong>Mail</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodMail">Mail::Mail()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Mail object.</dd>
							<dt><strong>Mail</strong></dt>
				<dd>in file mail.class.php, class <a href="io/Mail.php">Mail</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to send mails without having to deal with the mail headers and parameters.</dd>
							<dt><strong>MIME_FORMAT_HTML</strong></dt>
				<dd>in file mail.class.php, constant <a href="io/_io---mail.class.php.php#defineMIME_FORMAT_HTML">MIME_FORMAT_HTML</a></dd>
							<dt><strong>MIME_FORMAT_TEXT</strong></dt>
				<dd>in file mail.class.php, constant <a href="io/_io---mail.class.php.php#defineMIME_FORMAT_TEXT">MIME_FORMAT_TEXT</a></dd>
							<dt><strong>$mode</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$mode">File::$mode</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>NO_DELETE_ON_ERROR</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineNO_DELETE_ON_ERROR">NO_DELETE_ON_ERROR</a></dd>
							<dt><strong>NO_UNIQ_NAME</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineNO_UNIQ_NAME">NO_UNIQ_NAME</a></dd>
							<dt><strong>NOTCLOSEFILE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineNOTCLOSEFILE">NOTCLOSEFILE</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="o"></a>
	<div>
		<h2>o</h2>
		<dl>
							<dt><strong>$object</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$object">Mail::$object</a></dd>
							<dt><strong>open</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodopen">File::open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Opens the file. You cannot read or write a closed file, use this method to open it.</dd>
							<dt><strong>open</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodopen">Folder::open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Opens the folder.</dd>
							<dt><strong>open</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodopen">FileSystemElement::open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Opens the file system element.</dd>
							<dt><strong>OPEN_AFTER</strong></dt>
				<dd>in file file_system_element.class.php, constant <a href="io/filesystem/_io---filesystem---file_system_element.class.php.php#defineOPEN_AFTER">OPEN_AFTER</a></dd>
							<dt><strong>OPEN_NOW</strong></dt>
				<dd>in file file_system_element.class.php, constant <a href="io/filesystem/_io---filesystem---file_system_element.class.php.php#defineOPEN_NOW">OPEN_NOW</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>parse</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodparse">Template::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the file. It will use the variables you assigned.</dd>
							<dt><strong>pparse</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodpparse">Template::pparse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the file whose name is $parse_name and which has been declared with the set_filenames_method. It uses the variables you assigned (when you assign a variable it will be usable in every file handled by this object).</dd>
							<dt><strong>$path</strong></dt>
				<dd>in file file_system_element.class.php, variable <a href="io/filesystem/FileSystemElement.php#var$path">FileSystemElement::$path</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>$recipients</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$recipients">Mail::$recipients</a></dd>
							<dt><strong>$return_mode</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$return_mode">Template::$return_mode</a></dd>
							<dt><strong>READ</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineREAD">READ</a></dd>
							<dt><strong>READ_WRITE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineREAD_WRITE">READ_WRITE</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>$sender_mail</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$sender_mail">Mail::$sender_mail</a></dd>
							<dt><strong>$sender_name</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$sender_name">Mail::$sender_name</a></dd>
							<dt><strong>send</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodsend">Mail::send()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sends the mail.</dd>
							<dt><strong>send_from_properties</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodsend_from_properties">Mail::send_from_properties()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sends the mail.</dd>
							<dt><strong>set_content</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_content">Mail::set_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The mail content.</dd>
							<dt><strong>set_filenames</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodset_filenames">Template::set_filenames()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads several files in the same Template instance.</dd>
							<dt><strong>set_headers</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_headers">Mail::set_headers()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the headers. Forces them, they won't be generated automatically.</dd>
							<dt><strong>set_mime</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_mime">Mail::set_mime()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the MIME type of the mail content</dd>
							<dt><strong>set_object</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_object">Mail::set_object()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the mail object</dd>
							<dt><strong>set_recipients</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_recipients">Mail::set_recipients()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the recipient(s) of the mail.</dd>
							<dt><strong>set_sender</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_sender">Mail::set_sender()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the mail sender.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$template</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$template">Template::$template</a></dd>
							<dt><strong>$tpl</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$tpl">Template::$tpl</a></dd>
							<dt><strong>template.class.php</strong></dt>
				<dd>procedural page <a href="io/_io---template.class.php.php">template.class.php</a></dd>
							<dt><strong>Template</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodTemplate">Template::Template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Template object.</dd>
							<dt><strong>Template</strong></dt>
				<dd>in file template.class.php, class <a href="io/Template.php">Template</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to handle a template file. Your template files should have the .tpl extension. &lt;h1&gt;The PHPBoost template syntax&lt;/h1&gt; &lt;h2&gt;Simple variables&lt;/h2&gt; A simple variable is accessible with the {NAME} syntax where NAME is its template name. If the variable is not assigned, nothing will be displayed (no error message). Simple variables are assigned by the assign_vars() method. &lt;h2&gt;Loops&lt;/h2&gt; You can make some loops to repeat a pattern, those loops can be nested. A loop has a name (name) and each iteration contains some variables, for example, the variable VAR.<ul><li>START name #</li></ul> My variable is {name.VAR}<ul><li>END name #</li></ul> To nest loops, here is an example:<ul><li>START loop1 #</li></ul> I write my loop1 var here: {loop1.VAR}.<ul><li>START loop1.loop2 #</li></ul> I can write my loop2 var here: {loop1.loop2.VAR} but also my loop1 var of the parent loop: {loop1.VAR}.<ul></ul><ul><li>END loop1 #</li></ul> To assign the variable, see the assign_block_vars() method which creates one iteration. &lt;h2&gt;Conditions&lt;/h2&gt; When you want to display something only in particular case, you can use some condition tests.<ul><li>IF C_MY_TEST #</li></ul> This text will be displayed only if the C_MY_TEST variable is true<ul><li>ENDIF #</li></ul> You can nest some conditions.&lt;/li&gt; &lt;/ul&gt; To be more efficient, this class uses a cache and parses each file only once. &lt;h1&gt;File paths&lt;/h1&gt; The web site can have several themes whose files aren't in the same folders. When you load a file, you just have to load the generic file and the good template file will be loaded dinamically. &lt;h2&gt;Kernel template file&lt;/h2&gt; When you want to load a kernel template file, the path you must indicate is only the name of the file, for example header.tpl loads /template/your_theme/header.tpl and if it doesn't exist, it will load /template/default/header.tpl. &lt;h2&gt;Module template file&lt;/h2&gt; When you want to load a module template file, you must indicate the name of you module and then the name of the file like this: module/file.tpl which will load the /module/templates/file.tpl. If the user themes redefines the file.tpl file for the module module, the file templates/your_theme/modules/module/file.tpl will be loaded. &lt;h2&gt;Menu template file&lt;/h2&gt; To load a file of a menu, use this kind of path: menus/my_menu/file.tpl which will load the /menus/my_menu/templates/file.tpl file. &lt;h2&gt;Framework template file&lt;/h2&gt; To load a framework file, use a path like this: framework/package/file.tpl which will load /templates/your_theme/framework/package/file.tpl if the theme overrides it, otherwise /templates/default/framework/package/file.tpl will be used.</dd>
							<dt><strong>TEMPLATE_STRING_MODE</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineTEMPLATE_STRING_MODE">TEMPLATE_STRING_MODE</a></dd>
							<dt><strong>TEMPLATE_WRITE_MODE</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineTEMPLATE_WRITE_MODE">TEMPLATE_WRITE_MODE</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>upload.class.php</strong></dt>
				<dd>procedural page <a href="io/_io---upload.class.php.php">upload.class.php</a></dd>
							<dt><strong>unassign_block_vars</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodunassign_block_vars">Template::unassign_block_vars()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a block. It won't be browsable any more in your template.</dd>
							<dt><strong>UNIQ_NAME</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineUNIQ_NAME">UNIQ_NAME</a></dd>
							<dt><strong>Upload</strong></dt>
				<dd>in file upload.class.php, method <a href="io/Upload.php#methodUpload">Upload::Upload()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>Upload</strong></dt>
				<dd>in file upload.class.php, class <a href="io/Upload.php">Upload</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides you methods to upload easily files to the ftp.</dd>
							<dt><strong>unlock</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodunlock">File::unlock()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unlocks a file. The file must have been locked before you call this method.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="v"></a>
	<div>
		<h2>v</h2>
		<dl>
							<dt><strong>validate_img</strong></dt>
				<dd>in file upload.class.php, method <a href="io/Upload.php#methodvalidate_img">Upload::validate_img()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks whether an image is compliant to an maximum width and height, otherwise is $delete value is true delete it.</dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
  <hr />
	<a name="w"></a>
	<div>
		<h2>w</h2>
		<dl>
							<dt><strong>write</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodwrite">FileSystemElement::write()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Does the necessary treatment to apply at each writing operation</dd>
							<dt><strong>write</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodwrite">File::write()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Writes some text in the file.</dd>
							<dt><strong>WRITE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineWRITE">WRITE</a></dd>
					</dl>
	</div>
	<a href="elementindex_io.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                        
                                                            <a href="classtrees_io.php" class="menu">class tree: io</a> -
            <a href="elementindex_io.php" class="menu">index: io</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:17 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>