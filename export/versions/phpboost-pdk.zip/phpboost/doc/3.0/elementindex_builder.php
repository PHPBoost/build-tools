<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'builder - Package builder Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('builder', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">builder</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                    
                                                                                                                                                                                                                                                            <a href="classtrees_builder.php" class="menu">class tree: builder</a> - 
                <a href="elementindex_builder.php" class="menu">index: builder</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="builder/form/FormBuilder.php">FormBuilder</a>            </li>
                    <li>
                <a href="builder/form/FormCheckbox.php">FormCheckbox</a>            </li>
                    <li>
                <a href="builder/form/FormCheckboxOption.php">FormCheckboxOption</a>            </li>
                    <li>
                <a href="builder/form/FormField.php">FormField</a>            </li>
                    <li>
                <a href="builder/form/FormFieldset.php">FormFieldset</a>            </li>
                    <li>
                <a href="builder/form/FormFileUploader.php">FormFileUploader</a>            </li>
                    <li>
                <a href="builder/form/FormHiddenField.php">FormHiddenField</a>            </li>
                    <li>
                <a href="builder/form/FormRadioChoice.php">FormRadioChoice</a>            </li>
                    <li>
                <a href="builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a>            </li>
                    <li>
                <a href="builder/form/FormSelect.php">FormSelect</a>            </li>
                    <li>
                <a href="builder/form/FormSelectOption.php">FormSelectOption</a>            </li>
                    <li>
                <a href="builder/form/FormTextarea.php">FormTextarea</a>            </li>
                    <li>
                <a href="builder/form/FormTextEdit.php">FormTextEdit</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="builder/form/_builder---form---form_builder.class.php.php">                form_builder.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_checkbox.class.php.php">                form_checkbox.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_checkbox_option.class.php.php">                form_checkbox_option.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_field.class.php.php">                form_field.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_fieldset.class.php.php">                form_fieldset.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_file_uploader.class.php.php">                form_file_uploader.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_hidden_field.class.php.php">                form_hidden_field.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_radio_choice.class.php.php">                form_radio_choice.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_radio_choice_option.class.php.php">                form_radio_choice_option.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_select.class.php.php">                form_select.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_select_option.class.php.php">                form_select_option.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_textarea.class.php.php">                form_textarea.class.php
                </a>            </li>
                    <li>
                <a href="builder/form/_builder---form---form_text_edit.class.php.php">                form_text_edit.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package builder</h1>
	[ <a href="elementindex_builder.php#a">a</a> ]
	[ <a href="elementindex_builder.php#d">d</a> ]
	[ <a href="elementindex_builder.php#f">f</a> ]
	[ <a href="elementindex_builder.php#g">g</a> ]
	[ <a href="elementindex_builder.php#o">o</a> ]
	[ <a href="elementindex_builder.php#s">s</a> ]
	[ <a href="elementindex_builder.php#t">t</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>add_errors</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodadd_errors">FormField::add_errors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Merge errors.</dd>
							<dt><strong>add_field</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodadd_field">FormFieldset::add_field()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Store fields in the fieldset.</dd>
							<dt><strong>add_fieldset</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodadd_fieldset">FormBuilder::add_fieldset()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add fieldset in the form.</dd>
							<dt><strong>add_option</strong></dt>
				<dd>in file form_select.class.php, method <a href="builder/form/FormSelect.php#methodadd_option">FormSelect::add_option()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add an option for the radio field.</dd>
							<dt><strong>add_option</strong></dt>
				<dd>in file form_checkbox.class.php, method <a href="builder/form/FormCheckbox.php#methodadd_option">FormCheckbox::add_option()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add an option for the radio field.</dd>
							<dt><strong>add_option</strong></dt>
				<dd>in file form_radio_choice.class.php, method <a href="builder/form/FormRadioChoice.php#methodadd_option">FormRadioChoice::add_option()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add an option for the radio field.</dd>
					</dl>
	</div>
	<a href="elementindex_builder.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>$display_preview</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$display_preview">FormBuilder::$display_preview</a></dd>
							<dt><strong>$display_reset</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$display_reset">FormBuilder::$display_reset</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_hidden_field.class.php, method <a href="builder/form/FormHiddenField.php#methoddisplay">FormHiddenField::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_file_uploader.class.php, method <a href="builder/form/FormFileUploader.php#methoddisplay">FormFileUploader::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_radio_choice_option.class.php, method <a href="builder/form/FormRadioChoiceOption.php#methoddisplay">FormRadioChoiceOption::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_select.class.php, method <a href="builder/form/FormSelect.php#methoddisplay">FormSelect::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_radio_choice.class.php, method <a href="builder/form/FormRadioChoice.php#methoddisplay">FormRadioChoice::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_checkbox_option.class.php, method <a href="builder/form/FormCheckboxOption.php#methoddisplay">FormCheckboxOption::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_text_edit.class.php, method <a href="builder/form/FormTextEdit.php#methoddisplay">FormTextEdit::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methoddisplay">FormBuilder::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the form</dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_textarea.class.php, method <a href="builder/form/FormTextarea.php#methoddisplay">FormTextarea::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_checkbox.class.php, method <a href="builder/form/FormCheckbox.php#methoddisplay">FormCheckbox::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_select_option.class.php, method <a href="builder/form/FormSelectOption.php#methoddisplay">FormSelectOption::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methoddisplay">FormFieldset::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the form</dd>
							<dt><strong>display_preview_button</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methoddisplay_preview_button">FormFieldset::display_preview_button()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display a preview button for the specified field.</dd>
							<dt><strong>display_preview_button</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methoddisplay_preview_button">FormBuilder::display_preview_button()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display a preview button for the specified field.</dd>
							<dt><strong>display_reset</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methoddisplay_reset">FormBuilder::display_reset()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display a reset button for the form.</dd>
					</dl>
	</div>
	<a href="elementindex_builder.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$fieldset_display_required</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_display_required">FormFieldset::$fieldset_display_required</a></dd>
							<dt><strong>$fieldset_errors</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_errors">FormFieldset::$fieldset_errors</a></dd>
							<dt><strong>$fieldset_fields</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_fields">FormFieldset::$fieldset_fields</a></dd>
							<dt><strong>$fieldset_title</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_title">FormFieldset::$fieldset_title</a></dd>
							<dt><strong>$field_cols</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_cols">FormTextarea::$field_cols</a></dd>
							<dt><strong>$field_css_class</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_css_class">FormField::$field_css_class</a></dd>
							<dt><strong>$field_editor</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_editor">FormTextarea::$field_editor</a></dd>
							<dt><strong>$field_errors</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_errors">FormField::$field_errors</a></dd>
							<dt><strong>$field_forbidden_tags</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_forbidden_tags">FormTextarea::$field_forbidden_tags</a></dd>
							<dt><strong>$field_id</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_id">FormField::$field_id</a></dd>
							<dt><strong>$field_identifier_preview</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$field_identifier_preview">FormBuilder::$field_identifier_preview</a></dd>
							<dt><strong>$field_maxlength</strong></dt>
				<dd>in file form_text_edit.class.php, variable <a href="builder/form/FormTextEdit.php#var$field_maxlength">FormTextEdit::$field_maxlength</a></dd>
							<dt><strong>$field_multiple</strong></dt>
				<dd>in file form_select.class.php, variable <a href="builder/form/FormSelect.php#var$field_multiple">FormSelect::$field_multiple</a></dd>
							<dt><strong>$field_name</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_name">FormField::$field_name</a></dd>
							<dt><strong>$field_on_blur</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_on_blur">FormField::$field_on_blur</a></dd>
							<dt><strong>$field_options</strong></dt>
				<dd>in file form_select.class.php, variable <a href="builder/form/FormSelect.php#var$field_options">FormSelect::$field_options</a></dd>
							<dt><strong>$field_options</strong></dt>
				<dd>in file form_radio_choice.class.php, variable <a href="builder/form/FormRadioChoice.php#var$field_options">FormRadioChoice::$field_options</a></dd>
							<dt><strong>$field_options</strong></dt>
				<dd>in file form_checkbox.class.php, variable <a href="builder/form/FormCheckbox.php#var$field_options">FormCheckbox::$field_options</a></dd>
							<dt><strong>$field_required</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_required">FormField::$field_required</a></dd>
							<dt><strong>$field_required_alert</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_required_alert">FormField::$field_required_alert</a></dd>
							<dt><strong>$field_rows</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_rows">FormTextarea::$field_rows</a></dd>
							<dt><strong>$field_size</strong></dt>
				<dd>in file form_text_edit.class.php, variable <a href="builder/form/FormTextEdit.php#var$field_size">FormTextEdit::$field_size</a></dd>
							<dt><strong>$field_size</strong></dt>
				<dd>in file form_file_uploader.class.php, variable <a href="builder/form/FormFileUploader.php#var$field_size">FormFileUploader::$field_size</a></dd>
							<dt><strong>$field_sub_title</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_sub_title">FormField::$field_sub_title</a></dd>
							<dt><strong>$field_title</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_title">FormField::$field_title</a></dd>
							<dt><strong>$field_value</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_value">FormField::$field_value</a></dd>
							<dt><strong>$form_action</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_action">FormBuilder::$form_action</a></dd>
							<dt><strong>$form_class</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_class">FormBuilder::$form_class</a></dd>
							<dt><strong>$form_fieldsets</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_fieldsets">FormBuilder::$form_fieldsets</a></dd>
							<dt><strong>$form_name</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_name">FormBuilder::$form_name</a></dd>
							<dt><strong>$form_submit</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_submit">FormBuilder::$form_submit</a></dd>
							<dt><strong>form_builder.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_builder.class.php.php">form_builder.class.php</a></dd>
							<dt><strong>form_checkbox.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_checkbox.class.php.php">form_checkbox.class.php</a></dd>
							<dt><strong>form_checkbox_option.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_checkbox_option.class.php.php">form_checkbox_option.class.php</a></dd>
							<dt><strong>form_field.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_field.class.php.php">form_field.class.php</a></dd>
							<dt><strong>form_fieldset.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_fieldset.class.php.php">form_fieldset.class.php</a></dd>
							<dt><strong>form_file_uploader.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_file_uploader.class.php.php">form_file_uploader.class.php</a></dd>
							<dt><strong>form_hidden_field.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_hidden_field.class.php.php">form_hidden_field.class.php</a></dd>
							<dt><strong>form_radio_choice.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_radio_choice.class.php.php">form_radio_choice.class.php</a></dd>
							<dt><strong>form_radio_choice_option.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_radio_choice_option.class.php.php">form_radio_choice_option.class.php</a></dd>
							<dt><strong>form_select.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_select.class.php.php">form_select.class.php</a></dd>
							<dt><strong>form_select_option.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_select_option.class.php.php">form_select_option.class.php</a></dd>
							<dt><strong>form_textarea.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_textarea.class.php.php">form_textarea.class.php</a></dd>
							<dt><strong>form_text_edit.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_text_edit.class.php.php">form_text_edit.class.php</a></dd>
							<dt><strong>FIELD_INPUT__CHECKBOX</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__CHECKBOX">FIELD_INPUT__CHECKBOX</a></dd>
							<dt><strong>FIELD_INPUT__FILE</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__FILE">FIELD_INPUT__FILE</a></dd>
							<dt><strong>FIELD_INPUT__HIDDEN</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__HIDDEN">FIELD_INPUT__HIDDEN</a></dd>
							<dt><strong>FIELD_INPUT__RADIO</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__RADIO">FIELD_INPUT__RADIO</a></dd>
							<dt><strong>FIELD_INPUT__TEXT</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__TEXT">FIELD_INPUT__TEXT</a></dd>
							<dt><strong>FIELD__SELECT</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD__SELECT">FIELD__SELECT</a></dd>
							<dt><strong>FIELD__TEXTAREA</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD__TEXTAREA">FIELD__TEXTAREA</a></dd>
							<dt><strong>FormBuilder</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodFormBuilder">FormBuilder::FormBuilder()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>FormBuilder</strong></dt>
				<dd>in file form_builder.class.php, class <a href="builder/form/FormBuilder.php">FormBuilder</a></dd>
							<dt><strong>FormCheckbox</strong></dt>
				<dd>in file form_checkbox.class.php, method <a href="builder/form/FormCheckbox.php#methodFormCheckbox">FormCheckbox::FormCheckbox()</a></dd>
							<dt><strong>FormCheckbox</strong></dt>
				<dd>in file form_checkbox.class.php, class <a href="builder/form/FormCheckbox.php">FormCheckbox</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages checkbox input fields.</dd>
							<dt><strong>FormCheckboxOption</strong></dt>
				<dd>in file form_checkbox_option.class.php, class <a href="builder/form/FormCheckboxOption.php">FormCheckboxOption</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages the checkbox fields. It provides you some additionnal field options: <ul><li>optiontitle : The option title</li><li>checked : Specify it whether the option has to be checked.</li></ul></dd>
							<dt><strong>FormCheckboxOption</strong></dt>
				<dd>in file form_checkbox_option.class.php, method <a href="builder/form/FormCheckboxOption.php#methodFormCheckboxOption">FormCheckboxOption::FormCheckboxOption()</a></dd>
							<dt><strong>FormField</strong></dt>
				<dd>in file form_field.class.php, class <a href="builder/form/FormField.php">FormField</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Abstract class which manage Fields. You can specify several option with the argument $fieldOptions : <ul><li>title : The field title</li><li>subtitle : The field subtitle</li><li>value : The default value for the field</li><li>id : The field identifier</li><li>class : The css class used for the field</li><li>required : Specify if the field is required.</li><li>onblur : Action performed when cursor is clicked outside the field area. (javascript)</li></ul></dd>
							<dt><strong>FormField</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodFormField">FormField::FormField()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>FormFieldset</strong></dt>
				<dd>in file form_fieldset.class.php, class <a href="builder/form/FormFieldset.php">FormFieldset</a></dd>
							<dt><strong>FormFieldset</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodFormFieldset">FormFieldset::FormFieldset()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>FormFileUploader</strong></dt>
				<dd>in file form_file_uploader.class.php, class <a href="builder/form/FormFileUploader.php">FormFileUploader</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage file input fields. It provides you additionnal field options : <ul><li>size : The size for the field</li></ul></dd>
							<dt><strong>FormFileUploader</strong></dt>
				<dd>in file form_file_uploader.class.php, method <a href="builder/form/FormFileUploader.php#methodFormFileUploader">FormFileUploader::FormFileUploader()</a></dd>
							<dt><strong>FormHiddenField</strong></dt>
				<dd>in file form_hidden_field.class.php, class <a href="builder/form/FormHiddenField.php">FormHiddenField</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage hidden input fields.</dd>
							<dt><strong>FormHiddenField</strong></dt>
				<dd>in file form_hidden_field.class.php, method <a href="builder/form/FormHiddenField.php#methodFormHiddenField">FormHiddenField::FormHiddenField()</a></dd>
							<dt><strong>FormRadioChoice</strong></dt>
				<dd>in file form_radio_choice.class.php, method <a href="builder/form/FormRadioChoice.php#methodFormRadioChoice">FormRadioChoice::FormRadioChoice()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor It takes a variable number of parameters. The first two are required.</dd>
							<dt><strong>FormRadioChoice</strong></dt>
				<dd>in file form_radio_choice.class.php, class <a href="builder/form/FormRadioChoice.php">FormRadioChoice</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage radio input fields.</dd>
							<dt><strong>FormRadioChoiceOption</strong></dt>
				<dd>in file form_radio_choice_option.class.php, class <a href="builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage radio input field options. It provides you additionnal field options : <ul><li>optiontitle : The option title</li><li>checked : Specify if the option has to be checked.</li></ul></dd>
							<dt><strong>FormRadioChoiceOption</strong></dt>
				<dd>in file form_radio_choice_option.class.php, method <a href="builder/form/FormRadioChoiceOption.php#methodFormRadioChoiceOption">FormRadioChoiceOption::FormRadioChoiceOption()</a></dd>
							<dt><strong>FormSelect</strong></dt>
				<dd>in file form_select.class.php, class <a href="builder/form/FormSelect.php">FormSelect</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage select fields. It provides you additionnal field options : <ul><li>multiple : Type of select field, mutiple allow you to check several options.</li></ul></dd>
							<dt><strong>FormSelect</strong></dt>
				<dd>in file form_select.class.php, method <a href="builder/form/FormSelect.php#methodFormSelect">FormSelect::FormSelect()</a></dd>
							<dt><strong>FormSelectOption</strong></dt>
				<dd>in file form_select_option.class.php, class <a href="builder/form/FormSelectOption.php">FormSelectOption</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage select field options.</dd>
							<dt><strong>FormSelectOption</strong></dt>
				<dd>in file form_select_option.class.php, method <a href="builder/form/FormSelectOption.php#methodFormSelectOption">FormSelectOption::FormSelectOption()</a></dd>
							<dt><strong>FormTextarea</strong></dt>
				<dd>in file form_textarea.class.php, class <a href="builder/form/FormTextarea.php">FormTextarea</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage multi-line text fields.</dd>
							<dt><strong>FormTextarea</strong></dt>
				<dd>in file form_textarea.class.php, method <a href="builder/form/FormTextarea.php#methodFormTextarea">FormTextarea::FormTextarea()</a></dd>
							<dt><strong>FormTextEdit</strong></dt>
				<dd>in file form_text_edit.class.php, method <a href="builder/form/FormTextEdit.php#methodFormTextEdit">FormTextEdit::FormTextEdit()</a></dd>
							<dt><strong>FormTextEdit</strong></dt>
				<dd>in file form_text_edit.class.php, class <a href="builder/form/FormTextEdit.php">FormTextEdit</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage single-line text fields. It provides you additionnal field options : <ul><li>size : The maximum size for the field</li><li>maxlength : The maximum length for the field</li><li>required_alert : Text displayed if field is empty (javscript only)</li></ul></dd>
					</dl>
	</div>
	<a href="elementindex_builder.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>get_display_required</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodget_display_required">FormFieldset::get_display_required()</a></dd>
							<dt><strong>get_errors</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodget_errors">FormField::get_errors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get all errors occured in the field construct process.</dd>
							<dt><strong>get_fields</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodget_fields">FormFieldset::get_fields()</a></dd>
							<dt><strong>get_form_action</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_action">FormBuilder::get_form_action()</a></dd>
							<dt><strong>get_form_class</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_class">FormBuilder::get_form_class()</a></dd>
							<dt><strong>get_form_name</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_name">FormBuilder::get_form_name()</a></dd>
							<dt><strong>get_form_submit</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_submit">FormBuilder::get_form_submit()</a></dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodget_id">FormField::get_id()</a></dd>
							<dt><strong>get_required_alert</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodget_required_alert">FormField::get_required_alert()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodget_title">FormFieldset::get_title()</a></dd>
					</dl>
	</div>
	<a href="elementindex_builder.php#top">top</a><br />
  <hr />
	<a name="o"></a>
	<div>
		<h2>o</h2>
		<dl>
							<dt><strong>$option_checked</strong></dt>
				<dd>in file form_checkbox_option.class.php, variable <a href="builder/form/FormCheckboxOption.php#var$option_checked">FormCheckboxOption::$option_checked</a></dd>
							<dt><strong>$option_checked</strong></dt>
				<dd>in file form_radio_choice_option.class.php, variable <a href="builder/form/FormRadioChoiceOption.php#var$option_checked">FormRadioChoiceOption::$option_checked</a></dd>
							<dt><strong>$option_selected</strong></dt>
				<dd>in file form_select_option.class.php, variable <a href="builder/form/FormSelectOption.php#var$option_selected">FormSelectOption::$option_selected</a></dd>
							<dt><strong>$option_title</strong></dt>
				<dd>in file form_select_option.class.php, variable <a href="builder/form/FormSelectOption.php#var$option_title">FormSelectOption::$option_title</a></dd>
							<dt><strong>$option_title</strong></dt>
				<dd>in file form_radio_choice_option.class.php, variable <a href="builder/form/FormRadioChoiceOption.php#var$option_title">FormRadioChoiceOption::$option_title</a></dd>
							<dt><strong>$option_title</strong></dt>
				<dd>in file form_checkbox_option.class.php, variable <a href="builder/form/FormCheckboxOption.php#var$option_title">FormCheckboxOption::$option_title</a></dd>
					</dl>
	</div>
	<a href="elementindex_builder.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>set_display_required</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodset_display_required">FormFieldset::set_display_required()</a></dd>
							<dt><strong>set_form_action</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_action">FormBuilder::set_form_action()</a></dd>
							<dt><strong>set_form_class</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_class">FormBuilder::set_form_class()</a></dd>
							<dt><strong>set_form_name</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_name">FormBuilder::set_form_name()</a></dd>
							<dt><strong>set_form_submit</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_submit">FormBuilder::set_form_submit()</a></dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodset_title">FormFieldset::set_title()</a></dd>
					</dl>
	</div>
	<a href="elementindex_builder.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>throw_error</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodthrow_error">FormFieldset::throw_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Store all erros in the field construct process.</dd>
							<dt><strong>throw_error</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodthrow_error">FormField::throw_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Store all erros in the field construct process.</dd>
					</dl>
	</div>
	<a href="elementindex_builder.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                
                                                                                                                                                                                    <a href="classtrees_builder.php" class="menu">class tree: builder</a> -
            <a href="elementindex_builder.php" class="menu">index: builder</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:35 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>