<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'modules - Package modules Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('modules', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">modules</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="classtrees_modules.php" class="menu">class tree: modules</a> - 
                <a href="elementindex_modules.php" class="menu">index: modules</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="modules/ModuleInterface.php">ModuleInterface</a>            </li>
                    <li>
                <a href="modules/ModulesDiscoveryService.php">ModulesDiscoveryService</a>            </li>
                    <li>
                <a href="modules/PackagesManager.php">PackagesManager</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="modules/_modules---modules_discovery_service.class.php.php">                modules_discovery_service.class.php
                </a>            </li>
                    <li>
                <a href="modules/_modules---module_interface.class.php.php">                module_interface.class.php
                </a>            </li>
                    <li>
                <a href="modules/_modules---packages_manager.class.php.php">                packages_manager.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package modules</h1>
	[ <a href="elementindex_modules.php#a">a</a> ]
	[ <a href="elementindex_modules.php#c">c</a> ]
	[ <a href="elementindex_modules.php#d">d</a> ]
	[ <a href="elementindex_modules.php#e">e</a> ]
	[ <a href="elementindex_modules.php#f">f</a> ]
	[ <a href="elementindex_modules.php#g">g</a> ]
	[ <a href="elementindex_modules.php#h">h</a> ]
	[ <a href="elementindex_modules.php#i">i</a> ]
	[ <a href="elementindex_modules.php#l">l</a> ]
	[ <a href="elementindex_modules.php#m">m</a> ]
	[ <a href="elementindex_modules.php#n">n</a> ]
	[ <a href="elementindex_modules.php#p">p</a> ]
	[ <a href="elementindex_modules.php#s">s</a> ]
	[ <a href="elementindex_modules.php#u">u</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>$attributes</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$attributes">ModuleInterface::$attributes</a></dd>
							<dt><strong>$available_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, variable <a href="modules/ModulesDiscoveryService.php#var$available_modules">ModulesDiscoveryService::$available_modules</a></dd>
							<dt><strong>ACCES_DENIED</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineACCES_DENIED">ACCES_DENIED</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>CONFIG_CONFLICT</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineCONFIG_CONFLICT">CONFIG_CONFLICT</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>DO_NOT_GENERATE_CACHE_AFTER_THE_OPERATION</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineDO_NOT_GENERATE_CACHE_AFTER_THE_OPERATION">DO_NOT_GENERATE_CACHE_AFTER_THE_OPERATION</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>$enabled</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$enabled">ModuleInterface::$enabled</a></dd>
							<dt><strong>$errors</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$errors">ModuleInterface::$errors</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$functionalities</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$functionalities">ModuleInterface::$functionalities</a></dd>
							<dt><strong>functionality</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodfunctionality">ModulesDiscoveryService::functionality()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Call the method call functionality on each speficied modules</dd>
							<dt><strong>functionality</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodfunctionality">ModuleInterface::functionality()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the existance of the functionality and if exists call it.  If she's not available, the FUNCTIONNALITY_NOT_IMPLEMENTED flag is raised.</dd>
							<dt><strong>FUNCTIONNALITY_NOT_IMPLEMENTED</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineFUNCTIONNALITY_NOT_IMPLEMENTED">FUNCTIONNALITY_NOT_IMPLEMENTED</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>GENERATE_CACHE_AFTER_THE_OPERATION</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineGENERATE_CACHE_AFTER_THE_OPERATION">GENERATE_CACHE_AFTER_THE_OPERATION</a></dd>
							<dt><strong>get_all_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodget_all_modules">ModulesDiscoveryService::get_all_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a list with all the modules in it, even with those that have no ModuleInterface. Useful to do generic operations on modules.</dd>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_attribute">ModuleInterface::get_attribute()</a></dd>
							<dt><strong>get_available_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodget_available_modules">ModulesDiscoveryService::get_available_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the ModuleInterface list.</dd>
							<dt><strong>get_errors</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_errors">ModuleInterface::get_errors()</a></dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_id">ModuleInterface::get_id()</a></dd>
							<dt><strong>get_infos</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_infos">ModuleInterface::get_infos()</a></dd>
							<dt><strong>get_module</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodget_module">ModulesDiscoveryService::get_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the ModuleInterface of the module which id is $module_id.</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_name">ModuleInterface::get_name()</a></dd>
							<dt><strong>got_error</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodgot_error">ModuleInterface::got_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the last error. If called with no arguments, returns true if an error has occured  otherwise, false. If the method got an argument,</dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>has_functionalities</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodhas_functionalities">ModuleInterface::has_functionalities()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the availability of the functionalities (hook)</dd>
							<dt><strong>has_functionality</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodhas_functionality">ModuleInterface::has_functionality()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the availability of the functionality (hook)</dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$id</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$id">ModuleInterface::$id</a></dd>
							<dt><strong>$infos</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$infos">ModuleInterface::$infos</a></dd>
							<dt><strong>install_module</strong></dt>
				<dd>in file packages_manager.class.php, method <a href="modules/PackagesManager.php#methodinstall_module">PackagesManager::install_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Installs a module.</dd>
							<dt><strong>is_enabled</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodis_enabled">ModuleInterface::is_enabled()</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>$loaded_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, variable <a href="modules/ModulesDiscoveryService.php#var$loaded_modules">ModulesDiscoveryService::$loaded_modules</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>ModuleInterface</strong></dt>
				<dd>in file module_interface.class.php, class <a href="modules/ModuleInterface.php">ModuleInterface</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This Class allow you to call methods on a ModuleInterface extended class that you're not sure of the method's availality. It also provides a set of generic methods that you could use to integrate your module with others, or allow your module to share services.</dd>
							<dt><strong>ModuleInterface</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodModuleInterface">ModuleInterface::ModuleInterface()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;ModuleInterface constructor</dd>
							<dt><strong>modules_discovery_service.class.php</strong></dt>
				<dd>procedural page <a href="modules/_modules---modules_discovery_service.class.php.php">modules_discovery_service.class.php</a></dd>
							<dt><strong>module_interface.class.php</strong></dt>
				<dd>procedural page <a href="modules/_modules---module_interface.class.php.php">module_interface.class.php</a></dd>
							<dt><strong>ModulesDiscoveryService</strong></dt>
				<dd>in file modules_discovery_service.class.php, class <a href="modules/ModulesDiscoveryService.php">ModulesDiscoveryService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is a ModuleInterface factory providing some services like mass operations (on several modules at the same time) or identifications methods to get all modules that provide a given functionality</dd>
							<dt><strong>ModulesDiscoveryService</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodModulesDiscoveryService">ModulesDiscoveryService::ModulesDiscoveryService()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new ModuleInterface factory</dd>
							<dt><strong>MODULE_ALREADY_INSTALLED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_ALREADY_INSTALLED">MODULE_ALREADY_INSTALLED</a></dd>
							<dt><strong>MODULE_ATTRIBUTE_DOES_NOT_EXIST</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineMODULE_ATTRIBUTE_DOES_NOT_EXIST">MODULE_ATTRIBUTE_DOES_NOT_EXIST</a></dd>
							<dt><strong>MODULE_FILES_COULD_NOT_BE_DROPPED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_FILES_COULD_NOT_BE_DROPPED">MODULE_FILES_COULD_NOT_BE_DROPPED</a></dd>
							<dt><strong>MODULE_INSTALLED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_INSTALLED">MODULE_INSTALLED</a></dd>
							<dt><strong>MODULE_NOT_AVAILABLE</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineMODULE_NOT_AVAILABLE">MODULE_NOT_AVAILABLE</a><br>&nbsp;&nbsp;&nbsp;&nbsp;module_interface.                            -------------------   begin                : January 15, 2008   copyright            : (C) 2008 Lo�c Rouchon   email                : horn@phpboost.
###################################################
   This program is free software; you can redistribute it and/or modify   it under the terms of the GNU General Public License as published by   the Free Software Foundation; either version 2 of the License, or   (at your option) any later version.</dd>
							<dt><strong>MODULE_NOT_YET_IMPLEMENTED</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineMODULE_NOT_YET_IMPLEMENTED">MODULE_NOT_YET_IMPLEMENTED</a></dd>
							<dt><strong>MODULE_UNINSTALLED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_UNINSTALLED">MODULE_UNINSTALLED</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>$name</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$name">ModuleInterface::$name</a></dd>
							<dt><strong>NOT_INSTALLED_MODULE</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineNOT_INSTALLED_MODULE">NOT_INSTALLED_MODULE</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>packages_manager.class.php</strong></dt>
				<dd>procedural page <a href="modules/_modules---packages_manager.class.php.php">packages_manager.class.php</a></dd>
							<dt><strong>PackagesManager</strong></dt>
				<dd>in file packages_manager.class.php, class <a href="modules/PackagesManager.php">PackagesManager</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to manages the PHPBoost packages which are nothing else than the modules.</dd>
							<dt><strong>PHP_VERSION_CONFLICT</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#definePHP_VERSION_CONFLICT">PHP_VERSION_CONFLICT</a></dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>set_attribute</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodset_attribute">ModuleInterface::set_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the $value of the attribute identified by the string $attribute.</dd>
							<dt><strong>set_error</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodset_error">ModuleInterface::set_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the flag error.</dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>UNEXISTING_MODULE</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineUNEXISTING_MODULE">UNEXISTING_MODULE</a></dd>
							<dt><strong>uninstall_module</strong></dt>
				<dd>in file packages_manager.class.php, method <a href="modules/PackagesManager.php#methoduninstall_module">PackagesManager::uninstall_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Uninstalls a module.</dd>
							<dt><strong>unset_attribute</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodunset_attribute">ModuleInterface::unset_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete the attribute and free its memory.</dd>
					</dl>
	</div>
	<a href="elementindex_modules.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="classtrees_modules.php" class="menu">class tree: modules</a> -
            <a href="elementindex_modules.php" class="menu">index: modules</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:35 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>