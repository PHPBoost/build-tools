<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Class Trees for Package events');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="elementindex_events.php" class="menu">index: events</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                    </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class Trees for Package events</h1>
<hr />
<br />
<div class="classtree">Root class AdministratorAlertService</div><br />
<ul>
<li><a href="events/AdministratorAlertService.php">AdministratorAlertService</a></li></ul>

<hr />
<br />
<div class="classtree">Root class ContributionService</div><br />
<ul>
<li><a href="events/ContributionService.php">ContributionService</a></li></ul>

<hr />
<br />
<div class="classtree">Root class Event</div><br />
<ul>
<li><a href="events/Event.php">Event</a><ul>
<li><a href="events/AdministratorAlert.php">AdministratorAlert</a></li><li><a href="events/Contribution.php">Contribution</a></li></ul></li>
</ul>

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="classtrees_events.php" class="menu">class tree: events</a> -
            <a href="elementindex_events.php" class="menu">index: events</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:36 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>