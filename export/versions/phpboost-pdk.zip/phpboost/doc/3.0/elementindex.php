<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', ' - Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top"></div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                                                                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                    </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Index of all elements</h1>
	[ <a href="elementindex.php#a">a</a> ]
	[ <a href="elementindex.php#b">b</a> ]
	[ <a href="elementindex.php#c">c</a> ]
	[ <a href="elementindex.php#d">d</a> ]
	[ <a href="elementindex.php#e">e</a> ]
	[ <a href="elementindex.php#f">f</a> ]
	[ <a href="elementindex.php#g">g</a> ]
	[ <a href="elementindex.php#h">h</a> ]
	[ <a href="elementindex.php#i">i</a> ]
	[ <a href="elementindex.php#j">j</a> ]
	[ <a href="elementindex.php#k">k</a> ]
	[ <a href="elementindex.php#l">l</a> ]
	[ <a href="elementindex.php#m">m</a> ]
	[ <a href="elementindex.php#n">n</a> ]
	[ <a href="elementindex.php#o">o</a> ]
	[ <a href="elementindex.php#p">p</a> ]
	[ <a href="elementindex.php#q">q</a> ]
	[ <a href="elementindex.php#r">r</a> ]
	[ <a href="elementindex.php#s">s</a> ]
	[ <a href="elementindex.php#t">t</a> ]
	[ <a href="elementindex.php#u">u</a> ]
	[ <a href="elementindex.php#v">v</a> ]
	[ <a href="elementindex.php#w">w</a> ]
	[ <a href="elementindex.php#x">x</a> ]
	[ <a href="elementindex.php#_">_</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>$apps</strong></dt>
				<dd>in file updates.class.php, variable <a href="core/Updates.php#var$apps">Updates::$apps</a></dd>
							<dt><strong>$archive_all</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$archive_all">Errors::$archive_all</a></dd>
							<dt><strong>$array_allocated_color</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$array_allocated_color">Stats::$array_allocated_color</a></dd>
							<dt><strong>$array_color_stats</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$array_color_stats">Stats::$array_color_stats</a></dd>
							<dt><strong>$array_links</strong></dt>
				<dd>in file breadcrumb.class.php, variable <a href="core/BreadCrumb.php#var$array_links">BreadCrumb::$array_links</a></dd>
							<dt><strong>$array_tags</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$array_tags">Parser::$array_tags</a></dd>
							<dt><strong>$array_tags</strong></dt>
				<dd>in file tinymce_editor.class.php, variable <a href="content/editor/TinyMCEEditor.php#var$array_tags">TinyMCEEditor::$array_tags</a></dd>
							<dt><strong>$array_tags2</strong></dt>
				<dd>in file tinymce_editor.class.php, variable <a href="content/editor/TinyMCEEditor.php#var$array_tags2">TinyMCEEditor::$array_tags2</a></dd>
							<dt><strong>$array_tags3</strong></dt>
				<dd>in file tinymce_editor.class.php, variable <a href="content/editor/TinyMCEEditor.php#var$array_tags3">TinyMCEEditor::$array_tags3</a></dd>
							<dt><strong>$attributes</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$attributes">ModuleInterface::$attributes</a></dd>
							<dt><strong>$auth</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$auth">Menu::$auth</a></dd>
							<dt><strong>$auth</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$auth">FeedItem::$auth</a></dd>
							<dt><strong>$auth</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$auth">Contribution::$auth</a></dd>
							<dt><strong>$authors</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$authors">Application::$authors</a></dd>
							<dt><strong>$auth_bit</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$auth_bit">FeedData::$auth_bit</a></dd>
							<dt><strong>$autoconnect</strong></dt>
				<dd>in file session.class.php, variable <a href="members/Session.php#var$autoconnect">Session::$autoconnect</a></dd>
							<dt><strong>$available_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, variable <a href="modules/ModulesDiscoveryService.php#var$available_modules">ModulesDiscoveryService::$available_modules</a></dd>
							<dt><strong>absolute</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodabsolute">Url::absolute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the absolute url</dd>
							<dt><strong>ACCES_DENIED</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineACCES_DENIED">ACCES_DENIED</a></dd>
							<dt><strong>act</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodact">Session::act()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Manage the actions for the session caused by the user (connection, disconnection).</dd>
							<dt><strong>add</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodadd">BreadCrumb::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a link in the bread crumb. This link will be put at the end of the list.</dd>
							<dt><strong>add</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodadd">CategoriesManager::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a category. We can decide if it will be visible and what its position will be</dd>
							<dt><strong>add</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodadd">Comments::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a comment</dd>
							<dt><strong>ADD</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineADD">ADD</a></dd>
							<dt><strong>add</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodadd">LinksMenu::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a single LinksMenuLink or (sub) Menu</dd>
							<dt><strong>add</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methodadd">Note::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a note on the item. It has to be into the notation scale.</dd>
							<dt><strong>add</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodadd">SiteMapSection::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds an elemement to the section</dd>
							<dt><strong>add</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodadd">SiteMap::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds an element to the elements list of the SiteMap</dd>
							<dt><strong>ADDSLASHES_AUTO</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineADDSLASHES_AUTO">ADDSLASHES_AUTO</a></dd>
							<dt><strong>ADDSLASHES_FORCE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineADDSLASHES_FORCE">ADDSLASHES_FORCE</a></dd>
							<dt><strong>ADDSLASHES_NONE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineADDSLASHES_NONE">ADDSLASHES_NONE</a></dd>
							<dt><strong>add_array</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodadd_array">LinksMenu::add_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a list of LinksMenu or (sub)Menu to the current one</dd>
							<dt><strong>add_child</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodadd_child">FeedsCat::add_child()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a FeedsCat child to the current FeedsCat object</dd>
							<dt><strong>add_errors</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodadd_errors">FormField::add_errors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Merge errors.</dd>
							<dt><strong>add_feed</strong></dt>
				<dd>in file feeds_list.class.php, method <a href="content/syndication/FeedsList.php#methodadd_feed">FeedsList::add_feed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds the FeedsCat $cat_tree to the current feeds list</dd>
							<dt><strong>add_field</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodadd_field">FormFieldset::add_field()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Store fields in the fieldset.</dd>
							<dt><strong>add_fieldset</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodadd_fieldset">FormBuilder::add_fieldset()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add fieldset in the form.</dd>
							<dt><strong>Add_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodAdd_folder">Uploads::Add_folder()</a></dd>
							<dt><strong>add_item</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodadd_item">FeedData::add_item()</a></dd>
							<dt><strong>add_member</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodadd_member">Group::add_member()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a member in a group</dd>
							<dt><strong>add_mini_menu</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodadd_mini_menu">MenuService::add_mini_menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add the menu named in the $menu folder</dd>
							<dt><strong>add_mini_module</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodadd_mini_module">MenuService::add_mini_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add the module named $module mini modules</dd>
							<dt><strong>add_option</strong></dt>
				<dd>in file form_select.class.php, method <a href="builder/form/FormSelect.php#methodadd_option">FormSelect::add_option()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add an option for the radio field.</dd>
							<dt><strong>add_option</strong></dt>
				<dd>in file form_checkbox.class.php, method <a href="builder/form/FormCheckbox.php#methodadd_option">FormCheckbox::add_option()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add an option for the radio field.</dd>
							<dt><strong>add_option</strong></dt>
				<dd>in file form_radio_choice.class.php, method <a href="builder/form/FormRadioChoice.php#methodadd_option">FormRadioChoice::add_option()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add an option for the radio field.</dd>
							<dt><strong>ADD_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#defineADD_SLASHES">ADD_SLASHES</a></dd>
							<dt><strong>ADD_THIS_CATEGORY_IN_LIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineADD_THIS_CATEGORY_IN_LIST">ADD_THIS_CATEGORY_IN_LIST</a></dd>
							<dt><strong>AdministratorAlert</strong></dt>
				<dd>in file administrator_alert.class.php, class <a href="events/AdministratorAlert.php">AdministratorAlert</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents an alert which must be sent to the administrator. It allows to the module developers to handle the administrator alerts. The administrator alerts can be in the administration panel and can be used when you want to signal an important event to the administrator(s).</dd>
							<dt><strong>AdministratorAlert</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodAdministratorAlert">AdministratorAlert::AdministratorAlert()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an AdministratorAlert object.</dd>
							<dt><strong>AdministratorAlertService</strong></dt>
				<dd>in file administrator_alert_service.class.php, class <a href="events/AdministratorAlertService.php">AdministratorAlertService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This static class allows you to handler easily the administrator alerts which can be made in PHPBoost.</dd>
							<dt><strong>ADMINISTRATOR_ALERT_TYPE</strong></dt>
				<dd>in file administrator_alert_service.class.php, constant <a href="events/_events---administrator_alert_service.class.php.php#defineADMINISTRATOR_ALERT_TYPE">ADMINISTRATOR_ALERT_TYPE</a></dd>
							<dt><strong>ADMIN_ALERT_HIGH_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_HIGH_PRIORITY">ADMIN_ALERT_HIGH_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_LOW_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_LOW_PRIORITY">ADMIN_ALERT_LOW_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_MEDIUM_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_MEDIUM_PRIORITY">ADMIN_ALERT_MEDIUM_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_STATUS_PROCESSED</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_STATUS_PROCESSED">ADMIN_ALERT_STATUS_PROCESSED</a></dd>
							<dt><strong>ADMIN_ALERT_STATUS_UNREAD</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_STATUS_UNREAD">ADMIN_ALERT_STATUS_UNREAD</a></dd>
							<dt><strong>ADMIN_ALERT_VERY_HIGH_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_VERY_HIGH_PRIORITY">ADMIN_ALERT_VERY_HIGH_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_VERY_LOW_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_VERY_LOW_PRIORITY">ADMIN_ALERT_VERY_LOW_PRIORITY</a></dd>
							<dt><strong>admin_display</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodadmin_display">Menu::admin_display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu admin gui</dd>
							<dt><strong>ADMIN_NOAUTH_DEFAULT</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineADMIN_NOAUTH_DEFAULT">ADMIN_NOAUTH_DEFAULT</a></dd>
							<dt><strong>ADMIN_NO_CHECK</strong></dt>
				<dd>in file uploads.class.php, constant <a href="members/_members---uploads.class.php.php#defineADMIN_NO_CHECK">ADMIN_NO_CHECK</a></dd>
							<dt><strong>affected_rows</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodaffected_rows">Sql::affected_rows()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of the rows which have been affected by a request.</dd>
							<dt><strong>AJAX_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineAJAX_MODE">AJAX_MODE</a></dd>
							<dt><strong>ALREADY_HASHED</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineALREADY_HASHED">ALREADY_HASHED</a></dd>
							<dt><strong>Application</strong></dt>
				<dd>in file application.class.php, class <a href="core/Application.php">Application</a></dd>
							<dt><strong>Application</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodApplication">Application::Application()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor of the class</dd>
							<dt><strong>APPLICATION_TYPE__KERNEL</strong></dt>
				<dd>in file application.class.php, constant <a href="core/_core---application.class.php.php#defineAPPLICATION_TYPE__KERNEL">APPLICATION_TYPE__KERNEL</a></dd>
							<dt><strong>APPLICATION_TYPE__MODULE</strong></dt>
				<dd>in file application.class.php, constant <a href="core/_core---application.class.php.php#defineAPPLICATION_TYPE__MODULE">APPLICATION_TYPE__MODULE</a></dd>
							<dt><strong>APPLICATION_TYPE__TEMPLATE</strong></dt>
				<dd>in file application.class.php, constant <a href="core/_core---application.class.php.php#defineAPPLICATION_TYPE__TEMPLATE">APPLICATION_TYPE__TEMPLATE</a></dd>
							<dt><strong>ARCHIVE_ALL_ERRORS</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineARCHIVE_ALL_ERRORS">ARCHIVE_ALL_ERRORS</a></dd>
							<dt><strong>ARCHIVE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineARCHIVE_ERROR">ARCHIVE_ERROR</a></dd>
							<dt><strong>array_combine</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionarray_combine">array_combine()</a></dd>
							<dt><strong>assign_block_vars</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodassign_block_vars">Template::assign_block_vars()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assigns a template block. A block represents a loop and has a name which be used in your template file to indicate which loop you want to browse. To know what syntax to use to browse a loop, see the class description, there are examples.</dd>
							<dt><strong>assign_positions_conditions</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodassign_positions_conditions">MenuService::assign_positions_conditions()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assigns the positions conditions for different printing modes</dd>
							<dt><strong>assign_vars</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodassign_vars">Template::assign_vars()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assigns some simple template vars.  Those variables will be accessed in your template with the {var_name} syntax.</dd>
							<dt><strong>ATOM</strong></dt>
				<dd>in file atom.class.php, class <a href="content/syndication/ATOM.php">ATOM</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class could load a feed by its url or by a FeedData element and export it to the ATOM format</dd>
							<dt><strong>ATOM</strong></dt>
				<dd>in file atom.class.php, method <a href="content/syndication/ATOM.php#methodATOM">ATOM::ATOM()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new ATOM object</dd>
							<dt><strong>Authorizations</strong></dt>
				<dd>in file authorizations.class.php, class <a href="members/Authorizations.php">Authorizations</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class contains only static methods, it souldn't be instantiated.</dd>
							<dt><strong>auth_array_simple</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodauth_array_simple">Authorizations::auth_array_simple()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns an array with the authorizations given by variable number of arrays passed in argument.</dd>
							<dt><strong>AUTH_CHILD_PRIORITY</strong></dt>
				<dd>in file authorizations.class.php, constant <a href="members/_members---authorizations.class.php.php#defineAUTH_CHILD_PRIORITY">AUTH_CHILD_PRIORITY</a></dd>
							<dt><strong>AUTH_PARENT_PRIORITY</strong></dt>
				<dd>in file authorizations.class.php, constant <a href="members/_members---authorizations.class.php.php#defineAUTH_PARENT_PRIORITY">AUTH_PARENT_PRIORITY</a></dd>
							<dt><strong>AUTOCONNECT</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineAUTOCONNECT">AUTOCONNECT</a></dd>
							<dt><strong>auto_connect</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodauto_connect">Sql::auto_connect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Connects automatically the application to the DBMS by reading the database configuration file whose path is /kernel/db/config.php. If an error occures while connecting to the server, the script execution will be stopped and the error will be written in the page.</dd>
							<dt><strong>AUTO_LOAD_FREQUENT_VARS</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineAUTO_LOAD_FREQUENT_VARS">AUTO_LOAD_FREQUENT_VARS</a></dd>
							<dt><strong>atom.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---atom.class.php.php">atom.class.php</a></dd>
							<dt><strong>application.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---application.class.php.php">application.class.php</a></dd>
							<dt><strong>administrator_alert.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---administrator_alert.class.php.php">administrator_alert.class.php</a></dd>
							<dt><strong>administrator_alert_service.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---administrator_alert_service.class.php.php">administrator_alert_service.class.php</a></dd>
							<dt><strong>authorizations.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---authorizations.class.php.php">authorizations.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>$backup_script</strong></dt>
				<dd>in file backup.class.php, variable <a href="db/Backup.php#var$backup_script">Backup::$backup_script</a></dd>
							<dt><strong>$base_directory</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$base_directory">Uploads::$base_directory</a></dd>
							<dt><strong>$base_directory</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$base_directory">Upload::$base_directory</a></dd>
							<dt><strong>$base_name</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$base_name">Sql::$base_name</a></dd>
							<dt><strong>$begin_at</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$begin_at">FeedMenu::$begin_at</a></dd>
							<dt><strong>$block</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$block">Menu::$block</a></dd>
							<dt><strong>$bug_corrections</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$bug_corrections">Application::$bug_corrections</a></dd>
							<dt><strong>Backup</strong></dt>
				<dd>in file backup.class.php, class <a href="db/Backup.php">Backup</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class helps you to generate the backup file of your data base.</dd>
							<dt><strong>Backup</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodBackup">Backup::Backup()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Backup object</dd>
							<dt><strong>BBCodeEditor</strong></dt>
				<dd>in file bbcode_editor.class.php, class <a href="content/editor/BBCodeEditor.php">BBCodeEditor</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides an interface editor for contents.</dd>
							<dt><strong>BBCodeEditor</strong></dt>
				<dd>in file bbcode_editor.class.php, method <a href="content/editor/BBCodeEditor.php#methodBBCodeEditor">BBCodeEditor::BBCodeEditor()</a></dd>
							<dt><strong>BBCodeHighlighter</strong></dt>
				<dd>in file bbcode_highlighter.class.php, method <a href="content/parser/BBCodeHighlighter.php#methodBBCodeHighlighter">BBCodeHighlighter::BBCodeHighlighter()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BBCodeHighlighter objet</dd>
							<dt><strong>BBCodeHighlighter</strong></dt>
				<dd>in file bbcode_highlighter.class.php, class <a href="content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is a highlighter for the PHPBoost BBCode language. It supplies the highlighted code written in XHTML.</dd>
							<dt><strong>BBCodeParser</strong></dt>
				<dd>in file bbcode_parser.class.php, method <a href="content/parser/BBCodeParser.php#methodBBCodeParser">BBCodeParser::BBCodeParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BBCodeParser object</dd>
							<dt><strong>BBCodeParser</strong></dt>
				<dd>in file bbcode_parser.class.php, class <a href="content/parser/BBCodeParser.php">BBCodeParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Converts the PHPBoost BBCode language to the XHTML language which is stocked in the database and can be displayed nearly directly. It parses only the authorized tags (defined in the parent class which is ContentParser).</dd>
							<dt><strong>BBCodeUnparser</strong></dt>
				<dd>in file bbcode_unparser.class.php, class <a href="content/parser/BBCodeUnparser.php">BBCodeUnparser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;BBCode unparser. It converts a content using the PHPBoost HTML reference code (for example coming from a database) to the PHPBoost BBCode syntax.</dd>
							<dt><strong>BBCodeUnparser</strong></dt>
				<dd>in file bbcode_unparser.class.php, method <a href="content/parser/BBCodeUnparser.php#methodBBCodeUnparser">BBCodeUnparser::BBCodeUnparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BBCodeUnparser object</dd>
							<dt><strong>BBCODE_HIGHLIGHTER_BLOCK_CODE</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_HIGHLIGHTER_BLOCK_CODE">BBCODE_HIGHLIGHTER_BLOCK_CODE</a></dd>
							<dt><strong>BBCODE_HIGHLIGHTER_INLINE_CODE</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_HIGHLIGHTER_INLINE_CODE">BBCODE_HIGHLIGHTER_INLINE_CODE</a></dd>
							<dt><strong>BBCODE_LANGUAGE</strong></dt>
				<dd>in file content_formatting_factory.class.php, constant <a href="content/parser/_content---parser---content_formatting_factory.class.php.php#defineBBCODE_LANGUAGE">BBCODE_LANGUAGE</a></dd>
							<dt><strong>BBCODE_LIST_ITEM_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_LIST_ITEM_COLOR">BBCODE_LIST_ITEM_COLOR</a></dd>
							<dt><strong>BBCODE_PARAM_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_PARAM_COLOR">BBCODE_PARAM_COLOR</a></dd>
							<dt><strong>BBCODE_PARAM_NAME_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_PARAM_NAME_COLOR">BBCODE_PARAM_NAME_COLOR</a></dd>
							<dt><strong>BBCODE_TAG_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_TAG_COLOR">BBCODE_TAG_COLOR</a></dd>
							<dt><strong>Bench</strong></dt>
				<dd>in file bench.class.php, class <a href="util/Bench.php">Bench</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is done to time a process easily. You choose when to start and when to stop.</dd>
							<dt><strong>Bench</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodBench">Bench::Bench()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;starts the bench now</dd>
							<dt><strong>BLOCK_POSITION__ALL</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__ALL">BLOCK_POSITION__ALL</a></dd>
							<dt><strong>BLOCK_POSITION__BOTTOM_CENTRAL</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__BOTTOM_CENTRAL">BLOCK_POSITION__BOTTOM_CENTRAL</a></dd>
							<dt><strong>BLOCK_POSITION__FOOTER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__FOOTER">BLOCK_POSITION__FOOTER</a></dd>
							<dt><strong>BLOCK_POSITION__HEADER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__HEADER">BLOCK_POSITION__HEADER</a></dd>
							<dt><strong>BLOCK_POSITION__LEFT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__LEFT">BLOCK_POSITION__LEFT</a></dd>
							<dt><strong>BLOCK_POSITION__NOT_ENABLED</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__NOT_ENABLED">BLOCK_POSITION__NOT_ENABLED</a></dd>
							<dt><strong>BLOCK_POSITION__RIGHT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__RIGHT">BLOCK_POSITION__RIGHT</a></dd>
							<dt><strong>BLOCK_POSITION__SUB_HEADER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__SUB_HEADER">BLOCK_POSITION__SUB_HEADER</a></dd>
							<dt><strong>BLOCK_POSITION__TOP_CENTRAL</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__TOP_CENTRAL">BLOCK_POSITION__TOP_CENTRAL</a></dd>
							<dt><strong>BLOCK_POSITION__TOP_FOOTER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__TOP_FOOTER">BLOCK_POSITION__TOP_FOOTER</a></dd>
							<dt><strong>BreadCrumb</strong></dt>
				<dd>in file breadcrumb.class.php, class <a href="core/BreadCrumb.php">BreadCrumb</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is used to represent the bread crumb displayed on each page of the website. It enables the user to locate himself in the whole site. A bread crumb can look like this: Home &gt;&gt; My module &gt;&gt; First level category &gt;&gt; Second level category &gt;&gt; Third level category &gt;&gt; .. &gt;&gt; My page &gt;&gt; Edition</dd>
							<dt><strong>BreadCrumb</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodBreadCrumb">BreadCrumb::BreadCrumb()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BreadCrumb object.</dd>
							<dt><strong>build</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodbuild">AdministratorAlert::build()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an alert from its whole parameters.</dd>
							<dt><strong>build</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodbuild">Event::build()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an event object from its whole parameters.</dd>
							<dt><strong>build</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodbuild">Contribution::build()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a contribution object from its whole parameters.</dd>
							<dt><strong>build_administration_interface</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_administration_interface">CategoriesManager::build_administration_interface()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the list of categories and links to makes operations to administrate them (delete, move, add...), it supplies a string ready to be displayed. It uses AJAX, read the class description to understand this user interface.</dd>
							<dt><strong>build_auth_array_from_form</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodbuild_auth_array_from_form">Authorizations::build_auth_array_from_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns an array with the authorizations given by variable number of arrays passed in argument. This returned array is used to be serialized.</dd>
							<dt><strong>build_children_id_list</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_children_id_list">CategoriesManager::build_children_id_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the list of all the children of a category</dd>
							<dt><strong>build_kernel_map</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodbuild_kernel_map">SiteMap::build_kernel_map()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds to the site map all the kernel links.</dd>
							<dt><strong>build_modules_maps</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodbuild_modules_maps">SiteMap::build_modules_maps()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds to the site map all maps of the installed modules</dd>
							<dt><strong>build_parents_id_list</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_parents_id_list">CategoriesManager::build_parents_id_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the list of the parent categories of a category</dd>
							<dt><strong>build_select_form</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_select_form">CategoriesManager::build_select_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a formulary which allows user to choose a category in a select form.</dd>
							<dt><strong>bbcode_editor.class.php</strong></dt>
				<dd>procedural page <a href="content/editor/_content---editor---bbcode_editor.class.php.php">bbcode_editor.class.php</a></dd>
							<dt><strong>bbcode_highlighter.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php">bbcode_highlighter.class.php</a></dd>
							<dt><strong>bbcode_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---bbcode_parser.class.php.php">bbcode_parser.class.php</a></dd>
							<dt><strong>bbcode_unparser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---bbcode_unparser.class.php.php">bbcode_unparser.class.php</a></dd>
							<dt><strong>breadcrumb.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---breadcrumb.class.php.php">breadcrumb.class.php</a></dd>
							<dt><strong>backup.class.php</strong></dt>
				<dd>procedural page <a href="db/_db---backup.class.php.php">backup.class.php</a></dd>
							<dt><strong>bench.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---bench.class.php.php">bench.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>$cache_file_name</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$cache_file_name">CategoriesManager::$cache_file_name</a></dd>
							<dt><strong>$cache_var</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$cache_var">CategoriesManager::$cache_var</a></dd>
							<dt><strong>$category</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$category">FeedMenu::$category</a></dd>
							<dt><strong>$cat_name</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$cat_name">FeedsCat::$cat_name</a></dd>
							<dt><strong>$change_freq</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$change_freq">SiteMapLink::$change_freq</a></dd>
							<dt><strong>$children</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$children">FeedsCat::$children</a></dd>
							<dt><strong>$code</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$code">Captcha::$code</a></dd>
							<dt><strong>$color_index</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$color_index">Stats::$color_index</a></dd>
							<dt><strong>$compatibility_max</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$compatibility_max">Application::$compatibility_max</a></dd>
							<dt><strong>$compatibility_min</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$compatibility_min">Application::$compatibility_min</a></dd>
							<dt><strong>$connected</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$connected">Sql::$connected</a></dd>
							<dt><strong>$content</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$content">Mail::$content</a></dd>
							<dt><strong>$content</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$content">Parser::$content</a></dd>
							<dt><strong>$content</strong></dt>
				<dd>in file content_menu.class.php, variable <a href="menu/contentmenu/ContentMenu.php#var$content">ContentMenu::$content</a></dd>
							<dt><strong>$contents</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$contents">File::$contents</a></dd>
							<dt><strong>$creation_date</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$creation_date">Event::$creation_date</a></dd>
							<dt><strong>$current_status</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$current_status">Event::$current_status</a></dd>
							<dt><strong>Cache</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodCache">Cache::Cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Cache object. Check if the directory in which the cache is written is writable.</dd>
							<dt><strong>cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodcache">Feed::cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Send the feed data in the cache</dd>
							<dt><strong>Cache</strong></dt>
				<dd>in file cache.class.php, class <a href="core/Cache.php">Cache</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is the cache manager of PHPBoost. Its functioning is very particular. Loading a file is equivalent to include the file. The cache file must define some PHP global variables. They will be usable in the execution context of the page. You should read on the PHPBoost website the documentation which explains you how to integrate a cache for you module, it's too much complex to be explained here.</dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodcache_export">LinksMenu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodcache_export">LinksMenuElement::cache_export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the string to write in the cache file</dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodcache_export">ContentMenu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodcache_export">FeedMenu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file mini_menu.class.php, method <a href="menu/minimenu/MiniMenu.php#methodcache_export">MiniMenu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodcache_export">Menu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file links_menu_link.class.php, method <a href="menu/linksmenu/LinksMenuLink.php#methodcache_export">LinksMenuLink::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file module_mini_menu.class.php, method <a href="menu/modulesminimenu/ModuleMiniMenu.php#methodcache_export">ModuleMiniMenu::cache_export()</a></dd>
							<dt><strong>cache_export_begin</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodcache_export_begin">LinksMenuElement::cache_export_begin()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the string to write in the cache file at the beginning of the Menu element</dd>
							<dt><strong>cache_export_begin</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodcache_export_begin">Menu::cache_export_begin()</a></dd>
							<dt><strong>cache_export_end</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodcache_export_end">LinksMenuElement::cache_export_end()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the string to write in the cache file at the end of the Menu element</dd>
							<dt><strong>cache_export_end</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodcache_export_end">Menu::cache_export_end()</a></dd>
							<dt><strong>CACHE_TIME</strong></dt>
				<dd>in file search.class.php, constant <a href="content/_content---search.class.php.php#defineCACHE_TIME">CACHE_TIME</a></dd>
							<dt><strong>CACHE_TIMES_USED</strong></dt>
				<dd>in file search.class.php, constant <a href="content/_content---search.class.php.php#defineCACHE_TIMES_USED">CACHE_TIMES_USED</a></dd>
							<dt><strong>Captcha</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodCaptcha">Captcha::Captcha()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Captcha constructor. It allows you to create multiple instance of captcha, and check if GD is loaded.</dd>
							<dt><strong>Captcha</strong></dt>
				<dd>in file captcha.class.php, class <a href="util/Captcha.php">Captcha</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provide you an easy way to prevent spam by bot in public formular.</dd>
							<dt><strong>CAPTCHA_EASY</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_EASY">CAPTCHA_EASY</a></dd>
							<dt><strong>CAPTCHA_HARD</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_HARD">CAPTCHA_HARD</a></dd>
							<dt><strong>CAPTCHA_NORMAL</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_NORMAL">CAPTCHA_NORMAL</a></dd>
							<dt><strong>CAPTCHA_VERY_EASY</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_VERY_EASY">CAPTCHA_VERY_EASY</a></dd>
							<dt><strong>CAPTCHA_VERY_HARD</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_VERY_HARD">CAPTCHA_VERY_HARD</a></dd>
							<dt><strong>capture_and_shift_bit_auth</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodcapture_and_shift_bit_auth">Authorizations::capture_and_shift_bit_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Capture authorizations and shift a particular bit to an another bit (1 is used by default).</dd>
							<dt><strong>CategoriesManager</strong></dt>
				<dd>in file categories_manager.class.php, class <a href="content/CategoriesManager.php">CategoriesManager</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to manage easily the administration of categories for your modules. It's as generic as possible, if you want to complete some actions to specialize them for you module, you can create a new class inheritating of it in which you call its methods using the syntax parent::method(). <br /> /!\ Warning : /!\ <ul><li>Your DB table must respect some rules :
         <ul><li>You must have an integer attribute whose name is id and which represents the identifier of each category. It must be a primary key.</li><li>You also must have an integer attribute named id_parent which represents the identifier of the parent category (it will be 0 if its parent category is the root of the tree).</li><li>To maintain order, you must have a field containing the rank of the category which be an integer named c_order.</li><li>A field visible boolean (tynint 1 sur mysql)</li><li>A field name containing the category name</li></ul></li><li>In this class the user are supposed to be an administrator, no checking of his auth is done.</li><li>To be correctly displayed, you must supply to functions a variable extracted from a file cache. Use the Cache class to build your file cache. Your variable must be an array in which keys are categories identifiers, an values are still arrays which are as this :
      <ul><li>key id_parent containing the id_parent field of the database</li><li>key name containing the name of the category</li><li>key order</li><li>key visible which is a boolean</li></ul></li><li>You can also have other fields such as auth level, description, visible, that class won't modify them.</li><li>To display the list of categories and actions you can do on them, you may want to customize it. For that you must build an array that you will give to set_display_config() containing your choices :
      <ul><li>Key 'xmlhttprequest_file' which corresponds to the name of the file which will treat the AJAX requests. We usually call it xmlhttprequest.php.</li><li>Key 'url' which represents the url of the category (it won't display any link up to categories if you don't give this field). Its structure is the following :
              <ul><li>key 'unrewrited' =&gt; string containing unrewrited urls (let %d where you want to display the category identifier)</li><li>Key administration_file_name which represents the file which allows you to update category</li><li>rewrited url (optionnal) 'rewrited' =&gt; string containing rewrited urls (let %d where you want to display the category identifier and %s the category name if you need it)</li></ul></li></ul></li></ul>  If you need more informations to use this class, we advise you to look at the wiki of PHPBoost, in which there is a tutorial explaining how to use it step by step.</dd>
							<dt><strong>CategoriesManager</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodCategoriesManager">CategoriesManager::CategoriesManager()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a CategoriesManager object</dd>
							<dt><strong>CATEGORY_DOES_NOT_EXIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineCATEGORY_DOES_NOT_EXIST">CATEGORY_DOES_NOT_EXIST</a></dd>
							<dt><strong>CAT_UNVISIBLE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineCAT_UNVISIBLE">CAT_UNVISIBLE</a></dd>
							<dt><strong>CAT_VISIBLE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineCAT_VISIBLE">CAT_VISIBLE</a></dd>
							<dt><strong>change_chmod</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodchange_chmod">FileSystemElement::change_chmod()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Changes the chmod of the element.</dd>
							<dt><strong>change_position</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodchange_position">MenuService::change_position()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Change the menu position in a block</dd>
							<dt><strong>change_visibility</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodchange_visibility">CategoriesManager::change_visibility()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Changes the visibility of a category</dd>
							<dt><strong>check</strong></dt>
				<dd>in file repository.class.php, method <a href="core/Repository.php#methodcheck">Repository::check()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check Application</dd>
							<dt><strong>check</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodcheck">Session::check()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check session validity, and update it</dd>
							<dt><strong>CHECK_ALL_UPDATES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_ALL_UPDATES">CHECK_ALL_UPDATES</a></dd>
							<dt><strong>check_auth</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodcheck_auth">User::check_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the authorizations given by all the user groups. Then check the authorization.</dd>
							<dt><strong>check_auth</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodcheck_auth">Authorizations::check_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check authorizations for a member, a group or a rank</dd>
							<dt><strong>check_compatibility</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodcheck_compatibility">Application::check_compatibility()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks compatibility with limits</dd>
							<dt><strong>check_date</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodcheck_date">Date::check_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Determines whether a date is correct. For example the february 31st is not correct.</dd>
							<dt><strong>check_display_config</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodcheck_display_config">CategoriesManager::check_display_config()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if display configuration is good</dd>
							<dt><strong>check_error</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodcheck_error">CategoriesManager::check_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if an error has been raised on the last reported error. At each call of a method of this class which can raise an error, the last error is erased.</dd>
							<dt><strong>CHECK_EXIST</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineCHECK_EXIST">CHECK_EXIST</a></dd>
							<dt><strong>CHECK_KERNEL</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_KERNEL">CHECK_KERNEL</a></dd>
							<dt><strong>check_level</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodcheck_level">User::check_level()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the authorization level</dd>
							<dt><strong>check_mail</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functioncheck_mail">check_mail()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if a string could match an email address form.</dd>
							<dt><strong>check_max_value</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodcheck_max_value">User::check_max_value()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the maximum value of authorization in all user groups.</dd>
							<dt><strong>CHECK_MODULES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_MODULES">CHECK_MODULES</a></dd>
							<dt><strong>check_nbr_links</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functioncheck_nbr_links">check_nbr_links()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if a string contains less than a defined number of links (used to prevent SPAM).</dd>
							<dt><strong>CHECK_PM_BOX</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineCHECK_PM_BOX">CHECK_PM_BOX</a></dd>
							<dt><strong>CHECK_THEMES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_THEMES">CHECK_THEMES</a></dd>
							<dt><strong>check_validity</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodcheck_validity">Mail::check_validity()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks that an email address has a correct form.</dd>
							<dt><strong>check_wellformness</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodcheck_wellformness">Url::check_wellformness()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the url match the requested url form</dd>
							<dt><strong>CLASS_IMPORT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineCLASS_IMPORT">CLASS_IMPORT</a></dd>
							<dt><strong>clean</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodclean">BreadCrumb::clean()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Removes all the existing links.</dd>
							<dt><strong>clean_database_name</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodclean_database_name">Sql::clean_database_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Cleans the data base name to be sure it's a correct name</dd>
							<dt><strong>clear_cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodclear_cache">Feed::clear_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Clear the cache of the specified module_id.</dd>
							<dt><strong>clear_html_br</strong></dt>
				<dd>in file bbcode_parser.class.php, method <a href="content/parser/BBCodeParser.php#methodclear_html_br">BBCodeParser::clear_html_br()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Callback which clears the new line tag in the HTML generated code</dd>
							<dt><strong>close</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodclose">File::close()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Closes a file and frees the allocated memory relative to the file.</dd>
							<dt><strong>close</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodclose">Sql::close()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Closes the current MySQL connection if it is open.</dd>
							<dt><strong>CLOSEFILE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineCLOSEFILE">CLOSEFILE</a></dd>
							<dt><strong>Comments</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodComments">Comments::Comments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display comments form.</dd>
							<dt><strong>Comments</strong></dt>
				<dd>in file comments.class.php, class <a href="content/Comments.php">Comments</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages comments everywhere in phpboost Simplyfied use with the display_comments function: //news is the name of the modue, $idnews is the id in database for this item. display_comments('news', $idnews, url('news.php?id=' . $idnews . '&amp;amp;com=%s', 'news-0-' . $idnews . '.php?com=%s'))</dd>
							<dt><strong>compress</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodcompress">Url::compress()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Compress a url by removing all &quot;folder/..&quot; occurrences</dd>
							<dt><strong>compute_heritated_auth</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodcompute_heritated_auth">CategoriesManager::compute_heritated_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the global authorization level of the whole parent categories. The result corresponds to all the category's parents merged.</dd>
							<dt><strong>compute_number_contrib_for_each_profile</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodcompute_number_contrib_for_each_profile">ContributionService::compute_number_contrib_for_each_profile()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the number of contributions available for each profile. It will count the contributions for the administrator, the moderators, the members, for each group and for each member who can have some special authorizations.</dd>
							<dt><strong>compute_number_unread_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodcompute_number_unread_alerts">AdministratorAlertService::compute_number_unread_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Counts the number of unread alerts.</dd>
							<dt><strong>compute_referer</strong></dt>
				<dd>in file stats_saver.class.php, method <a href="core/StatsSaver.php#methodcompute_referer">StatsSaver::compute_referer()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Compute Stats of Site Referers</dd>
							<dt><strong>compute_users</strong></dt>
				<dd>in file stats_saver.class.php, method <a href="core/StatsSaver.php#methodcompute_users">StatsSaver::compute_users()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Compute Stats of Site Users</dd>
							<dt><strong>com_display_link</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodcom_display_link">Comments::com_display_link()</a></dd>
							<dt><strong>concat</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodconcat">Sql::concat()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the syntax to use the concatenation operator (CONCAT in MySQL). The MySQL fields names must be in a PHP string for instance between simple quotes: 'field_name' The PHP variables must be bordered by simple quotes, for example: '\'' . $my_var . '\''</dd>
							<dt><strong>concatenate_to_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodconcatenate_to_query">Backup::concatenate_to_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates a string at the end of the current script.</dd>
							<dt><strong>CONFIG_CONFLICT</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineCONFIG_CONFLICT">CONFIG_CONFLICT</a></dd>
							<dt><strong>connect</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodconnect">Sql::connect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method enables you to connect to the DBMS when you have the data base access informations.</dd>
							<dt><strong>CONNECTED_TO_DATABASE</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineCONNECTED_TO_DATABASE">CONNECTED_TO_DATABASE</a></dd>
							<dt><strong>CONNECTION_FAILED</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineCONNECTION_FAILED">CONNECTION_FAILED</a></dd>
							<dt><strong>categories_manager.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---categories_manager.class.php.php">categories_manager.class.php</a></dd>
							<dt><strong>comments.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---comments.class.php.php">comments.class.php</a></dd>
							<dt><strong>content_formatting_factory.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_formatting_factory.class.php.php">content_formatting_factory.class.php</a></dd>
							<dt><strong>content_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_parser.class.php.php">content_parser.class.php</a></dd>
							<dt><strong>content_second_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_second_parser.class.php.php">content_second_parser.class.php</a></dd>
							<dt><strong>content_unparser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_unparser.class.php.php">content_unparser.class.php</a></dd>
							<dt><strong>ContentEditor</strong></dt>
				<dd>in file editor.class.php, class <a href="content/editor/ContentEditor.php">ContentEditor</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Abstract class for editors content.</dd>
							<dt><strong>ContentEditor</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodContentEditor">ContentEditor::ContentEditor()</a></dd>
							<dt><strong>ContentFormattingFactory</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodContentFormattingFactory">ContentFormattingFactory::ContentFormattingFactory()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ContentFormattingFactoryy object</dd>
							<dt><strong>ContentFormattingFactory</strong></dt>
				<dd>in file content_formatting_factory.class.php, class <a href="content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is approximatively a factory which provides objets capable to format some content. The text formatting uses a syntax, PHPBoost supports both the BBCode syntax and a WYSIWYG tool syntax (TinyMCE). You can choose the formatting type you want to deal with.</dd>
							<dt><strong>ContentMenu</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodContentMenu">ContentMenu::ContentMenu()</a></dd>
							<dt><strong>ContentMenu</strong></dt>
				<dd>in file content_menu.class.php, class <a href="menu/contentmenu/ContentMenu.php">ContentMenu</a></dd>
							<dt><strong>ContentParser</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodContentParser">ContentParser::ContentParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Buils a ContentParser object.</dd>
							<dt><strong>ContentParser</strong></dt>
				<dd>in file content_parser.class.php, class <a href="content/parser/ContentParser.php">ContentParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is abstract. It contains tools that are usefull for implement a content parser.</dd>
							<dt><strong>ContentSecondParser</strong></dt>
				<dd>in file content_second_parser.class.php, method <a href="content/parser/ContentSecondParser.php#methodContentSecondParser">ContentSecondParser::ContentSecondParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ContentSecondParser object</dd>
							<dt><strong>ContentSecondParser</strong></dt>
				<dd>in file content_second_parser.class.php, class <a href="content/parser/ContentSecondParser.php">ContentSecondParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class ensures the real time processing of the content. The major part of the processing is saved in the database to minimize as much as possible the treatment when the content is displayed. However, some tags cannot be cached, because we cannot have return to the original code. It's for instance the case of the code tag which replaces the code by a lot of html code which formats the code. This kind of tag is treated in real time by this class. The content you put in that parser must come from a ContentParser class (BBCodeParser or TinyMCEParser) (it can have been saved in a database between the first parsing and the real time parsing).</dd>
							<dt><strong>ContentUnparser</strong></dt>
				<dd>in file content_unparser.class.php, class <a href="content/parser/ContentUnparser.php">ContentUnparser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is an abstract class. It contains the common elements needed by all the unparsers of PHPBoost.</dd>
							<dt><strong>ContentUnparser</strong></dt>
				<dd>in file content_unparser.class.php, method <a href="content/parser/ContentUnparser.php#methodContentUnparser">ContentUnparser::ContentUnparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ContentUnparser class.</dd>
							<dt><strong>CONTENT_MENU__CLASS</strong></dt>
				<dd>in file content_menu.class.php, constant <a href="menu/contentmenu/_menu---content---content_menu.class.php.php#defineCONTENT_MENU__CLASS">CONTENT_MENU__CLASS</a></dd>
							<dt><strong>Contribution</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodContribution">Contribution::Contribution()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Contribution object.</dd>
							<dt><strong>Contribution</strong></dt>
				<dd>in file contribution.class.php, class <a href="events/Contribution.php">Contribution</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a contribution made by a user to complete the content of the website. All the contributions are managed in the contribution panel.</dd>
							<dt><strong>ContributionService</strong></dt>
				<dd>in file contribution_service.class.php, class <a href="events/ContributionService.php">ContributionService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This service allows developers to manage their contributions.</dd>
							<dt><strong>CONTRIBUTION_AUTH_BIT</strong></dt>
				<dd>in file contribution.class.php, constant <a href="events/_events---contribution.class.php.php#defineCONTRIBUTION_AUTH_BIT">CONTRIBUTION_AUTH_BIT</a></dd>
							<dt><strong>CONTRIBUTION_TYPE</strong></dt>
				<dd>in file contribution_service.class.php, constant <a href="events/_events---contribution_service.class.php.php#defineCONTRIBUTION_TYPE">CONTRIBUTION_TYPE</a></dd>
							<dt><strong>copy</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodcopy">Template::copy()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Clones this object.</dd>
							<dt><strong>cache.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---cache.class.php.php">cache.class.php</a></dd>
							<dt><strong>count_conversations</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methodcount_conversations">PrivateMsg::count_conversations()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Counts the user's number of conversation.</dd>
							<dt><strong>count_table</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodcount_table">Sql::count_table()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Counts the number of the row contained in a table.</dd>
							<dt><strong>create_database</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodcreate_database">Sql::create_database()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Creates a data base on the DBMS at which is connected the current object.</dd>
							<dt><strong>CRLF</strong></dt>
				<dd>in file mail.class.php, constant <a href="io/_io---mail.class.php.php#defineCRLF">CRLF</a></dd>
							<dt><strong>csrf_get_protect</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodcsrf_get_protect">Session::csrf_get_protect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the session against CSRF attacks by GET. Checks that GETs are done from this site with a correct token.</dd>
							<dt><strong>csrf_post_protect</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodcsrf_post_protect">Session::csrf_post_protect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the session against CSRF attacks by POST. Checks that POSTs are done from this site. 2 different cases are accepted but the first is safer: <ul><li>The request contains a parameter whose name is token and value is the value of the token of the current session.</li><li>If the token isn't in the request, we analyse the HTTP referer to be sure that the request comes from the current site and not from another which can be suspect</li></ul> If the request doesn't match any of these two cases, this method will consider that it's a CSRF attack.</dd>
							<dt><strong>contribution.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---contribution.class.php.php">contribution.class.php</a></dd>
							<dt><strong>contribution_service.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---contribution_service.class.php.php">contribution_service.class.php</a></dd>
							<dt><strong>content_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/contentmenu/_menu---content---content_menu.class.php.php">content_menu.class.php</a></dd>
							<dt><strong>captcha.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---captcha.class.php.php">captcha.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>$data</strong></dt>
				<dd>in file session.class.php, variable <a href="members/Session.php#var$data">Session::$data</a></dd>
							<dt><strong>$data</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$data">Feed::$data</a></dd>
							<dt><strong>$data_stats</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$data_stats">Stats::$data_stats</a></dd>
							<dt><strong>$date</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$date">MiniCalendar::$date</a></dd>
							<dt><strong>$date</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$date">FeedData::$date</a></dd>
							<dt><strong>$date</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$date">FeedItem::$date</a></dd>
							<dt><strong>$decimal</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$decimal">Stats::$decimal</a></dd>
							<dt><strong>$depth</strong></dt>
				<dd>in file site_map_element.class.php, variable <a href="content/sitemap/SiteMapElement.php#var$depth">SiteMapElement::$depth</a></dd>
							<dt><strong>$depth</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$depth">LinksMenuElement::$depth</a></dd>
							<dt><strong>$desc</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$desc">FeedData::$desc</a></dd>
							<dt><strong>$desc</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$desc">FeedItem::$desc</a></dd>
							<dt><strong>$description</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$description">Contribution::$description</a></dd>
							<dt><strong>$description</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$description">Application::$description</a></dd>
							<dt><strong>$description</strong></dt>
				<dd>in file module_map.class.php, variable <a href="content/sitemap/ModuleMap.php#var$description">ModuleMap::$description</a></dd>
							<dt><strong>$difficulty</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$difficulty">Captcha::$difficulty</a></dd>
							<dt><strong>$display_config</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$display_config">CategoriesManager::$display_config</a></dd>
							<dt><strong>$display_preview</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$display_preview">FormBuilder::$display_preview</a></dd>
							<dt><strong>$display_reset</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$display_reset">FormBuilder::$display_reset</a></dd>
							<dt><strong>$display_title</strong></dt>
				<dd>in file content_menu.class.php, variable <a href="menu/contentmenu/ContentMenu.php#var$display_title">ContentMenu::$display_title</a></dd>
							<dt><strong>$download_url</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$download_url">Application::$download_url</a></dd>
							<dt><strong>$duration</strong></dt>
				<dd>in file bench.class.php, variable <a href="util/Bench.php#var$duration">Bench::$duration</a></dd>
							<dt><strong>Date</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodDate">Date::Date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds and initializes a date. It admits a variable number of parameters depending on the value of the first one. The second parameter allows us to chose what time referential we use to create the date: <ul><li>TIMEZONE_SYSTEM if that date comes from for example the database (dates must be stored under this referential).</li><li>TIMEZONE_SITE if it's an entry coming from the site (nearly never used).</li><li>TIMEZONE_USER if it's an entry coming from the user (it's own timezone will be used)</li></ul> The first parameter determines how to initialize the date, here are the rules to use for the other parameters: <ul><li>DATE_NOW will initialize the date to the current time.
 $date = new Date(DATE_NOW); will build a date with the current date.</li><li>DATE_YEAR_MONTH_DAY if you want to build a date from a specified day (year, month, day). In this case the following parameters are:
         <ul><li>int The year (for instance 2009)</li><li>int The month (for example 11)</li><li>int The day (for example 09)</li></ul>
 For example, $date = new Date(DATE_YEAR_MONTH_DAY, TIMEZONE_USER, 2009, 11, 09);</li><li>DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND if you want to build a date from a specified time. Here is the rule for the following parameters:
         <ul><li>int The year (for instance 2009)</li><li>int The month (for instance 11)</li><li>int The day (for instance 09)</li><li>int The hour (for instance 12)</li><li>int The minutes (for instance 34)</li><li>int The seconds (for instance 12)</li></ul>
 For instance $date = new Date(DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND, 2009, 11, 09, 12, 34, 12);</li><li>DATE_TIMESTAMP which builds a date from a UNIX timestamp.
 For example $date = new Date(DATE_TIMESTAMP, time()); is equivalent to $date = new Date(DATE_NOW);</li><li>DATE_FROM_STRING which decodes a date written in a string by matching a pattern you have to specify.
 The pattern is easy to write: d for day, m for month and y for year.
 For instance, if your third parameter is '24/12/2009' and the fourth is 'm/d/y', it will be the december 24th of 2009.</li></ul> Here are the rules:</dd>
							<dt><strong>Date</strong></dt>
				<dd>in file date.class.php, class <a href="util/Date.php">Date</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to handle easily some dates. A date is a day and an hour (year, month, day, hour, minutes, seconds). It supports the most common formats and manages timezones. Here are the definitions of the 3 existing timezones: <ul><li>System timezone: it's the timezone of the server, configured by the hoster. For instance, if your server is in France, it should be GMT+1.</li><li>Site timezone: it's the timezone of the central place of the site. For example, if your site deals with the italian soccer championship, it will be GMT+1.</li><li>User timezone :  each registered user can specify its timezone. It's particulary useful for people who visit some sites from a foreign country.</li></ul></dd>
							<dt><strong>date_diff</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methoddate_diff">Sql::date_diff()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the MySQL syntax which enables you to compute the number of years separating a date in a data base field and today.</dd>
							<dt><strong>DATE_FORMAT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT">DATE_FORMAT</a></dd>
							<dt><strong>DATE_FORMAT_LONG</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT_LONG">DATE_FORMAT_LONG</a></dd>
							<dt><strong>DATE_FORMAT_SHORT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT_SHORT">DATE_FORMAT_SHORT</a></dd>
							<dt><strong>DATE_FORMAT_TINY</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT_TINY">DATE_FORMAT_TINY</a></dd>
							<dt><strong>DATE_FROM_STRING</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FROM_STRING">DATE_FROM_STRING</a></dd>
							<dt><strong>DATE_NOW</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_NOW">DATE_NOW</a></dd>
							<dt><strong>DATE_RFC822_F</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC822_F">DATE_RFC822_F</a></dd>
							<dt><strong>DATE_RFC822_FORMAT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC822_FORMAT">DATE_RFC822_FORMAT</a></dd>
							<dt><strong>DATE_RFC3339_F</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC3339_F">DATE_RFC3339_F</a></dd>
							<dt><strong>DATE_RFC3339_FORMAT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC3339_FORMAT">DATE_RFC3339_FORMAT</a></dd>
							<dt><strong>DATE_TIMESTAMP</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_TIMESTAMP">DATE_TIMESTAMP</a></dd>
							<dt><strong>DATE_YEAR_MONTH_DAY</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_YEAR_MONTH_DAY">DATE_YEAR_MONTH_DAY</a></dd>
							<dt><strong>DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND">DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND</a></dd>
							<dt><strong>DBTYPE</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineDBTYPE">DBTYPE</a></dd>
							<dt><strong>DB_NO_CONNECT</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineDB_NO_CONNECT">DB_NO_CONNECT</a></dd>
							<dt><strong>DEBUG_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDEBUG_MODE">DEBUG_MODE</a></dd>
							<dt><strong>DEFAULT_ATOM_TEMPLATE</strong></dt>
				<dd>in file atom.class.php, constant <a href="content/syndication/_content---syndication---atom.class.php.php#defineDEFAULT_ATOM_TEMPLATE">DEFAULT_ATOM_TEMPLATE</a></dd>
							<dt><strong>DEFAULT_FEED_NAME</strong></dt>
				<dd>in file feed.class.php, constant <a href="content/syndication/_content---syndication---feed.class.php.php#defineDEFAULT_FEED_NAME">DEFAULT_FEED_NAME</a></dd>
							<dt><strong>DEFAULT_LANGUAGE</strong></dt>
				<dd>in file content_formatting_factory.class.php, constant <a href="content/parser/_content---parser---content_formatting_factory.class.php.php#defineDEFAULT_LANGUAGE">DEFAULT_LANGUAGE</a></dd>
							<dt><strong>DEFAULT_RSS_TEMPLATE</strong></dt>
				<dd>in file rss.class.php, constant <a href="content/syndication/_content---syndication---rss.class.php.php#defineDEFAULT_RSS_TEMPLATE">DEFAULT_RSS_TEMPLATE</a></dd>
							<dt><strong>del</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methoddel">Comments::del()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete a comment</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methoddelete">FileSystemElement::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes the element</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete">MenuService::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete a Menu from the database</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methoddelete">File::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes the file.</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methoddelete">Folder::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes the folder and all what it contains.</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methoddelete">CategoriesManager::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a category.</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methoddelete">PrivateMsg::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a private message, until the recipient has not read it.</dd>
							<dt><strong>delete_alert</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methoddelete_alert">AdministratorAlertService::delete_alert()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes an alert from the database.</dd>
							<dt><strong>delete_all</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methoddelete_all">Comments::delete_all()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete all comments for the specified item.</dd>
							<dt><strong>delete_contribution</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methoddelete_contribution">ContributionService::delete_contribution()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a contribution in the database.</dd>
							<dt><strong>delete_conversation</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methoddelete_conversation">PrivateMsg::delete_conversation()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a conversation.</dd>
							<dt><strong>delete_file</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methoddelete_file">Cache::delete_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a cache file.</dd>
							<dt><strong>delete_file</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiondelete_file">delete_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a file</dd>
							<dt><strong>delete_mini_menu</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete_mini_menu">MenuService::delete_mini_menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;delete the mini menu named $menu</dd>
							<dt><strong>delete_mini_module</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete_mini_module">MenuService::delete_mini_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;delete the mini module $module</dd>
							<dt><strong>delete_module_feeds_menus</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete_module_feeds_menus">MenuService::delete_module_feeds_menus()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete all the feeds menus with the this module id</dd>
							<dt><strong>DELETE_ON_ERROR</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineDELETE_ON_ERROR">DELETE_ON_ERROR</a></dd>
							<dt><strong>Del_file</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodDel_file">Uploads::Del_file()</a></dd>
							<dt><strong>Del_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodDel_folder">Uploads::Del_folder()</a></dd>
							<dt><strong>DEL_PM_CONVERS</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineDEL_PM_CONVERS">DEL_PM_CONVERS</a></dd>
							<dt><strong>disable</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddisable">MenuService::disable()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Disable a menu</dd>
							<dt><strong>display</strong></dt>
				<dd>in file bbcode_editor.class.php, method <a href="content/editor/BBCodeEditor.php#methoddisplay">BBCodeEditor::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the editor</dd>
							<dt><strong>display</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methoddisplay">MiniCalendar::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays the mini calendar. You must call the display method in the same order as the calendars are displayed, because it requires a javascript code loading.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methoddisplay">Pagination::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a list of links between pages.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methoddisplay">Menu::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu</dd>
							<dt><strong>display</strong></dt>
				<dd>in file links_menu_link.class.php, method <a href="menu/linksmenu/LinksMenuLink.php#methoddisplay">LinksMenuLink::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu</dd>
							<dt><strong>display</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methoddisplay">LinksMenuElement::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays the menu according to the given template</dd>
							<dt><strong>display</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methoddisplay">LinksMenu::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu</dd>
							<dt><strong>display</strong></dt>
				<dd>in file tinymce_editor.class.php, method <a href="content/editor/TinyMCEEditor.php#methoddisplay">TinyMCEEditor::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the editor</dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methoddisplay">FormBuilder::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the form</dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_checkbox.class.php, method <a href="builder/form/FormCheckbox.php#methoddisplay">FormCheckbox::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methoddisplay">FormFieldset::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the form</dd>
							<dt><strong>display</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methoddisplay">FeedMenu::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methoddisplay">Captcha::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the captcha image to the user, and set the code to decrypt in the database.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methoddisplay">Comments::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display comments form.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methoddisplay">ContentMenu::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the content menu.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methoddisplay">Errors::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exception handler for developper, return the error.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methoddisplay">BreadCrumb::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays the bread crumb.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_checkbox_option.class.php, method <a href="builder/form/FormCheckboxOption.php#methoddisplay">FormCheckboxOption::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_file_uploader.class.php, method <a href="builder/form/FormFileUploader.php#methoddisplay">FormFileUploader::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_textarea.class.php, method <a href="builder/form/FormTextarea.php#methoddisplay">FormTextarea::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_text_edit.class.php, method <a href="builder/form/FormTextEdit.php#methoddisplay">FormTextEdit::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_select.class.php, method <a href="builder/form/FormSelect.php#methoddisplay">FormSelect::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_select_option.class.php, method <a href="builder/form/FormSelectOption.php#methoddisplay">FormSelectOption::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_radio_choice.class.php, method <a href="builder/form/FormRadioChoice.php#methoddisplay">FormRadioChoice::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_hidden_field.class.php, method <a href="builder/form/FormHiddenField.php#methoddisplay">FormHiddenField::display()</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file form_radio_choice_option.class.php, method <a href="builder/form/FormRadioChoiceOption.php#methoddisplay">FormRadioChoiceOption::display()</a></dd>
							<dt><strong>DISPLAYING_CONFIGURATION_NOT_SET</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDISPLAYING_CONFIGURATION_NOT_SET">DISPLAYING_CONFIGURATION_NOT_SET</a></dd>
							<dt><strong>DISPLAY_ALL_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineDISPLAY_ALL_ERROR">DISPLAY_ALL_ERROR</a></dd>
							<dt><strong>display_comments</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiondisplay_comments">display_comments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML code of the comments manager.</dd>
							<dt><strong>display_editor</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiondisplay_editor">display_editor()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML code of the user editor. It uses the ContentFormattingFactory class, it allows you to write less code lines.</dd>
							<dt><strong>display_form</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methoddisplay_form">Captcha::display_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display captcha formular.</dd>
							<dt><strong>display_form</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methoddisplay_form">Note::display_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the ajax notation form.</dd>
							<dt><strong>display_img</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methoddisplay_img">Note::display_img()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Static method which display the notation with images, you can restrain the number of images displayed with the argument $num_stars_display</dd>
							<dt><strong>display_preview_button</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methoddisplay_preview_button">FormBuilder::display_preview_button()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display a preview button for the specified field.</dd>
							<dt><strong>display_preview_button</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methoddisplay_preview_button">FormFieldset::display_preview_button()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display a preview button for the specified field.</dd>
							<dt><strong>display_reset</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methoddisplay_reset">FormBuilder::display_reset()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display a reset button for the form.</dd>
							<dt><strong>DO_NOT_ADD_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#defineDO_NOT_ADD_SLASHES">DO_NOT_ADD_SLASHES</a></dd>
							<dt><strong>DO_NOT_ADD_THIS_CATEGORY_IN_LIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDO_NOT_ADD_THIS_CATEGORY_IN_LIST">DO_NOT_ADD_THIS_CATEGORY_IN_LIST</a></dd>
							<dt><strong>DO_NOT_AUTO_LOAD_FREQUENT_VARS</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineDO_NOT_AUTO_LOAD_FREQUENT_VARS">DO_NOT_AUTO_LOAD_FREQUENT_VARS</a></dd>
							<dt><strong>DO_NOT_GENERATE_CACHE_AFTER_THE_OPERATION</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineDO_NOT_GENERATE_CACHE_AFTER_THE_OPERATION">DO_NOT_GENERATE_CACHE_AFTER_THE_OPERATION</a></dd>
							<dt><strong>DO_NOT_LOAD_CACHE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDO_NOT_LOAD_CACHE">DO_NOT_LOAD_CACHE</a></dd>
							<dt><strong>draw_ellipse</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methoddraw_ellipse">Stats::draw_ellipse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Drawn an ellipse.</dd>
							<dt><strong>draw_graph</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methoddraw_graph">Stats::draw_graph()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Draw graph, not yet implemented.</dd>
							<dt><strong>draw_histogram</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methoddraw_histogram">Stats::draw_histogram()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Draw a histogram</dd>
							<dt><strong>DRAW_LEGEND</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineDRAW_LEGEND">DRAW_LEGEND</a></dd>
							<dt><strong>DRAW_VALUES</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineDRAW_VALUES">DRAW_VALUES</a></dd>
							<dt><strong>drop_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methoddrop_tables">Sql::drop_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Drops some tables in the data base.</dd>
							<dt><strong>date.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---date.class.php.php">date.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>$elements</strong></dt>
				<dd>in file site_map_section.class.php, variable <a href="content/sitemap/SiteMapSection.php#var$elements">SiteMapSection::$elements</a></dd>
							<dt><strong>$elements</strong></dt>
				<dd>in file site_map.class.php, variable <a href="content/sitemap/SiteMap.php#var$elements">SiteMap::$elements</a></dd>
							<dt><strong>$elements</strong></dt>
				<dd>in file links_menu.class.php, variable <a href="menu/linksmenu/LinksMenu.php#var$elements">LinksMenu::$elements</a></dd>
							<dt><strong>$enabled</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$enabled">ModuleInterface::$enabled</a></dd>
							<dt><strong>$enabled</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$enabled">Menu::$enabled</a></dd>
							<dt><strong>$entitled</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$entitled">Event::$entitled</a></dd>
							<dt><strong>$error</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$error">Upload::$error</a></dd>
							<dt><strong>$error</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$error">Uploads::$error</a></dd>
							<dt><strong>$errors</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$errors">ModuleInterface::$errors</a></dd>
							<dt><strong>$errors</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$errors">CategoriesManager::$errors</a></dd>
							<dt><strong>$errors</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$errors">Search::$errors</a></dd>
							<dt><strong>$extension</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$extension">Upload::$extension</a></dd>
							<dt><strong>$extension</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$extension">Uploads::$extension</a></dd>
							<dt><strong>editor.class.php</strong></dt>
				<dd>procedural page <a href="content/editor/_content---editor---editor.class.php.php">editor.class.php</a></dd>
							<dt><strong>errors.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---errors.class.php.php">errors.class.php</a></dd>
							<dt><strong>edit_member</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodedit_member">Group::edit_member()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Edits the user groups, compute difference between previous and new groups.</dd>
							<dt><strong>EMPTY_FOLDER</strong></dt>
				<dd>in file uploads.class.php, constant <a href="members/_members---uploads.class.php.php#defineEMPTY_FOLDER">EMPTY_FOLDER</a></dd>
							<dt><strong>Empty_folder_member</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodEmpty_folder_member">Uploads::Empty_folder_member()</a></dd>
							<dt><strong>enable</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodenable">MenuService::enable()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Enable a menu</dd>
							<dt><strong>enabled</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodenabled">Menu::enabled()</a></dd>
							<dt><strong>enable_all</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodenable_all">MenuService::enable_all()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Enables or disables all menus</dd>
							<dt><strong>end</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodend">Session::end()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Destroy the session</dd>
							<dt><strong>ERASE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineERASE">ERASE</a></dd>
							<dt><strong>Errors</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodErrors">Errors::Errors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>Errors</strong></dt>
				<dd>in file errors.class.php, class <a href="core/Errors.php">Errors</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is the error manager of PHPBoost. It is designed to collect and store all errors occurs in the projet.</dd>
							<dt><strong>ERRORS_MANAGEMENT_BY_RETURN</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineERRORS_MANAGEMENT_BY_RETURN">ERRORS_MANAGEMENT_BY_RETURN</a></dd>
							<dt><strong>ERROR_CAT_IS_AT_BOTTOM</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineERROR_CAT_IS_AT_BOTTOM">ERROR_CAT_IS_AT_BOTTOM</a></dd>
							<dt><strong>ERROR_CAT_IS_AT_TOP</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineERROR_CAT_IS_AT_TOP">ERROR_CAT_IS_AT_TOP</a></dd>
							<dt><strong>ERROR_GETTING_CACHE</strong></dt>
				<dd>in file feed.class.php, constant <a href="content/syndication/_content---syndication---feed.class.php.php#defineERROR_GETTING_CACHE">ERROR_GETTING_CACHE</a></dd>
							<dt><strong>ERROR_UNKNOWN_MOTION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineERROR_UNKNOWN_MOTION">ERROR_UNKNOWN_MOTION</a></dd>
							<dt><strong>escape</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodescape">Sql::escape()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Escapes the dangerous characters in the string you inject in your requests.</dd>
							<dt><strong>Event</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodEvent">Event::Event()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an Event object.</dd>
							<dt><strong>Event</strong></dt>
				<dd>in file event.class.php, class <a href="events/Event.php">Event</a><br>&nbsp;&nbsp;&nbsp;&nbsp;It's the common part between two types of event existing now in PHPBoost: <ul><li>User contribution managed into the contribution panel</li><li>Administrator alert, triggered for example when a new update is available or when a new member account is to approbate</li></ul></dd>
							<dt><strong>event.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---event.class.php.php">event.class.php</a></dd>
							<dt><strong>EVENT_STATUS_BEING_PROCESSED</strong></dt>
				<dd>in file event.class.php, constant <a href="events/_events---event.class.php.php#defineEVENT_STATUS_BEING_PROCESSED">EVENT_STATUS_BEING_PROCESSED</a></dd>
							<dt><strong>EVENT_STATUS_PROCESSED</strong></dt>
				<dd>in file event.class.php, constant <a href="events/_events---event.class.php.php#defineEVENT_STATUS_PROCESSED">EVENT_STATUS_PROCESSED</a></dd>
							<dt><strong>EVENT_STATUS_UNREAD</strong></dt>
				<dd>in file event.class.php, constant <a href="events/_events---event.class.php.php#defineEVENT_STATUS_UNREAD">EVENT_STATUS_UNREAD</a></dd>
							<dt><strong>exists</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodexists">FileSystemElement::exists()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Allows you to know if the file system element exists.</dd>
							<dt><strong>EXPLICIT_ERRORS_MANAGEMENT</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineEXPLICIT_ERRORS_MANAGEMENT">EXPLICIT_ERRORS_MANAGEMENT</a></dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodexport">SiteMapSection::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the section according to the given configuration. You will use the following template variables: <ul><li>SECTION_NAME which contains the name of the section</li><li>SECTION_URL which contains the URL of the link associated to the section</li><li>DEPTH which contains the depth of the section in the site map tree (useful for CSS classes names)</li><li>LINK_CODE which contains the code got by the associated link export</li><li>C_SECTION, boolean meaning that it's a section (useful if you want to use a sigle template for the whole export configuration)</li><li>A loop &quot;element&quot; containing evert element of the section (their code is available in the CODE variable of the loop)</li></ul></dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodexport">SiteMapElement::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the element</dd>
							<dt><strong>export</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodexport">Feed::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the feed as a string parsed by the &lt;$tpl&gt; template</dd>
							<dt><strong>export</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodexport">ModuleMap::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the sitemap (according to a configuration of templates). In your template, you will be able to use the following variables: <ul><li>MODULE_NAME which contains the name of the module</li><li>MODULE_DESCRIPTION which contains the description of the module</li><li>MODULE_URL which contains the URL of the module root page</li><li>DEPTH which is the depth of the module map in the sitemap (generally 1).
  It might be usefull to apply different CSS styles to each level of depth.</li><li>LINK_CODE which contains the code of the link associated to the module root exported with the same configuration.</li><li>C_MODULE_MAP which is a boolean whose value is true, this will enable you to use a single template for the whole export configuration</li><li>The loop &quot;element&quot; for which the variable CODE contains the code of each sub element of the module (for example categories)</li></ul></dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodexport">SiteMap::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports a SiteMap. You will be able to use the following variables into the templates used to export: <ul><li>C_SITE_MAP which is a condition indicating if it's a site map (useful if you want to use a sigle template
 for the whole export configuration)</li><li>SITE_NAME which contains the name of the site</li><li>A loop &quot;element&quot; in which the code of each element is in the variable CODE</li></ul></dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodexport">SiteMapLink::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the section according to the given configuration. You will use the following template variables: <ul><li>LOC containing the URL of the link</li><li>TEXT containing the name of the target page</li><li>C_DISPLAY_DATE indicating if the date is not empty</li><li>DATE containing the date of the last modification of the target page, formatted for the sitemap.xml file</li><li>ACTUALIZATION_FREQUENCY corresponding to the code needed in the sitemap.xml file</li><li>PRIORITY corresponding to the code needed in the sitemap.xml file to indicate the priority of the target page.</li><li>C_LINK indicating that we are displaying a link (useful if you want to use a signe template export configuration)</li></ul></dd>
							<dt><strong>export_file</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodexport_file">Backup::export_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Writes the backup script in a text file.</dd>
							<dt><strong>export_html_text</strong></dt>
				<dd>in file content_second_parser.class.php, method <a href="content/parser/ContentSecondParser.php#methodexport_html_text">ContentSecondParser::export_html_text()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Transforms a PHPBoost HTML content to make it exportable and usable every where in the web.</dd>
							<dt><strong>extract_table_structure</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodextract_table_structure">Backup::extract_table_structure()</a></dd>
							<dt><strong>E_STRICT</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineE_STRICT">E_STRICT</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$fd</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$fd">File::$fd</a></dd>
							<dt><strong>$fieldset_display_required</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_display_required">FormFieldset::$fieldset_display_required</a></dd>
							<dt><strong>$fieldset_errors</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_errors">FormFieldset::$fieldset_errors</a></dd>
							<dt><strong>$fieldset_fields</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_fields">FormFieldset::$fieldset_fields</a></dd>
							<dt><strong>$fieldset_title</strong></dt>
				<dd>in file form_fieldset.class.php, variable <a href="builder/form/FormFieldset.php#var$fieldset_title">FormFieldset::$fieldset_title</a></dd>
							<dt><strong>$field_cols</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_cols">FormTextarea::$field_cols</a></dd>
							<dt><strong>$field_css_class</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_css_class">FormField::$field_css_class</a></dd>
							<dt><strong>$field_editor</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_editor">FormTextarea::$field_editor</a></dd>
							<dt><strong>$field_errors</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_errors">FormField::$field_errors</a></dd>
							<dt><strong>$field_forbidden_tags</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_forbidden_tags">FormTextarea::$field_forbidden_tags</a></dd>
							<dt><strong>$field_id</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_id">FormField::$field_id</a></dd>
							<dt><strong>$field_identifier_preview</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$field_identifier_preview">FormBuilder::$field_identifier_preview</a></dd>
							<dt><strong>$field_maxlength</strong></dt>
				<dd>in file form_text_edit.class.php, variable <a href="builder/form/FormTextEdit.php#var$field_maxlength">FormTextEdit::$field_maxlength</a></dd>
							<dt><strong>$field_multiple</strong></dt>
				<dd>in file form_select.class.php, variable <a href="builder/form/FormSelect.php#var$field_multiple">FormSelect::$field_multiple</a></dd>
							<dt><strong>$field_name</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_name">FormField::$field_name</a></dd>
							<dt><strong>$field_on_blur</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_on_blur">FormField::$field_on_blur</a></dd>
							<dt><strong>$field_options</strong></dt>
				<dd>in file form_checkbox.class.php, variable <a href="builder/form/FormCheckbox.php#var$field_options">FormCheckbox::$field_options</a></dd>
							<dt><strong>$field_options</strong></dt>
				<dd>in file form_select.class.php, variable <a href="builder/form/FormSelect.php#var$field_options">FormSelect::$field_options</a></dd>
							<dt><strong>$field_options</strong></dt>
				<dd>in file form_radio_choice.class.php, variable <a href="builder/form/FormRadioChoice.php#var$field_options">FormRadioChoice::$field_options</a></dd>
							<dt><strong>$field_required</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_required">FormField::$field_required</a></dd>
							<dt><strong>$field_required_alert</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_required_alert">FormField::$field_required_alert</a></dd>
							<dt><strong>$field_rows</strong></dt>
				<dd>in file form_textarea.class.php, variable <a href="builder/form/FormTextarea.php#var$field_rows">FormTextarea::$field_rows</a></dd>
							<dt><strong>$field_size</strong></dt>
				<dd>in file form_file_uploader.class.php, variable <a href="builder/form/FormFileUploader.php#var$field_size">FormFileUploader::$field_size</a></dd>
							<dt><strong>$field_size</strong></dt>
				<dd>in file form_text_edit.class.php, variable <a href="builder/form/FormTextEdit.php#var$field_size">FormTextEdit::$field_size</a></dd>
							<dt><strong>$field_sub_title</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_sub_title">FormField::$field_sub_title</a></dd>
							<dt><strong>$field_title</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_title">FormField::$field_title</a></dd>
							<dt><strong>$field_value</strong></dt>
				<dd>in file form_field.class.php, variable <a href="builder/form/FormField.php#var$field_value">FormField::$field_value</a></dd>
							<dt><strong>$filename</strong></dt>
				<dd>in file module_mini_menu.class.php, variable <a href="menu/modulesminimenu/ModuleMiniMenu.php#var$filename">ModuleMiniMenu::$filename</a></dd>
							<dt><strong>$filename</strong></dt>
				<dd>in file uploads.class.php, variable <a href="members/Uploads.php#var$filename">Uploads::$filename</a></dd>
							<dt><strong>$filename</strong></dt>
				<dd>in file upload.class.php, variable <a href="io/Upload.php#var$filename">Upload::$filename</a></dd>
							<dt><strong>$files</strong></dt>
				<dd>in file folder.class.php, variable <a href="io/filesystem/Folder.php#var$files">Folder::$files</a></dd>
							<dt><strong>$files</strong></dt>
				<dd>in file cache.class.php, variable <a href="core/Cache.php#var$files">Cache::$files</a></dd>
							<dt><strong>$files</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$files">Template::$files</a></dd>
							<dt><strong>$fixer_id</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$fixer_id">Contribution::$fixer_id</a></dd>
							<dt><strong>$fixer_login</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$fixer_login">Contribution::$fixer_login</a></dd>
							<dt><strong>$fixing_date</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$fixing_date">Contribution::$fixing_date</a></dd>
							<dt><strong>$fixing_url</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$fixing_url">Event::$fixing_url</a></dd>
							<dt><strong>$folders</strong></dt>
				<dd>in file folder.class.php, variable <a href="io/filesystem/Folder.php#var$folders">Folder::$folders</a></dd>
							<dt><strong>$font</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$font">Captcha::$font</a></dd>
							<dt><strong>$forbidden_tags</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$forbidden_tags">ContentEditor::$forbidden_tags</a></dd>
							<dt><strong>$forbidden_tags</strong></dt>
				<dd>in file content_parser.class.php, variable <a href="content/parser/ContentParser.php#var$forbidden_tags">ContentParser::$forbidden_tags</a></dd>
							<dt><strong>$format</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$format">Mail::$format</a></dd>
							<dt><strong>$form_action</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_action">FormBuilder::$form_action</a></dd>
							<dt><strong>$form_class</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_class">FormBuilder::$form_class</a></dd>
							<dt><strong>$form_fieldsets</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_fieldsets">FormBuilder::$form_fieldsets</a></dd>
							<dt><strong>$form_name</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$form_name">MiniCalendar::$form_name</a></dd>
							<dt><strong>$form_name</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_name">FormBuilder::$form_name</a></dd>
							<dt><strong>$form_submit</strong></dt>
				<dd>in file form_builder.class.php, variable <a href="builder/form/FormBuilder.php#var$form_submit">FormBuilder::$form_submit</a></dd>
							<dt><strong>$functionalities</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$functionalities">ModuleInterface::$functionalities</a></dd>
							<dt><strong>$function_name</strong></dt>
				<dd>in file mini_menu.class.php, variable <a href="menu/minimenu/MiniMenu.php#var$function_name">MiniMenu::$function_name</a></dd>
							<dt><strong>form_builder.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_builder.class.php.php">form_builder.class.php</a></dd>
							<dt><strong>form_checkbox.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_checkbox.class.php.php">form_checkbox.class.php</a></dd>
							<dt><strong>form_checkbox_option.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_checkbox_option.class.php.php">form_checkbox_option.class.php</a></dd>
							<dt><strong>form_field.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_field.class.php.php">form_field.class.php</a></dd>
							<dt><strong>form_fieldset.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_fieldset.class.php.php">form_fieldset.class.php</a></dd>
							<dt><strong>form_file_uploader.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_file_uploader.class.php.php">form_file_uploader.class.php</a></dd>
							<dt><strong>form_hidden_field.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_hidden_field.class.php.php">form_hidden_field.class.php</a></dd>
							<dt><strong>form_radio_choice.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_radio_choice.class.php.php">form_radio_choice.class.php</a></dd>
							<dt><strong>form_radio_choice_option.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_radio_choice_option.class.php.php">form_radio_choice_option.class.php</a></dd>
							<dt><strong>form_select.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_select.class.php.php">form_select.class.php</a></dd>
							<dt><strong>form_select_option.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_select_option.class.php.php">form_select_option.class.php</a></dd>
							<dt><strong>form_textarea.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_textarea.class.php.php">form_textarea.class.php</a></dd>
							<dt><strong>form_text_edit.class.php</strong></dt>
				<dd>procedural page <a href="builder/form/_builder---form---form_text_edit.class.php.php">form_text_edit.class.php</a></dd>
							<dt><strong>feed.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feed.class.php.php">feed.class.php</a></dd>
							<dt><strong>feeds_cat.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feeds_cat.class.php.php">feeds_cat.class.php</a></dd>
							<dt><strong>feeds_list.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feeds_list.class.php.php">feeds_list.class.php</a></dd>
							<dt><strong>feed_data.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feed_data.class.php.php">feed_data.class.php</a></dd>
							<dt><strong>feed_item.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feed_item.class.php.php">feed_item.class.php</a></dd>
							<dt><strong>Feed</strong></dt>
				<dd>in file feed.class.php, class <a href="content/syndication/Feed.php">Feed</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class could be used to export feeds</dd>
							<dt><strong>Feed</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodFeed">Feed::Feed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new feed object</dd>
							<dt><strong>FeedData</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodFeedData">FeedData::FeedData()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FeedData Object</dd>
							<dt><strong>FeedData</strong></dt>
				<dd>in file feed_data.class.php, class <a href="content/syndication/FeedData.php">FeedData</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Contains meta-informations about a feed with its entries</dd>
							<dt><strong>FeedItem</strong></dt>
				<dd>in file feed_item.class.php, class <a href="content/syndication/FeedItem.php">FeedItem</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Contains meta-informations and informations about a feed entry / item</dd>
							<dt><strong>FeedItem</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodFeedItem">FeedItem::FeedItem()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FeedItem element</dd>
							<dt><strong>FeedMenu</strong></dt>
				<dd>in file feed_menu.class.php, class <a href="menu/feedmenu/FeedMenu.php">FeedMenu</a></dd>
							<dt><strong>FeedMenu</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodFeedMenu">FeedMenu::FeedMenu()</a></dd>
							<dt><strong>FeedsCat</strong></dt>
				<dd>in file feeds_cat.class.php, class <a href="content/syndication/FeedsCat.php">FeedsCat</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Describes a feed by building a category tree</dd>
							<dt><strong>FeedsCat</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodFeedsCat">FeedsCat::FeedsCat()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FeedsCat Object</dd>
							<dt><strong>FeedsList</strong></dt>
				<dd>in file feeds_list.class.php, class <a href="content/syndication/FeedsList.php">FeedsList</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class contains an agregation of differents feeds</dd>
							<dt><strong>FeedsList</strong></dt>
				<dd>in file feeds_list.class.php, method <a href="content/syndication/FeedsList.php#methodFeedsList">FeedsList::FeedsList()</a></dd>
							<dt><strong>FEEDS_PATH</strong></dt>
				<dd>in file feed.class.php, constant <a href="content/syndication/_content---syndication---feed.class.php.php#defineFEEDS_PATH">FEEDS_PATH</a></dd>
							<dt><strong>FEED_DATA__CLASS</strong></dt>
				<dd>in file feed_data.class.php, constant <a href="content/syndication/_content---syndication---feed_data.class.php.php#defineFEED_DATA__CLASS">FEED_DATA__CLASS</a></dd>
							<dt><strong>FEED_MENU__CLASS</strong></dt>
				<dd>in file feed_menu.class.php, constant <a href="menu/feedmenu/_menu---feed---feed_menu.class.php.php#defineFEED_MENU__CLASS">FEED_MENU__CLASS</a></dd>
							<dt><strong>fetch_assoc</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodfetch_assoc">Sql::fetch_assoc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Browses a MySQL result resource row per row. When you call this method on a resource, you get the next row.</dd>
							<dt><strong>fetch_row</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodfetch_row">Sql::fetch_row()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Browses a MySQL result resource row per row. When you call this method on a resource, you get the next row.</dd>
							<dt><strong>FIELD_INPUT__CHECKBOX</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__CHECKBOX">FIELD_INPUT__CHECKBOX</a></dd>
							<dt><strong>FIELD_INPUT__FILE</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__FILE">FIELD_INPUT__FILE</a></dd>
							<dt><strong>FIELD_INPUT__HIDDEN</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__HIDDEN">FIELD_INPUT__HIDDEN</a></dd>
							<dt><strong>FIELD_INPUT__RADIO</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__RADIO">FIELD_INPUT__RADIO</a></dd>
							<dt><strong>FIELD_INPUT__TEXT</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD_INPUT__TEXT">FIELD_INPUT__TEXT</a></dd>
							<dt><strong>FIELD__SELECT</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD__SELECT">FIELD__SELECT</a></dd>
							<dt><strong>FIELD__TEXTAREA</strong></dt>
				<dd>in file form_builder.class.php, constant <a href="builder/form/_builder---form---form_builder.class.php.php#defineFIELD__TEXTAREA">FIELD__TEXTAREA</a></dd>
							<dt><strong>file</strong></dt>
				<dd>in file upload.class.php, method <a href="io/Upload.php#methodfile">Upload::file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Uploads a file.</dd>
							<dt><strong>File</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodFile">File::File()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a File object.</dd>
							<dt><strong>File</strong></dt>
				<dd>in file file.class.php, class <a href="io/filesystem/File.php">File</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a text file which can be read and written.</dd>
							<dt><strong>FileSystemElement</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodFileSystemElement">FileSystemElement::FileSystemElement()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FileSystemElement object from the path of the element.</dd>
							<dt><strong>FileSystemElement</strong></dt>
				<dd>in file file_system_element.class.php, class <a href="io/filesystem/FileSystemElement.php">FileSystemElement</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents any file system element.</dd>
							<dt><strong>file_get_contents_emulate</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionfile_get_contents_emulate">file_get_contents_emulate()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Emulates the PHP file_get_contents_emulate.</dd>
							<dt><strong>finclude</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodfinclude">File::finclude()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Includes the file. Executes its PHP content here. Equivalent to the PHP include function.</dd>
							<dt><strong>find_by_criteria</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodfind_by_criteria">ContributionService::find_by_criteria()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a list of the contributions matching the required criteria(s). All the parameters represent the criterias you can use. If you don't want to use a criteria, let the null value. The returned contribution match all the criterias (it's a AND condition).</dd>
							<dt><strong>find_by_criteria</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodfind_by_criteria">AdministratorAlertService::find_by_criteria()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a list of alerts matching the required criteria(s). You can specify many criterias. When you use several of them, it's a AND condition. It will only return the alert which match all the criterias.</dd>
							<dt><strong>find_by_id</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodfind_by_id">ContributionService::find_by_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Finds a contribution with its identifier.</dd>
							<dt><strong>find_by_id</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodfind_by_id">AdministratorAlertService::find_by_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an alert knowing its id.</dd>
							<dt><strong>find_by_identifier</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodfind_by_identifier">AdministratorAlertService::find_by_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Finds an alert knowing its identifier and maybe its type.</dd>
							<dt><strong>find_require_dir</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionfind_require_dir">find_require_dir()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Finds a folder according to the user language. You find the file in a folder in which there is one folder per lang. If it doesn't exist, you want to choose the file in another language. This function returns the path of an existing file (if the required lang exists, it will be it, otherwise it will be one of the existing files).</dd>
							<dt><strong>Find_subfolder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodFind_subfolder">Uploads::Find_subfolder()</a></dd>
							<dt><strong>flush</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodflush">File::flush()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;forces a write of all buffered output.</dd>
							<dt><strong>Folder</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodFolder">Folder::Folder()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Folder object.</dd>
							<dt><strong>Folder</strong></dt>
				<dd>in file folder.class.php, class <a href="io/filesystem/Folder.php">Folder</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to handle very easily a folder on the serveur.</dd>
							<dt><strong>format</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodformat">Date::format()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Formats the date to a particular format.</dd>
							<dt><strong>FormBuilder</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodFormBuilder">FormBuilder::FormBuilder()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>FormBuilder</strong></dt>
				<dd>in file form_builder.class.php, class <a href="builder/form/FormBuilder.php">FormBuilder</a></dd>
							<dt><strong>FormCheckbox</strong></dt>
				<dd>in file form_checkbox.class.php, class <a href="builder/form/FormCheckbox.php">FormCheckbox</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages checkbox input fields.</dd>
							<dt><strong>FormCheckbox</strong></dt>
				<dd>in file form_checkbox.class.php, method <a href="builder/form/FormCheckbox.php#methodFormCheckbox">FormCheckbox::FormCheckbox()</a></dd>
							<dt><strong>FormCheckboxOption</strong></dt>
				<dd>in file form_checkbox_option.class.php, method <a href="builder/form/FormCheckboxOption.php#methodFormCheckboxOption">FormCheckboxOption::FormCheckboxOption()</a></dd>
							<dt><strong>FormCheckboxOption</strong></dt>
				<dd>in file form_checkbox_option.class.php, class <a href="builder/form/FormCheckboxOption.php">FormCheckboxOption</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages the checkbox fields. It provides you some additionnal field options: <ul><li>optiontitle : The option title</li><li>checked : Specify it whether the option has to be checked.</li></ul></dd>
							<dt><strong>FormField</strong></dt>
				<dd>in file form_field.class.php, class <a href="builder/form/FormField.php">FormField</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Abstract class which manage Fields. You can specify several option with the argument $fieldOptions : <ul><li>title : The field title</li><li>subtitle : The field subtitle</li><li>value : The default value for the field</li><li>id : The field identifier</li><li>class : The css class used for the field</li><li>required : Specify if the field is required.</li><li>onblur : Action performed when cursor is clicked outside the field area. (javascript)</li></ul></dd>
							<dt><strong>FormField</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodFormField">FormField::FormField()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>FormFieldset</strong></dt>
				<dd>in file form_fieldset.class.php, class <a href="builder/form/FormFieldset.php">FormFieldset</a></dd>
							<dt><strong>FormFieldset</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodFormFieldset">FormFieldset::FormFieldset()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>FormFileUploader</strong></dt>
				<dd>in file form_file_uploader.class.php, class <a href="builder/form/FormFileUploader.php">FormFileUploader</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage file input fields. It provides you additionnal field options : <ul><li>size : The size for the field</li></ul></dd>
							<dt><strong>FormFileUploader</strong></dt>
				<dd>in file form_file_uploader.class.php, method <a href="builder/form/FormFileUploader.php#methodFormFileUploader">FormFileUploader::FormFileUploader()</a></dd>
							<dt><strong>FormHiddenField</strong></dt>
				<dd>in file form_hidden_field.class.php, method <a href="builder/form/FormHiddenField.php#methodFormHiddenField">FormHiddenField::FormHiddenField()</a></dd>
							<dt><strong>FormHiddenField</strong></dt>
				<dd>in file form_hidden_field.class.php, class <a href="builder/form/FormHiddenField.php">FormHiddenField</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage hidden input fields.</dd>
							<dt><strong>FormRadioChoice</strong></dt>
				<dd>in file form_radio_choice.class.php, class <a href="builder/form/FormRadioChoice.php">FormRadioChoice</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage radio input fields.</dd>
							<dt><strong>FormRadioChoice</strong></dt>
				<dd>in file form_radio_choice.class.php, method <a href="builder/form/FormRadioChoice.php#methodFormRadioChoice">FormRadioChoice::FormRadioChoice()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor It takes a variable number of parameters. The first two are required.</dd>
							<dt><strong>FormRadioChoiceOption</strong></dt>
				<dd>in file form_radio_choice_option.class.php, class <a href="builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage radio input field options. It provides you additionnal field options : <ul><li>optiontitle : The option title</li><li>checked : Specify if the option has to be checked.</li></ul></dd>
							<dt><strong>FormRadioChoiceOption</strong></dt>
				<dd>in file form_radio_choice_option.class.php, method <a href="builder/form/FormRadioChoiceOption.php#methodFormRadioChoiceOption">FormRadioChoiceOption::FormRadioChoiceOption()</a></dd>
							<dt><strong>FormSelect</strong></dt>
				<dd>in file form_select.class.php, class <a href="builder/form/FormSelect.php">FormSelect</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage select fields. It provides you additionnal field options : <ul><li>multiple : Type of select field, mutiple allow you to check several options.</li></ul></dd>
							<dt><strong>FormSelect</strong></dt>
				<dd>in file form_select.class.php, method <a href="builder/form/FormSelect.php#methodFormSelect">FormSelect::FormSelect()</a></dd>
							<dt><strong>FormSelectOption</strong></dt>
				<dd>in file form_select_option.class.php, class <a href="builder/form/FormSelectOption.php">FormSelectOption</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage select field options.</dd>
							<dt><strong>FormSelectOption</strong></dt>
				<dd>in file form_select_option.class.php, method <a href="builder/form/FormSelectOption.php#methodFormSelectOption">FormSelectOption::FormSelectOption()</a></dd>
							<dt><strong>FormTextarea</strong></dt>
				<dd>in file form_textarea.class.php, method <a href="builder/form/FormTextarea.php#methodFormTextarea">FormTextarea::FormTextarea()</a></dd>
							<dt><strong>FormTextarea</strong></dt>
				<dd>in file form_textarea.class.php, class <a href="builder/form/FormTextarea.php">FormTextarea</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage multi-line text fields.</dd>
							<dt><strong>FormTextEdit</strong></dt>
				<dd>in file form_text_edit.class.php, class <a href="builder/form/FormTextEdit.php">FormTextEdit</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage single-line text fields. It provides you additionnal field options : <ul><li>size : The maximum size for the field</li><li>maxlength : The maximum length for the field</li><li>required_alert : Text displayed if field is empty (javscript only)</li></ul></dd>
							<dt><strong>FormTextEdit</strong></dt>
				<dd>in file form_text_edit.class.php, method <a href="builder/form/FormTextEdit.php#methodFormTextEdit">FormTextEdit::FormTextEdit()</a></dd>
							<dt><strong>FRANKLINBC_TTF</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineFRANKLINBC_TTF">FRANKLINBC_TTF</a></dd>
							<dt><strong>frequire</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodfrequire">File::frequire()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Requires the file. Executes its PHP content here. Equivalent to the PHP require function.</dd>
							<dt><strong>functionality</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodfunctionality">ModulesDiscoveryService::functionality()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Call the method call functionality on each speficied modules</dd>
							<dt><strong>functionality</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodfunctionality">ModuleInterface::functionality()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the existance of the functionality and if exists call it.  If she's not available, the FUNCTIONNALITY_NOT_IMPLEMENTED flag is raised.</dd>
							<dt><strong>FUNCTIONNALITY_NOT_IMPLEMENTED</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineFUNCTIONNALITY_NOT_IMPLEMENTED">FUNCTIONNALITY_NOT_IMPLEMENTED</a></dd>
							<dt><strong>functions.inc.php</strong></dt>
				<dd>procedural page <a href="phpboost/_functions.inc.php.php">functions.inc.php</a></dd>
							<dt><strong>file.class.php</strong></dt>
				<dd>procedural page <a href="io/filesystem/_io---filesystem---file.class.php.php">file.class.php</a></dd>
							<dt><strong>file_system_element.class.php</strong></dt>
				<dd>procedural page <a href="io/filesystem/_io---filesystem---file_system_element.class.php.php">file_system_element.class.php</a></dd>
							<dt><strong>folder.class.php</strong></dt>
				<dd>procedural page <a href="io/filesystem/_io---filesystem---folder.class.php.php">folder.class.php</a></dd>
							<dt><strong>feed_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/feedmenu/_menu---feed---feed_menu.class.php.php">feed_menu.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>$gd_loaded</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$gd_loaded">Captcha::$gd_loaded</a></dd>
							<dt><strong>$groups_auth</strong></dt>
				<dd>in file groups.class.php, variable <a href="members/Group.php#var$groups_auth">Group::$groups_auth</a></dd>
							<dt><strong>$groups_auth</strong></dt>
				<dd>in file user.class.php, variable <a href="members/User.php#var$groups_auth">User::$groups_auth</a></dd>
							<dt><strong>$groups_name</strong></dt>
				<dd>in file groups.class.php, variable <a href="members/Group.php#var$groups_name">Group::$groups_name</a></dd>
							<dt><strong>$guid</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$guid">FeedItem::$guid</a></dd>
							<dt><strong>garbage_collector</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodgarbage_collector">Session::garbage_collector()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes all the existing sessions</dd>
							<dt><strong>generate_all_files</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_all_files">Cache::generate_all_files()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Regenerates all the cache files managed by the PHPBoost cache manager. This method needs a lot of resource, call it only when you are sure you need it.</dd>
							<dt><strong>generate_all_modules</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_all_modules">Cache::generate_all_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates all the module cache files.</dd>
							<dt><strong>generate_cache</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodgenerate_cache">ContributionService::generate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the contribution cache file.</dd>
							<dt><strong>generate_cache</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodgenerate_cache">MenuService::generate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generate the cache</dd>
							<dt><strong>GENERATE_CACHE_AFTER_THE_OPERATION</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineGENERATE_CACHE_AFTER_THE_OPERATION">GENERATE_CACHE_AFTER_THE_OPERATION</a></dd>
							<dt><strong>generate_create_table_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodgenerate_create_table_query">Backup::generate_create_table_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates the tables creation to the SQL backup script.</dd>
							<dt><strong>generate_drop_table_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodgenerate_drop_table_query">Backup::generate_drop_table_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates the query which drops the PHPBoost tables only if they exist to the backup SQL script.</dd>
							<dt><strong>generate_file</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_file">Cache::generate_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates a file according to the specified method.</dd>
							<dt><strong>generate_insert_values_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodgenerate_insert_values_query">Backup::generate_insert_values_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates the tables content insertion queries to the SQL backup script.</dd>
							<dt><strong>generate_module_file</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_module_file">Cache::generate_module_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates a module file</dd>
							<dt><strong>generate_select</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodgenerate_select">Authorizations::generate_select()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generate a multiple select field for the form which create authorization for ranks, groups and members.</dd>
							<dt><strong>get</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodget">FileSystemElement::get()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Initializes the file system element just before to be read.</dd>
							<dt><strong>get_absolute_root</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodget_absolute_root">Url::get_absolute_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the absolute website root Url</dd>
							<dt><strong>get_admin_url</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodget_admin_url">Uploads::get_admin_url()</a></dd>
							<dt><strong>get_all_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodget_all_alerts">AdministratorAlertService::get_all_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists all the alerts of the site. You can order them. You can also choose how much alerts you want.</dd>
							<dt><strong>get_all_content</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_all_content">Folder::get_all_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns all the file system elements contained by the folder.</dd>
							<dt><strong>get_all_contributions</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodget_all_contributions">ContributionService::get_all_contributions()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets all the contributions of the table. You can sort the list.</dd>
							<dt><strong>get_all_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodget_all_modules">ModulesDiscoveryService::get_all_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a list with all the modules in it, even with those that have no ModuleInterface. Useful to do generic operations on modules.</dd>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_attribute">ModuleInterface::get_attribute()</a></dd>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methodget_attribute">Note::get_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor</dd>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_attribute">User::get_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor</dd>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodget_attribute">Comments::get_attribute()</a></dd>
							<dt><strong>get_auth</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_auth">Contribution::get_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the authorization of treatment of this contribution.</dd>
							<dt><strong>get_auth</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_auth">Menu::get_auth()</a></dd>
							<dt><strong>get_auth</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_auth">FeedItem::get_auth()</a></dd>
							<dt><strong>get_authors</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_authors">Application::get_authors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Authors</dd>
							<dt><strong>get_available_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodget_available_modules">ModulesDiscoveryService::get_available_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the ModuleInterface list.</dd>
							<dt><strong>get_available_tags</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_available_tags">ContentFormattingFactory::get_available_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the map of all the formatting types supported by the PHPBoost formatting editors and parsers. The keys of the map are the tags identifiers and the values the tags names.</dd>
							<dt><strong>get_block</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_block">Menu::get_block()</a></dd>
							<dt><strong>get_block_position</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_block_position">Menu::get_block_position()</a></dd>
							<dt><strong>get_bug_corrections</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_bug_corrections">Application::get_bug_corrections()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Bug Corrections Text</dd>
							<dt><strong>get_cache_file_name</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodget_cache_file_name">Feed::get_cache_file_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feed data cache filename</dd>
							<dt><strong>get_category_id</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_category_id">FeedsCat::get_category_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the category id</dd>
							<dt><strong>get_category_name</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_category_name">FeedsCat::get_category_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the category name</dd>
							<dt><strong>get_change_freq</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_change_freq">SiteMapLink::get_change_freq()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the change frequency (how often the target page is actualized)</dd>
							<dt><strong>get_children</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodget_children">LinksMenu::get_children()</a></dd>
							<dt><strong>get_children</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_children">FeedsCat::get_children()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current category children</dd>
							<dt><strong>get_compatibility_max</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_compatibility_max">Application::get_compatibility_max()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Compatibility Max value</dd>
							<dt><strong>get_compatibility_min</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_compatibility_min">Application::get_compatibility_min()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Compatibility min value</dd>
							<dt><strong>get_content</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodget_content">ContentMenu::get_content()</a></dd>
							<dt><strong>get_content</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_content">Mail::get_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail content.</dd>
							<dt><strong>get_content</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodget_content">Parser::get_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the content of the parser. If you called a method which parses the content, this content will be parsed.</dd>
							<dt><strong>get_contents</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_contents">File::get_contents()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the content of the file.</dd>
							<dt><strong>get_creation_date</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_creation_date">Event::get_creation_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the creation date of the event.</dd>
							<dt><strong>get_current_page</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methodget_current_page">Pagination::get_current_page()</a></dd>
							<dt><strong>get_data_base_name</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodget_data_base_name">Sql::get_data_base_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the data base which with the object is connected.</dd>
							<dt><strong>get_date</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_date">FeedItem::get_date()</a></dd>
							<dt><strong>get_date</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodget_date">MiniCalendar::get_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the date</dd>
							<dt><strong>get_date</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_date">FeedData::get_date()</a></dd>
							<dt><strong>get_date_rfc822</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_date_rfc822">FeedData::get_date_rfc822()</a></dd>
							<dt><strong>get_date_rfc822</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_date_rfc822">FeedItem::get_date_rfc822()</a></dd>
							<dt><strong>get_date_rfc3339</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_date_rfc3339">FeedData::get_date_rfc3339()</a></dd>
							<dt><strong>get_date_rfc3339</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_date_rfc3339">FeedItem::get_date_rfc3339()</a></dd>
							<dt><strong>get_day</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_day">Date::get_day()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the day of the date</dd>
							<dt><strong>get_dbms_version</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodget_dbms_version">Sql::get_dbms_version()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the version of MySQL used.</dd>
							<dt><strong>get_depth</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodget_depth">SiteMapElement::get_depth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the depth of the element in the tree</dd>
							<dt><strong>get_desc</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_desc">FeedItem::get_desc()</a></dd>
							<dt><strong>get_desc</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_desc">FeedData::get_desc()</a></dd>
							<dt><strong>get_description</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_description">Application::get_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Description Text</dd>
							<dt><strong>get_description</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodget_description">ModuleMap::get_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the module description</dd>
							<dt><strong>get_description</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_description">Contribution::get_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the description of the contribution.</dd>
							<dt><strong>get_display_required</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodget_display_required">FormFieldset::get_display_required()</a></dd>
							<dt><strong>get_display_title</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodget_display_title">ContentMenu::get_display_title()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the title will be displayed</dd>
							<dt><strong>get_download_url</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_download_url">Application::get_download_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Download URL</dd>
							<dt><strong>get_editor</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_editor">ContentFormattingFactory::get_editor()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns an editor object which will display the editor corresponding to the language you chose.</dd>
							<dt><strong>get_entitled</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_entitled">Event::get_entitled()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the entitled of the event.</dd>
							<dt><strong>get_errno_class</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodget_errno_class">Errors::get_errno_class()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get Error type</dd>
							<dt><strong>get_errors</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodget_errors">FormField::get_errors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get all errors occured in the field construct process.</dd>
							<dt><strong>get_errors</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_errors">ModuleInterface::get_errors()</a></dd>
							<dt><strong>get_executed_requests_number</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodget_executed_requests_number">Sql::get_executed_requests_number()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of request executed by this object.</dd>
							<dt><strong>get_feeds_list</strong></dt>
				<dd>in file feeds_list.class.php, method <a href="content/syndication/FeedsList.php#methodget_feeds_list">FeedsList::get_feeds_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feeds list</dd>
							<dt><strong>get_feeds_list</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodget_feeds_list">CategoriesManager::get_feeds_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the list of the feeds corresponding to each category of the category tree.</dd>
							<dt><strong>get_feed_menu</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodget_feed_menu">Feed::get_feed_menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the code which shows all the feeds formats.</dd>
							<dt><strong>get_fields</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodget_fields">FormFieldset::get_fields()</a></dd>
							<dt><strong>get_files</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_files">Folder::get_files()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the files contained in this folder.</dd>
							<dt><strong>get_first_folder</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_first_folder">Folder::get_first_folder()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the first folder present in this folder</dd>
							<dt><strong>get_first_msg</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methodget_first_msg">Pagination::get_first_msg()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the first message of the current page displayed. It usually used in SQL queries. Example : $Sql-&gt;query_while(&quot;SELECT n.contents FROM &quot; . PREFIX . &quot;news n    &quot; . $Sql-&gt;limit($Pagination-&gt;get_first_msg($CONFIG_NEWS['pagination_news'], 'p'), $CONFIG_NEWS['pagination_news']), __LINE__, __FILE__); For further informations, refer to the db package documentation.</dd>
							<dt><strong>get_fixer_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_fixer_id">Contribution::get_fixer_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the identifier of the fixer.</dd>
							<dt><strong>get_fixer_login</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_fixer_login">Contribution::get_fixer_login()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the fixer login.</dd>
							<dt><strong>get_fixing_date</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_fixing_date">Contribution::get_fixing_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the contribution fixing date.</dd>
							<dt><strong>get_fixing_url</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_fixing_url">Event::get_fixing_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the URL corresponding to the alert.</dd>
							<dt><strong>get_folders</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodget_folders">Folder::get_folders()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the folders contained in this folder.</dd>
							<dt><strong>get_forbidden_tags</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodget_forbidden_tags">ContentEditor::get_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the fordidden tags.</dd>
							<dt><strong>get_forbidden_tags</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodget_forbidden_tags">ContentParser::get_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the forbidden tags.</dd>
							<dt><strong>get_form_action</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_action">FormBuilder::get_form_action()</a></dd>
							<dt><strong>get_form_class</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_class">FormBuilder::get_form_class()</a></dd>
							<dt><strong>get_form_name</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_name">FormBuilder::get_form_name()</a></dd>
							<dt><strong>get_form_submit</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodget_form_submit">FormBuilder::get_form_submit()</a></dd>
							<dt><strong>get_groups</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_groups">User::get_groups()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get all user groups</dd>
							<dt><strong>get_groups_array</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodget_groups_array">Group::get_groups_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the array of user groups (id =&gt; name)</dd>
							<dt><strong>get_group_color</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_group_color">User::get_group_color()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the user group associated color.</dd>
							<dt><strong>get_guid</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_guid">FeedItem::get_guid()</a></dd>
							<dt><strong>get_headers</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_headers">Mail::get_headers()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail headers.</dd>
							<dt><strong>get_host</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_host">FeedData::get_host()</a></dd>
							<dt><strong>get_hours</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_hours">Date::get_hours()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the hours of the date</dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_id">Application::get_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of id</dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodget_id">FormField::get_id()</a></dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_id">Menu::get_id()</a></dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_id">ModuleInterface::get_id()</a></dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_id">Event::get_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the id of the event (in the event data base).</dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodget_id">User::get_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the user id</dd>
							<dt><strong>get_identifier</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_identifier">Application::get_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets an identifier of the application</dd>
							<dt><strong>get_identifier</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_identifier">Event::get_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the identifier of the event. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events.</dd>
							<dt><strong>get_ids</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodget_ids">Search::get_ids()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the search id</dd>
							<dt><strong>get_id_in_module</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_id_in_module">Event::get_id_in_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the id in the module. This value corresponds to the id of the daba base entry associated to the event.</dd>
							<dt><strong>get_image</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodget_image">LinksMenuElement::get_image()</a></dd>
							<dt><strong>get_image_url</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_image_url">FeedItem::get_image_url()</a></dd>
							<dt><strong>get_img_mimetype</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodget_img_mimetype">Uploads::get_img_mimetype()</a></dd>
							<dt><strong>get_improvments</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_improvments">Application::get_improvments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Improvments Text</dd>
							<dt><strong>get_infos</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_infos">ModuleInterface::get_infos()</a></dd>
							<dt><strong>get_ini_config</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_ini_config">get_ini_config()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the config field of a module configuration file. In fact, this field contains the default module configuration in which we can find some &quot; characters. To solve the problem, this field is considered as a comment and when we want to retrieve its value, we have to call this method which returns its value.</dd>
							<dt><strong>get_items</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_items">FeedData::get_items()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feed items</dd>
							<dt><strong>get_lang</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_lang">FeedData::get_lang()</a></dd>
							<dt><strong>get_language</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_language">ContentFormattingFactory::get_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the language of the factory</dd>
							<dt><strong>get_language</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_language">Application::get_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Language</dd>
							<dt><strong>get_last_access_date</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_last_access_date">File::get_last_access_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the last access date of the file.</dd>
							<dt><strong>get_last_modification_date</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_last_modification_date">SiteMapLink::get_last_modification_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the last modification date of the target page</dd>
							<dt><strong>get_last_modification_date</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_last_modification_date">File::get_last_modification_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the date of the last modification of the file.</dd>
							<dt><strong>get_last__error_log</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodget_last__error_log">Errors::get_last__error_log()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get last error informations</dd>
							<dt><strong>get_lines</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodget_lines">File::get_lines()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the content of the file grouped by lines.</dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodget_link">SiteMapSection::get_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the link associated to the section</dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_link">FeedData::get_link()</a></dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_link">SiteMapLink::get_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the URL of the link</dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_link">FeedItem::get_link()</a></dd>
							<dt><strong>get_link_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_link_stream">SitemapExportConfig::get_link_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a SiteMapLink object.</dd>
							<dt><strong>get_localized_language</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_localized_language">Application::get_localized_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Localized language</dd>
							<dt><strong>get_menus_map</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodget_menus_map">MenuService::get_menus_map()</a></dd>
							<dt><strong>get_menu_list</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodget_menu_list">MenuService::get_menu_list()</a></dd>
							<dt><strong>get_menu_types_list</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodget_menu_types_list">LinksMenu::get_menu_types_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;static method which returns all the menu types</dd>
							<dt><strong>get_microtime</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodget_microtime">Bench::get_microtime()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;computes the time with a microsecond precision</dd>
							<dt><strong>get_mime</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_mime">Mail::get_mime()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the MIME type of the mail content</dd>
							<dt><strong>get_minutes</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_minutes">Date::get_minutes()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the minutes of the date</dd>
							<dt><strong>get_module</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_module">Contribution::get_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the module in which the contribution is used.</dd>
							<dt><strong>get_module</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodget_module">ModulesDiscoveryService::get_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the ModuleInterface of the module which id is $module_id.</dd>
							<dt><strong>get_module_data_path</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodget_module_data_path">Template::get_module_data_path()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the path of the module. This path will be used to write the relative paths in your templates.</dd>
							<dt><strong>get_module_id</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodget_module_id">FeedMenu::get_module_id()</a></dd>
							<dt><strong>get_module_id</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_module_id">FeedsCat::get_module_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the module id</dd>
							<dt><strong>get_module_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_module_map_stream">SitemapExportConfig::get_module_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a ModuleMap object.</dd>
							<dt><strong>get_module_name</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_module_name">Contribution::get_module_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the name of the module in which the contribution is used.</dd>
							<dt><strong>get_module_name</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_module_name">get_module_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the identifier (name of the folder) of the module which is currently executed.</dd>
							<dt><strong>get_module_parameters</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodget_module_parameters">Session::get_module_parameters()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get module's parametres from session</dd>
							<dt><strong>get_month</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_month">Date::get_month()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the month of the date</dd>
							<dt><strong>get_must_regenerate_cache</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_must_regenerate_cache">Event::get_must_regenerate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the value indicating if the cache must be generated.</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodget_name">FileSystemElement::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the element name.</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodget_name">ModuleInterface::get_name()</a></dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodget_name">SiteMapElement::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the menu</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_name">SiteMapLink::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the target page</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_name">Application::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of name</dd>
							<dt><strong>get_new_features</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_new_features">Application::get_new_features()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of New Features Text</dd>
							<dt><strong>get_number_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodget_number_alerts">AdministratorAlertService::get_number_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of alerts.</dd>
							<dt><strong>get_number_unread_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodget_number_unread_alerts">AdministratorAlertService::get_number_unread_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of unread alerts.</dd>
							<dt><strong>get_object</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_object">Mail::get_object()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail object.</dd>
							<dt><strong>get_page_path</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodget_page_path">Parser::get_page_path()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the page path</dd>
							<dt><strong>get_parsed</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodget_parsed">Feed::get_parsed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Export a feed</dd>
							<dt><strong>get_parser</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_parser">ContentFormattingFactory::get_parser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a parser which will work in the language you chose.</dd>
							<dt><strong>get_path_to_root</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodget_path_to_root">Parser::get_path_to_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the path to root attribute.</dd>
							<dt><strong>get_poster_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_poster_id">Contribution::get_poster_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the identifier of the poster.</dd>
							<dt><strong>get_poster_login</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_poster_login">Contribution::get_poster_login()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the poster login.</dd>
							<dt><strong>get_priority</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_priority">Application::get_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Priority</dd>
							<dt><strong>get_priority</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_priority">SiteMapLink::get_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the priority of the link</dd>
							<dt><strong>get_priority</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodget_priority">AdministratorAlert::get_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the priority of the alert.</dd>
							<dt><strong>get_priority_name</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodget_priority_name">AdministratorAlert::get_priority_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the priority name. It's automatically translater to the user language, ready to be displayed.</dd>
							<dt><strong>get_properties</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodget_properties">AdministratorAlert::get_properties()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the alert properties.</dd>
							<dt><strong>get_pubdate</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_pubdate">Application::get_pubdate()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Publication Date</dd>
							<dt><strong>get_recipients</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_recipients">Mail::get_recipients()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail recipients' addresses. They are separated by a comma.</dd>
							<dt><strong>get_relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodget_relative">Url::get_relative()</a></dd>
							<dt><strong>get_repository</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_repository">Application::get_repository()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Repository</dd>
							<dt><strong>get_required_alert</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodget_required_alert">FormField::get_required_alert()</a></dd>
							<dt><strong>get_results</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodget_results">Search::get_results()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Puts results from the search results in the $results parameter and returns the number of results. Query complexity: 1 query.</dd>
							<dt><strong>get_results_by_id</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodget_results_by_id">Search::get_results_by_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Puts results from the search results identified by the $id_search parameter in the $results parameter and returns the number of results. Query complexity: 2 queries.</dd>
							<dt><strong>get_script</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_script">Backup::get_script()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current backup script.</dd>
							<dt><strong>get_seconds</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_seconds">Date::get_seconds()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the seconds of the date</dd>
							<dt><strong>get_second_parser</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_second_parser">ContentFormattingFactory::get_second_parser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a second parser which will work in the language you chose.</dd>
							<dt><strong>get_section_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_section_stream">SitemapExportConfig::get_section_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a SiteMapSection object.</dd>
							<dt><strong>get_security_improvments</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_security_improvments">Application::get_security_improvments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Security Improvments</dd>
							<dt><strong>get_security_update</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_security_update">Application::get_security_update()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Security Update</dd>
							<dt><strong>get_sender_mail</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_sender_mail">Mail::get_sender_mail()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail address of the sender.</dd>
							<dt><strong>get_sender_name</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodget_sender_name">Mail::get_sender_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the mail sender's name.</dd>
							<dt><strong>get_server_url_page</strong></dt>
				<dd>in file unusual_functions.inc.php, function <a href="util/_util---unusual_functions.inc.php.php#functionget_server_url_page">get_server_url_page()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the path at which we must redirect the user when PHPBoost is not installed.</dd>
							<dt><strong>get_site_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_site_map_stream">SitemapExportConfig::get_site_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a SiteMap object.</dd>
							<dt><strong>get_site_name</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodget_site_name">SiteMap::get_site_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the site</dd>
							<dt><strong>get_start_page</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_start_page">get_start_page()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the site start page.</dd>
							<dt><strong>get_status</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_status">Event::get_status()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the status of the event. The status is one of those elements: ul&gt;     &lt;li&gt;EVENT_STATUS_UNREAD if it's not read.&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_BEING_PROCESSED if the event is beeing processed&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_PROCESSED if the event is processed. &lt;/ul&gt;</dd>
							<dt><strong>get_status_name</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_status_name">Contribution::get_status_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the contribution status name. It's automatically translated in the user language, ready to be displayed.</dd>
							<dt><strong>get_status_name</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_status_name">Event::get_status_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the event status name. It's automatically translated in the user language.</dd>
							<dt><strong>get_tables_list</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_tables_list">Backup::get_tables_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the list of the tables used by PHPBoost.</dd>
							<dt><strong>get_tables_number</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_tables_number">Backup::get_tables_number()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of tables used by PHPBoost.</dd>
							<dt><strong>get_tables_properties_list</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_tables_properties_list">Backup::get_tables_properties_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the tables (name and informations relative to each table) of the data base at which is connected this SQL object. This method calls the SHOW TABLE STATUS MySQL query, to know more about it, see http://dev.mysql.com/doc/refman/5.1/en/show-table-status.html</dd>
							<dt><strong>get_template</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodget_template">FeedMenu::get_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the tpl to parse a feed</dd>
							<dt><strong>get_template</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodget_template">ContentEditor::get_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the template used for the editor.</dd>
							<dt><strong>get_timestamp</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_timestamp">Date::get_timestamp()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the timestamp associated to the date</dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file module_mini_menu.class.php, method <a href="menu/modulesminimenu/ModuleMiniMenu.php#methodget_title">ModuleMiniMenu::get_title()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodget_title">FormFieldset::get_title()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_title">FeedData::get_title()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_title">Menu::get_title()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_title">FeedItem::get_title()</a></dd>
							<dt><strong>get_token</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodget_token">Session::get_token()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the session token</dd>
							<dt><strong>get_type</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_type">Event::get_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
							<dt><strong>get_type</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodget_type">LinksMenu::get_type()</a></dd>
							<dt><strong>get_type</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_type">Application::get_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Type</dd>
							<dt><strong>get_uid</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodget_uid">LinksMenuElement::get_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the menu uid</dd>
							<dt><strong>get_uid</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_uid">get_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a unique identifier (useful for example to generate some javascript ids)</dd>
							<dt><strong>get_ulang</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_ulang">get_ulang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current user's language.</dd>
							<dt><strong>get_unparser</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_unparser">ContentFormattingFactory::get_unparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a unparser which will work in the language you chose.</dd>
							<dt><strong>get_update_url</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_update_url">Application::get_update_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Update URL</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodget_url">FeedMenu::get_url()</a></dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodget_url">Uploads::get_url()</a></dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file repository.class.php, method <a href="core/Repository.php#methodget_url">Repository::get_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of url</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_url">SiteMapLink::get_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the URL of the link</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodget_url">LinksMenuElement::get_url()</a></dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_url">FeedsCat::get_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feed url</dd>
							<dt><strong>get_user_editor</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_user_editor">ContentFormattingFactory::get_user_editor()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the editor of the current user (chosen in its profile).</dd>
							<dt><strong>get_utheme</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_utheme">get_utheme()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current user's theme.</dd>
							<dt><strong>get_version</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_version">Application::get_version()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Version</dd>
							<dt><strong>get_warning</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_warning">Application::get_warning()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Warning</dd>
							<dt><strong>get_warning_level</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_warning_level">Application::get_warning_level()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Warning level</dd>
							<dt><strong>get_wellformness_regex</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodget_wellformness_regex">Url::get_wellformness_regex()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the regex matching the requested url form</dd>
							<dt><strong>get_year</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_year">Date::get_year()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the year of the date</dd>
							<dt><strong>gmdate_format</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiongmdate_format">gmdate_format()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Formats a date according to a specific form.</dd>
							<dt><strong>got_error</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodgot_error">ModuleInterface::got_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the last error. If called with no arguments, returns true if an error has occured  otherwise, false. If the method got an argument,</dd>
							<dt><strong>Group</strong></dt>
				<dd>in file groups.class.php, class <a href="members/Group.php">Group</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides methods to manage user in groups.</dd>
							<dt><strong>Group</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodGroup">Group::Group()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Constructor. Loads informations groups.</dd>
							<dt><strong>GROUP_DEFAULT_IDSELECT</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineGROUP_DEFAULT_IDSELECT">GROUP_DEFAULT_IDSELECT</a></dd>
							<dt><strong>GROUP_DISABLED_ADVANCED_AUTH</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineGROUP_DISABLED_ADVANCED_AUTH">GROUP_DISABLED_ADVANCED_AUTH</a></dd>
							<dt><strong>GROUP_DISABLE_SELECT</strong></dt>
				<dd>in file groups.class.php, constant <a href="members/_members---groups.class.php.php#defineGROUP_DISABLE_SELECT">GROUP_DISABLE_SELECT</a></dd>
							<dt><strong>GROUP_TYPE</strong></dt>
				<dd>in file user.class.php, constant <a href="members/_members---user.class.php.php#defineGROUP_TYPE">GROUP_TYPE</a></dd>
							<dt><strong>groups.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---groups.class.php.php">groups.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>$headers</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$headers">Mail::$headers</a></dd>
							<dt><strong>$height</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$height">Captcha::$height</a></dd>
							<dt><strong>$host</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$host">FeedData::$host</a></dd>
							<dt><strong>$html_auth</strong></dt>
				<dd>in file content_parser.class.php, variable <a href="content/parser/ContentParser.php#var$html_auth">ContentParser::$html_auth</a></dd>
							<dt><strong>handler</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodhandler">Errors::handler()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exception handler for developper.</dd>
							<dt><strong>handler_php</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodhandler_php">Errors::handler_php()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;PHP exceptions handler</dd>
							<dt><strong>has_functionalities</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodhas_functionalities">ModuleInterface::has_functionalities()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the availability of the functionalities (hook)</dd>
							<dt><strong>has_functionality</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodhas_functionality">ModuleInterface::has_functionality()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check the availability of the functionality (hook)</dd>
							<dt><strong>highlight_query</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodhighlight_query">Sql::highlight_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Highlights a SQL query to be more readable by a human.</dd>
							<dt><strong>HORIZONTAL_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineHORIZONTAL_MENU">HORIZONTAL_MENU</a></dd>
							<dt><strong>HORIZONTAL_SCROLLING_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineHORIZONTAL_SCROLLING_MENU">HORIZONTAL_SCROLLING_MENU</a></dd>
							<dt><strong>htmlspecialchars_decode</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionhtmlspecialchars_decode">htmlspecialchars_decode()</a></dd>
							<dt><strong>html_convert_absolute2root_relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodhtml_convert_absolute2root_relative">Url::html_convert_absolute2root_relative()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML text with only relatives urls</dd>
							<dt><strong>html_convert_root_relative2absolute</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodhtml_convert_root_relative2absolute">Url::html_convert_root_relative2absolute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML text with only absolutes urls</dd>
							<dt><strong>html_convert_root_relative2relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodhtml_convert_root_relative2relative">Url::html_convert_root_relative2relative()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Transforms the relative URL whose base is the site root (for instance /images/mypic.png) to the real relative path fited to the current page.</dd>
							<dt><strong>html_entity_decode</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionhtml_entity_decode">html_entity_decode()</a></dd>
							<dt><strong>HTML_NO_PROTECT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineHTML_NO_PROTECT">HTML_NO_PROTECT</a></dd>
							<dt><strong>HTML_PROTECT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineHTML_PROTECT">HTML_PROTECT</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$id</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$id">ModuleInterface::$id</a></dd>
							<dt><strong>$id</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$id">Event::$id</a></dd>
							<dt><strong>$id</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$id">FeedsCat::$id</a></dd>
							<dt><strong>$id</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$id">Application::$id</a></dd>
							<dt><strong>$id</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$id">Menu::$id</a></dd>
							<dt><strong>$idcom</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$idcom">Comments::$idcom</a></dd>
							<dt><strong>$identifier</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$identifier">Event::$identifier</a></dd>
							<dt><strong>$identifier</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$identifier">ContentEditor::$identifier</a></dd>
							<dt><strong>$idprov</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$idprov">Comments::$idprov</a></dd>
							<dt><strong>$idprov</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$idprov">Note::$idprov</a></dd>
							<dt><strong>$id_cat</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$id_cat">Feed::$id_cat</a></dd>
							<dt><strong>$id_in_module</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$id_in_module">Event::$id_in_module</a></dd>
							<dt><strong>$id_search</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$id_search">Search::$id_search</a></dd>
							<dt><strong>$id_user</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$id_user">Search::$id_user</a></dd>
							<dt><strong>$image</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$image">LinksMenuElement::$image</a></dd>
							<dt><strong>$image_url</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$image_url">FeedItem::$image_url</a></dd>
							<dt><strong>$improvments</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$improvments">Application::$improvments</a></dd>
							<dt><strong>$infos</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$infos">ModuleInterface::$infos</a></dd>
							<dt><strong>$instance</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$instance">Captcha::$instance</a></dd>
							<dt><strong>$is_kernel_script</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$is_kernel_script">Comments::$is_kernel_script</a></dd>
							<dt><strong>$is_open</strong></dt>
				<dd>in file file_system_element.class.php, variable <a href="io/filesystem/FileSystemElement.php#var$is_open">FileSystemElement::$is_open</a></dd>
							<dt><strong>$is_relative</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$is_relative">Url::$is_relative</a></dd>
							<dt><strong>$items</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$items">FeedData::$items</a></dd>
							<dt><strong>id</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodid">Menu::id()</a></dd>
							<dt><strong>IGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineIGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH">IGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</a></dd>
							<dt><strong>import</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionimport">import()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Umports a class or a lib from the framework</dd>
							<dt><strong>inc</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functioninc">inc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Includes a file</dd>
							<dt><strong>INCORRECT_DISPLAYING_CONFIGURATION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineINCORRECT_DISPLAYING_CONFIGURATION">INCORRECT_DISPLAYING_CONFIGURATION</a></dd>
							<dt><strong>INC_IMPORT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineINC_IMPORT">INC_IMPORT</a></dd>
							<dt><strong>indent_query</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodindent_query">Sql::indent_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Indents a MySQL query.</dd>
							<dt><strong>insert_id</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodinsert_id">Sql::insert_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the ID generated from the previous INSERT operation.</dd>
							<dt><strong>insert_results</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodinsert_results">Search::insert_results()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Inserts search results in the database cache in order to speed up next searches. Query complexity: 1 + k / 10 queries. (k represent the number of results to insert in the database)</dd>
							<dt><strong>install_module</strong></dt>
				<dd>in file packages_manager.class.php, method <a href="modules/PackagesManager.php#methodinstall_module">PackagesManager::install_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Installs a module.</dd>
							<dt><strong>INTEGRATED_IN_ENVIRONMENT</strong></dt>
				<dd>in file comments.class.php, constant <a href="content/_content---comments.class.php.php#defineINTEGRATED_IN_ENVIRONMENT">INTEGRATED_IN_ENVIRONMENT</a></dd>
							<dt><strong>is_available</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodis_available">Captcha::is_available()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if captcha is loaded, disabled for members.</dd>
							<dt><strong>is_enabled</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodis_enabled">ModuleInterface::is_enabled()</a></dd>
							<dt><strong>is_enabled</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodis_enabled">Menu::is_enabled()</a></dd>
							<dt><strong>is_in_cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodis_in_cache">Feed::is_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the feed data are in the cache</dd>
							<dt><strong>is_in_cache</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodis_in_cache">Search::is_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the module results are in cache, else, false.</dd>
							<dt><strong>is_loaded</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodis_loaded">Comments::is_loaded()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check if the comments system is correctly loaded.</dd>
							<dt><strong>is_open</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodis_open">File::is_open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Allows you to know if the file is already open.</dd>
							<dt><strong>is_relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodis_relative">Url::is_relative()</a></dd>
							<dt><strong>is_search_id_in_cache</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodis_search_id_in_cache">Search::is_search_id_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the id_search is in cache, else, false.</dd>
							<dt><strong>is_valid</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodis_valid">Captcha::is_valid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check if the code is valid, then delete it in the database to avoid multiple attempts.</dd>
							<dt><strong>images_stats.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---images_stats.class.php.php">images_stats.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="j"></a>
	<div>
		<h2>j</h2>
		<dl>
							<dt><strong>js_require</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodjs_require">Captcha::js_require()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Javascript alert if the formular of the captcha code is empty.</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="k"></a>
	<div>
		<h2>k</h2>
		<dl>
							<dt><strong>KERNEL_SCRIPT</strong></dt>
				<dd>in file comments.class.php, constant <a href="content/_content---comments.class.php.php#defineKERNEL_SCRIPT">KERNEL_SCRIPT</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>$lang</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$lang">FeedData::$lang</a></dd>
							<dt><strong>$language</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$language">Application::$language</a></dd>
							<dt><strong>$language_type</strong></dt>
				<dd>in file content_formatting_factory.class.php, variable <a href="content/parser/ContentFormattingFactory.php#var$language_type">ContentFormattingFactory::$language_type</a></dd>
							<dt><strong>$language_type</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$language_type">ContentEditor::$language_type</a></dd>
							<dt><strong>$last_modification_date</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$last_modification_date">SiteMapLink::$last_modification_date</a></dd>
							<dt><strong>$lines</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$lines">File::$lines</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$link">Sql::$link</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$link">FeedData::$link</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file site_map_section.class.php, variable <a href="content/sitemap/SiteMapSection.php#var$link">SiteMapSection::$link</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$link">SiteMapLink::$link</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$link">FeedItem::$link</a></dd>
							<dt><strong>$link_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$link_file">SitemapExportConfig::$link_file</a></dd>
							<dt><strong>$list</strong></dt>
				<dd>in file feeds_list.class.php, variable <a href="content/syndication/FeedsList.php#var$list">FeedsList::$list</a></dd>
							<dt><strong>$loaded_modules</strong></dt>
				<dd>in file modules_discovery_service.class.php, variable <a href="modules/ModulesDiscoveryService.php#var$loaded_modules">ModulesDiscoveryService::$loaded_modules</a></dd>
							<dt><strong>$localized_language</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$localized_language">Application::$localized_language</a></dd>
							<dt><strong>$lock_com</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$lock_com">Comments::$lock_com</a></dd>
							<dt><strong>LIB_IMPORT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineLIB_IMPORT">LIB_IMPORT</a></dd>
							<dt><strong>limit</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlimit">Sql::limit()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the MySQL syntax used to impose a limit in your row selection.</dd>
							<dt><strong>LinksMenu</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodLinksMenu">LinksMenu::LinksMenu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Constructor</dd>
							<dt><strong>LinksMenu</strong></dt>
				<dd>in file links_menu.class.php, class <a href="menu/linksmenu/LinksMenu.php">LinksMenu</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create a Menu with children. Children could be Menu or LinksMenuLink objects</dd>
							<dt><strong>LinksMenuElement</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodLinksMenuElement">LinksMenuElement::LinksMenuElement()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a LinksMenuElement object</dd>
							<dt><strong>LinksMenuElement</strong></dt>
				<dd>in file links_menu_element.class.php, class <a href="menu/linksmenu/LinksMenuElement.php">LinksMenuElement</a><br>&nbsp;&nbsp;&nbsp;&nbsp;A LinksMenuElement contains a Title, an url, and an image url</dd>
							<dt><strong>LinksMenuLink</strong></dt>
				<dd>in file links_menu_link.class.php, class <a href="menu/linksmenu/LinksMenuLink.php">LinksMenuLink</a><br>&nbsp;&nbsp;&nbsp;&nbsp;A Simple menu link</dd>
							<dt><strong>LinksMenuLink</strong></dt>
				<dd>in file links_menu_link.class.php, method <a href="menu/linksmenu/LinksMenuLink.php#methodLinksMenuLink">LinksMenuLink::LinksMenuLink()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Constructor</dd>
							<dt><strong>LINKS_MENU_ELEMENT__CLASS</strong></dt>
				<dd>in file links_menu_element.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php#defineLINKS_MENU_ELEMENT__CLASS">LINKS_MENU_ELEMENT__CLASS</a></dd>
							<dt><strong>LINKS_MENU_ELEMENT__CLASSIC_DISPLAYING</strong></dt>
				<dd>in file links_menu_element.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php#defineLINKS_MENU_ELEMENT__CLASSIC_DISPLAYING">LINKS_MENU_ELEMENT__CLASSIC_DISPLAYING</a></dd>
							<dt><strong>LINKS_MENU_ELEMENT__FULL_DISPLAYING</strong></dt>
				<dd>in file links_menu_element.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php#defineLINKS_MENU_ELEMENT__FULL_DISPLAYING">LINKS_MENU_ELEMENT__FULL_DISPLAYING</a></dd>
							<dt><strong>LINKS_MENU_LINK__CLASS</strong></dt>
				<dd>in file links_menu_link.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_link.class.php.php#defineLINKS_MENU_LINK__CLASS">LINKS_MENU_LINK__CLASS</a></dd>
							<dt><strong>LINKS_MENU__CLASS</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineLINKS_MENU__CLASS">LINKS_MENU__CLASS</a></dd>
							<dt><strong>LINK_START_PAGE</strong></dt>
				<dd>in file pagination.class.php, constant <a href="util/_util---pagination.class.php.php#defineLINK_START_PAGE">LINK_START_PAGE</a></dd>
							<dt><strong>list_databases</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlist_databases">Sql::list_databases()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the existing data bases on the DBMS at which the object is connected. Only the data bases visible for the user connected will be returned.</dd>
							<dt><strong>list_db_tables</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodlist_db_tables">Backup::list_db_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the list of the tables present on the database used.</dd>
							<dt><strong>list_fields</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlist_fields">Sql::list_fields()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists all the columns of a table.</dd>
							<dt><strong>list_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlist_tables">Sql::list_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the tables (name and informations relative to each table) of the data base at which is connected this SQL object. This method calls the SHOW TABLE STATUS MySQL query, to know more about it, see http://dev.mysql.com/doc/refman/5.1/en/show-table-status.html</dd>
							<dt><strong>load</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodload">Session::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get informations from the user, and set it for his session.</dd>
							<dt><strong>load</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodload">Cache::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a file file.</dd>
							<dt><strong>load</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodload">MenuService::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieve a Menu Object from the database by its id</dd>
							<dt><strong>load</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodload">Application::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads an XML description</dd>
							<dt><strong>LOAD_CACHE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineLOAD_CACHE">LOAD_CACHE</a></dd>
							<dt><strong>load_data</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methodload_data">Stats::load_data()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Load data for the charts.</dd>
							<dt><strong>load_data</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodload_data">Feed::load_data()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a FeedData element</dd>
							<dt><strong>load_file</strong></dt>
				<dd>in file rss.class.php, method <a href="content/syndication/RSS.php#methodload_file">RSS::load_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a feed by its url</dd>
							<dt><strong>load_file</strong></dt>
				<dd>in file atom.class.php, method <a href="content/syndication/ATOM.php#methodload_file">ATOM::load_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a feed by its url</dd>
							<dt><strong>load_file</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodload_file">Feed::load_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a feed by its url</dd>
							<dt><strong>load_ini_file</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionload_ini_file">load_ini_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a configuration file. You choose a bases path, and you specify a folder name in which you file should be found, if it doesn't exist, it will take a file in another folder. It's very interesting when you want to</dd>
							<dt><strong>load_menu_lang</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionload_menu_lang">load_menu_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a menu lang file. It will load alone the file corresponding to the user lang, but if it doesn't exist, another lang will be choosen. An error will be displayed on the page and the script execution will be stopped if no lang file is found for this menu.</dd>
							<dt><strong>load_module_lang</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionload_module_lang">load_module_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a module lang file. It will load alone the file corresponding to the user lang, but if it doesn't exist, another lang will be choosen. An error will be displayed on the page and the script execution will be stopped if no lang file is found for this module.</dd>
							<dt><strong>lock</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodlock">Comments::lock()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lock or unlock comments for an item.</dd>
							<dt><strong>lock</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodlock">File::lock()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Locks the file (it won't be readable by another thread which could try to access it).</dd>
							<dt><strong>LOCK</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineLOCK">LOCK</a></dd>
							<dt><strong>LOW_PRIORITY</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineLOW_PRIORITY">LOW_PRIORITY</a></dd>
							<dt><strong>links_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/linksmenu/_menu---links---links_menu.class.php.php">links_menu.class.php</a></dd>
							<dt><strong>links_menu_element.class.php</strong></dt>
				<dd>procedural page <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php">links_menu_element.class.php</a></dd>
							<dt><strong>links_menu_link.class.php</strong></dt>
				<dd>procedural page <a href="menu/linksmenu/_menu---links---links_menu_link.class.php.php">links_menu_link.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>$mode</strong></dt>
				<dd>in file file.class.php, variable <a href="io/filesystem/File.php#var$mode">File::$mode</a></dd>
							<dt><strong>$module</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$module">Contribution::$module</a></dd>
							<dt><strong>$modules</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$modules">Search::$modules</a></dd>
							<dt><strong>$modules_conditions</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$modules_conditions">Search::$modules_conditions</a></dd>
							<dt><strong>$module_data_path</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$module_data_path">Template::$module_data_path</a></dd>
							<dt><strong>$module_folder</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$module_folder">Note::$module_folder</a></dd>
							<dt><strong>$module_folder</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$module_folder">Comments::$module_folder</a></dd>
							<dt><strong>$module_id</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$module_id">FeedMenu::$module_id</a></dd>
							<dt><strong>$module_id</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$module_id">FeedsCat::$module_id</a></dd>
							<dt><strong>$module_id</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$module_id">Feed::$module_id</a></dd>
							<dt><strong>$module_map_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$module_map_file">SitemapExportConfig::$module_map_file</a></dd>
							<dt><strong>$must_regenerate_cache</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$must_regenerate_cache">Event::$must_regenerate_cache</a></dd>
							<dt><strong>module_map.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---module_map.class.php.php">module_map.class.php</a></dd>
							<dt><strong>menu_service.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---menu_service.class.php.php">menu_service.class.php</a></dd>
							<dt><strong>mysql.class.php</strong></dt>
				<dd>procedural page <a href="db/_db---mysql.class.php.php">mysql.class.php</a></dd>
							<dt><strong>mail.class.php</strong></dt>
				<dd>procedural page <a href="io/_io---mail.class.php.php">mail.class.php</a></dd>
							<dt><strong>MAGIC_QUOTES_DISABLED</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineMAGIC_QUOTES_DISABLED">MAGIC_QUOTES_DISABLED</a></dd>
							<dt><strong>Mail</strong></dt>
				<dd>in file mail.class.php, class <a href="io/Mail.php">Mail</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to send mails without having to deal with the mail headers and parameters.</dd>
							<dt><strong>Mail</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodMail">Mail::Mail()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Mail object.</dd>
							<dt><strong>Member_memory_used</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodMember_memory_used">Uploads::Member_memory_used()</a></dd>
							<dt><strong>Menu</strong></dt>
				<dd>in file menu.class.php, class <a href="menu/Menu.php">Menu</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a menu element and is used to build any kind of menu</dd>
							<dt><strong>Menu</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodMenu">Menu::Menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a Menu element.</dd>
							<dt><strong>menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/_menu---menu.class.php.php">menu.class.php</a></dd>
							<dt><strong>mini_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/minimenu/_menu---mini---mini_menu.class.php.php">mini_menu.class.php</a></dd>
							<dt><strong>module_mini_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php">module_mini_menu.class.php</a></dd>
							<dt><strong>MenuService</strong></dt>
				<dd>in file menu_service.class.php, class <a href="core/MenuService.php">MenuService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This service manage kernel menus by adding the persistance to menus objects. It also provides all moving and disabling methods to change the website appearance.</dd>
							<dt><strong>MENU_AUTH_BIT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_AUTH_BIT">MENU_AUTH_BIT</a></dd>
							<dt><strong>MENU_ENABLED</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_ENABLED">MENU_ENABLED</a></dd>
							<dt><strong>MENU_ENABLE_OR_NOT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_ENABLE_OR_NOT">MENU_ENABLE_OR_NOT</a></dd>
							<dt><strong>MENU_NOT_ENABLED</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_NOT_ENABLED">MENU_NOT_ENABLED</a></dd>
							<dt><strong>MENU__CLASS</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU__CLASS">MENU__CLASS</a></dd>
							<dt><strong>merge_auth</strong></dt>
				<dd>in file authorizations.class.php, method <a href="members/Authorizations.php#methodmerge_auth">Authorizations::merge_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Merge two authorizations array, first is the parent, second is the inherited child.</dd>
							<dt><strong>MIME_FORMAT_HTML</strong></dt>
				<dd>in file mail.class.php, constant <a href="io/_io---mail.class.php.php#defineMIME_FORMAT_HTML">MIME_FORMAT_HTML</a></dd>
							<dt><strong>MIME_FORMAT_TEXT</strong></dt>
				<dd>in file mail.class.php, constant <a href="io/_io---mail.class.php.php#defineMIME_FORMAT_TEXT">MIME_FORMAT_TEXT</a></dd>
							<dt><strong>MiniCalendar</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodMiniCalendar">MiniCalendar::MiniCalendar()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a calendar which will be displayable.</dd>
							<dt><strong>MiniCalendar</strong></dt>
				<dd>in file mini_calendar.class.php, class <a href="util/MiniCalendar.php">MiniCalendar</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to retrieve easily a date entered by a user. If the user isn't in the same timezone as the server, the hour will be automatically recomputed.</dd>
							<dt><strong>MiniMenu</strong></dt>
				<dd>in file mini_menu.class.php, class <a href="menu/minimenu/MiniMenu.php">MiniMenu</a></dd>
							<dt><strong>MiniMenu</strong></dt>
				<dd>in file mini_menu.class.php, method <a href="menu/minimenu/MiniMenu.php#methodMiniMenu">MiniMenu::MiniMenu()</a></dd>
							<dt><strong>MINI_MENU__CLASS</strong></dt>
				<dd>in file mini_menu.class.php, constant <a href="menu/minimenu/_menu---mini---mini_menu.class.php.php#defineMINI_MENU__CLASS">MINI_MENU__CLASS</a></dd>
							<dt><strong>ModuleInterface</strong></dt>
				<dd>in file module_interface.class.php, class <a href="modules/ModuleInterface.php">ModuleInterface</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This Class allow you to call methods on a ModuleInterface extended class that you're not sure of the method's availality. It also provides a set of generic methods that you could use to integrate your module with others, or allow your module to share services.</dd>
							<dt><strong>ModuleInterface</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodModuleInterface">ModuleInterface::ModuleInterface()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;ModuleInterface constructor</dd>
							<dt><strong>ModuleMap</strong></dt>
				<dd>in file module_map.class.php, class <a href="content/sitemap/ModuleMap.php">ModuleMap</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The ModuleMap class represents the map of a module. It has a description (generally the module description) and contains some elements which can be some simple links or some sections (which can match the categories for example).</dd>
							<dt><strong>ModuleMap</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodModuleMap">ModuleMap::ModuleMap()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ModuleMap object</dd>
							<dt><strong>ModuleMiniMenu</strong></dt>
				<dd>in file module_mini_menu.class.php, method <a href="menu/modulesminimenu/ModuleMiniMenu.php#methodModuleMiniMenu">ModuleMiniMenu::ModuleMiniMenu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a ModuleMiniMenu element.</dd>
							<dt><strong>ModuleMiniMenu</strong></dt>
				<dd>in file module_mini_menu.class.php, class <a href="menu/modulesminimenu/ModuleMiniMenu.php">ModuleMiniMenu</a></dd>
							<dt><strong>modules_discovery_service.class.php</strong></dt>
				<dd>procedural page <a href="modules/_modules---modules_discovery_service.class.php.php">modules_discovery_service.class.php</a></dd>
							<dt><strong>module_interface.class.php</strong></dt>
				<dd>procedural page <a href="modules/_modules---module_interface.class.php.php">module_interface.class.php</a></dd>
							<dt><strong>ModulesDiscoveryService</strong></dt>
				<dd>in file modules_discovery_service.class.php, class <a href="modules/ModulesDiscoveryService.php">ModulesDiscoveryService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is a ModuleInterface factory providing some services like mass operations (on several modules at the same time) or identifications methods to get all modules that provide a given functionality</dd>
							<dt><strong>ModulesDiscoveryService</strong></dt>
				<dd>in file modules_discovery_service.class.php, method <a href="modules/ModulesDiscoveryService.php#methodModulesDiscoveryService">ModulesDiscoveryService::ModulesDiscoveryService()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new ModuleInterface factory</dd>
							<dt><strong>modules_in_cache</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodmodules_in_cache">Search::modules_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the list of the modules ids present in the cache</dd>
							<dt><strong>MODULE_ALREADY_INSTALLED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_ALREADY_INSTALLED">MODULE_ALREADY_INSTALLED</a></dd>
							<dt><strong>MODULE_ATTRIBUTE_DOES_NOT_EXIST</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineMODULE_ATTRIBUTE_DOES_NOT_EXIST">MODULE_ATTRIBUTE_DOES_NOT_EXIST</a></dd>
							<dt><strong>MODULE_FILES_COULD_NOT_BE_DROPPED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_FILES_COULD_NOT_BE_DROPPED">MODULE_FILES_COULD_NOT_BE_DROPPED</a></dd>
							<dt><strong>MODULE_INSTALLED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_INSTALLED">MODULE_INSTALLED</a></dd>
							<dt><strong>MODULE_MINI_MENU__CLASS</strong></dt>
				<dd>in file module_mini_menu.class.php, constant <a href="menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php#defineMODULE_MINI_MENU__CLASS">MODULE_MINI_MENU__CLASS</a></dd>
							<dt><strong>MODULE_NOT_AVAILABLE</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineMODULE_NOT_AVAILABLE">MODULE_NOT_AVAILABLE</a><br>&nbsp;&nbsp;&nbsp;&nbsp;module_interface.                            -------------------   begin                : January 15, 2008   copyright            : (C) 2008 Lo�c Rouchon   email                : horn@phpboost.
###################################################
   This program is free software; you can redistribute it and/or modify   it under the terms of the GNU General Public License as published by   the Free Software Foundation; either version 2 of the License, or   (at your option) any later version.</dd>
							<dt><strong>MODULE_NOT_YET_IMPLEMENTED</strong></dt>
				<dd>in file module_interface.class.php, constant <a href="modules/_modules---module_interface.class.php.php#defineMODULE_NOT_YET_IMPLEMENTED">MODULE_NOT_YET_IMPLEMENTED</a></dd>
							<dt><strong>MODULE_UNINSTALLED</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineMODULE_UNINSTALLED">MODULE_UNINSTALLED</a></dd>
							<dt><strong>move</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodmove">MenuService::move()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Move a menu into a block and save it. Enable or disable it according to the destination block</dd>
							<dt><strong>move</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodmove">CategoriesManager::move()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Moves a category (makes it gone up or down)</dd>
							<dt><strong>MOVE_CATEGORY_DOWN</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineMOVE_CATEGORY_DOWN">MOVE_CATEGORY_DOWN</a></dd>
							<dt><strong>MOVE_CATEGORY_UP</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineMOVE_CATEGORY_UP">MOVE_CATEGORY_UP</a></dd>
							<dt><strong>MOVE_DOWN</strong></dt>
				<dd>in file menu_service.class.php, constant <a href="core/_core---menu_service.class.php.php#defineMOVE_DOWN">MOVE_DOWN</a></dd>
							<dt><strong>Move_file</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodMove_file">Uploads::Move_file()</a></dd>
							<dt><strong>Move_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodMove_folder">Uploads::Move_folder()</a></dd>
							<dt><strong>move_into_another</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodmove_into_another">CategoriesManager::move_into_another()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Moves a category into another category. You can specify its future position in its future parent category.</dd>
							<dt><strong>MOVE_UP</strong></dt>
				<dd>in file menu_service.class.php, constant <a href="core/_core---menu_service.class.php.php#defineMOVE_UP">MOVE_UP</a></dd>
							<dt><strong>mini_calendar.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---mini_calendar.class.php.php">mini_calendar.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>$name</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$name">FeedMenu::$name</a></dd>
							<dt><strong>$name</strong></dt>
				<dd>in file module_interface.class.php, variable <a href="modules/ModuleInterface.php#var$name">ModuleInterface::$name</a></dd>
							<dt><strong>$name</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$name">Application::$name</a></dd>
							<dt><strong>$name</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$name">SiteMapLink::$name</a></dd>
							<dt><strong>$name</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$name">Feed::$name</a></dd>
							<dt><strong>$nbr_color</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$nbr_color">Stats::$nbr_color</a></dd>
							<dt><strong>$nbr_com</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$nbr_com">Comments::$nbr_com</a></dd>
							<dt><strong>$nbr_end_links</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$nbr_end_links">Pagination::$nbr_end_links</a></dd>
							<dt><strong>$nbr_entry</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$nbr_entry">Stats::$nbr_entry</a></dd>
							<dt><strong>$nbr_start_links</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$nbr_start_links">Pagination::$nbr_start_links</a></dd>
							<dt><strong>$new_features</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$new_features">Application::$new_features</a></dd>
							<dt><strong>$notation_scale</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$notation_scale">Note::$notation_scale</a></dd>
							<dt><strong>$number</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$number">FeedMenu::$number</a></dd>
							<dt><strong>$num_instance</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$num_instance">MiniCalendar::$num_instance</a></dd>
							<dt><strong>note.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---note.class.php.php">note.class.php</a></dd>
							<dt><strong>NEW_CATEGORY_IS_IN_ITS_CHILDRENS</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNEW_CATEGORY_IS_IN_ITS_CHILDRENS">NEW_CATEGORY_IS_IN_ITS_CHILDRENS</a></dd>
							<dt><strong>NEW_PARENT_CATEGORY_DOES_NOT_EXIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNEW_PARENT_CATEGORY_DOES_NOT_EXIST">NEW_PARENT_CATEGORY_DOES_NOT_EXIST</a></dd>
							<dt><strong>NEW_STATUS_UNKNOWN</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNEW_STATUS_UNKNOWN">NEW_STATUS_UNKNOWN</a></dd>
							<dt><strong>NOCHECK_PM_BOX</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineNOCHECK_PM_BOX">NOCHECK_PM_BOX</a></dd>
							<dt><strong>NORMAL_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNORMAL_MODE">NORMAL_MODE</a></dd>
							<dt><strong>NOTCLOSEFILE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineNOTCLOSEFILE">NOTCLOSEFILE</a></dd>
							<dt><strong>Note</strong></dt>
				<dd>in file note.class.php, class <a href="content/Note.php">Note</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides you an easy way to manage notation.</dd>
							<dt><strong>Note</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methodNote">Note::Note()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create an new object Note.</dd>
							<dt><strong>NOTE_DISPLAY_BLOCK</strong></dt>
				<dd>in file note.class.php, constant <a href="content/_content---note.class.php.php#defineNOTE_DISPLAY_BLOCK">NOTE_DISPLAY_BLOCK</a></dd>
							<dt><strong>NOTE_DISPLAY_NOTE</strong></dt>
				<dd>in file note.class.php, constant <a href="content/_content---note.class.php.php#defineNOTE_DISPLAY_NOTE">NOTE_DISPLAY_NOTE</a></dd>
							<dt><strong>NOTE_NODISPLAY_NBRNOTES</strong></dt>
				<dd>in file note.class.php, constant <a href="content/_content---note.class.php.php#defineNOTE_NODISPLAY_NBRNOTES">NOTE_NODISPLAY_NBRNOTES</a></dd>
							<dt><strong>NOT_INSTALLED_MODULE</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineNOT_INSTALLED_MODULE">NOT_INSTALLED_MODULE</a></dd>
							<dt><strong>NOT_RECURSIVE_EXPLORATION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNOT_RECURSIVE_EXPLORATION">NOT_RECURSIVE_EXPLORATION</a></dd>
							<dt><strong>NO_ALLOCATE_COLOR</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_ALLOCATE_COLOR">NO_ALLOCATE_COLOR</a></dd>
							<dt><strong>NO_ARCHIVE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineNO_ARCHIVE_ERROR">NO_ARCHIVE_ERROR</a></dd>
							<dt><strong>NO_AUTOCONNECT</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineNO_AUTOCONNECT">NO_AUTOCONNECT</a></dd>
							<dt><strong>NO_DELETE_ON_ERROR</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineNO_DELETE_ON_ERROR">NO_DELETE_ON_ERROR</a></dd>
							<dt><strong>NO_DRAW_LEGEND</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_DRAW_LEGEND">NO_DRAW_LEGEND</a></dd>
							<dt><strong>NO_DRAW_PERCENT</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_DRAW_PERCENT">NO_DRAW_PERCENT</a></dd>
							<dt><strong>NO_DRAW_VALUES</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_DRAW_VALUES">NO_DRAW_VALUES</a></dd>
							<dt><strong>NO_EDITOR_UNPARSE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineNO_EDITOR_UNPARSE">NO_EDITOR_UNPARSE</a></dd>
							<dt><strong>NO_FATAL_ERROR</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineNO_FATAL_ERROR">NO_FATAL_ERROR</a></dd>
							<dt><strong>NO_FATAL_ERROR_CACHE</strong></dt>
				<dd>in file cache.class.php, constant <a href="core/_core---cache.class.php.php#defineNO_FATAL_ERROR_CACHE">NO_FATAL_ERROR_CACHE</a></dd>
							<dt><strong>NO_FILE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineNO_FILE_ERROR">NO_FILE_ERROR</a></dd>
							<dt><strong>NO_LINE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineNO_LINE_ERROR">NO_LINE_ERROR</a></dd>
							<dt><strong>NO_PREVIOUS_NEXT_LINKS</strong></dt>
				<dd>in file pagination.class.php, constant <a href="util/_util---pagination.class.php.php#defineNO_PREVIOUS_NEXT_LINKS">NO_PREVIOUS_NEXT_LINKS</a></dd>
							<dt><strong>NO_UNIQ_NAME</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineNO_UNIQ_NAME">NO_UNIQ_NAME</a></dd>
							<dt><strong>NO_UPDATE_PAGES</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineNO_UPDATE_PAGES">NO_UPDATE_PAGES</a></dd>
							<dt><strong>number_round</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionnumber_round">number_round()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Rounds a number</dd>
							<dt><strong>numeric</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionnumeric">numeric()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Converts a string to a numeric value.</dd>
							<dt><strong>num_rows</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodnum_rows">Sql::num_rows()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of rows got by a selection query.</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="o"></a>
	<div>
		<h2>o</h2>
		<dl>
							<dt><strong>$object</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$object">Mail::$object</a></dd>
							<dt><strong>$options</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$options">Note::$options</a></dd>
							<dt><strong>$option_checked</strong></dt>
				<dd>in file form_checkbox_option.class.php, variable <a href="builder/form/FormCheckboxOption.php#var$option_checked">FormCheckboxOption::$option_checked</a></dd>
							<dt><strong>$option_checked</strong></dt>
				<dd>in file form_radio_choice_option.class.php, variable <a href="builder/form/FormRadioChoiceOption.php#var$option_checked">FormRadioChoiceOption::$option_checked</a></dd>
							<dt><strong>$option_selected</strong></dt>
				<dd>in file form_select_option.class.php, variable <a href="builder/form/FormSelectOption.php#var$option_selected">FormSelectOption::$option_selected</a></dd>
							<dt><strong>$option_title</strong></dt>
				<dd>in file form_radio_choice_option.class.php, variable <a href="builder/form/FormRadioChoiceOption.php#var$option_title">FormRadioChoiceOption::$option_title</a></dd>
							<dt><strong>$option_title</strong></dt>
				<dd>in file form_checkbox_option.class.php, variable <a href="builder/form/FormCheckboxOption.php#var$option_title">FormCheckboxOption::$option_title</a></dd>
							<dt><strong>$option_title</strong></dt>
				<dd>in file form_select_option.class.php, variable <a href="builder/form/FormSelectOption.php#var$option_title">FormSelectOption::$option_title</a></dd>
							<dt><strong>of_class</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionof_class">of_class()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Tells if an object is an instance of a class</dd>
							<dt><strong>open</strong></dt>
				<dd>in file folder.class.php, method <a href="io/filesystem/Folder.php#methodopen">Folder::open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Opens the folder.</dd>
							<dt><strong>open</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodopen">FileSystemElement::open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Opens the file system element.</dd>
							<dt><strong>open</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodopen">File::open()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Opens the file. You cannot read or write a closed file, use this method to open it.</dd>
							<dt><strong>OPEN_AFTER</strong></dt>
				<dd>in file file_system_element.class.php, constant <a href="io/filesystem/_io---filesystem---file_system_element.class.php.php#defineOPEN_AFTER">OPEN_AFTER</a></dd>
							<dt><strong>OPEN_NOW</strong></dt>
				<dd>in file file_system_element.class.php, constant <a href="io/filesystem/_io---filesystem---file_system_element.class.php.php#defineOPEN_NOW">OPEN_NOW</a></dd>
							<dt><strong>optimize_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodoptimize_tables">Sql::optimize_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Optimizes some tables in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>$page</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$page">Pagination::$page</a></dd>
							<dt><strong>$page_path</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$page_path">Parser::$page_path</a></dd>
							<dt><strong>$path</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$path">Note::$path</a></dd>
							<dt><strong>$path</strong></dt>
				<dd>in file file_system_element.class.php, variable <a href="io/filesystem/FileSystemElement.php#var$path">FileSystemElement::$path</a></dd>
							<dt><strong>$path</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$path">Comments::$path</a></dd>
							<dt><strong>$path_to_root</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$path_to_root">Parser::$path_to_root</a></dd>
							<dt><strong>$path_to_root</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$path_to_root">Url::$path_to_root</a></dd>
							<dt><strong>$personal_tpl</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$personal_tpl">Errors::$personal_tpl</a></dd>
							<dt><strong>$pm_convers_id</strong></dt>
				<dd>in file pm.class.php, variable <a href="members/PrivateMsg.php#var$pm_convers_id">PrivateMsg::$pm_convers_id</a></dd>
							<dt><strong>$pm_msg_id</strong></dt>
				<dd>in file pm.class.php, variable <a href="members/PrivateMsg.php#var$pm_msg_id">PrivateMsg::$pm_msg_id</a></dd>
							<dt><strong>$position</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$position">Menu::$position</a></dd>
							<dt><strong>$poster_id</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$poster_id">Contribution::$poster_id</a></dd>
							<dt><strong>$poster_login</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$poster_login">Contribution::$poster_login</a></dd>
							<dt><strong>$priority</strong></dt>
				<dd>in file administrator_alert.class.php, variable <a href="events/AdministratorAlert.php#var$priority">AdministratorAlert::$priority</a></dd>
							<dt><strong>$priority</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$priority">Application::$priority</a></dd>
							<dt><strong>$priority</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$priority">SiteMapLink::$priority</a></dd>
							<dt><strong>$properties</strong></dt>
				<dd>in file administrator_alert.class.php, variable <a href="events/AdministratorAlert.php#var$properties">AdministratorAlert::$properties</a></dd>
							<dt><strong>$pubdate</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$pubdate">Application::$pubdate</a></dd>
							<dt><strong>parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---parser.class.php.php">parser.class.php</a></dd>
							<dt><strong>pm.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---pm.class.php.php">pm.class.php</a></dd>
							<dt><strong>packages_manager.class.php</strong></dt>
				<dd>procedural page <a href="modules/_modules---packages_manager.class.php.php">packages_manager.class.php</a></dd>
							<dt><strong>PackagesManager</strong></dt>
				<dd>in file packages_manager.class.php, class <a href="modules/PackagesManager.php">PackagesManager</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to manages the PHPBoost packages which are nothing else than the modules.</dd>
							<dt><strong>pages_displayed</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionpages_displayed">pages_displayed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This function is called by the kernel on each displayed page to count the number of pages seen at each hour.</dd>
							<dt><strong>Pagination</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methodPagination">Pagination::Pagination()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Buils a Pagination.</dd>
							<dt><strong>Pagination</strong></dt>
				<dd>in file pagination.class.php, class <a href="util/Pagination.php">Pagination</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to manage easily a pagination system. It's very useful when you have a lot of items and you cannot display all of them. It also can generate the where clause to insert in your SQL query which selects the items.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodparse">Template::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the file. It will use the variables you assigned.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file bbcode_parser.class.php, method <a href="content/parser/BBCodeParser.php#methodparse">BBCodeParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the parser content from BBCode to XHTML.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodparse">Sql::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a SQL file. The SQL file contains the name of the tables with the prefix phpboost_.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file bbcode_unparser.class.php, method <a href="content/parser/BBCodeUnparser.php#methodparse">BBCodeUnparser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unparses the content of the parser. Converts it from HTML syntax to BBcode syntax</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file template_highlighter.class.php, method <a href="content/parser/TemplateHighlighter.php#methodparse">TemplateHighlighter::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Highlights the code. It uses the geshi HTML syntax highlighter and then it highlights the specific template syntax.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file bbcode_highlighter.class.php, method <a href="content/parser/BBCodeHighlighter.php#methodparse">BBCodeHighlighter::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Highlights the content of the parser.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file tinymce_unparser.class.php, method <a href="content/parser/TinyMCEUnparser.php#methodparse">TinyMCEUnparser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unparses the content of the parser. It goes from the PHPBoost reference formatting syntax to the TinyMCE one.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file tinymce_parser.class.php, method <a href="content/parser/TinyMCEParser.php#methodparse">TinyMCEParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the content of the parser. Translates the whole content from the TinyMCE syntax to the PHPBoost one.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file content_second_parser.class.php, method <a href="content/parser/ContentSecondParser.php#methodparse">ContentSecondParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the content of the parser. The result will be ready to be displayed.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodparse">ContentParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the content of the parser</dd>
							<dt><strong>Parser</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodParser">Parser::Parser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Parser object.</dd>
							<dt><strong>Parser</strong></dt>
				<dd>in file parser.class.php, class <a href="content/parser/Parser.php">Parser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is the basis of all the formatting processings that exist in PHPBoost.</dd>
							<dt><strong>PARSER_DO_NOT_STRIP_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#definePARSER_DO_NOT_STRIP_SLASHES">PARSER_DO_NOT_STRIP_SLASHES</a></dd>
							<dt><strong>PARSER_STRIP_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#definePARSER_STRIP_SLASHES">PARSER_STRIP_SLASHES</a></dd>
							<dt><strong>parse_ini_array</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionparse_ini_array">parse_ini_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a table written in a special syntax which is user-friendly and can be inserted in a ini file (PHP serialized arrays cannot be inserted because they contain the &quot; character). The syntax is very easy, it really looks like the PHP array declaration: key =&gt; value, key2 =&gt; value2 You can nest some elements: key =&gt; (key1 =&gt; value1, key2 =&gt; value2), key2 =&gt; value2</dd>
							<dt><strong>path_to_root</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodpath_to_root">Url::path_to_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Overrides the used PATH_TO_ROOT. if the argument is null, the value is only returned. Please note this is a PHP4 hack to allow a Class variable.</dd>
							<dt><strong>PHPBOOST_OFFICIAL_REPOSITORY</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#definePHPBOOST_OFFICIAL_REPOSITORY">PHPBOOST_OFFICIAL_REPOSITORY</a></dd>
							<dt><strong>phpboost_version</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionphpboost_version">phpboost_version()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the full phpboost version with its build number</dd>
							<dt><strong>PHP_MIN_VERSION_UPDATES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#definePHP_MIN_VERSION_UPDATES">PHP_MIN_VERSION_UPDATES</a></dd>
							<dt><strong>PHP_VERSION_CONFLICT</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#definePHP_VERSION_CONFLICT">PHP_VERSION_CONFLICT</a></dd>
							<dt><strong>PICK_UP</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#definePICK_UP">PICK_UP</a></dd>
							<dt><strong>POP_UP_WINDOW</strong></dt>
				<dd>in file comments.class.php, constant <a href="content/_content---comments.class.php.php#definePOP_UP_WINDOW">POP_UP_WINDOW</a></dd>
							<dt><strong>pparse</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodpparse">Template::pparse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the file whose name is $parse_name and which has been declared with the set_filenames_method. It uses the variables you assigned (when you assign a variable it will be usable in every file handled by this object).</dd>
							<dt><strong>PrivateMsg</strong></dt>
				<dd>in file pm.class.php, class <a href="members/PrivateMsg.php">PrivateMsg</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides methods to manage private message.</dd>
							<dt><strong>PRODUCTION_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#definePRODUCTION_MODE">PRODUCTION_MODE</a></dd>
							<dt><strong>pagination.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---pagination.class.php.php">pagination.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="q"></a>
	<div>
		<h2>q</h2>
		<dl>
							<dt><strong>query</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery">Sql::query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sends a simple selection query to the DBMS and retrieves the result. A simple query selects only one field in one row.</dd>
							<dt><strong>query_array</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_array">Sql::query_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method makes automatically a query on several fields of a row. You tell it in which table you want to select, which row you want to use, and it will return you the values. It takes a variable number of parameters.</dd>
							<dt><strong>query_close</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_close">Sql::query_close()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Frees the memory allocated for a resource.</dd>
							<dt><strong>query_inject</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_inject">Sql::query_inject()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method enables you to execute CUD (Create Update Delete) queries in the database, and more generally, any query which has not any return value.</dd>
							<dt><strong>query_while</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_while">Sql::query_while()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method enables you to execute a Retrieve query on several rows in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>$recipients</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$recipients">Mail::$recipients</a></dd>
							<dt><strong>$redirect</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$redirect">Errors::$redirect</a></dd>
							<dt><strong>$repositories</strong></dt>
				<dd>in file updates.class.php, variable <a href="core/Updates.php#var$repositories">Updates::$repositories</a></dd>
							<dt><strong>$repository</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$repository">Application::$repository</a></dd>
							<dt><strong>$req</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$req">Sql::$req</a></dd>
							<dt><strong>$return_mode</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$return_mode">Template::$return_mode</a></dd>
							<dt><strong>rss.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---rss.class.php.php">rss.class.php</a></dd>
							<dt><strong>repository.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---repository.class.php.php">repository.class.php</a></dd>
							<dt><strong>RANK_TYPE</strong></dt>
				<dd>in file user.class.php, constant <a href="members/_members---user.class.php.php#defineRANK_TYPE">RANK_TYPE</a></dd>
							<dt><strong>read</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodread">Feed::read()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads the feed data in cache and export it</dd>
							<dt><strong>READ</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineREAD">READ</a></dd>
							<dt><strong>READ_WRITE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineREAD_WRITE">READ_WRITE</a></dd>
							<dt><strong>RECURSIVE_EXPLORATION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineRECURSIVE_EXPLORATION">RECURSIVE_EXPLORATION</a></dd>
							<dt><strong>redirect</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionredirect">redirect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Redirects the user to the URL and stops purely the script execution (database deconnexion...).</dd>
							<dt><strong>redirect_confirm</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionredirect_confirm">redirect_confirm()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays a confirmation message during a defined delay and then redirects the user.</dd>
							<dt><strong>REIMPLANT</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#defineREIMPLANT">REIMPLANT</a></dd>
							<dt><strong>relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodrelative">Url::relative()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the relative url if defined, else the absolute one</dd>
							<dt><strong>RELOAD_CACHE</strong></dt>
				<dd>in file cache.class.php, constant <a href="core/_core---cache.class.php.php#defineRELOAD_CACHE">RELOAD_CACHE</a></dd>
							<dt><strong>remove_last</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodremove_last">BreadCrumb::remove_last()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Removes the last link of the list</dd>
							<dt><strong>remove_member</strong></dt>
				<dd>in file groups.class.php, method <a href="members/Group.php#methodremove_member">Group::remove_member()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Removes a member in a group.</dd>
							<dt><strong>Rename_file</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodRename_file">Uploads::Rename_file()</a></dd>
							<dt><strong>Rename_folder</strong></dt>
				<dd>in file uploads.class.php, method <a href="members/Uploads.php#methodRename_folder">Uploads::Rename_folder()</a></dd>
							<dt><strong>repair_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodrepair_tables">Sql::repair_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Repairs some tables in the data base.</dd>
							<dt><strong>Repository</strong></dt>
				<dd>in file repository.class.php, class <a href="core/Repository.php">Repository</a></dd>
							<dt><strong>Repository</strong></dt>
				<dd>in file repository.class.php, method <a href="core/Repository.php#methodRepository">Repository::Repository()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor of the class</dd>
							<dt><strong>req</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionreq">req()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Requires a file</dd>
							<dt><strong>retrieve</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionretrieve">retrieve()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves an input variable. You can retrieve any parameter of the HTTP request which launched the execution of this page.</dd>
							<dt><strong>retrieve_date</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodretrieve_date">MiniCalendar::retrieve_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves a date entered in a mini calendar.</dd>
							<dt><strong>reverse</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodreverse">BreadCrumb::reverse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Reverses the whole list of the links. It's very useful when it's easier for you to make the list in the reverse way, at the end, you only need to reverse the list and it will be ok.</dd>
							<dt><strong>root_to_local</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodroot_to_local">Url::root_to_local()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the relative path from the website root to the current path if working on a relative url</dd>
							<dt><strong>RSS</strong></dt>
				<dd>in file rss.class.php, class <a href="content/syndication/RSS.php">RSS</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class could load a feed by its url or by a FeedData element and export it to the RSS format</dd>
							<dt><strong>RSS</strong></dt>
				<dd>in file rss.class.php, method <a href="content/syndication/RSS.php#methodRSS">RSS::RSS()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new RSS object</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>$script</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$script">Note::$script</a></dd>
							<dt><strong>$script</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$script">Comments::$script</a></dd>
							<dt><strong>$script_path</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$script_path">Note::$script_path</a></dd>
							<dt><strong>$search</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$search">Search::$search</a></dd>
							<dt><strong>$section_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$section_file">SitemapExportConfig::$section_file</a></dd>
							<dt><strong>$security_improvments</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$security_improvments">Application::$security_improvments</a></dd>
							<dt><strong>$security_update</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$security_update">Application::$security_update</a></dd>
							<dt><strong>$sender_mail</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$sender_mail">Mail::$sender_mail</a></dd>
							<dt><strong>$sender_name</strong></dt>
				<dd>in file mail.class.php, variable <a href="io/Mail.php#var$sender_name">Mail::$sender_name</a></dd>
							<dt><strong>$server_url</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$server_url">Url::$server_url</a></dd>
							<dt><strong>$session_mod</strong></dt>
				<dd>in file session.class.php, variable <a href="members/Session.php#var$session_mod">Session::$session_mod</a></dd>
							<dt><strong>$site_map_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$site_map_file">SitemapExportConfig::$site_map_file</a></dd>
							<dt><strong>$site_name</strong></dt>
				<dd>in file site_map.class.php, variable <a href="content/sitemap/SiteMap.php#var$site_name">SiteMap::$site_name</a></dd>
							<dt><strong>$sql_table</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$sql_table">Note::$sql_table</a></dd>
							<dt><strong>$sql_table</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$sql_table">Comments::$sql_table</a></dd>
							<dt><strong>$start</strong></dt>
				<dd>in file bench.class.php, variable <a href="util/Bench.php#var$start">Bench::$start</a></dd>
							<dt><strong>$str</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$str">Feed::$str</a></dd>
							<dt><strong>$style</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$style">MiniCalendar::$style</a></dd>
							<dt><strong>search.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---search.class.php.php">search.class.php</a></dd>
							<dt><strong>site_map.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map.class.php.php">site_map.class.php</a></dd>
							<dt><strong>site_map_element.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_element.class.php.php">site_map_element.class.php</a></dd>
							<dt><strong>site_map_export_config.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_export_config.class.php.php">site_map_export_config.class.php</a></dd>
							<dt><strong>site_map_link.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_link.class.php.php">site_map_link.class.php</a></dd>
							<dt><strong>site_map_section.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_section.class.php.php">site_map_section.class.php</a></dd>
							<dt><strong>stats_saver.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---stats_saver.class.php.php">stats_saver.class.php</a></dd>
							<dt><strong>session.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---session.class.php.php">session.class.php</a></dd>
							<dt><strong>save</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodsave">MenuService::save()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;save a Menu in the database</dd>
							<dt><strong>save_alert</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodsave_alert">AdministratorAlertService::save_alert()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create or updates an alert in the database. It creates it whether it doesn't exist or updates it if it already exists.</dd>
							<dt><strong>save_contribution</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodsave_contribution">ContributionService::save_contribution()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create or update a contribution in the database.</dd>
							<dt><strong>Search</strong></dt>
				<dd>in file search.class.php, class <a href="content/Search.php">Search</a></dd>
							<dt><strong>Search</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodSearch">Search::Search()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a search object. Query Complexity: 6 + k / 10 database queries. (k represent the number of module without search cache)</dd>
							<dt><strong>SEASURF_ATTACK_ERROR_PAGE</strong></dt>
				<dd>in file session.class.php, constant <a href="members/_members---session.class.php.php#defineSEASURF_ATTACK_ERROR_PAGE">SEASURF_ATTACK_ERROR_PAGE</a></dd>
							<dt><strong>second_parse</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionsecond_parse">second_parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Second parses a string with several default parameters. This methods exists to lighten the number of lines written.</dd>
							<dt><strong>second_parse_url</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionsecond_parse_url">second_parse_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Second parses relative urls to absolute urls.</dd>
							<dt><strong>securit_register_globals</strong></dt>
				<dd>in file unusual_functions.inc.php, function <a href="util/_util---unusual_functions.inc.php.php#functionsecurit_register_globals">securit_register_globals()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unsets all the variables automatically set by the register_globals option. This function must be called only if the register_globals option is enable, otherwise it is useless.</dd>
							<dt><strong>send</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodsend">Mail::send()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sends the mail.</dd>
							<dt><strong>send</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methodsend">PrivateMsg::send()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Answers to a conversation</dd>
							<dt><strong>send_from_properties</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodsend_from_properties">Mail::send_from_properties()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sends the mail.</dd>
							<dt><strong>serialize</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodserialize">FeedData::serialize()</a></dd>
							<dt><strong>SERVER_URL</strong></dt>
				<dd>in file url.class.php, constant <a href="util/_util---url.class.php.php#defineSERVER_URL">SERVER_URL</a></dd>
							<dt><strong>server_url</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodserver_url">Url::server_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Overrides the used SERVER URL. if the argument is null, the value is only returned. Please note this is a PHP4 hack to allow a Class variable.</dd>
							<dt><strong>Session</strong></dt>
				<dd>in file session.class.php, class <a href="members/Session.php">Session</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages all sessions for the users.</dd>
							<dt><strong>set_arg</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodset_arg">Comments::set_arg()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set argument for the comments system.</dd>
							<dt><strong>set_attribute</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodset_attribute">ModuleInterface::set_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the $value of the attribute identified by the string $attribute.</dd>
							<dt><strong>set_auth</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_auth">FeedItem::set_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item auth, useful to check authorizations</dd>
							<dt><strong>set_auth</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_auth">Menu::set_auth()</a></dd>
							<dt><strong>set_auth</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_auth">Contribution::set_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the authorization of the contribution. It will determine who will be able to treat the contribution.</dd>
							<dt><strong>set_auth_bit</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_auth_bit">FeedData::set_auth_bit()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed auth bit, useful to check authorizations</dd>
							<dt><strong>set_block</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_block">Menu::set_block()</a></dd>
							<dt><strong>set_block_position</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_block_position">Menu::set_block_position()</a></dd>
							<dt><strong>set_cat</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodset_cat">FeedMenu::set_cat()</a></dd>
							<dt><strong>set_change_freq</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_change_freq">SiteMapLink::set_change_freq()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the change frequency</dd>
							<dt><strong>set_content</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodset_content">Parser::set_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the content of the parser. When you will call a parse method, it will deal with this content.</dd>
							<dt><strong>set_content</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodset_content">ContentMenu::set_content()</a></dd>
							<dt><strong>set_content</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_content">Mail::set_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The mail content.</dd>
							<dt><strong>set_creation_date</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_creation_date">Event::set_creation_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the creation date of the event.</dd>
							<dt><strong>set_date</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodset_date">MiniCalendar::set_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the date at which will be initialized the calendar.</dd>
							<dt><strong>set_date</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_date">FeedItem::set_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item date</dd>
							<dt><strong>set_date</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_date">FeedData::set_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed data date</dd>
							<dt><strong>set_default_template</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodset_default_template">Errors::set_default_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set default template for the handler methods.</dd>
							<dt><strong>set_depth</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodset_depth">SiteMapElement::set_depth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the depth of the element</dd>
							<dt><strong>set_depth</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodset_depth">SiteMapSection::set_depth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the depth of the element</dd>
							<dt><strong>set_desc</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_desc">FeedData::set_desc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed description</dd>
							<dt><strong>set_desc</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_desc">FeedItem::set_desc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item description</dd>
							<dt><strong>set_description</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodset_description">ModuleMap::set_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the description of the module</dd>
							<dt><strong>set_description</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_description">Contribution::set_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the description of the contribution.</dd>
							<dt><strong>set_difficulty</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_difficulty">Captcha::set_difficulty()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modifies the level of difficulty to decrypt the code on the captcha image.</dd>
							<dt><strong>set_display_config</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodset_display_config">CategoriesManager::set_display_config()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Method which sets the displaying configuration Config example $config = array(         'xmlhttprequest_file' =&gt; 'xmlhttprequest.php',         'administration_file_name' =&gt; 'admin_news_cats.php',         'url' =&gt; array(             'unrewrited' =&gt; PATH_TO_ROOT . '/news/news.php?id=%d',             'rewrited' =&gt; PATH_TO_ROOT . '/news-%d+%s.php'         ), );</dd>
							<dt><strong>set_display_required</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodset_display_required">FormFieldset::set_display_required()</a></dd>
							<dt><strong>set_display_title</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodset_display_title">ContentMenu::set_display_title()</a></dd>
							<dt><strong>set_entitled</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_entitled">Event::set_entitled()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the entitled of the event. The entitled can be considered as the name, it must be explicit.</dd>
							<dt><strong>set_error</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodset_error">ModuleInterface::set_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the flag error.</dd>
							<dt><strong>set_filenames</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodset_filenames">Template::set_filenames()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads several files in the same Template instance.</dd>
							<dt><strong>set_fixer_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_fixer_id">Contribution::set_fixer_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id of the fixer.</dd>
							<dt><strong>set_fixing_date</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_fixing_date">Contribution::set_fixing_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the fixing date.</dd>
							<dt><strong>set_fixing_url</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_fixing_url">Event::set_fixing_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the URL corresponding to the event. For the contributions and the administrator alerts it's the number URL at which the problem can be solved.</dd>
							<dt><strong>set_font</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_font">Captcha::set_font()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify font used for the text on the image.</dd>
							<dt><strong>set_forbidden_tags</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodset_forbidden_tags">ContentEditor::set_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the forbidden tags</dd>
							<dt><strong>set_forbidden_tags</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodset_forbidden_tags">ContentParser::set_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the tags which mustn't be parsed.</dd>
							<dt><strong>set_form_action</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_action">FormBuilder::set_form_action()</a></dd>
							<dt><strong>set_form_class</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_class">FormBuilder::set_form_class()</a></dd>
							<dt><strong>set_form_name</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_name">FormBuilder::set_form_name()</a></dd>
							<dt><strong>set_form_submit</strong></dt>
				<dd>in file form_builder.class.php, method <a href="builder/form/FormBuilder.php#methodset_form_submit">FormBuilder::set_form_submit()</a></dd>
							<dt><strong>set_guid</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_guid">FeedItem::set_guid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item guid</dd>
							<dt><strong>set_headers</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_headers">Mail::set_headers()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the headers. Forces them, they won't be generated automatically.</dd>
							<dt><strong>set_height</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_height">Captcha::set_height()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify height of the image.</dd>
							<dt><strong>set_host</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_host">FeedData::set_host()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed host</dd>
							<dt><strong>set_html_auth</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodset_html_auth">ContentParser::set_html_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the required authorizations that are necessary to post some HTML code which will be displayed by the web browser.</dd>
							<dt><strong>set_id</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_id">Event::set_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id of the event. The id is the corresponding data base entry one.</dd>
							<dt><strong>set_identifier</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodset_identifier">ContentEditor::set_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the html identifier of the textarea field which contain the content to edit.</dd>
							<dt><strong>set_identifier</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_identifier">Event::set_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the event identifier. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events. You don't have to use it, you can let it blank.</dd>
							<dt><strong>set_id_in_module</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_id_in_module">Event::set_id_in_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id in module parameter. It corresponds to the id of the element corresponding to the event in your data base tables. For example, il you use the events to allow user to purpose some news in your web site, it will be the id of the news added.</dd>
							<dt><strong>set_image</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodset_image">LinksMenuElement::set_image()</a></dd>
							<dt><strong>set_image_url</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_image_url">FeedItem::set_image_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item picture</dd>
							<dt><strong>set_instance</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_instance">Captcha::set_instance()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify instance number.</dd>
							<dt><strong>set_lang</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_lang">FeedData::set_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed language</dd>
							<dt><strong>set_language</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodset_language">ContentFormattingFactory::set_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Changes the language of the factory</dd>
							<dt><strong>set_last_modification_date</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_last_modification_date">SiteMapLink::set_last_modification_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the last modification date of the target page</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_link">FeedData::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item link</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodset_link">SiteMapSection::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the link associated to the section</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_link">SiteMapLink::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the URL of the link</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_link">FeedItem::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item link</dd>
							<dt><strong>set_link_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_link_stream">SitemapExportConfig::set_link_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a SiteMapLink object.</dd>
							<dt><strong>set_mime</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_mime">Mail::set_mime()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the MIME type of the mail content</dd>
							<dt><strong>set_module</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_module">Contribution::set_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the module in which the contribution is used.</dd>
							<dt><strong>set_module_id</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodset_module_id">FeedMenu::set_module_id()</a></dd>
							<dt><strong>set_module_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_module_map_stream">SitemapExportConfig::set_module_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a ModuleMap object.</dd>
							<dt><strong>set_module_parameters</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodset_module_parameters">Session::set_module_parameters()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Save module's parameters into session</dd>
							<dt><strong>set_must_regenerate_cache</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_must_regenerate_cache">Event::set_must_regenerate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets a private property indicating if the changes made on this event imply the regeneration of the events cache.</dd>
							<dt><strong>set_name</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_name">SiteMapLink::set_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the name of the element</dd>
							<dt><strong>set_name</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodset_name">FeedMenu::set_name()</a></dd>
							<dt><strong>set_object</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_object">Mail::set_object()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the mail object</dd>
							<dt><strong>set_page_path</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodset_page_path">Parser::set_page_path()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the page path</dd>
							<dt><strong>set_path_to_root</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodset_path_to_root">Parser::set_path_to_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the reference path for relative URL</dd>
							<dt><strong>set_poster_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_poster_id">Contribution::set_poster_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id of the poster.</dd>
							<dt><strong>set_priority</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodset_priority">AdministratorAlert::set_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the priority of the alert.</dd>
							<dt><strong>set_priority</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_priority">SiteMapLink::set_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the priority of the link</dd>
							<dt><strong>set_properties</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodset_properties">AdministratorAlert::set_properties()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the properties of the alert.</dd>
							<dt><strong>set_recipients</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_recipients">Mail::set_recipients()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the recipient(s) of the mail.</dd>
							<dt><strong>set_section_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_section_stream">SitemapExportConfig::set_section_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a SiteMapSection object.</dd>
							<dt><strong>set_sender</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#methodset_sender">Mail::set_sender()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the mail sender.</dd>
							<dt><strong>set_site_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_site_map_stream">SitemapExportConfig::set_site_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a Site object.</dd>
							<dt><strong>set_site_name</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodset_site_name">SiteMap::set_site_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the name of the site. The default value is the name of the site taken from the site configuration.</dd>
							<dt><strong>set_status</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_status">Event::set_status()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the status of the event.</dd>
							<dt><strong>set_status</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_status">Contribution::set_status()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the status of the contribution.</dd>
							<dt><strong>set_style</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodset_style">MiniCalendar::set_style()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the CSS properties of the element. You can use it if you want to customize the mini calendar, but the best solution is to redefine the template in your module. The template used is framework/mini_calendar.tpl.</dd>
							<dt><strong>set_subregex_multiplicity</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionset_subregex_multiplicity">set_subregex_multiplicity()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the sub-regex with its multiplicity option</dd>
							<dt><strong>set_template</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodset_template">Errors::set_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set a personnal template for the handler methods.</dd>
							<dt><strong>set_template</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodset_template">ContentEditor::set_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set an alternative template for the editor.</dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_title">FeedData::set_title()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed title</dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodset_title">FormFieldset::set_title()</a></dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_title">Menu::set_title()</a></dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_title">FeedItem::set_title()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item title</dd>
							<dt><strong>set_type</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodset_type">LinksMenu::set_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the type of the menu</dd>
							<dt><strong>set_type</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_type">Event::set_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
							<dt><strong>set_url</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodset_url">LinksMenuElement::set_url()</a></dd>
							<dt><strong>set_user_lang</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodset_user_lang">User::set_user_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the user lang.</dd>
							<dt><strong>set_user_theme</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodset_user_theme">User::set_user_theme()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the user theme.</dd>
							<dt><strong>set_width</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_width">Captcha::set_width()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify width of the image.</dd>
							<dt><strong>SiteMap</strong></dt>
				<dd>in file site_map.class.php, class <a href="content/sitemap/SiteMap.php">SiteMap</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Describes the map of the site. Can be exported according to any text form by using a template configuration. A site map contains some links, some link sections and some module maps (which also contain links and sections).</dd>
							<dt><strong>SiteMap</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodSiteMap">SiteMap::SiteMap()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMap object with its elements</dd>
							<dt><strong>SiteMapElement</strong></dt>
				<dd>in file site_map_element.class.php, class <a href="content/sitemap/SiteMapElement.php">SiteMapElement</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This abstract is the root of every object which can be contained by a SiteMap object. Some SiteMapElements objects can contain one or many SiteMapElement objects therefore the elements can be represented by a tree an each element has a depth in the tree.</dd>
							<dt><strong>SiteMapElement</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodSiteMapElement">SiteMapElement::SiteMapElement()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapElement object</dd>
							<dt><strong>SitemapExportConfig</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodSitemapExportConfig">SitemapExportConfig::SitemapExportConfig()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapExportConfig object</dd>
							<dt><strong>SitemapExportConfig</strong></dt>
				<dd>in file site_map_export_config.class.php, class <a href="content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Configuration used to export a SiteMap. It contains some Template objects which are used to export each kind of elements of a sitemap. Using different configurations will enable you for example to export in HTML code to be displayed in a page of the web site (the site map) or to be written in the sitemap.xml file at the root of your site, this file will be read by the search engines to optimize the research of your site.</dd>
							<dt><strong>SiteMapLink</strong></dt>
				<dd>in file site_map_link.class.php, class <a href="content/sitemap/SiteMapLink.php">SiteMapLink</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a link of a site map.</dd>
							<dt><strong>SitemapLink</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodSitemapLink">SiteMapLink::SitemapLink()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapLink object</dd>
							<dt><strong>SiteMapSection</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodSiteMapSection">SiteMapSection::SiteMapSection()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapSection object</dd>
							<dt><strong>SiteMapSection</strong></dt>
				<dd>in file site_map_section.class.php, class <a href="content/sitemap/SiteMapSection.php">SiteMapSection</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a section of a site map.</dd>
							<dt><strong>SITE_MAP_AUTH_GUEST</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_AUTH_GUEST">SITE_MAP_AUTH_GUEST</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The site map will be seen by every body, only the public elements must appear</dd>
							<dt><strong>SITE_MAP_AUTH_USER</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_AUTH_USER">SITE_MAP_AUTH_USER</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The site map is for the current user.</dd>
							<dt><strong>SITE_MAP_FREQ_ALWAYS</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_ALWAYS">SITE_MAP_FREQ_ALWAYS</a></dd>
							<dt><strong>SITE_MAP_FREQ_DAILY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_DAILY">SITE_MAP_FREQ_DAILY</a></dd>
							<dt><strong>SITE_MAP_FREQ_DEFAULT</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_DEFAULT">SITE_MAP_FREQ_DEFAULT</a></dd>
							<dt><strong>SITE_MAP_FREQ_HOURLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_HOURLY">SITE_MAP_FREQ_HOURLY</a></dd>
							<dt><strong>SITE_MAP_FREQ_MONTHLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_MONTHLY">SITE_MAP_FREQ_MONTHLY</a></dd>
							<dt><strong>SITE_MAP_FREQ_NEVER</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_NEVER">SITE_MAP_FREQ_NEVER</a></dd>
							<dt><strong>SITE_MAP_FREQ_WEEKLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_WEEKLY">SITE_MAP_FREQ_WEEKLY</a></dd>
							<dt><strong>SITE_MAP_FREQ_YEARLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_YEARLY">SITE_MAP_FREQ_YEARLY</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_AVERAGE</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_AVERAGE">SITE_MAP_PRIORITY_AVERAGE</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_HIGH</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_HIGH">SITE_MAP_PRIORITY_HIGH</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_LOW</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_LOW">SITE_MAP_PRIORITY_LOW</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_MAX</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_MAX">SITE_MAP_PRIORITY_MAX</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_MIN</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_MIN">SITE_MAP_PRIORITY_MIN</a></dd>
							<dt><strong>SITE_MAP_SEARCH_ENGINE_MODE</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_SEARCH_ENGINE_MODE">SITE_MAP_SEARCH_ENGINE_MODE</a><br>&nbsp;&nbsp;&nbsp;&nbsp;It will be for the search engines (sitemap. can be forgotten in that case.</dd>
							<dt><strong>SITE_MAP_USER_MODE</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_USER_MODE">SITE_MAP_USER_MODE</a><br>&nbsp;&nbsp;&nbsp;&nbsp;It will be a page of the site containing the site map</dd>
							<dt><strong>Sql</strong></dt>
				<dd>in file mysql.class.php, class <a href="db/Sql.php">Sql</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages all the database access done by PHPBoost. It currently manages only one DBMS, MySQL, but we made it as generic as we could. It doesn't support ORM (Object Relationnal Mapping). On PHPBoost, all the table which are used contain a prefix which enables for example to install several instances of the software on the same data base. When you execute a query in a table, concatenate the PREFIX constant before the name of your table. Notice also that the kernel tables can have their name changed. You must not use their name directly but the constants which are defined in the file /kernel/db/tables.php.
 If you encounter any problem when writing queries, you should search what you need in the MySQL documentation, which is very well done: http://dev.mysql.com/doc/</dd>
							<dt><strong>Sql</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodSql">Sql::Sql()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a MySQL connection.</dd>
							<dt><strong>start</strong></dt>
				<dd>in file session.class.php, method <a href="members/Session.php#methodstart">Session::start()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Start the session</dd>
							<dt><strong>start_conversation</strong></dt>
				<dd>in file pm.class.php, method <a href="members/PrivateMsg.php#methodstart_conversation">PrivateMsg::start_conversation()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Starts a conversation with another member.</dd>
							<dt><strong>Stats</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methodStats">Stats::Stats()</a></dd>
							<dt><strong>Stats</strong></dt>
				<dd>in file images_stats.class.php, class <a href="util/Stats.php">Stats</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides easy ways to create several type of charts.</dd>
							<dt><strong>StatsSaver</strong></dt>
				<dd>in file stats_saver.class.php, class <a href="core/StatsSaver.php">StatsSaver</a></dd>
							<dt><strong>stop</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodstop">Bench::stop()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;stops the bench now</dd>
							<dt><strong>STOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineSTOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH">STOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</a></dd>
							<dt><strong>strhash</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrhash">strhash()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return a SHA256 hash of the $str string [with a salt]</dd>
							<dt><strong>strparse</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrparse">strparse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a string with several default parameters. This methods exists to lighten the number of lines written.</dd>
							<dt><strong>strprotect</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrprotect">strprotect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Protects an input variable. Never trust user input!</dd>
							<dt><strong>strtodate</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrtodate">strtodate()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Converts a formatted date to the SQL date format.</dd>
							<dt><strong>strtotimestamp</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrtotimestamp">strtotimestamp()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a formatted date</dd>
							<dt><strong>str_to_location</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodstr_to_location">MenuService::str_to_location()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Convert the string location the int location</dd>
							<dt><strong>subitems</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodsubitems">FeedData::subitems()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a items list containing $number items starting from the $begin_at one</dd>
							<dt><strong>substr_html</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionsubstr_html">substr_html()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Cuts a string containing some HTML code which contains some HTML entities. The substr PHP function considers a HTML entity as several characters. This function allows you to consider them as only one character.</dd>
							<dt><strong>SYSTEM_PM</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineSYSTEM_PM">SYSTEM_PM</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$table</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$table">CategoriesManager::$table</a></dd>
							<dt><strong>$tables</strong></dt>
				<dd>in file backup.class.php, variable <a href="db/Backup.php#var$tables">Backup::$tables</a></dd>
							<dt><strong>$tag</strong></dt>
				<dd>in file content_parser.class.php, variable <a href="content/parser/ContentParser.php#var$tag">ContentParser::$tag</a></dd>
							<dt><strong>$template</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$template">ContentEditor::$template</a></dd>
							<dt><strong>$template</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$template">Errors::$template</a></dd>
							<dt><strong>$template</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$template">Template::$template</a></dd>
							<dt><strong>$timestamp</strong></dt>
				<dd>in file date.class.php, variable <a href="util/Date.php#var$timestamp">Date::$timestamp</a></dd>
							<dt><strong>$title</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$title">FeedItem::$title</a></dd>
							<dt><strong>$title</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$title">FeedData::$title</a></dd>
							<dt><strong>$title</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$title">Menu::$title</a></dd>
							<dt><strong>$tpl</strong></dt>
				<dd>in file template.class.php, variable <a href="io/Template.php#var$tpl">Template::$tpl</a></dd>
							<dt><strong>$tpl</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$tpl">Feed::$tpl</a></dd>
							<dt><strong>$type</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$type">Event::$type</a></dd>
							<dt><strong>$type</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$type">Application::$type</a></dd>
							<dt><strong>$type</strong></dt>
				<dd>in file links_menu.class.php, variable <a href="menu/linksmenu/LinksMenu.php#var$type">LinksMenu::$type</a></dd>
							<dt><strong>tinymce_editor.class.php</strong></dt>
				<dd>procedural page <a href="content/editor/_content---editor---tinymce_editor.class.php.php">tinymce_editor.class.php</a></dd>
							<dt><strong>template_highlighter.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---template_highlighter.class.php.php">template_highlighter.class.php</a></dd>
							<dt><strong>tinymce_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---tinymce_parser.class.php.php">tinymce_parser.class.php</a></dd>
							<dt><strong>tinymce_unparser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---tinymce_unparser.class.php.php">tinymce_unparser.class.php</a></dd>
							<dt><strong>template.class.php</strong></dt>
				<dd>procedural page <a href="io/_io---template.class.php.php">template.class.php</a></dd>
							<dt><strong>Template</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodTemplate">Template::Template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Template object.</dd>
							<dt><strong>Template</strong></dt>
				<dd>in file template.class.php, class <a href="io/Template.php">Template</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to handle a template file. Your template files should have the .tpl extension. &lt;h1&gt;The PHPBoost template syntax&lt;/h1&gt; &lt;h2&gt;Simple variables&lt;/h2&gt; A simple variable is accessible with the {NAME} syntax where NAME is its template name. If the variable is not assigned, nothing will be displayed (no error message). Simple variables are assigned by the assign_vars() method. &lt;h2&gt;Loops&lt;/h2&gt; You can make some loops to repeat a pattern, those loops can be nested. A loop has a name (name) and each iteration contains some variables, for example, the variable VAR.<ul><li>START name #</li></ul> My variable is {name.VAR}<ul><li>END name #</li></ul> To nest loops, here is an example:<ul><li>START loop1 #</li></ul> I write my loop1 var here: {loop1.VAR}.<ul><li>START loop1.loop2 #</li></ul> I can write my loop2 var here: {loop1.loop2.VAR} but also my loop1 var of the parent loop: {loop1.VAR}.<ul></ul><ul><li>END loop1 #</li></ul> To assign the variable, see the assign_block_vars() method which creates one iteration. &lt;h2&gt;Conditions&lt;/h2&gt; When you want to display something only in particular case, you can use some condition tests.<ul><li>IF C_MY_TEST #</li></ul> This text will be displayed only if the C_MY_TEST variable is true<ul><li>ENDIF #</li></ul> You can nest some conditions.&lt;/li&gt; &lt;/ul&gt; To be more efficient, this class uses a cache and parses each file only once. &lt;h1&gt;File paths&lt;/h1&gt; The web site can have several themes whose files aren't in the same folders. When you load a file, you just have to load the generic file and the good template file will be loaded dinamically. &lt;h2&gt;Kernel template file&lt;/h2&gt; When you want to load a kernel template file, the path you must indicate is only the name of the file, for example header.tpl loads /template/your_theme/header.tpl and if it doesn't exist, it will load /template/default/header.tpl. &lt;h2&gt;Module template file&lt;/h2&gt; When you want to load a module template file, you must indicate the name of you module and then the name of the file like this: module/file.tpl which will load the /module/templates/file.tpl. If the user themes redefines the file.tpl file for the module module, the file templates/your_theme/modules/module/file.tpl will be loaded. &lt;h2&gt;Menu template file&lt;/h2&gt; To load a file of a menu, use this kind of path: menus/my_menu/file.tpl which will load the /menus/my_menu/templates/file.tpl file. &lt;h2&gt;Framework template file&lt;/h2&gt; To load a framework file, use a path like this: framework/package/file.tpl which will load /templates/your_theme/framework/package/file.tpl if the theme overrides it, otherwise /templates/default/framework/package/file.tpl will be used.</dd>
							<dt><strong>TemplateHighlighter</strong></dt>
				<dd>in file template_highlighter.class.php, class <a href="content/parser/TemplateHighlighter.php">TemplateHighlighter</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This is a syntax highlighter for the PHPBoost template syntax.</dd>
							<dt><strong>TemplateHighlighter</strong></dt>
				<dd>in file template_highlighter.class.php, method <a href="content/parser/TemplateHighlighter.php#methodTemplateHighlighter">TemplateHighlighter::TemplateHighlighter()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a TemplateHighlighter object.</dd>
							<dt><strong>TEMPLATE_STRING_MODE</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineTEMPLATE_STRING_MODE">TEMPLATE_STRING_MODE</a></dd>
							<dt><strong>TEMPLATE_WRITE_MODE</strong></dt>
				<dd>in file template.class.php, constant <a href="io/_io---template.class.php.php#defineTEMPLATE_WRITE_MODE">TEMPLATE_WRITE_MODE</a></dd>
							<dt><strong>throw_error</strong></dt>
				<dd>in file form_field.class.php, method <a href="builder/form/FormField.php#methodthrow_error">FormField::throw_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Store all erros in the field construct process.</dd>
							<dt><strong>throw_error</strong></dt>
				<dd>in file form_fieldset.class.php, method <a href="builder/form/FormFieldset.php#methodthrow_error">FormFieldset::throw_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Store all erros in the field construct process.</dd>
							<dt><strong>TIMEZONE_AUTO</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineTIMEZONE_AUTO">TIMEZONE_AUTO</a></dd>
							<dt><strong>TIMEZONE_SITE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineTIMEZONE_SITE">TIMEZONE_SITE</a></dd>
							<dt><strong>TIMEZONE_SYSTEM</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineTIMEZONE_SYSTEM">TIMEZONE_SYSTEM</a></dd>
							<dt><strong>TIMEZONE_USER</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineTIMEZONE_USER">TIMEZONE_USER</a></dd>
							<dt><strong>TinyMCEEditor</strong></dt>
				<dd>in file tinymce_editor.class.php, class <a href="content/editor/TinyMCEEditor.php">TinyMCEEditor</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides an interface editor for contents.</dd>
							<dt><strong>TinyMCEEditor</strong></dt>
				<dd>in file tinymce_editor.class.php, method <a href="content/editor/TinyMCEEditor.php#methodTinyMCEEditor">TinyMCEEditor::TinyMCEEditor()</a></dd>
							<dt><strong>TinyMCEParser</strong></dt>
				<dd>in file tinymce_parser.class.php, class <a href="content/parser/TinyMCEParser.php">TinyMCEParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables to use TinyMCE without breaking the compatibility with the BBCode formatting. PHPBoost has a reference syntax, it in HTML with specific CSS classes. The HTML code generated by TinyMCE must be modified to conform itself to this specific syntax. This class makes the translation from the TinyMCE HTML to the PHPBoost HTML.</dd>
							<dt><strong>TinyMCEParser</strong></dt>
				<dd>in file tinymce_parser.class.php, method <a href="content/parser/TinyMCEParser.php#methodTinyMCEParser">TinyMCEParser::TinyMCEParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds this kind of parser</dd>
							<dt><strong>TinyMCEUnparser</strong></dt>
				<dd>in file tinymce_unparser.class.php, class <a href="content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables to translate the content formatting from the PHPBoost standard one to the TinyMCE one. The PHPBoost one is historically the one corresponding to the BBCode translation in HTML and is now the reference. TinyMCE has a particular syntax and it must be respected if we want to make a formatting which can be edited after having beeing written, enough what using a WYSIWYG editor hasn't any advantage.</dd>
							<dt><strong>TinyMCEUnparser</strong></dt>
				<dd>in file tinymce_unparser.class.php, method <a href="content/parser/TinyMCEUnparser.php#methodTinyMCEUnparser">TinyMCEUnparser::TinyMCEUnparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a TinyMCEUnparser object</dd>
							<dt><strong>TINYMCE_LANGUAGE</strong></dt>
				<dd>in file content_formatting_factory.class.php, constant <a href="content/parser/_content---parser---content_formatting_factory.class.php.php#defineTINYMCE_LANGUAGE">TINYMCE_LANGUAGE</a></dd>
							<dt><strong>to_date</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodto_date">Date::to_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the date according to the format YYYY-mm-dd</dd>
							<dt><strong>to_js_string</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionto_js_string">to_js_string()</a></dd>
							<dt><strong>to_string</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodto_string">Bench::to_string()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the number formatted with $digits floating numbers</dd>
							<dt><strong>TPL_BRACES_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_BRACES_STYLE">TPL_BRACES_STYLE</a></dd>
							<dt><strong>TPL_KEYWORD_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_KEYWORD_STYLE">TPL_KEYWORD_STYLE</a></dd>
							<dt><strong>TPL_NESTED_VARIABLE_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_NESTED_VARIABLE_STYLE">TPL_NESTED_VARIABLE_STYLE</a></dd>
							<dt><strong>TPL_SHARP_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_SHARP_STYLE">TPL_SHARP_STYLE</a></dd>
							<dt><strong>TPL_VARIABLE_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_VARIABLE_STYLE">TPL_VARIABLE_STYLE</a></dd>
							<dt><strong>TREE_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineTREE_MENU">TREE_MENU</a></dd>
							<dt><strong>truncate_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodtruncate_tables">Sql::truncate_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Trucates some tables in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>$uid</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$uid">LinksMenuElement::$uid</a></dd>
							<dt><strong>$update_url</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$update_url">Application::$update_url</a></dd>
							<dt><strong>$url</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$url">LinksMenuElement::$url</a></dd>
							<dt><strong>$url</strong></dt>
				<dd>in file repository.class.php, variable <a href="core/Repository.php#var$url">Repository::$url</a></dd>
							<dt><strong>$url</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$url">Url::$url</a></dd>
							<dt><strong>$url</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$url">FeedMenu::$url</a></dd>
							<dt><strong>$user_data</strong></dt>
				<dd>in file user.class.php, variable <a href="members/User.php#var$user_data">User::$user_data</a></dd>
							<dt><strong>$user_groups</strong></dt>
				<dd>in file user.class.php, variable <a href="members/User.php#var$user_groups">User::$user_groups</a></dd>
							<dt><strong>updates.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---updates.class.php.php">updates.class.php</a></dd>
							<dt><strong>upload.class.php</strong></dt>
				<dd>procedural page <a href="io/_io---upload.class.php.php">upload.class.php</a></dd>
							<dt><strong>uploads.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---uploads.class.php.php">uploads.class.php</a></dd>
							<dt><strong>user.class.php</strong></dt>
				<dd>procedural page <a href="members/_members---user.class.php.php">user.class.php</a></dd>
							<dt><strong>unassign_block_vars</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#methodunassign_block_vars">Template::unassign_block_vars()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a block. It won't be browsable any more in your template.</dd>
							<dt><strong>UNEXISTING_DATABASE</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineUNEXISTING_DATABASE">UNEXISTING_DATABASE</a></dd>
							<dt><strong>UNEXISTING_MODULE</strong></dt>
				<dd>in file packages_manager.class.php, constant <a href="modules/_modules---packages_manager.class.php.php#defineUNEXISTING_MODULE">UNEXISTING_MODULE</a></dd>
							<dt><strong>uninstall_module</strong></dt>
				<dd>in file packages_manager.class.php, method <a href="modules/PackagesManager.php#methoduninstall_module">PackagesManager::uninstall_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Uninstalls a module.</dd>
							<dt><strong>UNIQ_NAME</strong></dt>
				<dd>in file upload.class.php, constant <a href="io/_io---upload.class.php.php#defineUNIQ_NAME">UNIQ_NAME</a></dd>
							<dt><strong>unlock</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodunlock">File::unlock()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unlocks a file. The file must have been locked before you call this method.</dd>
							<dt><strong>unparse</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionunparse">unparse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unparses a string with several default parameters. This methods exists to lighten the number of lines written.</dd>
							<dt><strong>unset_attribute</strong></dt>
				<dd>in file module_interface.class.php, method <a href="modules/ModuleInterface.php#methodunset_attribute">ModuleInterface::unset_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete the attribute and free its memory.</dd>
							<dt><strong>update</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodupdate">Comments::update()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Edit a comment</dd>
							<dt><strong>Updates</strong></dt>
				<dd>in file updates.class.php, method <a href="core/Updates.php#methodUpdates">Updates::Updates()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor of the class</dd>
							<dt><strong>Updates</strong></dt>
				<dd>in file updates.class.php, class <a href="core/Updates.php">Updates</a></dd>
							<dt><strong>update_cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodupdate_cache">Feed::update_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the cache of the $module_id, $name, $idcat feed with $data</dd>
							<dt><strong>update_instance</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodupdate_instance">Captcha::update_instance()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Updates the object instance.</dd>
							<dt><strong>UPDATE_MBR_PM</strong></dt>
				<dd>in file pm.class.php, constant <a href="members/_members---pm.class.php.php#defineUPDATE_MBR_PM">UPDATE_MBR_PM</a></dd>
							<dt><strong>update_mini_menus_list</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodupdate_mini_menus_list">MenuService::update_mini_menus_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the mini menus list by adding new ones and delete old ones</dd>
							<dt><strong>update_mini_modules_list</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodupdate_mini_modules_list">MenuService::update_mini_modules_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the mini modules list by adding new ones and delete old ones</dd>
							<dt><strong>update_uid</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodupdate_uid">LinksMenuElement::update_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the menu uid</dd>
							<dt><strong>update_uid</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodupdate_uid">LinksMenu::update_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the menu uid</dd>
							<dt><strong>update_user_lang</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodupdate_user_lang">User::update_user_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the lang for guest in the database (sessions table).</dd>
							<dt><strong>update_user_theme</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodupdate_user_theme">User::update_user_theme()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify the theme for guest in the database (sessions table).</dd>
							<dt><strong>Upload</strong></dt>
				<dd>in file upload.class.php, method <a href="io/Upload.php#methodUpload">Upload::Upload()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>Upload</strong></dt>
				<dd>in file upload.class.php, class <a href="io/Upload.php">Upload</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides you methods to upload easily files to the ftp.</dd>
							<dt><strong>Uploads</strong></dt>
				<dd>in file uploads.class.php, class <a href="members/Uploads.php">Uploads</a></dd>
							<dt><strong>Url</strong></dt>
				<dd>in file url.class.php, class <a href="util/Url.php">Url</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class offers a simple way to transform an absolute or relative link to a relative one to the website root. It can also deals with absolute url and will convert only those from this site into relatives ones. Usage : <ul><li>In content, get the url with the absolute() method. It will allow content include at multiple level</li><li>In forms, get the url with the relative() method. It's a faster way to display url</li></ul></dd>
							<dt><strong>Url</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodUrl">Url::Url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a Url object. By default, builds an Url object representing the current path. If the url is empty, no computation is done and an empty string will be returned when asking for both relative and absolute form of the url.</dd>
							<dt><strong>url</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionurl">url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds the session ID to an URL if the user doesn't accepts cookies. This functions allows you to generate an URL according to the site configuration concerning the URL rewriting.</dd>
							<dt><strong>url_encode_rewrite</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionurl_encode_rewrite">url_encode_rewrite()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Prepares a string for it to be used in an URL (with only a-z, 0-9 and - characters).</dd>
							<dt><strong>URL__CLASS</strong></dt>
				<dd>in file url.class.php, constant <a href="util/_util---url.class.php.php#defineURL__CLASS">URL__CLASS</a></dd>
							<dt><strong>User</strong></dt>
				<dd>in file user.class.php, method <a href="members/User.php#methodUser">User::User()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets global authorizations which are given by all the user groups authorizations.</dd>
							<dt><strong>User</strong></dt>
				<dd>in file user.class.php, class <a href="members/User.php">User</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manage user, it provide you methods to get or modify user informations, moreover methods allow you to control user authorizations</dd>
							<dt><strong>USER_TYPE</strong></dt>
				<dd>in file user.class.php, constant <a href="members/_members---user.class.php.php#defineUSER_TYPE">USER_TYPE</a></dd>
							<dt><strong>unusual_functions.inc.php</strong></dt>
				<dd>procedural page <a href="util/_util---unusual_functions.inc.php.php">unusual_functions.inc.php</a></dd>
							<dt><strong>url.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---url.class.php.php">url.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="v"></a>
	<div>
		<h2>v</h2>
		<dl>
							<dt><strong>$vars</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$vars">Comments::$vars</a></dd>
							<dt><strong>$var_page</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$var_page">Pagination::$var_page</a></dd>
							<dt><strong>$version</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$version">Application::$version</a></dd>
							<dt><strong>validate_img</strong></dt>
				<dd>in file upload.class.php, method <a href="io/Upload.php#methodvalidate_img">Upload::validate_img()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks whether an image is compliant to an maximum width and height, otherwise is $delete value is true delete it.</dd>
							<dt><strong>VERTICAL_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineVERTICAL_MENU">VERTICAL_MENU</a></dd>
							<dt><strong>VERTICAL_SCROLLING_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineVERTICAL_SCROLLING_MENU">VERTICAL_SCROLLING_MENU</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="w"></a>
	<div>
		<h2>w</h2>
		<dl>
							<dt><strong>$warning</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$warning">Application::$warning</a></dd>
							<dt><strong>$warning_level</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$warning_level">Application::$warning_level</a></dd>
							<dt><strong>$width</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$width">Captcha::$width</a></dd>
							<dt><strong>website_modules</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodwebsite_modules">MenuService::website_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return a menu with links to modules</dd>
							<dt><strong>wordwrap_html</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionwordwrap_html">wordwrap_html()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Inserts a carriage return every $lenght characters. It's equivalent to wordwrap PHP function but it can deal with the HTML entities. An entity is coded on several characters and the wordwrap function counts several characters for an entity whereas it represents only one character.</dd>
							<dt><strong>write</strong></dt>
				<dd>in file file_system_element.class.php, method <a href="io/filesystem/FileSystemElement.php#methodwrite">FileSystemElement::write()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Does the necessary treatment to apply at each writing operation</dd>
							<dt><strong>WRITE</strong></dt>
				<dd>in file file.class.php, constant <a href="io/filesystem/_io---filesystem---file.class.php.php#defineWRITE">WRITE</a></dd>
							<dt><strong>write</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodwrite">Cache::write()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Writes a cache file.</dd>
							<dt><strong>write</strong></dt>
				<dd>in file file.class.php, method <a href="io/filesystem/File.php#methodwrite">File::write()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Writes some text in the file.</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="x"></a>
	<div>
		<h2>x</h2>
		<dl>
							<dt><strong>$xml</strong></dt>
				<dd>in file repository.class.php, variable <a href="core/Repository.php#var$xml">Repository::$xml</a></dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
  <hr />
	<a name="_"></a>
	<div>
		<h2>_</h2>
		<dl>
							<dt><strong>_assign</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#method_assign">LinksMenuElement::_assign()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assign tpl vars</dd>
							<dt><strong>_assign</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#method_assign">Menu::_assign()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assign tpl vars</dd>
							<dt><strong>_check_cache_file</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_check_cache_file">Template::_check_cache_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Allows you to know if the cache file is still valid or if it has to be removed because the source file has been updated.</dd>
							<dt><strong>_check_file</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_check_file">Template::_check_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the path of the file to load dinamycally according to the user theme and the kind of file (kernel, module, menu or framework file).</dd>
							<dt><strong>_generate_headers</strong></dt>
				<dd>in file mail.class.php, method <a href="io/Mail.php#method_generate_headers">Mail::_generate_headers()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the mail headers.</dd>
							<dt><strong>_include</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_include">Template::_include()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Include a file in another file. You can access to the same variables in the two variables, it's just as if you had copied the content of the included file in the includer.</dd>
							<dt><strong>_load</strong></dt>
				<dd>in file template.class.php, method <a href="io/Template.php#method_load">Template::_load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a template file.</dd>
							<dt><strong>_parent</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#method_parent">LinksMenuElement::_parent()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Increase the Menu Depth and set the menu type to its parent one</dd>
							<dt><strong>_parent</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#method_parent">LinksMenu::_parent()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Increase the Menu Depth and set the menu type to its parent one</dd>
					</dl>
	</div>
	<a href="elementindex.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                                                    <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:26 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>