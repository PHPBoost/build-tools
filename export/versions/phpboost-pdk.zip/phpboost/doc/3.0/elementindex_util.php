<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'util - Package util Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('util', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">util</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                                                        
                                                        <a href="classtrees_util.php" class="menu">class tree: util</a> - 
                <a href="elementindex_util.php" class="menu">index: util</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="util/Bench.php">Bench</a>            </li>
                    <li>
                <a href="util/Captcha.php">Captcha</a>            </li>
                    <li>
                <a href="util/Date.php">Date</a>            </li>
                    <li>
                <a href="util/MiniCalendar.php">MiniCalendar</a>            </li>
                    <li>
                <a href="util/Pagination.php">Pagination</a>            </li>
                    <li>
                <a href="util/Stats.php">Stats</a>            </li>
                    <li>
                <a href="util/Url.php">Url</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="util/_util---bench.class.php.php">                bench.class.php
                </a>            </li>
                    <li>
                <a href="util/_util---captcha.class.php.php">                captcha.class.php
                </a>            </li>
                    <li>
                <a href="util/_util---date.class.php.php">                date.class.php
                </a>            </li>
                    <li>
                <a href="util/_util---images_stats.class.php.php">                images_stats.class.php
                </a>            </li>
                    <li>
                <a href="util/_util---mini_calendar.class.php.php">                mini_calendar.class.php
                </a>            </li>
                    <li>
                <a href="util/_util---pagination.class.php.php">                pagination.class.php
                </a>            </li>
                    <li>
                <a href="util/_util---unusual_functions.inc.php.php">                unusual_functions.inc.php
                </a>            </li>
                    <li>
                <a href="util/_util---url.class.php.php">                url.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package util</h1>
	[ <a href="elementindex_util.php#a">a</a> ]
	[ <a href="elementindex_util.php#b">b</a> ]
	[ <a href="elementindex_util.php#c">c</a> ]
	[ <a href="elementindex_util.php#d">d</a> ]
	[ <a href="elementindex_util.php#f">f</a> ]
	[ <a href="elementindex_util.php#g">g</a> ]
	[ <a href="elementindex_util.php#h">h</a> ]
	[ <a href="elementindex_util.php#i">i</a> ]
	[ <a href="elementindex_util.php#j">j</a> ]
	[ <a href="elementindex_util.php#l">l</a> ]
	[ <a href="elementindex_util.php#m">m</a> ]
	[ <a href="elementindex_util.php#n">n</a> ]
	[ <a href="elementindex_util.php#p">p</a> ]
	[ <a href="elementindex_util.php#r">r</a> ]
	[ <a href="elementindex_util.php#s">s</a> ]
	[ <a href="elementindex_util.php#t">t</a> ]
	[ <a href="elementindex_util.php#u">u</a> ]
	[ <a href="elementindex_util.php#v">v</a> ]
	[ <a href="elementindex_util.php#w">w</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>$array_allocated_color</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$array_allocated_color">Stats::$array_allocated_color</a></dd>
							<dt><strong>$array_color_stats</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$array_color_stats">Stats::$array_color_stats</a></dd>
							<dt><strong>absolute</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodabsolute">Url::absolute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the absolute url</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>Bench</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodBench">Bench::Bench()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;starts the bench now</dd>
							<dt><strong>Bench</strong></dt>
				<dd>in file bench.class.php, class <a href="util/Bench.php">Bench</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is done to time a process easily. You choose when to start and when to stop.</dd>
							<dt><strong>bench.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---bench.class.php.php">bench.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>$code</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$code">Captcha::$code</a></dd>
							<dt><strong>$color_index</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$color_index">Stats::$color_index</a></dd>
							<dt><strong>Captcha</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodCaptcha">Captcha::Captcha()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Captcha constructor. It allows you to create multiple instance of captcha, and check if GD is loaded.</dd>
							<dt><strong>Captcha</strong></dt>
				<dd>in file captcha.class.php, class <a href="util/Captcha.php">Captcha</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provide you an easy way to prevent spam by bot in public formular.</dd>
							<dt><strong>CAPTCHA_EASY</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_EASY">CAPTCHA_EASY</a></dd>
							<dt><strong>CAPTCHA_HARD</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_HARD">CAPTCHA_HARD</a></dd>
							<dt><strong>CAPTCHA_NORMAL</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_NORMAL">CAPTCHA_NORMAL</a></dd>
							<dt><strong>CAPTCHA_VERY_EASY</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_VERY_EASY">CAPTCHA_VERY_EASY</a></dd>
							<dt><strong>CAPTCHA_VERY_HARD</strong></dt>
				<dd>in file captcha.class.php, constant <a href="util/_util---captcha.class.php.php#defineCAPTCHA_VERY_HARD">CAPTCHA_VERY_HARD</a></dd>
							<dt><strong>check_date</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodcheck_date">Date::check_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Determines whether a date is correct. For example the february 31st is not correct.</dd>
							<dt><strong>check_wellformness</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodcheck_wellformness">Url::check_wellformness()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the url match the requested url form</dd>
							<dt><strong>compress</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodcompress">Url::compress()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Compress a url by removing all &quot;folder/..&quot; occurrences</dd>
							<dt><strong>captcha.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---captcha.class.php.php">captcha.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>$data_stats</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$data_stats">Stats::$data_stats</a></dd>
							<dt><strong>$date</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$date">MiniCalendar::$date</a></dd>
							<dt><strong>$decimal</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$decimal">Stats::$decimal</a></dd>
							<dt><strong>$difficulty</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$difficulty">Captcha::$difficulty</a></dd>
							<dt><strong>$duration</strong></dt>
				<dd>in file bench.class.php, variable <a href="util/Bench.php#var$duration">Bench::$duration</a></dd>
							<dt><strong>Date</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodDate">Date::Date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds and initializes a date. It admits a variable number of parameters depending on the value of the first one. The second parameter allows us to chose what time referential we use to create the date: <ul><li>TIMEZONE_SYSTEM if that date comes from for example the database (dates must be stored under this referential).</li><li>TIMEZONE_SITE if it's an entry coming from the site (nearly never used).</li><li>TIMEZONE_USER if it's an entry coming from the user (it's own timezone will be used)</li></ul> The first parameter determines how to initialize the date, here are the rules to use for the other parameters: <ul><li>DATE_NOW will initialize the date to the current time.
 $date = new Date(DATE_NOW); will build a date with the current date.</li><li>DATE_YEAR_MONTH_DAY if you want to build a date from a specified day (year, month, day). In this case the following parameters are:
         <ul><li>int The year (for instance 2009)</li><li>int The month (for example 11)</li><li>int The day (for example 09)</li></ul>
 For example, $date = new Date(DATE_YEAR_MONTH_DAY, TIMEZONE_USER, 2009, 11, 09);</li><li>DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND if you want to build a date from a specified time. Here is the rule for the following parameters:
         <ul><li>int The year (for instance 2009)</li><li>int The month (for instance 11)</li><li>int The day (for instance 09)</li><li>int The hour (for instance 12)</li><li>int The minutes (for instance 34)</li><li>int The seconds (for instance 12)</li></ul>
 For instance $date = new Date(DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND, 2009, 11, 09, 12, 34, 12);</li><li>DATE_TIMESTAMP which builds a date from a UNIX timestamp.
 For example $date = new Date(DATE_TIMESTAMP, time()); is equivalent to $date = new Date(DATE_NOW);</li><li>DATE_FROM_STRING which decodes a date written in a string by matching a pattern you have to specify.
 The pattern is easy to write: d for day, m for month and y for year.
 For instance, if your third parameter is '24/12/2009' and the fourth is 'm/d/y', it will be the december 24th of 2009.</li></ul> Here are the rules:</dd>
							<dt><strong>Date</strong></dt>
				<dd>in file date.class.php, class <a href="util/Date.php">Date</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class allows you to handle easily some dates. A date is a day and an hour (year, month, day, hour, minutes, seconds). It supports the most common formats and manages timezones. Here are the definitions of the 3 existing timezones: <ul><li>System timezone: it's the timezone of the server, configured by the hoster. For instance, if your server is in France, it should be GMT+1.</li><li>Site timezone: it's the timezone of the central place of the site. For example, if your site deals with the italian soccer championship, it will be GMT+1.</li><li>User timezone :  each registered user can specify its timezone. It's particulary useful for people who visit some sites from a foreign country.</li></ul></dd>
							<dt><strong>DATE_FORMAT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT">DATE_FORMAT</a></dd>
							<dt><strong>DATE_FORMAT_LONG</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT_LONG">DATE_FORMAT_LONG</a></dd>
							<dt><strong>DATE_FORMAT_SHORT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT_SHORT">DATE_FORMAT_SHORT</a></dd>
							<dt><strong>DATE_FORMAT_TINY</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FORMAT_TINY">DATE_FORMAT_TINY</a></dd>
							<dt><strong>DATE_FROM_STRING</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_FROM_STRING">DATE_FROM_STRING</a></dd>
							<dt><strong>DATE_NOW</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_NOW">DATE_NOW</a></dd>
							<dt><strong>DATE_RFC822_F</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC822_F">DATE_RFC822_F</a></dd>
							<dt><strong>DATE_RFC822_FORMAT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC822_FORMAT">DATE_RFC822_FORMAT</a></dd>
							<dt><strong>DATE_RFC3339_F</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC3339_F">DATE_RFC3339_F</a></dd>
							<dt><strong>DATE_RFC3339_FORMAT</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_RFC3339_FORMAT">DATE_RFC3339_FORMAT</a></dd>
							<dt><strong>DATE_TIMESTAMP</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_TIMESTAMP">DATE_TIMESTAMP</a></dd>
							<dt><strong>DATE_YEAR_MONTH_DAY</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_YEAR_MONTH_DAY">DATE_YEAR_MONTH_DAY</a></dd>
							<dt><strong>DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineDATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND">DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methoddisplay">Captcha::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the captcha image to the user, and set the code to decrypt in the database.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methoddisplay">Pagination::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a list of links between pages.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methoddisplay">MiniCalendar::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays the mini calendar. You must call the display method in the same order as the calendars are displayed, because it requires a javascript code loading.</dd>
							<dt><strong>display_form</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methoddisplay_form">Captcha::display_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display captcha formular.</dd>
							<dt><strong>draw_ellipse</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methoddraw_ellipse">Stats::draw_ellipse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Drawn an ellipse.</dd>
							<dt><strong>draw_graph</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methoddraw_graph">Stats::draw_graph()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Draw graph, not yet implemented.</dd>
							<dt><strong>draw_histogram</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methoddraw_histogram">Stats::draw_histogram()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Draw a histogram</dd>
							<dt><strong>DRAW_LEGEND</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineDRAW_LEGEND">DRAW_LEGEND</a></dd>
							<dt><strong>DRAW_VALUES</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineDRAW_VALUES">DRAW_VALUES</a></dd>
							<dt><strong>date.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---date.class.php.php">date.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$font</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$font">Captcha::$font</a></dd>
							<dt><strong>$form_name</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$form_name">MiniCalendar::$form_name</a></dd>
							<dt><strong>format</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodformat">Date::format()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Formats the date to a particular format.</dd>
							<dt><strong>FRANKLINBC_TTF</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineFRANKLINBC_TTF">FRANKLINBC_TTF</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>$gd_loaded</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$gd_loaded">Captcha::$gd_loaded</a></dd>
							<dt><strong>get_absolute_root</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodget_absolute_root">Url::get_absolute_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the absolute website root Url</dd>
							<dt><strong>get_current_page</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methodget_current_page">Pagination::get_current_page()</a></dd>
							<dt><strong>get_date</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodget_date">MiniCalendar::get_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the date</dd>
							<dt><strong>get_day</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_day">Date::get_day()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the day of the date</dd>
							<dt><strong>get_first_msg</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methodget_first_msg">Pagination::get_first_msg()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the first message of the current page displayed. It usually used in SQL queries. Example : $Sql-&gt;query_while(&quot;SELECT n.contents FROM &quot; . PREFIX . &quot;news n    &quot; . $Sql-&gt;limit($Pagination-&gt;get_first_msg($CONFIG_NEWS['pagination_news'], 'p'), $CONFIG_NEWS['pagination_news']), __LINE__, __FILE__); For further informations, refer to the db package documentation.</dd>
							<dt><strong>get_hours</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_hours">Date::get_hours()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the hours of the date</dd>
							<dt><strong>get_microtime</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodget_microtime">Bench::get_microtime()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;computes the time with a microsecond precision</dd>
							<dt><strong>get_minutes</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_minutes">Date::get_minutes()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the minutes of the date</dd>
							<dt><strong>get_month</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_month">Date::get_month()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the month of the date</dd>
							<dt><strong>get_relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodget_relative">Url::get_relative()</a></dd>
							<dt><strong>get_seconds</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_seconds">Date::get_seconds()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the seconds of the date</dd>
							<dt><strong>get_server_url_page</strong></dt>
				<dd>in file unusual_functions.inc.php, function <a href="util/_util---unusual_functions.inc.php.php#functionget_server_url_page">get_server_url_page()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the path at which we must redirect the user when PHPBoost is not installed.</dd>
							<dt><strong>get_timestamp</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_timestamp">Date::get_timestamp()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the timestamp associated to the date</dd>
							<dt><strong>get_wellformness_regex</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodget_wellformness_regex">Url::get_wellformness_regex()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the regex matching the requested url form</dd>
							<dt><strong>get_year</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodget_year">Date::get_year()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the year of the date</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>$height</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$height">Captcha::$height</a></dd>
							<dt><strong>html_convert_absolute2root_relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodhtml_convert_absolute2root_relative">Url::html_convert_absolute2root_relative()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML text with only relatives urls</dd>
							<dt><strong>html_convert_root_relative2absolute</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodhtml_convert_root_relative2absolute">Url::html_convert_root_relative2absolute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML text with only absolutes urls</dd>
							<dt><strong>html_convert_root_relative2relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodhtml_convert_root_relative2relative">Url::html_convert_root_relative2relative()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Transforms the relative URL whose base is the site root (for instance /images/mypic.png) to the real relative path fited to the current page.</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$instance</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$instance">Captcha::$instance</a></dd>
							<dt><strong>$is_relative</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$is_relative">Url::$is_relative</a></dd>
							<dt><strong>is_available</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodis_available">Captcha::is_available()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if captcha is loaded, disabled for members.</dd>
							<dt><strong>is_relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodis_relative">Url::is_relative()</a></dd>
							<dt><strong>is_valid</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodis_valid">Captcha::is_valid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check if the code is valid, then delete it in the database to avoid multiple attempts.</dd>
							<dt><strong>images_stats.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---images_stats.class.php.php">images_stats.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="j"></a>
	<div>
		<h2>j</h2>
		<dl>
							<dt><strong>js_require</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodjs_require">Captcha::js_require()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Javascript alert if the formular of the captcha code is empty.</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>LINK_START_PAGE</strong></dt>
				<dd>in file pagination.class.php, constant <a href="util/_util---pagination.class.php.php#defineLINK_START_PAGE">LINK_START_PAGE</a></dd>
							<dt><strong>load_data</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methodload_data">Stats::load_data()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Load data for the charts.</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>MiniCalendar</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodMiniCalendar">MiniCalendar::MiniCalendar()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a calendar which will be displayable.</dd>
							<dt><strong>MiniCalendar</strong></dt>
				<dd>in file mini_calendar.class.php, class <a href="util/MiniCalendar.php">MiniCalendar</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to retrieve easily a date entered by a user. If the user isn't in the same timezone as the server, the hour will be automatically recomputed.</dd>
							<dt><strong>mini_calendar.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---mini_calendar.class.php.php">mini_calendar.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>$nbr_color</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$nbr_color">Stats::$nbr_color</a></dd>
							<dt><strong>$nbr_end_links</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$nbr_end_links">Pagination::$nbr_end_links</a></dd>
							<dt><strong>$nbr_entry</strong></dt>
				<dd>in file images_stats.class.php, variable <a href="util/Stats.php#var$nbr_entry">Stats::$nbr_entry</a></dd>
							<dt><strong>$nbr_start_links</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$nbr_start_links">Pagination::$nbr_start_links</a></dd>
							<dt><strong>$num_instance</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$num_instance">MiniCalendar::$num_instance</a></dd>
							<dt><strong>NO_ALLOCATE_COLOR</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_ALLOCATE_COLOR">NO_ALLOCATE_COLOR</a></dd>
							<dt><strong>NO_DRAW_LEGEND</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_DRAW_LEGEND">NO_DRAW_LEGEND</a></dd>
							<dt><strong>NO_DRAW_PERCENT</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_DRAW_PERCENT">NO_DRAW_PERCENT</a></dd>
							<dt><strong>NO_DRAW_VALUES</strong></dt>
				<dd>in file images_stats.class.php, constant <a href="util/_util---images_stats.class.php.php#defineNO_DRAW_VALUES">NO_DRAW_VALUES</a></dd>
							<dt><strong>NO_PREVIOUS_NEXT_LINKS</strong></dt>
				<dd>in file pagination.class.php, constant <a href="util/_util---pagination.class.php.php#defineNO_PREVIOUS_NEXT_LINKS">NO_PREVIOUS_NEXT_LINKS</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>$page</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$page">Pagination::$page</a></dd>
							<dt><strong>$path_to_root</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$path_to_root">Url::$path_to_root</a></dd>
							<dt><strong>Pagination</strong></dt>
				<dd>in file pagination.class.php, class <a href="util/Pagination.php">Pagination</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to manage easily a pagination system. It's very useful when you have a lot of items and you cannot display all of them. It also can generate the where clause to insert in your SQL query which selects the items.</dd>
							<dt><strong>Pagination</strong></dt>
				<dd>in file pagination.class.php, method <a href="util/Pagination.php#methodPagination">Pagination::Pagination()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Buils a Pagination.</dd>
							<dt><strong>path_to_root</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodpath_to_root">Url::path_to_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Overrides the used PATH_TO_ROOT. if the argument is null, the value is only returned. Please note this is a PHP4 hack to allow a Class variable.</dd>
							<dt><strong>pagination.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---pagination.class.php.php">pagination.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>relative</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodrelative">Url::relative()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the relative url if defined, else the absolute one</dd>
							<dt><strong>retrieve_date</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodretrieve_date">MiniCalendar::retrieve_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves a date entered in a mini calendar.</dd>
							<dt><strong>root_to_local</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodroot_to_local">Url::root_to_local()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the relative path from the website root to the current path if working on a relative url</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>$server_url</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$server_url">Url::$server_url</a></dd>
							<dt><strong>$start</strong></dt>
				<dd>in file bench.class.php, variable <a href="util/Bench.php#var$start">Bench::$start</a></dd>
							<dt><strong>$style</strong></dt>
				<dd>in file mini_calendar.class.php, variable <a href="util/MiniCalendar.php#var$style">MiniCalendar::$style</a></dd>
							<dt><strong>securit_register_globals</strong></dt>
				<dd>in file unusual_functions.inc.php, function <a href="util/_util---unusual_functions.inc.php.php#functionsecurit_register_globals">securit_register_globals()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unsets all the variables automatically set by the register_globals option. This function must be called only if the register_globals option is enable, otherwise it is useless.</dd>
							<dt><strong>server_url</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodserver_url">Url::server_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Overrides the used SERVER URL. if the argument is null, the value is only returned. Please note this is a PHP4 hack to allow a Class variable.</dd>
							<dt><strong>SERVER_URL</strong></dt>
				<dd>in file url.class.php, constant <a href="util/_util---url.class.php.php#defineSERVER_URL">SERVER_URL</a></dd>
							<dt><strong>set_date</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodset_date">MiniCalendar::set_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the date at which will be initialized the calendar.</dd>
							<dt><strong>set_difficulty</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_difficulty">Captcha::set_difficulty()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modifies the level of difficulty to decrypt the code on the captcha image.</dd>
							<dt><strong>set_font</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_font">Captcha::set_font()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify font used for the text on the image.</dd>
							<dt><strong>set_height</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_height">Captcha::set_height()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify height of the image.</dd>
							<dt><strong>set_instance</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_instance">Captcha::set_instance()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify instance number.</dd>
							<dt><strong>set_style</strong></dt>
				<dd>in file mini_calendar.class.php, method <a href="util/MiniCalendar.php#methodset_style">MiniCalendar::set_style()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the CSS properties of the element. You can use it if you want to customize the mini calendar, but the best solution is to redefine the template in your module. The template used is framework/mini_calendar.tpl.</dd>
							<dt><strong>set_width</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodset_width">Captcha::set_width()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Modify width of the image.</dd>
							<dt><strong>Stats</strong></dt>
				<dd>in file images_stats.class.php, class <a href="util/Stats.php">Stats</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides easy ways to create several type of charts.</dd>
							<dt><strong>Stats</strong></dt>
				<dd>in file images_stats.class.php, method <a href="util/Stats.php#methodStats">Stats::Stats()</a></dd>
							<dt><strong>stop</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodstop">Bench::stop()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;stops the bench now</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$timestamp</strong></dt>
				<dd>in file date.class.php, variable <a href="util/Date.php#var$timestamp">Date::$timestamp</a></dd>
							<dt><strong>TIMEZONE_AUTO</strong></dt>
				<dd>in file date.class.php, constant <a href="util/_util---date.class.php.php#defineTIMEZONE_AUTO">TIMEZONE_AUTO</a></dd>
							<dt><strong>to_date</strong></dt>
				<dd>in file date.class.php, method <a href="util/Date.php#methodto_date">Date::to_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the date according to the format YYYY-mm-dd</dd>
							<dt><strong>to_string</strong></dt>
				<dd>in file bench.class.php, method <a href="util/Bench.php#methodto_string">Bench::to_string()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the number formatted with $digits floating numbers</dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>$url</strong></dt>
				<dd>in file url.class.php, variable <a href="util/Url.php#var$url">Url::$url</a></dd>
							<dt><strong>update_instance</strong></dt>
				<dd>in file captcha.class.php, method <a href="util/Captcha.php#methodupdate_instance">Captcha::update_instance()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Updates the object instance.</dd>
							<dt><strong>Url</strong></dt>
				<dd>in file url.class.php, method <a href="util/Url.php#methodUrl">Url::Url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a Url object. By default, builds an Url object representing the current path. If the url is empty, no computation is done and an empty string will be returned when asking for both relative and absolute form of the url.</dd>
							<dt><strong>Url</strong></dt>
				<dd>in file url.class.php, class <a href="util/Url.php">Url</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class offers a simple way to transform an absolute or relative link to a relative one to the website root. It can also deals with absolute url and will convert only those from this site into relatives ones. Usage : <ul><li>In content, get the url with the absolute() method. It will allow content include at multiple level</li><li>In forms, get the url with the relative() method. It's a faster way to display url</li></ul></dd>
							<dt><strong>URL__CLASS</strong></dt>
				<dd>in file url.class.php, constant <a href="util/_util---url.class.php.php#defineURL__CLASS">URL__CLASS</a></dd>
							<dt><strong>unusual_functions.inc.php</strong></dt>
				<dd>procedural page <a href="util/_util---unusual_functions.inc.php.php">unusual_functions.inc.php</a></dd>
							<dt><strong>url.class.php</strong></dt>
				<dd>procedural page <a href="util/_util---url.class.php.php">url.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="v"></a>
	<div>
		<h2>v</h2>
		<dl>
							<dt><strong>$var_page</strong></dt>
				<dd>in file pagination.class.php, variable <a href="util/Pagination.php#var$var_page">Pagination::$var_page</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
  <hr />
	<a name="w"></a>
	<div>
		<h2>w</h2>
		<dl>
							<dt><strong>$width</strong></dt>
				<dd>in file captcha.class.php, variable <a href="util/Captcha.php#var$width">Captcha::$width</a></dd>
					</dl>
	</div>
	<a href="elementindex_util.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                                            
                                        <a href="classtrees_util.php" class="menu">class tree: util</a> -
            <a href="elementindex_util.php" class="menu">index: util</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:35 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>