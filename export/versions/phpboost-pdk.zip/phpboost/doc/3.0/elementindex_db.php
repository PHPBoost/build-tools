<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'db - Package db Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('db', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">db</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                
                                                                                                                                                                                                                                <a href="classtrees_db.php" class="menu">class tree: db</a> - 
                <a href="elementindex_db.php" class="menu">index: db</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="db/Backup.php">Backup</a>            </li>
                    <li>
                <a href="db/Sql.php">Sql</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="db/_db---backup.class.php.php">                backup.class.php
                </a>            </li>
                    <li>
                <a href="db/_db---mysql.class.php.php">                mysql.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package db</h1>
	[ <a href="elementindex_db.php#a">a</a> ]
	[ <a href="elementindex_db.php#b">b</a> ]
	[ <a href="elementindex_db.php#c">c</a> ]
	[ <a href="elementindex_db.php#d">d</a> ]
	[ <a href="elementindex_db.php#e">e</a> ]
	[ <a href="elementindex_db.php#f">f</a> ]
	[ <a href="elementindex_db.php#g">g</a> ]
	[ <a href="elementindex_db.php#h">h</a> ]
	[ <a href="elementindex_db.php#i">i</a> ]
	[ <a href="elementindex_db.php#l">l</a> ]
	[ <a href="elementindex_db.php#m">m</a> ]
	[ <a href="elementindex_db.php#n">n</a> ]
	[ <a href="elementindex_db.php#o">o</a> ]
	[ <a href="elementindex_db.php#p">p</a> ]
	[ <a href="elementindex_db.php#q">q</a> ]
	[ <a href="elementindex_db.php#r">r</a> ]
	[ <a href="elementindex_db.php#s">s</a> ]
	[ <a href="elementindex_db.php#t">t</a> ]
	[ <a href="elementindex_db.php#u">u</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>affected_rows</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodaffected_rows">Sql::affected_rows()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of the rows which have been affected by a request.</dd>
							<dt><strong>auto_connect</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodauto_connect">Sql::auto_connect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Connects automatically the application to the DBMS by reading the database configuration file whose path is /kernel/db/config.php. If an error occures while connecting to the server, the script execution will be stopped and the error will be written in the page.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>$backup_script</strong></dt>
				<dd>in file backup.class.php, variable <a href="db/Backup.php#var$backup_script">Backup::$backup_script</a></dd>
							<dt><strong>$base_name</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$base_name">Sql::$base_name</a></dd>
							<dt><strong>Backup</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodBackup">Backup::Backup()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Backup object</dd>
							<dt><strong>Backup</strong></dt>
				<dd>in file backup.class.php, class <a href="db/Backup.php">Backup</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class helps you to generate the backup file of your data base.</dd>
							<dt><strong>backup.class.php</strong></dt>
				<dd>procedural page <a href="db/_db---backup.class.php.php">backup.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>$connected</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$connected">Sql::$connected</a></dd>
							<dt><strong>clean_database_name</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodclean_database_name">Sql::clean_database_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Cleans the data base name to be sure it's a correct name</dd>
							<dt><strong>close</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodclose">Sql::close()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Closes the current MySQL connection if it is open.</dd>
							<dt><strong>concat</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodconcat">Sql::concat()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the syntax to use the concatenation operator (CONCAT in MySQL). The MySQL fields names must be in a PHP string for instance between simple quotes: 'field_name' The PHP variables must be bordered by simple quotes, for example: '\'' . $my_var . '\''</dd>
							<dt><strong>concatenate_to_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodconcatenate_to_query">Backup::concatenate_to_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates a string at the end of the current script.</dd>
							<dt><strong>connect</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodconnect">Sql::connect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method enables you to connect to the DBMS when you have the data base access informations.</dd>
							<dt><strong>CONNECTED_TO_DATABASE</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineCONNECTED_TO_DATABASE">CONNECTED_TO_DATABASE</a></dd>
							<dt><strong>CONNECTION_FAILED</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineCONNECTION_FAILED">CONNECTION_FAILED</a></dd>
							<dt><strong>count_table</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodcount_table">Sql::count_table()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Counts the number of the row contained in a table.</dd>
							<dt><strong>create_database</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodcreate_database">Sql::create_database()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Creates a data base on the DBMS at which is connected the current object.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>date_diff</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methoddate_diff">Sql::date_diff()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the MySQL syntax which enables you to compute the number of years separating a date in a data base field and today.</dd>
							<dt><strong>DBTYPE</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineDBTYPE">DBTYPE</a></dd>
							<dt><strong>DB_NO_CONNECT</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineDB_NO_CONNECT">DB_NO_CONNECT</a></dd>
							<dt><strong>drop_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methoddrop_tables">Sql::drop_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Drops some tables in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>ERRORS_MANAGEMENT_BY_RETURN</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineERRORS_MANAGEMENT_BY_RETURN">ERRORS_MANAGEMENT_BY_RETURN</a></dd>
							<dt><strong>escape</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodescape">Sql::escape()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Escapes the dangerous characters in the string you inject in your requests.</dd>
							<dt><strong>EXPLICIT_ERRORS_MANAGEMENT</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineEXPLICIT_ERRORS_MANAGEMENT">EXPLICIT_ERRORS_MANAGEMENT</a></dd>
							<dt><strong>export_file</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodexport_file">Backup::export_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Writes the backup script in a text file.</dd>
							<dt><strong>extract_table_structure</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodextract_table_structure">Backup::extract_table_structure()</a></dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>fetch_assoc</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodfetch_assoc">Sql::fetch_assoc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Browses a MySQL result resource row per row. When you call this method on a resource, you get the next row.</dd>
							<dt><strong>fetch_row</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodfetch_row">Sql::fetch_row()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Browses a MySQL result resource row per row. When you call this method on a resource, you get the next row.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>generate_create_table_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodgenerate_create_table_query">Backup::generate_create_table_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates the tables creation to the SQL backup script.</dd>
							<dt><strong>generate_drop_table_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodgenerate_drop_table_query">Backup::generate_drop_table_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates the query which drops the PHPBoost tables only if they exist to the backup SQL script.</dd>
							<dt><strong>generate_insert_values_query</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodgenerate_insert_values_query">Backup::generate_insert_values_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Concatenates the tables content insertion queries to the SQL backup script.</dd>
							<dt><strong>get_data_base_name</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodget_data_base_name">Sql::get_data_base_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the data base which with the object is connected.</dd>
							<dt><strong>get_dbms_version</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodget_dbms_version">Sql::get_dbms_version()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the version of MySQL used.</dd>
							<dt><strong>get_executed_requests_number</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodget_executed_requests_number">Sql::get_executed_requests_number()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of request executed by this object.</dd>
							<dt><strong>get_script</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_script">Backup::get_script()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current backup script.</dd>
							<dt><strong>get_tables_list</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_tables_list">Backup::get_tables_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the list of the tables used by PHPBoost.</dd>
							<dt><strong>get_tables_number</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_tables_number">Backup::get_tables_number()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of tables used by PHPBoost.</dd>
							<dt><strong>get_tables_properties_list</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodget_tables_properties_list">Backup::get_tables_properties_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the tables (name and informations relative to each table) of the data base at which is connected this SQL object. This method calls the SHOW TABLE STATUS MySQL query, to know more about it, see http://dev.mysql.com/doc/refman/5.1/en/show-table-status.html</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>highlight_query</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodhighlight_query">Sql::highlight_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Highlights a SQL query to be more readable by a human.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>indent_query</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodindent_query">Sql::indent_query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Indents a MySQL query.</dd>
							<dt><strong>insert_id</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodinsert_id">Sql::insert_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the ID generated from the previous INSERT operation.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>$link</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$link">Sql::$link</a></dd>
							<dt><strong>limit</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlimit">Sql::limit()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the MySQL syntax used to impose a limit in your row selection.</dd>
							<dt><strong>list_databases</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlist_databases">Sql::list_databases()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the existing data bases on the DBMS at which the object is connected. Only the data bases visible for the user connected will be returned.</dd>
							<dt><strong>list_db_tables</strong></dt>
				<dd>in file backup.class.php, method <a href="db/Backup.php#methodlist_db_tables">Backup::list_db_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the list of the tables present on the database used.</dd>
							<dt><strong>list_fields</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlist_fields">Sql::list_fields()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists all the columns of a table.</dd>
							<dt><strong>list_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodlist_tables">Sql::list_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists the tables (name and informations relative to each table) of the data base at which is connected this SQL object. This method calls the SHOW TABLE STATUS MySQL query, to know more about it, see http://dev.mysql.com/doc/refman/5.1/en/show-table-status.html</dd>
							<dt><strong>LOW_PRIORITY</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineLOW_PRIORITY">LOW_PRIORITY</a></dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>mysql.class.php</strong></dt>
				<dd>procedural page <a href="db/_db---mysql.class.php.php">mysql.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>num_rows</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodnum_rows">Sql::num_rows()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of rows got by a selection query.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="o"></a>
	<div>
		<h2>o</h2>
		<dl>
							<dt><strong>optimize_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodoptimize_tables">Sql::optimize_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Optimizes some tables in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>parse</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodparse">Sql::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a SQL file. The SQL file contains the name of the tables with the prefix phpboost_.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="q"></a>
	<div>
		<h2>q</h2>
		<dl>
							<dt><strong>query</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery">Sql::query()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sends a simple selection query to the DBMS and retrieves the result. A simple query selects only one field in one row.</dd>
							<dt><strong>query_array</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_array">Sql::query_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method makes automatically a query on several fields of a row. You tell it in which table you want to select, which row you want to use, and it will return you the values. It takes a variable number of parameters.</dd>
							<dt><strong>query_close</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_close">Sql::query_close()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Frees the memory allocated for a resource.</dd>
							<dt><strong>query_inject</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_inject">Sql::query_inject()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method enables you to execute CUD (Create Update Delete) queries in the database, and more generally, any query which has not any return value.</dd>
							<dt><strong>query_while</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodquery_while">Sql::query_while()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This method enables you to execute a Retrieve query on several rows in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>$req</strong></dt>
				<dd>in file mysql.class.php, variable <a href="db/Sql.php#var$req">Sql::$req</a></dd>
							<dt><strong>repair_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodrepair_tables">Sql::repair_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Repairs some tables in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>Sql</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodSql">Sql::Sql()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a MySQL connection.</dd>
							<dt><strong>Sql</strong></dt>
				<dd>in file mysql.class.php, class <a href="db/Sql.php">Sql</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages all the database access done by PHPBoost. It currently manages only one DBMS, MySQL, but we made it as generic as we could. It doesn't support ORM (Object Relationnal Mapping). On PHPBoost, all the table which are used contain a prefix which enables for example to install several instances of the software on the same data base. When you execute a query in a table, concatenate the PREFIX constant before the name of your table. Notice also that the kernel tables can have their name changed. You must not use their name directly but the constants which are defined in the file /kernel/db/tables.php.
 If you encounter any problem when writing queries, you should search what you need in the MySQL documentation, which is very well done: http://dev.mysql.com/doc/</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$tables</strong></dt>
				<dd>in file backup.class.php, variable <a href="db/Backup.php#var$tables">Backup::$tables</a></dd>
							<dt><strong>truncate_tables</strong></dt>
				<dd>in file mysql.class.php, method <a href="db/Sql.php#methodtruncate_tables">Sql::truncate_tables()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Trucates some tables in the data base.</dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>UNEXISTING_DATABASE</strong></dt>
				<dd>in file mysql.class.php, constant <a href="db/_db---mysql.class.php.php#defineUNEXISTING_DATABASE">UNEXISTING_DATABASE</a></dd>
					</dl>
	</div>
	<a href="elementindex_db.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                    
                                                                                                                                                                <a href="classtrees_db.php" class="menu">class tree: db</a> -
            <a href="elementindex_db.php" class="menu">index: db</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:17 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>