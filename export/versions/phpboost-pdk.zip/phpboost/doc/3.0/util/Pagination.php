<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'util - Docs For Class Pagination');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('util', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">util</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                                                        
                                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> - 
                <a href="../elementindex_util.php" class="menu">index: util</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/Bench.php">Bench</a>            </li>
                    <li>
                <a href="../util/Captcha.php">Captcha</a>            </li>
                    <li>
                <a href="../util/Date.php">Date</a>            </li>
                    <li>
                <a href="../util/MiniCalendar.php">MiniCalendar</a>            </li>
                    <li>
                <a href="../util/Pagination.php">Pagination</a>            </li>
                    <li>
                <a href="../util/Stats.php">Stats</a>            </li>
                    <li>
                <a href="../util/Url.php">Url</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/_util---bench.class.php.php">                bench.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---captcha.class.php.php">                captcha.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---date.class.php.php">                date.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---images_stats.class.php.php">                images_stats.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---mini_calendar.class.php.php">                mini_calendar.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---pagination.class.php.php">                pagination.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---unusual_functions.inc.php.php">                unusual_functions.inc.php
                </a>            </li>
                    <li>
                <a href="../util/_util---url.class.php.php">                url.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Pagination</h1><p>Source Location: /util/pagination.class.php [line 38]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class enables you to manage easily a pagination system. It's very useful when you have a lot of items and you cannot display all of them. It also can generate the where clause to insert in your SQL query which selects the items.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�gis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../util/Pagination.php#methodPagination">Pagination</a></li><li class="bb_li"><a href="../util/Pagination.php#methoddisplay">display</a></li><li class="bb_li"><a href="../util/Pagination.php#methodget_current_page">get_current_page</a></li><li class="bb_li"><a href="../util/Pagination.php#methodget_first_msg">get_first_msg</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../util/Pagination.php#var$nbr_end_links">$nbr_end_links</a></li><li class="bb_li"><a href="../util/Pagination.php#var$nbr_start_links">$nbr_start_links</a></li><li class="bb_li"><a href="../util/Pagination.php#var$page">$page</a></li><li class="bb_li"><a href="../util/Pagination.php#var$var_page">$var_page</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class enables you to manage easily a pagination system. It's very useful when you have a lot of items and you cannot display all of them. It also can generate the where clause to insert in your SQL query which selects the items.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodPagination"></a>
    <h3>constructor Pagination <span class="smalllinenumber">[line 44]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Pagination Pagination(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Buils a Pagination.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 62]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string display(
string
$path, string
$total_msg, string
$var_page, string
$nbr_msg_page, string
$nbr_max_link, [string
$font_size = 11], [string
$previous_next = true], [string
$link_start_page = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns a list of links between pages.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Pagination links.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>Adress with the url() function which abstracts the management of url rewritting in pagination links. You have to specify where the value of page will be placed in the adresse with %d (it will be replaced automatically) Example: url('page.php?p=%d', 'page-%d.php') //p is the variable name passed by the arguement $var_page.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$total_msg</strong>&nbsp;&nbsp;</td>
        <td>The total number of items.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$var_page</strong>&nbsp;&nbsp;</td>
        <td>The variable name used to get the page in the adress (in most case &quot;p&quot; is used).</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$nbr_msg_page</strong>&nbsp;&nbsp;</td>
        <td>The number of items per page.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$nbr_max_link</strong>&nbsp;&nbsp;</td>
        <td>The maximum number of links displayed.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$font_size</strong>&nbsp;&nbsp;</td>
        <td>Links font size.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$previous_next</strong>&nbsp;&nbsp;</td>
        <td>Display links before and after pagination links, to go to the next/previous page.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$link_start_page</strong>&nbsp;&nbsp;</td>
        <td>Underline link to the current page.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_current_page"></a>
    <h3>method get_current_page <span class="smalllinenumber">[line 145]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_current_page(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Return the current page</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_first_msg"></a>
    <h3>method get_first_msg <span class="smalllinenumber">[line 135]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_first_msg(
int
$nbr_msg_page, string
$var_page)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the first message of the current page displayed. It usually used in SQL queries. Example : $Sql-&gt;query_while(&quot;SELECT n.contents FROM &quot; . PREFIX . &quot;news n    &quot; . $Sql-&gt;limit($Pagination-&gt;get_first_msg($CONFIG_NEWS['pagination_news'], 'p'), $CONFIG_NEWS['pagination_news']), __LINE__, __FILE__); For further informations, refer to the db package documentation.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the first message of the current page displayed.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$nbr_msg_page</strong>&nbsp;&nbsp;</td>
        <td>Number of messages per page.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$var_page</strong>&nbsp;&nbsp;</td>
        <td>The variable name used to get the page in the adress (in most case &quot;p&quot; is used).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                            <div class="var">
                            <a name="var_nbr_end_links"></a>
                <span class="line-number">[line 192]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$nbr_end_links</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;3</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_nbr_start_links"></a>
                <span class="line-number">[line 191]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$nbr_start_links</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;3</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_page"></a>
                <span class="line-number">[line 190]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$page</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_var_page"></a>
                <span class="line-number">[line 193]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$var_page</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                                            
                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> -
            <a href="../elementindex_util.php" class="menu">index: util</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:52 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>