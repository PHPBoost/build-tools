<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'util - Docs For Class MiniCalendar');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('util', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">util</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                                                        
                                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> - 
                <a href="../elementindex_util.php" class="menu">index: util</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/Bench.php">Bench</a>            </li>
                    <li>
                <a href="../util/Captcha.php">Captcha</a>            </li>
                    <li>
                <a href="../util/Date.php">Date</a>            </li>
                    <li>
                <a href="../util/MiniCalendar.php">MiniCalendar</a>            </li>
                    <li>
                <a href="../util/Pagination.php">Pagination</a>            </li>
                    <li>
                <a href="../util/Stats.php">Stats</a>            </li>
                    <li>
                <a href="../util/Url.php">Url</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/_util---bench.class.php.php">                bench.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---captcha.class.php.php">                captcha.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---date.class.php.php">                date.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---images_stats.class.php.php">                images_stats.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---mini_calendar.class.php.php">                mini_calendar.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---pagination.class.php.php">                pagination.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---unusual_functions.inc.php.php">                unusual_functions.inc.php
                </a>            </li>
                    <li>
                <a href="../util/_util---url.class.php.php">                url.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: MiniCalendar</h1><p>Source Location: /util/mini_calendar.class.php [line 37]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class enables you to retrieve easily a date entered by a user. If the user isn't in the same timezone as the server, the hour will be automatically recomputed.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Benoit Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../util/MiniCalendar.php#methodMiniCalendar">MiniCalendar</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#methoddisplay">display</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#methodget_date">get_date</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#methodretrieve_date">retrieve_date</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#methodset_date">set_date</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#methodset_style">set_style</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../util/MiniCalendar.php#var$date">$date</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#var$form_name">$form_name</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#var$num_instance">$num_instance</a></li><li class="bb_li"><a href="../util/MiniCalendar.php#var$style">$style</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class enables you to retrieve easily a date entered by a user. If the user isn't in the same timezone as the server, the hour will be automatically recomputed.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Benoit Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodMiniCalendar"></a>
    <h3>constructor MiniCalendar <span class="smalllinenumber">[line 44]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>MiniCalendar MiniCalendar(
string
$form_name)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a calendar which will be displayable.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_name</strong>&nbsp;&nbsp;</td>
        <td>Name of the mini calendar in the HTML code (you will retrieve the data in that field). This name must be a HTML identificator.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 86]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string display(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Displays the mini calendar. You must call the display method in the same order as the calendars are displayed, because it requires a javascript code loading.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The code to write in the HTML page.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_date"></a>
    <h3>method get_date <span class="smalllinenumber">[line 77]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../util/Date.php">Date</a> get_date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the date</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_date"></a>
    <h3>method set_date <span class="smalllinenumber">[line 57]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_date(
<a href="../util/Date.php">Date</a>
$date)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the date at which will be initialized the calendar.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$date</strong>&nbsp;&nbsp;</td>
        <td>Date</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_style"></a>
    <h3>method set_style <span class="smalllinenumber">[line 68]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_style(
string
$style)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the CSS properties of the element. You can use it if you want to customize the mini calendar, but the best solution is to redefine the template in your module. The template used is framework/mini_calendar.tpl.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$style</strong>&nbsp;&nbsp;</td>
        <td>The CSS properties</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodretrieve_date"></a>
	<h3>static method retrieve_date <span class="smalllinenumber">[line 119]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static <a href="../util/Date.php">Date</a> retrieve_date(
string
$calendar_name)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Retrieves a date entered in a mini calendar.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The date of the calendar.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$calendar_name</strong>&nbsp;&nbsp;</td>
        <td>Name of the calendar (HTML identifier).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                            <div class="var">
                            <a name="var_date"></a>
                <span class="line-number">[line 141]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type"><a href="../util/Date.php">Date</a></span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$date</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_form_name"></a>
                <span class="line-number">[line 137]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$form_name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_num_instance"></a>
                <span class="line-number">[line 129]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$num_instance</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_style"></a>
                <span class="line-number">[line 133]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$style</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                                            
                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> -
            <a href="../elementindex_util.php" class="menu">index: util</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:58 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>