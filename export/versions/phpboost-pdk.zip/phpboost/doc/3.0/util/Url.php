<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'util - Docs For Class Url');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('util', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">util</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                                                        
                                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> - 
                <a href="../elementindex_util.php" class="menu">index: util</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/Bench.php">Bench</a>            </li>
                    <li>
                <a href="../util/Captcha.php">Captcha</a>            </li>
                    <li>
                <a href="../util/Date.php">Date</a>            </li>
                    <li>
                <a href="../util/MiniCalendar.php">MiniCalendar</a>            </li>
                    <li>
                <a href="../util/Pagination.php">Pagination</a>            </li>
                    <li>
                <a href="../util/Stats.php">Stats</a>            </li>
                    <li>
                <a href="../util/Url.php">Url</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/_util---bench.class.php.php">                bench.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---captcha.class.php.php">                captcha.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---date.class.php.php">                date.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---images_stats.class.php.php">                images_stats.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---mini_calendar.class.php.php">                mini_calendar.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---pagination.class.php.php">                pagination.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---unusual_functions.inc.php.php">                unusual_functions.inc.php
                </a>            </li>
                    <li>
                <a href="../util/_util---url.class.php.php">                url.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Url</h1><p>Source Location: /util/url.class.php [line 44]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class offers a simple way to transform an absolute or relative link to a relative one to the website root. It can also deals with absolute url and will convert only those from this site into relatives ones. Usage : <ul><li>In content, get the url with the absolute() method. It will allow content include at multiple level</li><li>In forms, get the url with the relative() method. It's a faster way to display url</li></ul></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../util/Url.php#methodUrl">Url</a></li><li class="bb_li"><a href="../util/Url.php#methodabsolute">absolute</a></li><li class="bb_li"><a href="../util/Url.php#methodcheck_wellformness">check_wellformness</a></li><li class="bb_li"><a href="../util/Url.php#methodcompress">compress</a></li><li class="bb_li"><a href="../util/Url.php#methodget_absolute_root">get_absolute_root</a></li><li class="bb_li"><a href="../util/Url.php#methodget_relative">get_relative</a></li><li class="bb_li"><a href="../util/Url.php#methodget_wellformness_regex">get_wellformness_regex</a></li><li class="bb_li"><a href="../util/Url.php#methodhtml_convert_absolute2root_relative">html_convert_absolute2root_relative</a></li><li class="bb_li"><a href="../util/Url.php#methodhtml_convert_root_relative2absolute">html_convert_root_relative2absolute</a></li><li class="bb_li"><a href="../util/Url.php#methodhtml_convert_root_relative2relative">html_convert_root_relative2relative</a></li><li class="bb_li"><a href="../util/Url.php#methodis_relative">is_relative</a></li><li class="bb_li"><a href="../util/Url.php#methodpath_to_root">path_to_root</a></li><li class="bb_li"><a href="../util/Url.php#methodrelative">relative</a></li><li class="bb_li"><a href="../util/Url.php#methodroot_to_local">root_to_local</a></li><li class="bb_li"><a href="../util/Url.php#methodserver_url">server_url</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../util/Url.php#var$is_relative">$is_relative</a></li><li class="bb_li"><a href="../util/Url.php#var$path_to_root">$path_to_root</a></li><li class="bb_li"><a href="../util/Url.php#var$server_url">$server_url</a></li><li class="bb_li"><a href="../util/Url.php#var$url">$url</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class offers a simple way to transform an absolute or relative link to a relative one to the website root. It can also deals with absolute url and will convert only those from this site into relatives ones. Usage : <ul><li>In content, get the url with the absolute() method. It will allow content include at multiple level</li><li>In forms, get the url with the relative() method. It's a faster way to display url</li></ul></div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodUrl"></a>
    <h3>constructor Url <span class="smalllinenumber">[line 54]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Url Url(
[string
$url = '.'], [string
$path_to_root = null], [
$server_url = null])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Build a Url object. By default, builds an Url object representing the current path. If the url is empty, no computation is done and an empty string will be returned when asking for both relative and absolute form of the url.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>the url string relative to the current path, to the website root if beginning with a &quot;/&quot; or an absolute url</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path_to_root</strong>&nbsp;&nbsp;</td>
        <td>url context. default is PATH_TO_ROOT</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$server_url</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodabsolute"></a>
    <h3>method absolute <span class="smalllinenumber">[line 154]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string absolute(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the absolute url</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the absolute url</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_relative"></a>
    <h3>method is_relative <span class="smalllinenumber">[line 129]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool is_relative(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the url is a relative one</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodrelative"></a>
    <h3>method relative <span class="smalllinenumber">[line 138]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string relative(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the relative url if defined, else the absolute one</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the relative url if defined, else the absolute one</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodroot_to_local"></a>
    <h3>method root_to_local <span class="smalllinenumber">[line 197]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string root_to_local(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the relative path from the website root to the current path if working on a relative url</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the relative path from the website root to the current path if working on a relative url</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodcheck_wellformness"></a>
	<h3>static method check_wellformness <span class="smalllinenumber">[line 516]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static true check_wellformness(

$url, [int
$protocol = REGEX_MULTIPLICITY_OPTIONNAL], [int
$user = REGEX_MULTIPLICITY_OPTIONNAL], [int
$domain = REGEX_MULTIPLICITY_OPTIONNAL], [int
$folders = REGEX_MULTIPLICITY_OPTIONNAL], [int
$file = REGEX_MULTIPLICITY_OPTIONNAL], [int
$args = REGEX_MULTIPLICITY_OPTIONNAL], [int
$anchor = REGEX_MULTIPLICITY_OPTIONNAL], [bool
$forbid_js = true])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns true if the url match the requested url form</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> if the url match the requested url form</li><li><strong>see:</strong> REGEX_MULTIPLICITY_ALL</li><li><strong>see:</strong> REGEX_MULTIPLICITY_NOT_USED</li><li><strong>see:</strong> REGEX_MULTIPLICITY_AT_LEAST_ONE</li><li><strong>see:</strong> REGEX_MULTIPLICITY_NEEDED</li><li><strong>see:</strong> REGEX_MULTIPLICITY_OPTIONNAL</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$protocol</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the protocol sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$user</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the user:password@ sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$domain</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the domain sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$folders</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the folders sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the file sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$args</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the arguments sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$anchor</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the anchor sub-regex</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$forbid_js</strong>&nbsp;&nbsp;</td>
        <td>true if you want to forbid javascript uses in urls</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodcompress"></a>
	<h3>static method compress <span class="smalllinenumber">[line 173]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string compress(
string
$url)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Compress a url by removing all &quot;folder/..&quot; occurrences</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the compressed url</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>the url to compress</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_absolute_root"></a>
	<h3>static method get_absolute_root <span class="smalllinenumber">[line 217]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string get_absolute_root(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns the absolute website root Url</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the absolute website root Url</li></ul>
    </div>

	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_relative"></a>
	<h3>static method get_relative <span class="smalllinenumber">[line 402]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string get_relative(
string
$url, [string
$path_to_root = null], [string
$server_url = null])</code>
    </td></tr></table>
    </td></tr></table>
	
		    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the relative url of the $url parameter</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>the url to &quot;relativize&quot;</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path_to_root</strong>&nbsp;&nbsp;</td>
        <td>Path to root of the page to which you want to fit the URL</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$server_url</strong>&nbsp;&nbsp;</td>
        <td>Path from the site root of the page to which you want to fit the URL.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_wellformness_regex"></a>
	<h3>static method get_wellformness_regex <span class="smalllinenumber">[line 460]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static the get_wellformness_regex(
[int
$protocol = REGEX_MULTIPLICITY_OPTIONNAL], [int
$user = REGEX_MULTIPLICITY_OPTIONNAL], [int
$domain = REGEX_MULTIPLICITY_OPTIONNAL], [int
$folders = REGEX_MULTIPLICITY_OPTIONNAL], [int
$file = REGEX_MULTIPLICITY_OPTIONNAL], [int
$args = REGEX_MULTIPLICITY_OPTIONNAL], [int
$anchor = REGEX_MULTIPLICITY_OPTIONNAL], [bool
$forbid_js = true])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns the regex matching the requested url form</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> regex matching the requested url form</li><li><strong>see:</strong> REGEX_MULTIPLICITY_ALL</li><li><strong>see:</strong> REGEX_MULTIPLICITY_NOT_USED</li><li><strong>see:</strong> REGEX_MULTIPLICITY_AT_LEAST_ONE</li><li><strong>see:</strong> REGEX_MULTIPLICITY_NEEDED</li><li><strong>see:</strong> REGEX_MULTIPLICITY_OPTIONNAL</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$protocol</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the protocol sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$user</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the user:password@ sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$domain</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the domain sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$folders</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the folders sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the file sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$args</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the arguments sub-regex</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$anchor</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION for the anchor sub-regex</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$forbid_js</strong>&nbsp;&nbsp;</td>
        <td>true if you want to forbid javascript uses in urls</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodhtml_convert_absolute2root_relative"></a>
	<h3>static method html_convert_absolute2root_relative <span class="smalllinenumber">[line 257]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string html_convert_absolute2root_relative(
string
$html_text, [string
$path_to_root = PATH_TO_ROOT], [string
$server_url = SERVER_URL])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns the HTML text with only relatives urls</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The HTML text with only absolutes urls</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$html_text</strong>&nbsp;&nbsp;</td>
        <td>The HTML text in which we gonna search for absolutes urls to convert into relatives ones.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path_to_root</strong>&nbsp;&nbsp;</td>
        <td>Path to root of the page to which you want to fit the URL.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$server_url</strong>&nbsp;&nbsp;</td>
        <td>Path from the site root of the page to which you want to fit the URL.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodhtml_convert_root_relative2absolute"></a>
	<h3>static method html_convert_root_relative2absolute <span class="smalllinenumber">[line 232]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string html_convert_root_relative2absolute(
string
$html_text, [string
$path_to_root = PATH_TO_ROOT], [string
$server_url = SERVER_URL])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns the HTML text with only absolutes urls</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The HTML text with only absolutes urls</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$html_text</strong>&nbsp;&nbsp;</td>
        <td>The HTML text in which we gonna search for root relatives urls (only those beginning by '/') to convert into absolutes ones.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path_to_root</strong>&nbsp;&nbsp;</td>
        <td>Path to root of the page to which you want to fit the URL.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$server_url</strong>&nbsp;&nbsp;</td>
        <td>Path from the site root of the page to which you want to fit the URL.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodhtml_convert_root_relative2relative"></a>
	<h3>static method html_convert_root_relative2relative <span class="smalllinenumber">[line 282]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string html_convert_root_relative2relative(
string
$html_text, [string
$path_to_root = PATH_TO_ROOT], [string
$server_url = SERVER_URL])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Transforms the relative URL whose base is the site root (for instance /images/mypic.png) to the real relative path fited to the current page.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The transformed string</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$html_text</strong>&nbsp;&nbsp;</td>
        <td>The HTML text in which you want to replace the paths</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path_to_root</strong>&nbsp;&nbsp;</td>
        <td>Path to root of the page to which you want to fit the URL.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$server_url</strong>&nbsp;&nbsp;</td>
        <td>Path from the site root of the page to which you want to fit the URL.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodpath_to_root"></a>
	<h3>static method path_to_root <span class="smalllinenumber">[line 415]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string path_to_root(
[string
$path = null])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Overrides the used PATH_TO_ROOT. if the argument is null, the value is only returned. Please note this is a PHP4 hack to allow a Class variable.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the used PATH_TO_ROOT</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>the new PATH_TO_ROOT to use</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodserver_url"></a>
	<h3>static method server_url <span class="smalllinenumber">[line 432]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string server_url(
[
$url = null], string
$path)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Overrides the used SERVER URL. if the argument is null, the value is only returned. Please note this is a PHP4 hack to allow a Class variable.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the used SERVER URL</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>the new SERVER URL to use</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                            <div class="var">
                            <a name="var_is_relative"></a>
                <span class="line-number">[line 526]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$is_relative</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;false</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_path_to_root"></a>
                <span class="line-number">[line 527]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$path_to_root</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_server_url"></a>
                <span class="line-number">[line 528]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$server_url</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_url"></a>
                <span class="line-number">[line 525]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$url</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                                            
                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> -
            <a href="../elementindex_util.php" class="menu">index: util</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:39 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>