<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'util - Docs For Class Date');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('util', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">util</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                                                        
                                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> - 
                <a href="../elementindex_util.php" class="menu">index: util</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/Bench.php">Bench</a>            </li>
                    <li>
                <a href="../util/Captcha.php">Captcha</a>            </li>
                    <li>
                <a href="../util/Date.php">Date</a>            </li>
                    <li>
                <a href="../util/MiniCalendar.php">MiniCalendar</a>            </li>
                    <li>
                <a href="../util/Pagination.php">Pagination</a>            </li>
                    <li>
                <a href="../util/Stats.php">Stats</a>            </li>
                    <li>
                <a href="../util/Url.php">Url</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../util/_util---bench.class.php.php">                bench.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---captcha.class.php.php">                captcha.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---date.class.php.php">                date.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---images_stats.class.php.php">                images_stats.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---mini_calendar.class.php.php">                mini_calendar.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---pagination.class.php.php">                pagination.class.php
                </a>            </li>
                    <li>
                <a href="../util/_util---unusual_functions.inc.php.php">                unusual_functions.inc.php
                </a>            </li>
                    <li>
                <a href="../util/_util---url.class.php.php">                url.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Date</h1><p>Source Location: /util/date.class.php [line 57]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class allows you to handle easily some dates. A date is a day and an hour (year, month, day, hour, minutes, seconds). It supports the most common formats and manages timezones. Here are the definitions of the 3 existing timezones: <ul><li>System timezone: it's the timezone of the server, configured by the hoster. For instance, if your server is in France, it should be GMT+1.</li><li>Site timezone: it's the timezone of the central place of the site. For example, if your site deals with the italian soccer championship, it will be GMT+1.</li><li>User timezone :  each registered user can specify its timezone. It's particulary useful for people who visit some sites from a foreign country.</li></ul></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Benoit Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../util/Date.php#methodDate">Date</a></li><li class="bb_li"><a href="../util/Date.php#methodcheck_date">check_date</a></li><li class="bb_li"><a href="../util/Date.php#methodformat">format</a></li><li class="bb_li"><a href="../util/Date.php#methodget_day">get_day</a></li><li class="bb_li"><a href="../util/Date.php#methodget_hours">get_hours</a></li><li class="bb_li"><a href="../util/Date.php#methodget_minutes">get_minutes</a></li><li class="bb_li"><a href="../util/Date.php#methodget_month">get_month</a></li><li class="bb_li"><a href="../util/Date.php#methodget_seconds">get_seconds</a></li><li class="bb_li"><a href="../util/Date.php#methodget_timestamp">get_timestamp</a></li><li class="bb_li"><a href="../util/Date.php#methodget_year">get_year</a></li><li class="bb_li"><a href="../util/Date.php#methodto_date">to_date</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../util/Date.php#var$timestamp">$timestamp</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class allows you to handle easily some dates. A date is a day and an hour (year, month, day, hour, minutes, seconds). It supports the most common formats and manages timezones. Here are the definitions of the 3 existing timezones: <ul><li>System timezone: it's the timezone of the server, configured by the hoster. For instance, if your server is in France, it should be GMT+1.</li><li>Site timezone: it's the timezone of the central place of the site. For example, if your site deals with the italian soccer championship, it will be GMT+1.</li><li>User timezone :  each registered user can specify its timezone. It's particulary useful for people who visit some sites from a foreign country.</li></ul></div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Benoit Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodDate"></a>
    <h3>constructor Date <span class="smalllinenumber">[line 99]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Date Date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds and initializes a date. It admits a variable number of parameters depending on the value of the first one. The second parameter allows us to chose what time referential we use to create the date: <ul><li>TIMEZONE_SYSTEM if that date comes from for example the database (dates must be stored under this referential).</li><li>TIMEZONE_SITE if it's an entry coming from the site (nearly never used).</li><li>TIMEZONE_USER if it's an entry coming from the user (it's own timezone will be used)</li></ul> The first parameter determines how to initialize the date, here are the rules to use for the other parameters: <ul><li>DATE_NOW will initialize the date to the current time.
 $date = new Date(DATE_NOW); will build a date with the current date.</li><li>DATE_YEAR_MONTH_DAY if you want to build a date from a specified day (year, month, day). In this case the following parameters are:
         <ul><li>int The year (for instance 2009)</li><li>int The month (for example 11)</li><li>int The day (for example 09)</li></ul>
 For example, $date = new Date(DATE_YEAR_MONTH_DAY, TIMEZONE_USER, 2009, 11, 09);</li><li>DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND if you want to build a date from a specified time. Here is the rule for the following parameters:
         <ul><li>int The year (for instance 2009)</li><li>int The month (for instance 11)</li><li>int The day (for instance 09)</li><li>int The hour (for instance 12)</li><li>int The minutes (for instance 34)</li><li>int The seconds (for instance 12)</li></ul>
 For instance $date = new Date(DATE_YEAR_MONTH_DAY_HOUR_MINUTE_SECOND, 2009, 11, 09, 12, 34, 12);</li><li>DATE_TIMESTAMP which builds a date from a UNIX timestamp.
 For example $date = new Date(DATE_TIMESTAMP, time()); is equivalent to $date = new Date(DATE_NOW);</li><li>DATE_FROM_STRING which decodes a date written in a string by matching a pattern you have to specify.
 The pattern is easy to write: d for day, m for month and y for year.
 For instance, if your third parameter is '24/12/2009' and the fourth is 'm/d/y', it will be the december 24th of 2009.</li></ul> Here are the rules:</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodformat"></a>
    <h3>method format <span class="smalllinenumber">[line 228]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string format(
[int
$format = DATE_FORMAT_TINY], [int
$referencial_timezone = TIMEZONE_USER])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Formats the date to a particular format.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The formatted date</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$format</strong>&nbsp;&nbsp;</td>
        <td>One of the following enumeration: <ul><li>DATE_FORMAT_TINY for a tiny formatting (only month and day)</li><li>DATE_FORMAT_SHORT for a short formatting (month, day, year)</li><li>DATE_FORMAT for a longer displaying (year, month, day, hour and minutes)</li><li>DATE_FORMAT_LONG for a total displaying (year, month, day, hour, minutes and seconds)</li><li>DATE_RFC822_F to format according to what the RFC822 announces</li><li>DATE_RFC3339_F to format according to what the RFC3339 announces</li></ul></td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$referencial_timezone</strong>&nbsp;&nbsp;</td>
        <td>One of the following enumeration: <ul><li>TIMEZONE_SYSTEM</li><li>TIMZONE_SITE</li><li>TIMEZONE_USER</li></ul></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_day"></a>
    <h3>method get_day <span class="smalllinenumber">[line 302]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_day(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the day of the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The day</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_hours"></a>
    <h3>method get_hours <span class="smalllinenumber">[line 311]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_hours(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the hours of the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The hours</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_minutes"></a>
    <h3>method get_minutes <span class="smalllinenumber">[line 320]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_minutes(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the minutes of the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The minutes</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_month"></a>
    <h3>method get_month <span class="smalllinenumber">[line 293]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_month(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the month of the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The month</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_seconds"></a>
    <h3>method get_seconds <span class="smalllinenumber">[line 329]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_seconds(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the seconds of the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The seconds</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_timestamp"></a>
    <h3>method get_timestamp <span class="smalllinenumber">[line 275]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_timestamp(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the timestamp associated to the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The timestamp</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_year"></a>
    <h3>method get_year <span class="smalllinenumber">[line 284]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_year(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the year of the date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The year</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodto_date"></a>
    <h3>method to_date <span class="smalllinenumber">[line 338]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string to_date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Exports the date according to the format YYYY-mm-dd</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The formatted date</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodcheck_date"></a>
	<h3>static method check_date <span class="smalllinenumber">[line 352]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static bool check_date(
int
$month, int
$day, int
$year)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Determines whether a date is correct. For example the february 31st is not correct.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the date is correct and false otherwise.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$month</strong>&nbsp;&nbsp;</td>
        <td>The month</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$day</strong>&nbsp;&nbsp;</td>
        <td>The day</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$year</strong>&nbsp;&nbsp;</td>
        <td>The year</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                <div class="var">
                            <a name="var_timestamp"></a>
                <span class="line-number">[line 395]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$timestamp</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                                            
                                        <a href="../classtrees_util.php" class="menu">class tree: util</a> -
            <a href="../elementindex_util.php" class="menu">index: util</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:45 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>