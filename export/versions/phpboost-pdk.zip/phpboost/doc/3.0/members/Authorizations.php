<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'members - Docs For Class Authorizations');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('members', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">members</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                    
                                                                                                                                            <a href="../classtrees_members.php" class="menu">class tree: members</a> - 
                <a href="../elementindex_members.php" class="menu">index: members</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/Authorizations.php">Authorizations</a>            </li>
                    <li>
                <a href="../members/Group.php">Group</a>            </li>
                    <li>
                <a href="../members/PrivateMsg.php">PrivateMsg</a>            </li>
                    <li>
                <a href="../members/Session.php">Session</a>            </li>
                    <li>
                <a href="../members/Uploads.php">Uploads</a>            </li>
                    <li>
                <a href="../members/User.php">User</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/_members---authorizations.class.php.php">                authorizations.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---groups.class.php.php">                groups.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---pm.class.php.php">                pm.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---session.class.php.php">                session.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---uploads.class.php.php">                uploads.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---user.class.php.php">                user.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Authorizations</h1><p>Source Location: /members/authorizations.class.php [line 36]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class contains only static methods, it souldn't be instantiated.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�gis VIARRE &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt; / Sautel Benoit &lt;ben.popeye@phpboost.com&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../members/Authorizations.php#methodauth_array_simple">auth_array_simple</a></li><li class="bb_li"><a href="../members/Authorizations.php#methodbuild_auth_array_from_form">build_auth_array_from_form</a></li><li class="bb_li"><a href="../members/Authorizations.php#methodcapture_and_shift_bit_auth">capture_and_shift_bit_auth</a></li><li class="bb_li"><a href="../members/Authorizations.php#methodcheck_auth">check_auth</a></li><li class="bb_li"><a href="../members/Authorizations.php#methodgenerate_select">generate_select</a></li><li class="bb_li"><a href="../members/Authorizations.php#methodmerge_auth">merge_auth</a></li></ul>
    </div>
    </td>
<!--
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class contains only static methods, it souldn't be instantiated.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis VIARRE &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt; / Sautel Benoit &lt;ben.popeye@phpboost.com&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	


  <div class="list">
	<a name="methodauth_array_simple"></a>
	<h3>static method auth_array_simple <span class="smalllinenumber">[line 85]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static Array auth_array_simple(
int
$bit_value, string
$idselect, [boolean
$admin_auth_default = true])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns an array with the authorizations given by variable number of arrays passed in argument.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> with the authorization for the bit specified.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$bit_value</strong>&nbsp;&nbsp;</td>
        <td>The bit emplacement in the authorization array.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$idselect</strong>&nbsp;&nbsp;</td>
        <td>Html id of the html select field of authorizations (in most case the same value as $bit_value).</td>
      </tr>
          <tr>
        <td class="type">boolean&nbsp;&nbsp;</td>
        <td><strong>$admin_auth_default</strong>&nbsp;&nbsp;</td>
        <td>Give authorization for the administrator by default.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodbuild_auth_array_from_form"></a>
	<h3>static method build_auth_array_from_form <span class="smalllinenumber">[line 45]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static array build_auth_array_from_form(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns an array with the authorizations given by variable number of arrays passed in argument. This returned array is used to be serialized.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The array of authorizations.</li></ul>
    </div>

	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodcapture_and_shift_bit_auth"></a>
	<h3>static method capture_and_shift_bit_auth <span class="smalllinenumber">[line 328]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static array capture_and_shift_bit_auth(
array
$auth, int
$original_bit, [int
$final_bit = 1])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Capture authorizations and shift a particular bit to an another bit (1 is used by default).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The new authorization array.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$auth</strong>&nbsp;&nbsp;</td>
        <td>Array of authorizations.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$original_bit</strong>&nbsp;&nbsp;</td>
        <td>The bit to shift.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$final_bit</strong>&nbsp;&nbsp;</td>
        <td>Bit distination (1 is used by default).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodcheck_auth"></a>
	<h3>static method check_auth <span class="smalllinenumber">[line 251]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static boolean check_auth(
int
$type, int
$value, 
&$array_auth, int
$bit, array
$array_auth)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Check authorizations for a member, a group or a rank</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if authorized, false otherwise.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>Type of check, used RANK_TYPE for ranks, GROUP_TYPE for groups and USER_TYPE for users.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>Value int the authorization array to check.</td>
      </tr>
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$array_auth</strong>&nbsp;&nbsp;</td>
        <td>Array of authorization.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$bit</strong>&nbsp;&nbsp;</td>
        <td>Bit emplacement for the check</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$array_auth</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodgenerate_select"></a>
	<h3>static method generate_select <span class="smalllinenumber">[line 112]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static String generate_select(
int
$auth_bit, [array
$array_auth = array()], [array
$array_ranks_default = array()], [string
$idselect = ''], [int
$disabled = ''], [boolean
$disabled_advanced_auth = false])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Generate a multiple select field for the form which create authorization for ranks, groups and members.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The formated select.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$auth_bit</strong>&nbsp;&nbsp;</td>
        <td>The bit emplacement used to set it.</td>
      </tr>
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$array_auth</strong>&nbsp;&nbsp;</td>
        <td>Array of authorization, allow you to select value authorized for this bit.</td>
      </tr>
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$array_ranks_default</strong>&nbsp;&nbsp;</td>
        <td>Array of ranks selected by default.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$idselect</strong>&nbsp;&nbsp;</td>
        <td>Html id used for the select.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$disabled</strong>&nbsp;&nbsp;</td>
        <td>Disabled all option for the select. Set to 1 for disable.</td>
      </tr>
          <tr>
        <td class="type">boolean&nbsp;&nbsp;</td>
        <td><strong>$disabled_advanced_auth</strong>&nbsp;&nbsp;</td>
        <td>Disable advanced authorizations.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodmerge_auth"></a>
	<h3>static method merge_auth <span class="smalllinenumber">[line 287]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static array merge_auth(
array
$parent, array
$child, int
$auth_bit, int
$mode)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Merge two authorizations array, first is the parent, second is the inherited child.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The new array merged.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$parent</strong>&nbsp;&nbsp;</td>
        <td>Array of authorizations.</td>
      </tr>
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$child</strong>&nbsp;&nbsp;</td>
        <td>Array of authorizations.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$auth_bit</strong>&nbsp;&nbsp;</td>
        <td>Bit emplacement for the merge.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$mode</strong>&nbsp;&nbsp;</td>
        <td>Mode used for the merge. Use AUTH_PARENT_PRIORITY to give to the parent the priority for the authorization, AUTH_CHILD_PRIORITY otherwise.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                
                                                                                                    <a href="../classtrees_members.php" class="menu">class tree: members</a> -
            <a href="../elementindex_members.php" class="menu">index: members</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:27 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>