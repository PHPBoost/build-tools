<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'members - Docs For Class Uploads');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('members', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">members</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                    
                                                                                                                                            <a href="../classtrees_members.php" class="menu">class tree: members</a> - 
                <a href="../elementindex_members.php" class="menu">index: members</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/Authorizations.php">Authorizations</a>            </li>
                    <li>
                <a href="../members/Group.php">Group</a>            </li>
                    <li>
                <a href="../members/PrivateMsg.php">PrivateMsg</a>            </li>
                    <li>
                <a href="../members/Session.php">Session</a>            </li>
                    <li>
                <a href="../members/Uploads.php">Uploads</a>            </li>
                    <li>
                <a href="../members/User.php">User</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/_members---authorizations.class.php.php">                authorizations.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---groups.class.php.php">                groups.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---pm.class.php.php">                pm.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---session.class.php.php">                session.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---uploads.class.php.php">                uploads.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---user.class.php.php">                user.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Uploads</h1><p>Source Location: /members/uploads.class.php [line 36]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description"></div>
	




<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../members/Uploads.php#methodAdd_folder">Add_folder</a></li><li class="bb_li"><a href="../members/Uploads.php#methodDel_file">Del_file</a></li><li class="bb_li"><a href="../members/Uploads.php#methodDel_folder">Del_folder</a></li><li class="bb_li"><a href="../members/Uploads.php#methodEmpty_folder_member">Empty_folder_member</a></li><li class="bb_li"><a href="../members/Uploads.php#methodFind_subfolder">Find_subfolder</a></li><li class="bb_li"><a href="../members/Uploads.php#methodget_admin_url">get_admin_url</a></li><li class="bb_li"><a href="../members/Uploads.php#methodget_img_mimetype">get_img_mimetype</a></li><li class="bb_li"><a href="../members/Uploads.php#methodget_url">get_url</a></li><li class="bb_li"><a href="../members/Uploads.php#methodMember_memory_used">Member_memory_used</a></li><li class="bb_li"><a href="../members/Uploads.php#methodMove_file">Move_file</a></li><li class="bb_li"><a href="../members/Uploads.php#methodMove_folder">Move_folder</a></li><li class="bb_li"><a href="../members/Uploads.php#methodRename_file">Rename_file</a></li><li class="bb_li"><a href="../members/Uploads.php#methodRename_folder">Rename_folder</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../members/Uploads.php#var$base_directory">$base_directory</a></li><li class="bb_li"><a href="../members/Uploads.php#var$error">$error</a></li><li class="bb_li"><a href="../members/Uploads.php#var$extension">$extension</a></li><li class="bb_li"><a href="../members/Uploads.php#var$filename">$filename</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"></div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodAdd_folder"></a>
    <h3>method Add_folder <span class="smalllinenumber">[line 44]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Add_folder(

$id_parent, 
$user_id, 
$name)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_parent</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodDel_file"></a>
    <h3>method Del_file <span class="smalllinenumber">[line 101]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Del_file(

$id_file, 
$user_id, [
$admin = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_file</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$admin</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodDel_folder"></a>
    <h3>method Del_folder <span class="smalllinenumber">[line 75]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Del_folder(

$id_folder)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_folder</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodEmpty_folder_member"></a>
    <h3>method Empty_folder_member <span class="smalllinenumber">[line 58]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Empty_folder_member(

$user_id)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodFind_subfolder"></a>
    <h3>method Find_subfolder <span class="smalllinenumber">[line 255]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Find_subfolder(

$array_folders, 
$id_cat, 
&$array_child_folder)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$array_folders</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_cat</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$array_child_folder</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_admin_url"></a>
    <h3>method get_admin_url <span class="smalllinenumber">[line 270]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_admin_url(

$id_folder, 
$pwd, [
$member_link = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_folder</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$pwd</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$member_link</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_img_mimetype"></a>
    <h3>method get_img_mimetype <span class="smalllinenumber">[line 308]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_img_mimetype(

$type)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_url"></a>
    <h3>method get_url <span class="smalllinenumber">[line 285]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_url(

$id_folder, 
$pwd, 
$popup)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_folder</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$pwd</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$popup</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodMember_memory_used"></a>
    <h3>method Member_memory_used <span class="smalllinenumber">[line 300]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Member_memory_used(

$user_id)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodMove_file"></a>
    <h3>method Move_file <span class="smalllinenumber">[line 219]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Move_file(

$move, 
$to, 
$user_id, [
$admin = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$move</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$to</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$admin</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodMove_folder"></a>
    <h3>method Move_folder <span class="smalllinenumber">[line 182]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Move_folder(

$move, 
$to, 
$user_id, [
$admin = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$move</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$to</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$admin</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodRename_file"></a>
    <h3>method Rename_file <span class="smalllinenumber">[line 155]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Rename_file(

$id_file, 
$name, 
$previous_name, 
$user_id, [
$admin = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_file</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$previous_name</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$admin</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodRename_folder"></a>
    <h3>method Rename_folder <span class="smalllinenumber">[line 128]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void Rename_folder(

$id_folder, 
$name, 
$previous_name, 
$user_id, [
$admin = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$id_folder</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$previous_name</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$admin</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                            <div class="var">
                            <a name="var_base_directory"></a>
                <span class="line-number">[line 369]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$base_directory</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_error"></a>
                <span class="line-number">[line 39]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$error</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_extension"></a>
                <span class="line-number">[line 370]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$extension</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_filename"></a>
                <span class="line-number">[line 371]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$filename</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                
                                                                                                    <a href="../classtrees_members.php" class="menu">class tree: members</a> -
            <a href="../elementindex_members.php" class="menu">index: members</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:49:06 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>