<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'members - Docs For Class Group');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('members', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">members</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                    
                                                                                                                                            <a href="../classtrees_members.php" class="menu">class tree: members</a> - 
                <a href="../elementindex_members.php" class="menu">index: members</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/Authorizations.php">Authorizations</a>            </li>
                    <li>
                <a href="../members/Group.php">Group</a>            </li>
                    <li>
                <a href="../members/PrivateMsg.php">PrivateMsg</a>            </li>
                    <li>
                <a href="../members/Session.php">Session</a>            </li>
                    <li>
                <a href="../members/Uploads.php">Uploads</a>            </li>
                    <li>
                <a href="../members/User.php">User</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/_members---authorizations.class.php.php">                authorizations.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---groups.class.php.php">                groups.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---pm.class.php.php">                pm.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---session.class.php.php">                session.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---uploads.class.php.php">                uploads.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---user.class.php.php">                user.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Group</h1><p>Source Location: /members/groups.class.php [line 38]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class provides methods to manage user in groups.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�gis VIARRE &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../members/Group.php#methodGroup">Group</a></li><li class="bb_li"><a href="../members/Group.php#methodadd_member">add_member</a></li><li class="bb_li"><a href="../members/Group.php#methodedit_member">edit_member</a></li><li class="bb_li"><a href="../members/Group.php#methodget_groups_array">get_groups_array</a></li><li class="bb_li"><a href="../members/Group.php#methodremove_member">remove_member</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../members/Group.php#var$groups_auth">$groups_auth</a></li><li class="bb_li"><a href="../members/Group.php#var$groups_name">$groups_name</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class provides methods to manage user in groups.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis VIARRE &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodGroup"></a>
    <h3>constructor Group <span class="smalllinenumber">[line 45]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Group Group(

&$groups_info, array
$groups_info)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Constructor. Loads informations groups.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$groups_info</strong>&nbsp;&nbsp;</td>
        <td>Informations of all groups.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$groups_info</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadd_member"></a>
    <h3>method add_member <span class="smalllinenumber">[line 58]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>boolean add_member(
int
$user_id, int
$idgroup)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Adds a member in a group</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if the member has been succefully added.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td>User id</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idgroup</strong>&nbsp;&nbsp;</td>
        <td>Group id</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodedit_member"></a>
    <h3>method edit_member <span class="smalllinenumber">[line 84]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void edit_member(
int
$user_id, array
$array_user_groups)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Edits the user groups, compute difference between previous and new groups.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td>The user id</td>
      </tr>
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$array_user_groups</strong>&nbsp;&nbsp;</td>
        <td>The new array of groups.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_groups_array"></a>
    <h3>method get_groups_array <span class="smalllinenumber">[line 113]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>array get_groups_array(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the array of user groups (id =&gt; name)</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The array groups</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodremove_member"></a>
    <h3>method remove_member <span class="smalllinenumber">[line 123]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void remove_member(
int
$user_id, int
$idgroup)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Removes a member in a group.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td>The user id</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idgroup</strong>&nbsp;&nbsp;</td>
        <td>The id group.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                    <div class="var">
                            <a name="var_groups_auth"></a>
                <span class="line-number">[line 137]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$groups_auth</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_groups_name"></a>
                <span class="line-number">[line 136]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$groups_name</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                
                                                                                                    <a href="../classtrees_members.php" class="menu">class tree: members</a> -
            <a href="../elementindex_members.php" class="menu">index: members</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:25 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>