<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'members - Docs For Class Session');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('members', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">members</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                    
                                                                                                                                            <a href="../classtrees_members.php" class="menu">class tree: members</a> - 
                <a href="../elementindex_members.php" class="menu">index: members</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/Authorizations.php">Authorizations</a>            </li>
                    <li>
                <a href="../members/Group.php">Group</a>            </li>
                    <li>
                <a href="../members/PrivateMsg.php">PrivateMsg</a>            </li>
                    <li>
                <a href="../members/Session.php">Session</a>            </li>
                    <li>
                <a href="../members/Uploads.php">Uploads</a>            </li>
                    <li>
                <a href="../members/User.php">User</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../members/_members---authorizations.class.php.php">                authorizations.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---groups.class.php.php">                groups.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---pm.class.php.php">                pm.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---session.class.php.php">                session.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---uploads.class.php.php">                uploads.class.php
                </a>            </li>
                    <li>
                <a href="../members/_members---user.class.php.php">                user.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Session</h1><p>Source Location: /members/session.class.php [line 40]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class manages all sessions for the users.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�gis VIARRE &lt;crowkait@phpboost.com</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../members/Session.php#methodact">act</a></li><li class="bb_li"><a href="../members/Session.php#methodcheck">check</a></li><li class="bb_li"><a href="../members/Session.php#methodcsrf_get_protect">csrf_get_protect</a></li><li class="bb_li"><a href="../members/Session.php#methodcsrf_post_protect">csrf_post_protect</a></li><li class="bb_li"><a href="../members/Session.php#methodend">end</a></li><li class="bb_li"><a href="../members/Session.php#methodgarbage_collector">garbage_collector</a></li><li class="bb_li"><a href="../members/Session.php#methodget_module_parameters">get_module_parameters</a></li><li class="bb_li"><a href="../members/Session.php#methodget_token">get_token</a></li><li class="bb_li"><a href="../members/Session.php#methodload">load</a></li><li class="bb_li"><a href="../members/Session.php#methodset_module_parameters">set_module_parameters</a></li><li class="bb_li"><a href="../members/Session.php#methodstart">start</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../members/Session.php#var$autoconnect">$autoconnect</a></li><li class="bb_li"><a href="../members/Session.php#var$data">$data</a></li><li class="bb_li"><a href="../members/Session.php#var$session_mod">$session_mod</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class manages all sessions for the users.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis VIARRE &lt;crowkait@phpboost.com</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodact"></a>
    <h3>method act <span class="smalllinenumber">[line 51]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void act(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Manage the actions for the session caused by the user (connection, disconnection).</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcheck"></a>
    <h3>method check <span class="smalllinenumber">[line 297]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void check(
string
$session_script_title)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Check session validity, and update it</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$session_script_title</strong>&nbsp;&nbsp;</td>
        <td>The page title where the session has been check.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcsrf_get_protect"></a>
    <h3>method csrf_get_protect <span class="smalllinenumber">[line 715]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>true csrf_get_protect(
[mixed
$redirect = SEASURF_ATTACK_ERROR_PAGE])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Check the session against CSRF attacks by GET. Checks that GETs are done from this site with a correct token.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> if no csrf attack by get is detected</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$redirect</strong>&nbsp;&nbsp;</td>
        <td>if string, redirect to the $redirect error page if the token is wrong if false, do not redirect</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcsrf_post_protect"></a>
    <h3>method csrf_post_protect <span class="smalllinenumber">[line 681]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool csrf_post_protect(
[mixed
$redirect = SEASURF_ATTACK_ERROR_PAGE])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Check the session against CSRF attacks by POST. Checks that POSTs are done from this site. 2 different cases are accepted but the first is safer: <ul><li>The request contains a parameter whose name is token and value is the value of the token of the current session.</li><li>If the token isn't in the request, we analyse the HTTP referer to be sure that the request comes from the current site and not from another which can be suspect</li></ul> If the request doesn't match any of these two cases, this method will consider that it's a CSRF attack.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if no csrf attack by post is detected</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$redirect</strong>&nbsp;&nbsp;</td>
        <td>if string, redirect to the $redirect error page if the token is wrong if false, do not redirect</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodend"></a>
    <h3>method end <span class="smalllinenumber">[line 357]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void end(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Destroy the session</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_module_parameters"></a>
    <h3>method get_module_parameters <span class="smalllinenumber">[line 413]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>array get_module_parameters(
[string
$module = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Get module's parametres from session</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> array of parameters</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td>module  module name (if null then current module)</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_token"></a>
    <h3>method get_token <span class="smalllinenumber">[line 657]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_token(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Return the session token</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the session token</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodload"></a>
    <h3>method load <span class="smalllinenumber">[line 237]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void load(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Get informations from the user, and set it for his session.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_module_parameters"></a>
    <h3>method set_module_parameters <span class="smalllinenumber">[line 379]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_module_parameters(
mixed
$parameters, [
$module = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Save module's parameters into session</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$parameters</strong>&nbsp;&nbsp;</td>
        <td>module's parameters</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodstart"></a>
    <h3>method start <span class="smalllinenumber">[line 139]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>True start(
int
$user_id, string
$password, 
$level, string
$session_script, string
$session_script_get, string
$session_script_title, [boolean
$autoconnect = false], [boolean
$already_hashed = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Start the session</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> if succed, false otherwise and return an error code.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$user_id</strong>&nbsp;&nbsp;</td>
        <td>The member's user id.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$password</strong>&nbsp;&nbsp;</td>
        <td>The member's password.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$session_script</strong>&nbsp;&nbsp;</td>
        <td>Session script value where the session is started.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$session_script_get</strong>&nbsp;&nbsp;</td>
        <td>Get value of session script where the session is started.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$session_script_title</strong>&nbsp;&nbsp;</td>
        <td>Title of session script where the session is started.</td>
      </tr>
          <tr>
        <td class="type">boolean&nbsp;&nbsp;</td>
        <td><strong>$autoconnect</strong>&nbsp;&nbsp;</td>
        <td>The member user id.</td>
      </tr>
          <tr>
        <td class="type">boolean&nbsp;&nbsp;</td>
        <td><strong>$already_hashed</strong>&nbsp;&nbsp;</td>
        <td>True if password has been already hashed width str_hash() function, false otherwise.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$level</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodgarbage_collector"></a>
	<h3>static method garbage_collector <span class="smalllinenumber">[line 546]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static void garbage_collector(
)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Deletes all the existing sessions</div>
	
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                        <div class="var">
                            <a name="var_autoconnect"></a>
                <span class="line-number">[line 45]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$autoconnect</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_data"></a>
                <span class="line-number">[line 43]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$data</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_session_mod"></a>
                <span class="line-number">[line 44]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$session_mod</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                
                                                                                                    <a href="../classtrees_members.php" class="menu">class tree: members</a> -
            <a href="../elementindex_members.php" class="menu">index: members</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:28 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>