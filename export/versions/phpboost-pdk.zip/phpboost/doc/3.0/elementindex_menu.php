<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'menu - Package menu Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('menu', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">menu</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                    
                                                                                                                                                                                                                                                            <a href="classtrees_menu.php" class="menu">class tree: menu</a> - 
                <a href="elementindex_menu.php" class="menu">index: menu</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/contentmenu/ContentMenu.php">ContentMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/feedmenu/FeedMenu.php">FeedMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/linksmenu/LinksMenu.php">LinksMenu</a>            </li>
                    <li>
                <a href="menu/linksmenu/LinksMenuElement.php">LinksMenuElement</a>            </li>
                    <li>
                <a href="menu/linksmenu/LinksMenuLink.php">LinksMenuLink</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="menu/Menu.php">Menu</a>            </li>
                                        <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/minimenu/MiniMenu.php">MiniMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/modulesminimenu/ModuleMiniMenu.php">ModuleMiniMenu</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="menu/_menu---menu.class.php.php">                menu.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/contentmenu/_menu---content---content_menu.class.php.php">                content_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/feedmenu/_menu---feed---feed_menu.class.php.php">                feed_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/linksmenu/_menu---links---links_menu.class.php.php">                links_menu.class.php
                </a>            </li>
                    <li>
                <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php">                links_menu_element.class.php
                </a>            </li>
                    <li>
                <a href="menu/linksmenu/_menu---links---links_menu_link.class.php.php">                links_menu_link.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/minimenu/_menu---mini---mini_menu.class.php.php">                mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php">                module_mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package menu</h1>
	[ <a href="elementindex_menu.php#a">a</a> ]
	[ <a href="elementindex_menu.php#b">b</a> ]
	[ <a href="elementindex_menu.php#c">c</a> ]
	[ <a href="elementindex_menu.php#d">d</a> ]
	[ <a href="elementindex_menu.php#e">e</a> ]
	[ <a href="elementindex_menu.php#f">f</a> ]
	[ <a href="elementindex_menu.php#g">g</a> ]
	[ <a href="elementindex_menu.php#h">h</a> ]
	[ <a href="elementindex_menu.php#i">i</a> ]
	[ <a href="elementindex_menu.php#l">l</a> ]
	[ <a href="elementindex_menu.php#m">m</a> ]
	[ <a href="elementindex_menu.php#n">n</a> ]
	[ <a href="elementindex_menu.php#p">p</a> ]
	[ <a href="elementindex_menu.php#s">s</a> ]
	[ <a href="elementindex_menu.php#t">t</a> ]
	[ <a href="elementindex_menu.php#u">u</a> ]
	[ <a href="elementindex_menu.php#v">v</a> ]
	[ <a href="elementindex_menu.php#_">_</a> ]

  <hr />
	<a name="_"></a>
	<div>
		<h2>_</h2>
		<dl>
							<dt><strong>_assign</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#method_assign">Menu::_assign()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assign tpl vars</dd>
							<dt><strong>_assign</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#method_assign">LinksMenuElement::_assign()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assign tpl vars</dd>
							<dt><strong>_parent</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#method_parent">LinksMenuElement::_parent()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Increase the Menu Depth and set the menu type to its parent one</dd>
							<dt><strong>_parent</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#method_parent">LinksMenu::_parent()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Increase the Menu Depth and set the menu type to its parent one</dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>$auth</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$auth">Menu::$auth</a></dd>
							<dt><strong>admin_display</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodadmin_display">Menu::admin_display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu admin gui</dd>
							<dt><strong>add</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodadd">LinksMenu::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a single LinksMenuLink or (sub) Menu</dd>
							<dt><strong>add_array</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodadd_array">LinksMenu::add_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a list of LinksMenu or (sub)Menu to the current one</dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>$block</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$block">Menu::$block</a></dd>
							<dt><strong>BLOCK_POSITION__ALL</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__ALL">BLOCK_POSITION__ALL</a></dd>
							<dt><strong>BLOCK_POSITION__BOTTOM_CENTRAL</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__BOTTOM_CENTRAL">BLOCK_POSITION__BOTTOM_CENTRAL</a></dd>
							<dt><strong>BLOCK_POSITION__FOOTER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__FOOTER">BLOCK_POSITION__FOOTER</a></dd>
							<dt><strong>BLOCK_POSITION__HEADER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__HEADER">BLOCK_POSITION__HEADER</a></dd>
							<dt><strong>BLOCK_POSITION__LEFT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__LEFT">BLOCK_POSITION__LEFT</a></dd>
							<dt><strong>BLOCK_POSITION__NOT_ENABLED</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__NOT_ENABLED">BLOCK_POSITION__NOT_ENABLED</a></dd>
							<dt><strong>BLOCK_POSITION__RIGHT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__RIGHT">BLOCK_POSITION__RIGHT</a></dd>
							<dt><strong>BLOCK_POSITION__SUB_HEADER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__SUB_HEADER">BLOCK_POSITION__SUB_HEADER</a></dd>
							<dt><strong>BLOCK_POSITION__TOP_CENTRAL</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__TOP_CENTRAL">BLOCK_POSITION__TOP_CENTRAL</a></dd>
							<dt><strong>BLOCK_POSITION__TOP_FOOTER</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineBLOCK_POSITION__TOP_FOOTER">BLOCK_POSITION__TOP_FOOTER</a></dd>
							<dt><strong>$begin_at</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$begin_at">FeedMenu::$begin_at</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>cache_export</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodcache_export">Menu::cache_export()</a></dd>
							<dt><strong>cache_export_begin</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodcache_export_begin">Menu::cache_export_begin()</a></dd>
							<dt><strong>cache_export_end</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodcache_export_end">Menu::cache_export_end()</a></dd>
							<dt><strong>$content</strong></dt>
				<dd>in file content_menu.class.php, variable <a href="menu/contentmenu/ContentMenu.php#var$content">ContentMenu::$content</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodcache_export">ContentMenu::cache_export()</a></dd>
							<dt><strong>ContentMenu</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodContentMenu">ContentMenu::ContentMenu()</a></dd>
							<dt><strong>ContentMenu</strong></dt>
				<dd>in file content_menu.class.php, class <a href="menu/contentmenu/ContentMenu.php">ContentMenu</a></dd>
							<dt><strong>CONTENT_MENU__CLASS</strong></dt>
				<dd>in file content_menu.class.php, constant <a href="menu/contentmenu/_menu---content---content_menu.class.php.php#defineCONTENT_MENU__CLASS">CONTENT_MENU__CLASS</a></dd>
							<dt><strong>content_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/contentmenu/_menu---content---content_menu.class.php.php">content_menu.class.php</a></dd>
							<dt><strong>$category</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$category">FeedMenu::$category</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodcache_export">FeedMenu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodcache_export">LinksMenu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodcache_export">LinksMenuElement::cache_export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the string to write in the cache file</dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file links_menu_link.class.php, method <a href="menu/linksmenu/LinksMenuLink.php#methodcache_export">LinksMenuLink::cache_export()</a></dd>
							<dt><strong>cache_export_begin</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodcache_export_begin">LinksMenuElement::cache_export_begin()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the string to write in the cache file at the beginning of the Menu element</dd>
							<dt><strong>cache_export_end</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodcache_export_end">LinksMenuElement::cache_export_end()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;returns the string to write in the cache file at the end of the Menu element</dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file mini_menu.class.php, method <a href="menu/minimenu/MiniMenu.php#methodcache_export">MiniMenu::cache_export()</a></dd>
							<dt><strong>cache_export</strong></dt>
				<dd>in file module_mini_menu.class.php, method <a href="menu/modulesminimenu/ModuleMiniMenu.php#methodcache_export">ModuleMiniMenu::cache_export()</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>display</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methoddisplay">Menu::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu</dd>
							<dt><strong>$display_title</strong></dt>
				<dd>in file content_menu.class.php, variable <a href="menu/contentmenu/ContentMenu.php#var$display_title">ContentMenu::$display_title</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methoddisplay">ContentMenu::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the content menu.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methoddisplay">FeedMenu::display()</a></dd>
							<dt><strong>$depth</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$depth">LinksMenuElement::$depth</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file links_menu_link.class.php, method <a href="menu/linksmenu/LinksMenuLink.php#methoddisplay">LinksMenuLink::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu</dd>
							<dt><strong>display</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methoddisplay">LinksMenuElement::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays the menu according to the given template</dd>
							<dt><strong>display</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methoddisplay">LinksMenu::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the menu</dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>$enabled</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$enabled">Menu::$enabled</a></dd>
							<dt><strong>enabled</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodenabled">Menu::enabled()</a></dd>
							<dt><strong>$elements</strong></dt>
				<dd>in file links_menu.class.php, variable <a href="menu/linksmenu/LinksMenu.php#var$elements">LinksMenu::$elements</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>FeedMenu</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodFeedMenu">FeedMenu::FeedMenu()</a></dd>
							<dt><strong>FeedMenu</strong></dt>
				<dd>in file feed_menu.class.php, class <a href="menu/feedmenu/FeedMenu.php">FeedMenu</a></dd>
							<dt><strong>FEED_MENU__CLASS</strong></dt>
				<dd>in file feed_menu.class.php, constant <a href="menu/feedmenu/_menu---feed---feed_menu.class.php.php#defineFEED_MENU__CLASS">FEED_MENU__CLASS</a></dd>
							<dt><strong>feed_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/feedmenu/_menu---feed---feed_menu.class.php.php">feed_menu.class.php</a></dd>
							<dt><strong>$function_name</strong></dt>
				<dd>in file mini_menu.class.php, variable <a href="menu/minimenu/MiniMenu.php#var$function_name">MiniMenu::$function_name</a></dd>
							<dt><strong>$filename</strong></dt>
				<dd>in file module_mini_menu.class.php, variable <a href="menu/modulesminimenu/ModuleMiniMenu.php#var$filename">ModuleMiniMenu::$filename</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>get_auth</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_auth">Menu::get_auth()</a></dd>
							<dt><strong>get_block</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_block">Menu::get_block()</a></dd>
							<dt><strong>get_block_position</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_block_position">Menu::get_block_position()</a></dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_id">Menu::get_id()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodget_title">Menu::get_title()</a></dd>
							<dt><strong>get_content</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodget_content">ContentMenu::get_content()</a></dd>
							<dt><strong>get_display_title</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodget_display_title">ContentMenu::get_display_title()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the title will be displayed</dd>
							<dt><strong>get_module_id</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodget_module_id">FeedMenu::get_module_id()</a></dd>
							<dt><strong>get_template</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodget_template">FeedMenu::get_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the tpl to parse a feed</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodget_url">FeedMenu::get_url()</a></dd>
							<dt><strong>get_children</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodget_children">LinksMenu::get_children()</a></dd>
							<dt><strong>get_image</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodget_image">LinksMenuElement::get_image()</a></dd>
							<dt><strong>get_menu_types_list</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodget_menu_types_list">LinksMenu::get_menu_types_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;static method which returns all the menu types</dd>
							<dt><strong>get_type</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodget_type">LinksMenu::get_type()</a></dd>
							<dt><strong>get_uid</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodget_uid">LinksMenuElement::get_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the menu uid</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodget_url">LinksMenuElement::get_url()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file module_mini_menu.class.php, method <a href="menu/modulesminimenu/ModuleMiniMenu.php#methodget_title">ModuleMiniMenu::get_title()</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>HORIZONTAL_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineHORIZONTAL_MENU">HORIZONTAL_MENU</a></dd>
							<dt><strong>HORIZONTAL_SCROLLING_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineHORIZONTAL_SCROLLING_MENU">HORIZONTAL_SCROLLING_MENU</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$id</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$id">Menu::$id</a></dd>
							<dt><strong>id</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodid">Menu::id()</a></dd>
							<dt><strong>is_enabled</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodis_enabled">Menu::is_enabled()</a></dd>
							<dt><strong>$image</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$image">LinksMenuElement::$image</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>LinksMenu</strong></dt>
				<dd>in file links_menu.class.php, class <a href="menu/linksmenu/LinksMenu.php">LinksMenu</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create a Menu with children. Children could be Menu or LinksMenuLink objects</dd>
							<dt><strong>LinksMenu</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodLinksMenu">LinksMenu::LinksMenu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Constructor</dd>
							<dt><strong>LinksMenuElement</strong></dt>
				<dd>in file links_menu_element.class.php, class <a href="menu/linksmenu/LinksMenuElement.php">LinksMenuElement</a><br>&nbsp;&nbsp;&nbsp;&nbsp;A LinksMenuElement contains a Title, an url, and an image url</dd>
							<dt><strong>LinksMenuElement</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodLinksMenuElement">LinksMenuElement::LinksMenuElement()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a LinksMenuElement object</dd>
							<dt><strong>LinksMenuLink</strong></dt>
				<dd>in file links_menu_link.class.php, class <a href="menu/linksmenu/LinksMenuLink.php">LinksMenuLink</a><br>&nbsp;&nbsp;&nbsp;&nbsp;A Simple menu link</dd>
							<dt><strong>LinksMenuLink</strong></dt>
				<dd>in file links_menu_link.class.php, method <a href="menu/linksmenu/LinksMenuLink.php#methodLinksMenuLink">LinksMenuLink::LinksMenuLink()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Constructor</dd>
							<dt><strong>LINKS_MENU_ELEMENT__CLASS</strong></dt>
				<dd>in file links_menu_element.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php#defineLINKS_MENU_ELEMENT__CLASS">LINKS_MENU_ELEMENT__CLASS</a></dd>
							<dt><strong>LINKS_MENU_ELEMENT__CLASSIC_DISPLAYING</strong></dt>
				<dd>in file links_menu_element.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php#defineLINKS_MENU_ELEMENT__CLASSIC_DISPLAYING">LINKS_MENU_ELEMENT__CLASSIC_DISPLAYING</a></dd>
							<dt><strong>LINKS_MENU_ELEMENT__FULL_DISPLAYING</strong></dt>
				<dd>in file links_menu_element.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php#defineLINKS_MENU_ELEMENT__FULL_DISPLAYING">LINKS_MENU_ELEMENT__FULL_DISPLAYING</a></dd>
							<dt><strong>LINKS_MENU_LINK__CLASS</strong></dt>
				<dd>in file links_menu_link.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu_link.class.php.php#defineLINKS_MENU_LINK__CLASS">LINKS_MENU_LINK__CLASS</a></dd>
							<dt><strong>LINKS_MENU__CLASS</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineLINKS_MENU__CLASS">LINKS_MENU__CLASS</a></dd>
							<dt><strong>links_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/linksmenu/_menu---links---links_menu.class.php.php">links_menu.class.php</a></dd>
							<dt><strong>links_menu_element.class.php</strong></dt>
				<dd>procedural page <a href="menu/linksmenu/_menu---links---links_menu_element.class.php.php">links_menu_element.class.php</a></dd>
							<dt><strong>links_menu_link.class.php</strong></dt>
				<dd>procedural page <a href="menu/linksmenu/_menu---links---links_menu_link.class.php.php">links_menu_link.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>Menu</strong></dt>
				<dd>in file menu.class.php, class <a href="menu/Menu.php">Menu</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a menu element and is used to build any kind of menu</dd>
							<dt><strong>Menu</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodMenu">Menu::Menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a Menu element.</dd>
							<dt><strong>menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/_menu---menu.class.php.php">menu.class.php</a></dd>
							<dt><strong>MENU_AUTH_BIT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_AUTH_BIT">MENU_AUTH_BIT</a></dd>
							<dt><strong>MENU_ENABLED</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_ENABLED">MENU_ENABLED</a></dd>
							<dt><strong>MENU_ENABLE_OR_NOT</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_ENABLE_OR_NOT">MENU_ENABLE_OR_NOT</a></dd>
							<dt><strong>MENU_NOT_ENABLED</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU_NOT_ENABLED">MENU_NOT_ENABLED</a></dd>
							<dt><strong>MENU__CLASS</strong></dt>
				<dd>in file menu.class.php, constant <a href="menu/_menu---menu.class.php.php#defineMENU__CLASS">MENU__CLASS</a></dd>
							<dt><strong>$module_id</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$module_id">FeedMenu::$module_id</a></dd>
							<dt><strong>mini_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/minimenu/_menu---mini---mini_menu.class.php.php">mini_menu.class.php</a></dd>
							<dt><strong>MiniMenu</strong></dt>
				<dd>in file mini_menu.class.php, class <a href="menu/minimenu/MiniMenu.php">MiniMenu</a></dd>
							<dt><strong>MiniMenu</strong></dt>
				<dd>in file mini_menu.class.php, method <a href="menu/minimenu/MiniMenu.php#methodMiniMenu">MiniMenu::MiniMenu()</a></dd>
							<dt><strong>MINI_MENU__CLASS</strong></dt>
				<dd>in file mini_menu.class.php, constant <a href="menu/minimenu/_menu---mini---mini_menu.class.php.php#defineMINI_MENU__CLASS">MINI_MENU__CLASS</a></dd>
							<dt><strong>module_mini_menu.class.php</strong></dt>
				<dd>procedural page <a href="menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php">module_mini_menu.class.php</a></dd>
							<dt><strong>ModuleMiniMenu</strong></dt>
				<dd>in file module_mini_menu.class.php, class <a href="menu/modulesminimenu/ModuleMiniMenu.php">ModuleMiniMenu</a></dd>
							<dt><strong>ModuleMiniMenu</strong></dt>
				<dd>in file module_mini_menu.class.php, method <a href="menu/modulesminimenu/ModuleMiniMenu.php#methodModuleMiniMenu">ModuleMiniMenu::ModuleMiniMenu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a ModuleMiniMenu element.</dd>
							<dt><strong>MODULE_MINI_MENU__CLASS</strong></dt>
				<dd>in file module_mini_menu.class.php, constant <a href="menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php#defineMODULE_MINI_MENU__CLASS">MODULE_MINI_MENU__CLASS</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>$name</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$name">FeedMenu::$name</a></dd>
							<dt><strong>$number</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$number">FeedMenu::$number</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>$position</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$position">Menu::$position</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>set_auth</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_auth">Menu::set_auth()</a></dd>
							<dt><strong>set_block</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_block">Menu::set_block()</a></dd>
							<dt><strong>set_block_position</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_block_position">Menu::set_block_position()</a></dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file menu.class.php, method <a href="menu/Menu.php#methodset_title">Menu::set_title()</a></dd>
							<dt><strong>set_content</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodset_content">ContentMenu::set_content()</a></dd>
							<dt><strong>set_display_title</strong></dt>
				<dd>in file content_menu.class.php, method <a href="menu/contentmenu/ContentMenu.php#methodset_display_title">ContentMenu::set_display_title()</a></dd>
							<dt><strong>set_cat</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodset_cat">FeedMenu::set_cat()</a></dd>
							<dt><strong>set_module_id</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodset_module_id">FeedMenu::set_module_id()</a></dd>
							<dt><strong>set_name</strong></dt>
				<dd>in file feed_menu.class.php, method <a href="menu/feedmenu/FeedMenu.php#methodset_name">FeedMenu::set_name()</a></dd>
							<dt><strong>set_image</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodset_image">LinksMenuElement::set_image()</a></dd>
							<dt><strong>set_type</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodset_type">LinksMenu::set_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the type of the menu</dd>
							<dt><strong>set_url</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodset_url">LinksMenuElement::set_url()</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$title</strong></dt>
				<dd>in file menu.class.php, variable <a href="menu/Menu.php#var$title">Menu::$title</a></dd>
							<dt><strong>$type</strong></dt>
				<dd>in file links_menu.class.php, variable <a href="menu/linksmenu/LinksMenu.php#var$type">LinksMenu::$type</a></dd>
							<dt><strong>TREE_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineTREE_MENU">TREE_MENU</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>$url</strong></dt>
				<dd>in file feed_menu.class.php, variable <a href="menu/feedmenu/FeedMenu.php#var$url">FeedMenu::$url</a></dd>
							<dt><strong>$uid</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$uid">LinksMenuElement::$uid</a></dd>
							<dt><strong>$url</strong></dt>
				<dd>in file links_menu_element.class.php, variable <a href="menu/linksmenu/LinksMenuElement.php#var$url">LinksMenuElement::$url</a></dd>
							<dt><strong>update_uid</strong></dt>
				<dd>in file links_menu_element.class.php, method <a href="menu/linksmenu/LinksMenuElement.php#methodupdate_uid">LinksMenuElement::update_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the menu uid</dd>
							<dt><strong>update_uid</strong></dt>
				<dd>in file links_menu.class.php, method <a href="menu/linksmenu/LinksMenu.php#methodupdate_uid">LinksMenu::update_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the menu uid</dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
  <hr />
	<a name="v"></a>
	<div>
		<h2>v</h2>
		<dl>
							<dt><strong>VERTICAL_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineVERTICAL_MENU">VERTICAL_MENU</a></dd>
							<dt><strong>VERTICAL_SCROLLING_MENU</strong></dt>
				<dd>in file links_menu.class.php, constant <a href="menu/linksmenu/_menu---links---links_menu.class.php.php#defineVERTICAL_SCROLLING_MENU">VERTICAL_SCROLLING_MENU</a></dd>
					</dl>
	</div>
	<a href="elementindex_menu.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                
                                                                                                                                                                                    <a href="classtrees_menu.php" class="menu">class tree: menu</a> -
            <a href="elementindex_menu.php" class="menu">index: menu</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:26 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>