<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'events - Package events Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('events', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">events</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                
                                                                                                                                                                                                                                <a href="classtrees_events.php" class="menu">class tree: events</a> - 
                <a href="elementindex_events.php" class="menu">index: events</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="events/AdministratorAlert.php">AdministratorAlert</a>            </li>
                    <li>
                <a href="events/AdministratorAlertService.php">AdministratorAlertService</a>            </li>
                    <li>
                <a href="events/Contribution.php">Contribution</a>            </li>
                    <li>
                <a href="events/ContributionService.php">ContributionService</a>            </li>
                    <li>
                <a href="events/Event.php">Event</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="events/_events---administrator_alert.class.php.php">                administrator_alert.class.php
                </a>            </li>
                    <li>
                <a href="events/_events---administrator_alert_service.class.php.php">                administrator_alert_service.class.php
                </a>            </li>
                    <li>
                <a href="events/_events---contribution.class.php.php">                contribution.class.php
                </a>            </li>
                    <li>
                <a href="events/_events---contribution_service.class.php.php">                contribution_service.class.php
                </a>            </li>
                    <li>
                <a href="events/_events---event.class.php.php">                event.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package events</h1>
	[ <a href="elementindex_events.php#a">a</a> ]
	[ <a href="elementindex_events.php#b">b</a> ]
	[ <a href="elementindex_events.php#c">c</a> ]
	[ <a href="elementindex_events.php#d">d</a> ]
	[ <a href="elementindex_events.php#e">e</a> ]
	[ <a href="elementindex_events.php#f">f</a> ]
	[ <a href="elementindex_events.php#g">g</a> ]
	[ <a href="elementindex_events.php#i">i</a> ]
	[ <a href="elementindex_events.php#m">m</a> ]
	[ <a href="elementindex_events.php#p">p</a> ]
	[ <a href="elementindex_events.php#s">s</a> ]
	[ <a href="elementindex_events.php#t">t</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>$auth</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$auth">Contribution::$auth</a></dd>
							<dt><strong>AdministratorAlert</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodAdministratorAlert">AdministratorAlert::AdministratorAlert()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an AdministratorAlert object.</dd>
							<dt><strong>AdministratorAlert</strong></dt>
				<dd>in file administrator_alert.class.php, class <a href="events/AdministratorAlert.php">AdministratorAlert</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents an alert which must be sent to the administrator. It allows to the module developers to handle the administrator alerts. The administrator alerts can be in the administration panel and can be used when you want to signal an important event to the administrator(s).</dd>
							<dt><strong>AdministratorAlertService</strong></dt>
				<dd>in file administrator_alert_service.class.php, class <a href="events/AdministratorAlertService.php">AdministratorAlertService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This static class allows you to handler easily the administrator alerts which can be made in PHPBoost.</dd>
							<dt><strong>ADMINISTRATOR_ALERT_TYPE</strong></dt>
				<dd>in file administrator_alert_service.class.php, constant <a href="events/_events---administrator_alert_service.class.php.php#defineADMINISTRATOR_ALERT_TYPE">ADMINISTRATOR_ALERT_TYPE</a></dd>
							<dt><strong>ADMIN_ALERT_HIGH_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_HIGH_PRIORITY">ADMIN_ALERT_HIGH_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_LOW_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_LOW_PRIORITY">ADMIN_ALERT_LOW_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_MEDIUM_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_MEDIUM_PRIORITY">ADMIN_ALERT_MEDIUM_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_STATUS_PROCESSED</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_STATUS_PROCESSED">ADMIN_ALERT_STATUS_PROCESSED</a></dd>
							<dt><strong>ADMIN_ALERT_STATUS_UNREAD</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_STATUS_UNREAD">ADMIN_ALERT_STATUS_UNREAD</a></dd>
							<dt><strong>ADMIN_ALERT_VERY_HIGH_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_VERY_HIGH_PRIORITY">ADMIN_ALERT_VERY_HIGH_PRIORITY</a></dd>
							<dt><strong>ADMIN_ALERT_VERY_LOW_PRIORITY</strong></dt>
				<dd>in file administrator_alert.class.php, constant <a href="events/_events---administrator_alert.class.php.php#defineADMIN_ALERT_VERY_LOW_PRIORITY">ADMIN_ALERT_VERY_LOW_PRIORITY</a></dd>
							<dt><strong>administrator_alert.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---administrator_alert.class.php.php">administrator_alert.class.php</a></dd>
							<dt><strong>administrator_alert_service.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---administrator_alert_service.class.php.php">administrator_alert_service.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>build</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodbuild">Event::build()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an event object from its whole parameters.</dd>
							<dt><strong>build</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodbuild">Contribution::build()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a contribution object from its whole parameters.</dd>
							<dt><strong>build</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodbuild">AdministratorAlert::build()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an alert from its whole parameters.</dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>$creation_date</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$creation_date">Event::$creation_date</a></dd>
							<dt><strong>$current_status</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$current_status">Event::$current_status</a></dd>
							<dt><strong>compute_number_contrib_for_each_profile</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodcompute_number_contrib_for_each_profile">ContributionService::compute_number_contrib_for_each_profile()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the number of contributions available for each profile. It will count the contributions for the administrator, the moderators, the members, for each group and for each member who can have some special authorizations.</dd>
							<dt><strong>compute_number_unread_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodcompute_number_unread_alerts">AdministratorAlertService::compute_number_unread_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Counts the number of unread alerts.</dd>
							<dt><strong>Contribution</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodContribution">Contribution::Contribution()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Contribution object.</dd>
							<dt><strong>Contribution</strong></dt>
				<dd>in file contribution.class.php, class <a href="events/Contribution.php">Contribution</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a contribution made by a user to complete the content of the website. All the contributions are managed in the contribution panel.</dd>
							<dt><strong>ContributionService</strong></dt>
				<dd>in file contribution_service.class.php, class <a href="events/ContributionService.php">ContributionService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This service allows developers to manage their contributions.</dd>
							<dt><strong>CONTRIBUTION_AUTH_BIT</strong></dt>
				<dd>in file contribution.class.php, constant <a href="events/_events---contribution.class.php.php#defineCONTRIBUTION_AUTH_BIT">CONTRIBUTION_AUTH_BIT</a></dd>
							<dt><strong>CONTRIBUTION_TYPE</strong></dt>
				<dd>in file contribution_service.class.php, constant <a href="events/_events---contribution_service.class.php.php#defineCONTRIBUTION_TYPE">CONTRIBUTION_TYPE</a></dd>
							<dt><strong>contribution.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---contribution.class.php.php">contribution.class.php</a></dd>
							<dt><strong>contribution_service.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---contribution_service.class.php.php">contribution_service.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>$description</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$description">Contribution::$description</a></dd>
							<dt><strong>delete_alert</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methoddelete_alert">AdministratorAlertService::delete_alert()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes an alert from the database.</dd>
							<dt><strong>delete_contribution</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methoddelete_contribution">ContributionService::delete_contribution()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a contribution in the database.</dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>$entitled</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$entitled">Event::$entitled</a></dd>
							<dt><strong>Event</strong></dt>
				<dd>in file event.class.php, class <a href="events/Event.php">Event</a><br>&nbsp;&nbsp;&nbsp;&nbsp;It's the common part between two types of event existing now in PHPBoost: <ul><li>User contribution managed into the contribution panel</li><li>Administrator alert, triggered for example when a new update is available or when a new member account is to approbate</li></ul></dd>
							<dt><strong>Event</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodEvent">Event::Event()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an Event object.</dd>
							<dt><strong>event.class.php</strong></dt>
				<dd>procedural page <a href="events/_events---event.class.php.php">event.class.php</a></dd>
							<dt><strong>EVENT_STATUS_BEING_PROCESSED</strong></dt>
				<dd>in file event.class.php, constant <a href="events/_events---event.class.php.php#defineEVENT_STATUS_BEING_PROCESSED">EVENT_STATUS_BEING_PROCESSED</a></dd>
							<dt><strong>EVENT_STATUS_PROCESSED</strong></dt>
				<dd>in file event.class.php, constant <a href="events/_events---event.class.php.php#defineEVENT_STATUS_PROCESSED">EVENT_STATUS_PROCESSED</a></dd>
							<dt><strong>EVENT_STATUS_UNREAD</strong></dt>
				<dd>in file event.class.php, constant <a href="events/_events---event.class.php.php#defineEVENT_STATUS_UNREAD">EVENT_STATUS_UNREAD</a></dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$fixer_id</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$fixer_id">Contribution::$fixer_id</a></dd>
							<dt><strong>$fixer_login</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$fixer_login">Contribution::$fixer_login</a></dd>
							<dt><strong>$fixing_date</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$fixing_date">Contribution::$fixing_date</a></dd>
							<dt><strong>$fixing_url</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$fixing_url">Event::$fixing_url</a></dd>
							<dt><strong>find_by_criteria</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodfind_by_criteria">ContributionService::find_by_criteria()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a list of the contributions matching the required criteria(s). All the parameters represent the criterias you can use. If you don't want to use a criteria, let the null value. The returned contribution match all the criterias (it's a AND condition).</dd>
							<dt><strong>find_by_criteria</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodfind_by_criteria">AdministratorAlertService::find_by_criteria()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a list of alerts matching the required criteria(s). You can specify many criterias. When you use several of them, it's a AND condition. It will only return the alert which match all the criterias.</dd>
							<dt><strong>find_by_id</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodfind_by_id">ContributionService::find_by_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Finds a contribution with its identifier.</dd>
							<dt><strong>find_by_id</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodfind_by_id">AdministratorAlertService::find_by_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds an alert knowing its id.</dd>
							<dt><strong>find_by_identifier</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodfind_by_identifier">AdministratorAlertService::find_by_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Finds an alert knowing its identifier and maybe its type.</dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>generate_cache</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodgenerate_cache">ContributionService::generate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the contribution cache file.</dd>
							<dt><strong>get_all_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodget_all_alerts">AdministratorAlertService::get_all_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lists all the alerts of the site. You can order them. You can also choose how much alerts you want.</dd>
							<dt><strong>get_all_contributions</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodget_all_contributions">ContributionService::get_all_contributions()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets all the contributions of the table. You can sort the list.</dd>
							<dt><strong>get_auth</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_auth">Contribution::get_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the authorization of treatment of this contribution.</dd>
							<dt><strong>get_creation_date</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_creation_date">Event::get_creation_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the creation date of the event.</dd>
							<dt><strong>get_description</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_description">Contribution::get_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the description of the contribution.</dd>
							<dt><strong>get_entitled</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_entitled">Event::get_entitled()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the entitled of the event.</dd>
							<dt><strong>get_fixer_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_fixer_id">Contribution::get_fixer_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the identifier of the fixer.</dd>
							<dt><strong>get_fixer_login</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_fixer_login">Contribution::get_fixer_login()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the fixer login.</dd>
							<dt><strong>get_fixing_date</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_fixing_date">Contribution::get_fixing_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the contribution fixing date.</dd>
							<dt><strong>get_fixing_url</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_fixing_url">Event::get_fixing_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the URL corresponding to the alert.</dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_id">Event::get_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the id of the event (in the event data base).</dd>
							<dt><strong>get_identifier</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_identifier">Event::get_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the identifier of the event. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events.</dd>
							<dt><strong>get_id_in_module</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_id_in_module">Event::get_id_in_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the id in the module. This value corresponds to the id of the daba base entry associated to the event.</dd>
							<dt><strong>get_module</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_module">Contribution::get_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the module in which the contribution is used.</dd>
							<dt><strong>get_module_name</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_module_name">Contribution::get_module_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the name of the module in which the contribution is used.</dd>
							<dt><strong>get_must_regenerate_cache</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_must_regenerate_cache">Event::get_must_regenerate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the value indicating if the cache must be generated.</dd>
							<dt><strong>get_number_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodget_number_alerts">AdministratorAlertService::get_number_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of alerts.</dd>
							<dt><strong>get_number_unread_alerts</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodget_number_unread_alerts">AdministratorAlertService::get_number_unread_alerts()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the number of unread alerts.</dd>
							<dt><strong>get_poster_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_poster_id">Contribution::get_poster_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the identifier of the poster.</dd>
							<dt><strong>get_poster_login</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_poster_login">Contribution::get_poster_login()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the poster login.</dd>
							<dt><strong>get_priority</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodget_priority">AdministratorAlert::get_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the priority of the alert.</dd>
							<dt><strong>get_priority_name</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodget_priority_name">AdministratorAlert::get_priority_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the priority name. It's automatically translater to the user language, ready to be displayed.</dd>
							<dt><strong>get_properties</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodget_properties">AdministratorAlert::get_properties()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the alert properties.</dd>
							<dt><strong>get_status</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_status">Event::get_status()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the status of the event. The status is one of those elements: ul&gt;     &lt;li&gt;EVENT_STATUS_UNREAD if it's not read.&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_BEING_PROCESSED if the event is beeing processed&lt;/li&gt;     &lt;li&gt;EVENT_STATUS_PROCESSED if the event is processed. &lt;/ul&gt;</dd>
							<dt><strong>get_status_name</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodget_status_name">Contribution::get_status_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the contribution status name. It's automatically translated in the user language, ready to be displayed.</dd>
							<dt><strong>get_status_name</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_status_name">Event::get_status_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the event status name. It's automatically translated in the user language.</dd>
							<dt><strong>get_type</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodget_type">Event::get_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$id</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$id">Event::$id</a></dd>
							<dt><strong>$identifier</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$identifier">Event::$identifier</a></dd>
							<dt><strong>$id_in_module</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$id_in_module">Event::$id_in_module</a></dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>$module</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$module">Contribution::$module</a></dd>
							<dt><strong>$must_regenerate_cache</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$must_regenerate_cache">Event::$must_regenerate_cache</a></dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>$poster_id</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$poster_id">Contribution::$poster_id</a></dd>
							<dt><strong>$poster_login</strong></dt>
				<dd>in file contribution.class.php, variable <a href="events/Contribution.php#var$poster_login">Contribution::$poster_login</a></dd>
							<dt><strong>$priority</strong></dt>
				<dd>in file administrator_alert.class.php, variable <a href="events/AdministratorAlert.php#var$priority">AdministratorAlert::$priority</a></dd>
							<dt><strong>$properties</strong></dt>
				<dd>in file administrator_alert.class.php, variable <a href="events/AdministratorAlert.php#var$properties">AdministratorAlert::$properties</a></dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>save_alert</strong></dt>
				<dd>in file administrator_alert_service.class.php, method <a href="events/AdministratorAlertService.php#methodsave_alert">AdministratorAlertService::save_alert()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create or updates an alert in the database. It creates it whether it doesn't exist or updates it if it already exists.</dd>
							<dt><strong>save_contribution</strong></dt>
				<dd>in file contribution_service.class.php, method <a href="events/ContributionService.php#methodsave_contribution">ContributionService::save_contribution()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create or update a contribution in the database.</dd>
							<dt><strong>set_auth</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_auth">Contribution::set_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the authorization of the contribution. It will determine who will be able to treat the contribution.</dd>
							<dt><strong>set_creation_date</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_creation_date">Event::set_creation_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the creation date of the event.</dd>
							<dt><strong>set_description</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_description">Contribution::set_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the description of the contribution.</dd>
							<dt><strong>set_entitled</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_entitled">Event::set_entitled()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the entitled of the event. The entitled can be considered as the name, it must be explicit.</dd>
							<dt><strong>set_fixer_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_fixer_id">Contribution::set_fixer_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id of the fixer.</dd>
							<dt><strong>set_fixing_date</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_fixing_date">Contribution::set_fixing_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the fixing date.</dd>
							<dt><strong>set_fixing_url</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_fixing_url">Event::set_fixing_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the URL corresponding to the event. For the contributions and the administrator alerts it's the number URL at which the problem can be solved.</dd>
							<dt><strong>set_id</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_id">Event::set_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id of the event. The id is the corresponding data base entry one.</dd>
							<dt><strong>set_identifier</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_identifier">Event::set_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the event identifier. To retrieve your event, you might need to have a field in which you put some informations, for example a hash or an identifier. It's that identifier which can be used to filter the events. You don't have to use it, you can let it blank.</dd>
							<dt><strong>set_id_in_module</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_id_in_module">Event::set_id_in_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id in module parameter. It corresponds to the id of the element corresponding to the event in your data base tables. For example, il you use the events to allow user to purpose some news in your web site, it will be the id of the news added.</dd>
							<dt><strong>set_module</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_module">Contribution::set_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the module in which the contribution is used.</dd>
							<dt><strong>set_must_regenerate_cache</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_must_regenerate_cache">Event::set_must_regenerate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets a private property indicating if the changes made on this event imply the regeneration of the events cache.</dd>
							<dt><strong>set_poster_id</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_poster_id">Contribution::set_poster_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the id of the poster.</dd>
							<dt><strong>set_priority</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodset_priority">AdministratorAlert::set_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the priority of the alert.</dd>
							<dt><strong>set_properties</strong></dt>
				<dd>in file administrator_alert.class.php, method <a href="events/AdministratorAlert.php#methodset_properties">AdministratorAlert::set_properties()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the properties of the alert.</dd>
							<dt><strong>set_status</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_status">Event::set_status()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the status of the event.</dd>
							<dt><strong>set_status</strong></dt>
				<dd>in file contribution.class.php, method <a href="events/Contribution.php#methodset_status">Contribution::set_status()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the status of the contribution.</dd>
							<dt><strong>set_type</strong></dt>
				<dd>in file event.class.php, method <a href="events/Event.php#methodset_type">Event::set_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the type of the event. To retrieve your event, you might need to have a type of event, for example if your module has differents kinds of events. With this field, you can specify it.</dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$type</strong></dt>
				<dd>in file event.class.php, variable <a href="events/Event.php#var$type">Event::$type</a></dd>
					</dl>
	</div>
	<a href="elementindex_events.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                    
                                                                                                                                                                <a href="classtrees_events.php" class="menu">class tree: events</a> -
            <a href="elementindex_events.php" class="menu">index: events</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:39 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>