<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Package content Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                            
                                                                                    <a href="classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="elementindex_content.php" class="menu">index: content</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="content/Note.php">Note</a>            </li>
                    <li>
                <a href="content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package content</h1>
	[ <a href="elementindex_content.php#a">a</a> ]
	[ <a href="elementindex_content.php#b">b</a> ]
	[ <a href="elementindex_content.php#c">c</a> ]
	[ <a href="elementindex_content.php#d">d</a> ]
	[ <a href="elementindex_content.php#e">e</a> ]
	[ <a href="elementindex_content.php#f">f</a> ]
	[ <a href="elementindex_content.php#g">g</a> ]
	[ <a href="elementindex_content.php#h">h</a> ]
	[ <a href="elementindex_content.php#i">i</a> ]
	[ <a href="elementindex_content.php#k">k</a> ]
	[ <a href="elementindex_content.php#l">l</a> ]
	[ <a href="elementindex_content.php#m">m</a> ]
	[ <a href="elementindex_content.php#n">n</a> ]
	[ <a href="elementindex_content.php#o">o</a> ]
	[ <a href="elementindex_content.php#p">p</a> ]
	[ <a href="elementindex_content.php#r">r</a> ]
	[ <a href="elementindex_content.php#s">s</a> ]
	[ <a href="elementindex_content.php#t">t</a> ]
	[ <a href="elementindex_content.php#u">u</a> ]
	[ <a href="elementindex_content.php#v">v</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>add</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methodadd">Note::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a note on the item. It has to be into the notation scale.</dd>
							<dt><strong>add</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodadd">Comments::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add a comment</dd>
							<dt><strong>add</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodadd">CategoriesManager::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a category. We can decide if it will be visible and what its position will be</dd>
							<dt><strong>ADD_THIS_CATEGORY_IN_LIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineADD_THIS_CATEGORY_IN_LIST">ADD_THIS_CATEGORY_IN_LIST</a></dd>
							<dt><strong>AJAX_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineAJAX_MODE">AJAX_MODE</a></dd>
							<dt><strong>$array_tags</strong></dt>
				<dd>in file tinymce_editor.class.php, variable <a href="content/editor/TinyMCEEditor.php#var$array_tags">TinyMCEEditor::$array_tags</a></dd>
							<dt><strong>$array_tags2</strong></dt>
				<dd>in file tinymce_editor.class.php, variable <a href="content/editor/TinyMCEEditor.php#var$array_tags2">TinyMCEEditor::$array_tags2</a></dd>
							<dt><strong>$array_tags3</strong></dt>
				<dd>in file tinymce_editor.class.php, variable <a href="content/editor/TinyMCEEditor.php#var$array_tags3">TinyMCEEditor::$array_tags3</a></dd>
							<dt><strong>$array_tags</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$array_tags">Parser::$array_tags</a></dd>
							<dt><strong>ADD_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#defineADD_SLASHES">ADD_SLASHES</a></dd>
							<dt><strong>add</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodadd">SiteMapSection::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds an elemement to the section</dd>
							<dt><strong>add</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodadd">SiteMap::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds an element to the elements list of the SiteMap</dd>
							<dt><strong>$auth</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$auth">FeedItem::$auth</a></dd>
							<dt><strong>$auth_bit</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$auth_bit">FeedData::$auth_bit</a></dd>
							<dt><strong>add_child</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodadd_child">FeedsCat::add_child()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a FeedsCat child to the current FeedsCat object</dd>
							<dt><strong>add_feed</strong></dt>
				<dd>in file feeds_list.class.php, method <a href="content/syndication/FeedsList.php#methodadd_feed">FeedsList::add_feed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds the FeedsCat $cat_tree to the current feeds list</dd>
							<dt><strong>add_item</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodadd_item">FeedData::add_item()</a></dd>
							<dt><strong>ATOM</strong></dt>
				<dd>in file atom.class.php, class <a href="content/syndication/ATOM.php">ATOM</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class could load a feed by its url or by a FeedData element and export it to the ATOM format</dd>
							<dt><strong>ATOM</strong></dt>
				<dd>in file atom.class.php, method <a href="content/syndication/ATOM.php#methodATOM">ATOM::ATOM()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new ATOM object</dd>
							<dt><strong>atom.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---atom.class.php.php">atom.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>build_administration_interface</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_administration_interface">CategoriesManager::build_administration_interface()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the list of categories and links to makes operations to administrate them (delete, move, add...), it supplies a string ready to be displayed. It uses AJAX, read the class description to understand this user interface.</dd>
							<dt><strong>build_children_id_list</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_children_id_list">CategoriesManager::build_children_id_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the list of all the children of a category</dd>
							<dt><strong>build_parents_id_list</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_parents_id_list">CategoriesManager::build_parents_id_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds the list of the parent categories of a category</dd>
							<dt><strong>build_select_form</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodbuild_select_form">CategoriesManager::build_select_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a formulary which allows user to choose a category in a select form.</dd>
							<dt><strong>BBCodeEditor</strong></dt>
				<dd>in file bbcode_editor.class.php, method <a href="content/editor/BBCodeEditor.php#methodBBCodeEditor">BBCodeEditor::BBCodeEditor()</a></dd>
							<dt><strong>BBCodeEditor</strong></dt>
				<dd>in file bbcode_editor.class.php, class <a href="content/editor/BBCodeEditor.php">BBCodeEditor</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides an interface editor for contents.</dd>
							<dt><strong>bbcode_editor.class.php</strong></dt>
				<dd>procedural page <a href="content/editor/_content---editor---bbcode_editor.class.php.php">bbcode_editor.class.php</a></dd>
							<dt><strong>BBCodeHighlighter</strong></dt>
				<dd>in file bbcode_highlighter.class.php, method <a href="content/parser/BBCodeHighlighter.php#methodBBCodeHighlighter">BBCodeHighlighter::BBCodeHighlighter()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BBCodeHighlighter objet</dd>
							<dt><strong>BBCodeHighlighter</strong></dt>
				<dd>in file bbcode_highlighter.class.php, class <a href="content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is a highlighter for the PHPBoost BBCode language. It supplies the highlighted code written in XHTML.</dd>
							<dt><strong>BBCodeParser</strong></dt>
				<dd>in file bbcode_parser.class.php, class <a href="content/parser/BBCodeParser.php">BBCodeParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Converts the PHPBoost BBCode language to the XHTML language which is stocked in the database and can be displayed nearly directly. It parses only the authorized tags (defined in the parent class which is ContentParser).</dd>
							<dt><strong>BBCodeParser</strong></dt>
				<dd>in file bbcode_parser.class.php, method <a href="content/parser/BBCodeParser.php#methodBBCodeParser">BBCodeParser::BBCodeParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BBCodeParser object</dd>
							<dt><strong>BBCodeUnparser</strong></dt>
				<dd>in file bbcode_unparser.class.php, method <a href="content/parser/BBCodeUnparser.php#methodBBCodeUnparser">BBCodeUnparser::BBCodeUnparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BBCodeUnparser object</dd>
							<dt><strong>BBCodeUnparser</strong></dt>
				<dd>in file bbcode_unparser.class.php, class <a href="content/parser/BBCodeUnparser.php">BBCodeUnparser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;BBCode unparser. It converts a content using the PHPBoost HTML reference code (for example coming from a database) to the PHPBoost BBCode syntax.</dd>
							<dt><strong>BBCODE_HIGHLIGHTER_BLOCK_CODE</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_HIGHLIGHTER_BLOCK_CODE">BBCODE_HIGHLIGHTER_BLOCK_CODE</a></dd>
							<dt><strong>BBCODE_HIGHLIGHTER_INLINE_CODE</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_HIGHLIGHTER_INLINE_CODE">BBCODE_HIGHLIGHTER_INLINE_CODE</a></dd>
							<dt><strong>BBCODE_LANGUAGE</strong></dt>
				<dd>in file content_formatting_factory.class.php, constant <a href="content/parser/_content---parser---content_formatting_factory.class.php.php#defineBBCODE_LANGUAGE">BBCODE_LANGUAGE</a></dd>
							<dt><strong>BBCODE_LIST_ITEM_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_LIST_ITEM_COLOR">BBCODE_LIST_ITEM_COLOR</a></dd>
							<dt><strong>BBCODE_PARAM_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_PARAM_COLOR">BBCODE_PARAM_COLOR</a></dd>
							<dt><strong>BBCODE_PARAM_NAME_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_PARAM_NAME_COLOR">BBCODE_PARAM_NAME_COLOR</a></dd>
							<dt><strong>BBCODE_TAG_COLOR</strong></dt>
				<dd>in file bbcode_highlighter.class.php, constant <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php#defineBBCODE_TAG_COLOR">BBCODE_TAG_COLOR</a></dd>
							<dt><strong>bbcode_highlighter.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---bbcode_highlighter.class.php.php">bbcode_highlighter.class.php</a></dd>
							<dt><strong>bbcode_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---bbcode_parser.class.php.php">bbcode_parser.class.php</a></dd>
							<dt><strong>bbcode_unparser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---bbcode_unparser.class.php.php">bbcode_unparser.class.php</a></dd>
							<dt><strong>build_kernel_map</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodbuild_kernel_map">SiteMap::build_kernel_map()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds to the site map all the kernel links.</dd>
							<dt><strong>build_modules_maps</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodbuild_modules_maps">SiteMap::build_modules_maps()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds to the site map all maps of the installed modules</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>$cache_file_name</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$cache_file_name">CategoriesManager::$cache_file_name</a></dd>
							<dt><strong>$cache_var</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$cache_var">CategoriesManager::$cache_var</a></dd>
							<dt><strong>CACHE_TIME</strong></dt>
				<dd>in file search.class.php, constant <a href="content/_content---search.class.php.php#defineCACHE_TIME">CACHE_TIME</a></dd>
							<dt><strong>CACHE_TIMES_USED</strong></dt>
				<dd>in file search.class.php, constant <a href="content/_content---search.class.php.php#defineCACHE_TIMES_USED">CACHE_TIMES_USED</a></dd>
							<dt><strong>CategoriesManager</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodCategoriesManager">CategoriesManager::CategoriesManager()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a CategoriesManager object</dd>
							<dt><strong>CategoriesManager</strong></dt>
				<dd>in file categories_manager.class.php, class <a href="content/CategoriesManager.php">CategoriesManager</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables you to manage easily the administration of categories for your modules. It's as generic as possible, if you want to complete some actions to specialize them for you module, you can create a new class inheritating of it in which you call its methods using the syntax parent::method(). <br /> /!\ Warning : /!\ <ul><li>Your DB table must respect some rules :
         <ul><li>You must have an integer attribute whose name is id and which represents the identifier of each category. It must be a primary key.</li><li>You also must have an integer attribute named id_parent which represents the identifier of the parent category (it will be 0 if its parent category is the root of the tree).</li><li>To maintain order, you must have a field containing the rank of the category which be an integer named c_order.</li><li>A field visible boolean (tynint 1 sur mysql)</li><li>A field name containing the category name</li></ul></li><li>In this class the user are supposed to be an administrator, no checking of his auth is done.</li><li>To be correctly displayed, you must supply to functions a variable extracted from a file cache. Use the Cache class to build your file cache. Your variable must be an array in which keys are categories identifiers, an values are still arrays which are as this :
      <ul><li>key id_parent containing the id_parent field of the database</li><li>key name containing the name of the category</li><li>key order</li><li>key visible which is a boolean</li></ul></li><li>You can also have other fields such as auth level, description, visible, that class won't modify them.</li><li>To display the list of categories and actions you can do on them, you may want to customize it. For that you must build an array that you will give to set_display_config() containing your choices :
      <ul><li>Key 'xmlhttprequest_file' which corresponds to the name of the file which will treat the AJAX requests. We usually call it xmlhttprequest.php.</li><li>Key 'url' which represents the url of the category (it won't display any link up to categories if you don't give this field). Its structure is the following :
              <ul><li>key 'unrewrited' =&gt; string containing unrewrited urls (let %d where you want to display the category identifier)</li><li>Key administration_file_name which represents the file which allows you to update category</li><li>rewrited url (optionnal) 'rewrited' =&gt; string containing rewrited urls (let %d where you want to display the category identifier and %s the category name if you need it)</li></ul></li></ul></li></ul>  If you need more informations to use this class, we advise you to look at the wiki of PHPBoost, in which there is a tutorial explaining how to use it step by step.</dd>
							<dt><strong>CATEGORY_DOES_NOT_EXIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineCATEGORY_DOES_NOT_EXIST">CATEGORY_DOES_NOT_EXIST</a></dd>
							<dt><strong>CAT_UNVISIBLE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineCAT_UNVISIBLE">CAT_UNVISIBLE</a></dd>
							<dt><strong>CAT_VISIBLE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineCAT_VISIBLE">CAT_VISIBLE</a></dd>
							<dt><strong>change_visibility</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodchange_visibility">CategoriesManager::change_visibility()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Changes the visibility of a category</dd>
							<dt><strong>check_display_config</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodcheck_display_config">CategoriesManager::check_display_config()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if display configuration is good</dd>
							<dt><strong>check_error</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodcheck_error">CategoriesManager::check_error()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if an error has been raised on the last reported error. At each call of a method of this class which can raise an error, the last error is erased.</dd>
							<dt><strong>Comments</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodComments">Comments::Comments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display comments form.</dd>
							<dt><strong>Comments</strong></dt>
				<dd>in file comments.class.php, class <a href="content/Comments.php">Comments</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class manages comments everywhere in phpboost Simplyfied use with the display_comments function: //news is the name of the modue, $idnews is the id in database for this item. display_comments('news', $idnews, url('news.php?id=' . $idnews . '&amp;amp;com=%s', 'news-0-' . $idnews . '.php?com=%s'))</dd>
							<dt><strong>compute_heritated_auth</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodcompute_heritated_auth">CategoriesManager::compute_heritated_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the global authorization level of the whole parent categories. The result corresponds to all the category's parents merged.</dd>
							<dt><strong>com_display_link</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodcom_display_link">Comments::com_display_link()</a></dd>
							<dt><strong>categories_manager.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---categories_manager.class.php.php">categories_manager.class.php</a></dd>
							<dt><strong>comments.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---comments.class.php.php">comments.class.php</a></dd>
							<dt><strong>ContentEditor</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodContentEditor">ContentEditor::ContentEditor()</a></dd>
							<dt><strong>ContentEditor</strong></dt>
				<dd>in file editor.class.php, class <a href="content/editor/ContentEditor.php">ContentEditor</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Abstract class for editors content.</dd>
							<dt><strong>$content</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$content">Parser::$content</a></dd>
							<dt><strong>clear_html_br</strong></dt>
				<dd>in file bbcode_parser.class.php, method <a href="content/parser/BBCodeParser.php#methodclear_html_br">BBCodeParser::clear_html_br()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Callback which clears the new line tag in the HTML generated code</dd>
							<dt><strong>content_formatting_factory.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_formatting_factory.class.php.php">content_formatting_factory.class.php</a></dd>
							<dt><strong>content_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_parser.class.php.php">content_parser.class.php</a></dd>
							<dt><strong>content_second_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_second_parser.class.php.php">content_second_parser.class.php</a></dd>
							<dt><strong>content_unparser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---content_unparser.class.php.php">content_unparser.class.php</a></dd>
							<dt><strong>ContentFormattingFactory</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodContentFormattingFactory">ContentFormattingFactory::ContentFormattingFactory()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ContentFormattingFactoryy object</dd>
							<dt><strong>ContentFormattingFactory</strong></dt>
				<dd>in file content_formatting_factory.class.php, class <a href="content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is approximatively a factory which provides objets capable to format some content. The text formatting uses a syntax, PHPBoost supports both the BBCode syntax and a WYSIWYG tool syntax (TinyMCE). You can choose the formatting type you want to deal with.</dd>
							<dt><strong>ContentParser</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodContentParser">ContentParser::ContentParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Buils a ContentParser object.</dd>
							<dt><strong>ContentParser</strong></dt>
				<dd>in file content_parser.class.php, class <a href="content/parser/ContentParser.php">ContentParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is abstract. It contains tools that are usefull for implement a content parser.</dd>
							<dt><strong>ContentSecondParser</strong></dt>
				<dd>in file content_second_parser.class.php, method <a href="content/parser/ContentSecondParser.php#methodContentSecondParser">ContentSecondParser::ContentSecondParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ContentSecondParser object</dd>
							<dt><strong>ContentSecondParser</strong></dt>
				<dd>in file content_second_parser.class.php, class <a href="content/parser/ContentSecondParser.php">ContentSecondParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class ensures the real time processing of the content. The major part of the processing is saved in the database to minimize as much as possible the treatment when the content is displayed. However, some tags cannot be cached, because we cannot have return to the original code. It's for instance the case of the code tag which replaces the code by a lot of html code which formats the code. This kind of tag is treated in real time by this class. The content you put in that parser must come from a ContentParser class (BBCodeParser or TinyMCEParser) (it can have been saved in a database between the first parsing and the real time parsing).</dd>
							<dt><strong>ContentUnparser</strong></dt>
				<dd>in file content_unparser.class.php, class <a href="content/parser/ContentUnparser.php">ContentUnparser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is an abstract class. It contains the common elements needed by all the unparsers of PHPBoost.</dd>
							<dt><strong>ContentUnparser</strong></dt>
				<dd>in file content_unparser.class.php, method <a href="content/parser/ContentUnparser.php#methodContentUnparser">ContentUnparser::ContentUnparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ContentUnparser class.</dd>
							<dt><strong>$change_freq</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$change_freq">SiteMapLink::$change_freq</a></dd>
							<dt><strong>$cat_name</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$cat_name">FeedsCat::$cat_name</a></dd>
							<dt><strong>$children</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$children">FeedsCat::$children</a></dd>
							<dt><strong>cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodcache">Feed::cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Send the feed data in the cache</dd>
							<dt><strong>clear_cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodclear_cache">Feed::clear_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Clear the cache of the specified module_id.</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>$display_config</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$display_config">CategoriesManager::$display_config</a></dd>
							<dt><strong>DEBUG_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDEBUG_MODE">DEBUG_MODE</a></dd>
							<dt><strong>del</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methoddel">Comments::del()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete a comment</dd>
							<dt><strong>delete</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methoddelete">CategoriesManager::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a category.</dd>
							<dt><strong>delete_all</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methoddelete_all">Comments::delete_all()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete all comments for the specified item.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methoddisplay">Comments::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display comments form.</dd>
							<dt><strong>DISPLAYING_CONFIGURATION_NOT_SET</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDISPLAYING_CONFIGURATION_NOT_SET">DISPLAYING_CONFIGURATION_NOT_SET</a></dd>
							<dt><strong>display_form</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methoddisplay_form">Note::display_form()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the ajax notation form.</dd>
							<dt><strong>display_img</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methoddisplay_img">Note::display_img()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Static method which display the notation with images, you can restrain the number of images displayed with the argument $num_stars_display</dd>
							<dt><strong>DO_NOT_ADD_THIS_CATEGORY_IN_LIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDO_NOT_ADD_THIS_CATEGORY_IN_LIST">DO_NOT_ADD_THIS_CATEGORY_IN_LIST</a></dd>
							<dt><strong>DO_NOT_LOAD_CACHE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineDO_NOT_LOAD_CACHE">DO_NOT_LOAD_CACHE</a></dd>
							<dt><strong>display</strong></dt>
				<dd>in file tinymce_editor.class.php, method <a href="content/editor/TinyMCEEditor.php#methoddisplay">TinyMCEEditor::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the editor</dd>
							<dt><strong>display</strong></dt>
				<dd>in file bbcode_editor.class.php, method <a href="content/editor/BBCodeEditor.php#methoddisplay">BBCodeEditor::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Display the editor</dd>
							<dt><strong>DEFAULT_LANGUAGE</strong></dt>
				<dd>in file content_formatting_factory.class.php, constant <a href="content/parser/_content---parser---content_formatting_factory.class.php.php#defineDEFAULT_LANGUAGE">DEFAULT_LANGUAGE</a></dd>
							<dt><strong>DO_NOT_ADD_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#defineDO_NOT_ADD_SLASHES">DO_NOT_ADD_SLASHES</a></dd>
							<dt><strong>$depth</strong></dt>
				<dd>in file site_map_element.class.php, variable <a href="content/sitemap/SiteMapElement.php#var$depth">SiteMapElement::$depth</a></dd>
							<dt><strong>$description</strong></dt>
				<dd>in file module_map.class.php, variable <a href="content/sitemap/ModuleMap.php#var$description">ModuleMap::$description</a></dd>
							<dt><strong>$data</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$data">Feed::$data</a></dd>
							<dt><strong>$date</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$date">FeedItem::$date</a></dd>
							<dt><strong>$date</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$date">FeedData::$date</a></dd>
							<dt><strong>$desc</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$desc">FeedItem::$desc</a></dd>
							<dt><strong>$desc</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$desc">FeedData::$desc</a></dd>
							<dt><strong>DEFAULT_ATOM_TEMPLATE</strong></dt>
				<dd>in file atom.class.php, constant <a href="content/syndication/_content---syndication---atom.class.php.php#defineDEFAULT_ATOM_TEMPLATE">DEFAULT_ATOM_TEMPLATE</a></dd>
							<dt><strong>DEFAULT_FEED_NAME</strong></dt>
				<dd>in file feed.class.php, constant <a href="content/syndication/_content---syndication---feed.class.php.php#defineDEFAULT_FEED_NAME">DEFAULT_FEED_NAME</a></dd>
							<dt><strong>DEFAULT_RSS_TEMPLATE</strong></dt>
				<dd>in file rss.class.php, constant <a href="content/syndication/_content---syndication---rss.class.php.php#defineDEFAULT_RSS_TEMPLATE">DEFAULT_RSS_TEMPLATE</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>$errors</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$errors">CategoriesManager::$errors</a></dd>
							<dt><strong>$errors</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$errors">Search::$errors</a></dd>
							<dt><strong>ERROR_CAT_IS_AT_BOTTOM</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineERROR_CAT_IS_AT_BOTTOM">ERROR_CAT_IS_AT_BOTTOM</a></dd>
							<dt><strong>ERROR_CAT_IS_AT_TOP</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineERROR_CAT_IS_AT_TOP">ERROR_CAT_IS_AT_TOP</a></dd>
							<dt><strong>ERROR_UNKNOWN_MOTION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineERROR_UNKNOWN_MOTION">ERROR_UNKNOWN_MOTION</a></dd>
							<dt><strong>editor.class.php</strong></dt>
				<dd>procedural page <a href="content/editor/_content---editor---editor.class.php.php">editor.class.php</a></dd>
							<dt><strong>export_html_text</strong></dt>
				<dd>in file content_second_parser.class.php, method <a href="content/parser/ContentSecondParser.php#methodexport_html_text">ContentSecondParser::export_html_text()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Transforms a PHPBoost HTML content to make it exportable and usable every where in the web.</dd>
							<dt><strong>$elements</strong></dt>
				<dd>in file site_map_section.class.php, variable <a href="content/sitemap/SiteMapSection.php#var$elements">SiteMapSection::$elements</a></dd>
							<dt><strong>$elements</strong></dt>
				<dd>in file site_map.class.php, variable <a href="content/sitemap/SiteMap.php#var$elements">SiteMap::$elements</a></dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodexport">SiteMapLink::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the section according to the given configuration. You will use the following template variables: <ul><li>LOC containing the URL of the link</li><li>TEXT containing the name of the target page</li><li>C_DISPLAY_DATE indicating if the date is not empty</li><li>DATE containing the date of the last modification of the target page, formatted for the sitemap.xml file</li><li>ACTUALIZATION_FREQUENCY corresponding to the code needed in the sitemap.xml file</li><li>PRIORITY corresponding to the code needed in the sitemap.xml file to indicate the priority of the target page.</li><li>C_LINK indicating that we are displaying a link (useful if you want to use a signe template export configuration)</li></ul></dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodexport">SiteMapSection::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the section according to the given configuration. You will use the following template variables: <ul><li>SECTION_NAME which contains the name of the section</li><li>SECTION_URL which contains the URL of the link associated to the section</li><li>DEPTH which contains the depth of the section in the site map tree (useful for CSS classes names)</li><li>LINK_CODE which contains the code got by the associated link export</li><li>C_SECTION, boolean meaning that it's a section (useful if you want to use a sigle template for the whole export configuration)</li><li>A loop &quot;element&quot; containing evert element of the section (their code is available in the CODE variable of the loop)</li></ul></dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodexport">SiteMapElement::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the element</dd>
							<dt><strong>export</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodexport">SiteMap::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports a SiteMap. You will be able to use the following variables into the templates used to export: <ul><li>C_SITE_MAP which is a condition indicating if it's a site map (useful if you want to use a sigle template
 for the whole export configuration)</li><li>SITE_NAME which contains the name of the site</li><li>A loop &quot;element&quot; in which the code of each element is in the variable CODE</li></ul></dd>
							<dt><strong>export</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodexport">ModuleMap::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the sitemap (according to a configuration of templates). In your template, you will be able to use the following variables: <ul><li>MODULE_NAME which contains the name of the module</li><li>MODULE_DESCRIPTION which contains the description of the module</li><li>MODULE_URL which contains the URL of the module root page</li><li>DEPTH which is the depth of the module map in the sitemap (generally 1).
  It might be usefull to apply different CSS styles to each level of depth.</li><li>LINK_CODE which contains the code of the link associated to the module root exported with the same configuration.</li><li>C_MODULE_MAP which is a boolean whose value is true, this will enable you to use a single template for the whole export configuration</li><li>The loop &quot;element&quot; for which the variable CODE contains the code of each sub element of the module (for example categories)</li></ul></dd>
							<dt><strong>ERROR_GETTING_CACHE</strong></dt>
				<dd>in file feed.class.php, constant <a href="content/syndication/_content---syndication---feed.class.php.php#defineERROR_GETTING_CACHE">ERROR_GETTING_CACHE</a></dd>
							<dt><strong>export</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodexport">Feed::export()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exports the feed as a string parsed by the &lt;$tpl&gt; template</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$forbidden_tags</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$forbidden_tags">ContentEditor::$forbidden_tags</a></dd>
							<dt><strong>$forbidden_tags</strong></dt>
				<dd>in file content_parser.class.php, variable <a href="content/parser/ContentParser.php#var$forbidden_tags">ContentParser::$forbidden_tags</a></dd>
							<dt><strong>feed.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feed.class.php.php">feed.class.php</a></dd>
							<dt><strong>feeds_cat.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feeds_cat.class.php.php">feeds_cat.class.php</a></dd>
							<dt><strong>feeds_list.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feeds_list.class.php.php">feeds_list.class.php</a></dd>
							<dt><strong>feed_data.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feed_data.class.php.php">feed_data.class.php</a></dd>
							<dt><strong>feed_item.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---feed_item.class.php.php">feed_item.class.php</a></dd>
							<dt><strong>Feed</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodFeed">Feed::Feed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new feed object</dd>
							<dt><strong>Feed</strong></dt>
				<dd>in file feed.class.php, class <a href="content/syndication/Feed.php">Feed</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class could be used to export feeds</dd>
							<dt><strong>FeedData</strong></dt>
				<dd>in file feed_data.class.php, class <a href="content/syndication/FeedData.php">FeedData</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Contains meta-informations about a feed with its entries</dd>
							<dt><strong>FeedData</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodFeedData">FeedData::FeedData()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FeedData Object</dd>
							<dt><strong>FeedItem</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodFeedItem">FeedItem::FeedItem()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FeedItem element</dd>
							<dt><strong>FeedItem</strong></dt>
				<dd>in file feed_item.class.php, class <a href="content/syndication/FeedItem.php">FeedItem</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Contains meta-informations and informations about a feed entry / item</dd>
							<dt><strong>FeedsCat</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodFeedsCat">FeedsCat::FeedsCat()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a FeedsCat Object</dd>
							<dt><strong>FeedsCat</strong></dt>
				<dd>in file feeds_cat.class.php, class <a href="content/syndication/FeedsCat.php">FeedsCat</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Describes a feed by building a category tree</dd>
							<dt><strong>FeedsList</strong></dt>
				<dd>in file feeds_list.class.php, class <a href="content/syndication/FeedsList.php">FeedsList</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class contains an agregation of differents feeds</dd>
							<dt><strong>FeedsList</strong></dt>
				<dd>in file feeds_list.class.php, method <a href="content/syndication/FeedsList.php#methodFeedsList">FeedsList::FeedsList()</a></dd>
							<dt><strong>FEEDS_PATH</strong></dt>
				<dd>in file feed.class.php, constant <a href="content/syndication/_content---syndication---feed.class.php.php#defineFEEDS_PATH">FEEDS_PATH</a></dd>
							<dt><strong>FEED_DATA__CLASS</strong></dt>
				<dd>in file feed_data.class.php, constant <a href="content/syndication/_content---syndication---feed_data.class.php.php#defineFEED_DATA__CLASS">FEED_DATA__CLASS</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodget_attribute">Comments::get_attribute()</a></dd>
							<dt><strong>get_attribute</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methodget_attribute">Note::get_attribute()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor</dd>
							<dt><strong>get_feeds_list</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodget_feeds_list">CategoriesManager::get_feeds_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Computes the list of the feeds corresponding to each category of the category tree.</dd>
							<dt><strong>get_ids</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodget_ids">Search::get_ids()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the search id</dd>
							<dt><strong>get_results</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodget_results">Search::get_results()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Puts results from the search results in the $results parameter and returns the number of results. Query complexity: 1 query.</dd>
							<dt><strong>get_results_by_id</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodget_results_by_id">Search::get_results_by_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Puts results from the search results identified by the $id_search parameter in the $results parameter and returns the number of results. Query complexity: 2 queries.</dd>
							<dt><strong>get_forbidden_tags</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodget_forbidden_tags">ContentEditor::get_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the fordidden tags.</dd>
							<dt><strong>get_template</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodget_template">ContentEditor::get_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get the template used for the editor.</dd>
							<dt><strong>get_available_tags</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_available_tags">ContentFormattingFactory::get_available_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the map of all the formatting types supported by the PHPBoost formatting editors and parsers. The keys of the map are the tags identifiers and the values the tags names.</dd>
							<dt><strong>get_content</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodget_content">Parser::get_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the content of the parser. If you called a method which parses the content, this content will be parsed.</dd>
							<dt><strong>get_editor</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_editor">ContentFormattingFactory::get_editor()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns an editor object which will display the editor corresponding to the language you chose.</dd>
							<dt><strong>get_forbidden_tags</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodget_forbidden_tags">ContentParser::get_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the forbidden tags.</dd>
							<dt><strong>get_language</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_language">ContentFormattingFactory::get_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the language of the factory</dd>
							<dt><strong>get_page_path</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodget_page_path">Parser::get_page_path()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the page path</dd>
							<dt><strong>get_parser</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_parser">ContentFormattingFactory::get_parser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a parser which will work in the language you chose.</dd>
							<dt><strong>get_path_to_root</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodget_path_to_root">Parser::get_path_to_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the path to root attribute.</dd>
							<dt><strong>get_second_parser</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_second_parser">ContentFormattingFactory::get_second_parser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a second parser which will work in the language you chose.</dd>
							<dt><strong>get_unparser</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_unparser">ContentFormattingFactory::get_unparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a unparser which will work in the language you chose.</dd>
							<dt><strong>get_user_editor</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodget_user_editor">ContentFormattingFactory::get_user_editor()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the editor of the current user (chosen in its profile).</dd>
							<dt><strong>get_change_freq</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_change_freq">SiteMapLink::get_change_freq()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the change frequency (how often the target page is actualized)</dd>
							<dt><strong>get_depth</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodget_depth">SiteMapElement::get_depth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the depth of the element in the tree</dd>
							<dt><strong>get_description</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodget_description">ModuleMap::get_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return the module description</dd>
							<dt><strong>get_last_modification_date</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_last_modification_date">SiteMapLink::get_last_modification_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the last modification date of the target page</dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_link">SiteMapLink::get_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the URL of the link</dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodget_link">SiteMapSection::get_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the link associated to the section</dd>
							<dt><strong>get_link_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_link_stream">SitemapExportConfig::get_link_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a SiteMapLink object.</dd>
							<dt><strong>get_module_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_module_map_stream">SitemapExportConfig::get_module_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a ModuleMap object.</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_name">SiteMapLink::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the target page</dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodget_name">SiteMapElement::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the menu</dd>
							<dt><strong>get_priority</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_priority">SiteMapLink::get_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets the priority of the link</dd>
							<dt><strong>get_section_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_section_stream">SitemapExportConfig::get_section_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a SiteMapSection object.</dd>
							<dt><strong>get_site_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodget_site_map_stream">SitemapExportConfig::get_site_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the Template object to use while exporting a SiteMap object.</dd>
							<dt><strong>get_site_name</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodget_site_name">SiteMap::get_site_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the name of the site</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodget_url">SiteMapLink::get_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the URL of the link</dd>
							<dt><strong>$guid</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$guid">FeedItem::$guid</a></dd>
							<dt><strong>get_auth</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_auth">FeedItem::get_auth()</a></dd>
							<dt><strong>get_cache_file_name</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodget_cache_file_name">Feed::get_cache_file_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feed data cache filename</dd>
							<dt><strong>get_category_id</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_category_id">FeedsCat::get_category_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the category id</dd>
							<dt><strong>get_category_name</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_category_name">FeedsCat::get_category_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the category name</dd>
							<dt><strong>get_children</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_children">FeedsCat::get_children()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current category children</dd>
							<dt><strong>get_date</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_date">FeedData::get_date()</a></dd>
							<dt><strong>get_date</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_date">FeedItem::get_date()</a></dd>
							<dt><strong>get_date_rfc822</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_date_rfc822">FeedData::get_date_rfc822()</a></dd>
							<dt><strong>get_date_rfc822</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_date_rfc822">FeedItem::get_date_rfc822()</a></dd>
							<dt><strong>get_date_rfc3339</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_date_rfc3339">FeedData::get_date_rfc3339()</a></dd>
							<dt><strong>get_date_rfc3339</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_date_rfc3339">FeedItem::get_date_rfc3339()</a></dd>
							<dt><strong>get_desc</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_desc">FeedItem::get_desc()</a></dd>
							<dt><strong>get_desc</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_desc">FeedData::get_desc()</a></dd>
							<dt><strong>get_feeds_list</strong></dt>
				<dd>in file feeds_list.class.php, method <a href="content/syndication/FeedsList.php#methodget_feeds_list">FeedsList::get_feeds_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feeds list</dd>
							<dt><strong>get_feed_menu</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodget_feed_menu">Feed::get_feed_menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates the code which shows all the feeds formats.</dd>
							<dt><strong>get_guid</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_guid">FeedItem::get_guid()</a></dd>
							<dt><strong>get_host</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_host">FeedData::get_host()</a></dd>
							<dt><strong>get_image_url</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_image_url">FeedItem::get_image_url()</a></dd>
							<dt><strong>get_items</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_items">FeedData::get_items()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feed items</dd>
							<dt><strong>get_lang</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_lang">FeedData::get_lang()</a></dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_link">FeedItem::get_link()</a></dd>
							<dt><strong>get_link</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_link">FeedData::get_link()</a></dd>
							<dt><strong>get_module_id</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_module_id">FeedsCat::get_module_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the module id</dd>
							<dt><strong>get_parsed</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodget_parsed">Feed::get_parsed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Export a feed</dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodget_title">FeedData::get_title()</a></dd>
							<dt><strong>get_title</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodget_title">FeedItem::get_title()</a></dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file feeds_cat.class.php, method <a href="content/syndication/FeedsCat.php#methodget_url">FeedsCat::get_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the feed url</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>$html_auth</strong></dt>
				<dd>in file content_parser.class.php, variable <a href="content/parser/ContentParser.php#var$html_auth">ContentParser::$html_auth</a></dd>
							<dt><strong>$host</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$host">FeedData::$host</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$idcom</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$idcom">Comments::$idcom</a></dd>
							<dt><strong>$idprov</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$idprov">Note::$idprov</a></dd>
							<dt><strong>$idprov</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$idprov">Comments::$idprov</a></dd>
							<dt><strong>$id_search</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$id_search">Search::$id_search</a></dd>
							<dt><strong>$id_user</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$id_user">Search::$id_user</a></dd>
							<dt><strong>$is_kernel_script</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$is_kernel_script">Comments::$is_kernel_script</a></dd>
							<dt><strong>IGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineIGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH">IGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</a></dd>
							<dt><strong>INCORRECT_DISPLAYING_CONFIGURATION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineINCORRECT_DISPLAYING_CONFIGURATION">INCORRECT_DISPLAYING_CONFIGURATION</a></dd>
							<dt><strong>insert_results</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodinsert_results">Search::insert_results()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Inserts search results in the database cache in order to speed up next searches. Query complexity: 1 + k / 10 queries. (k represent the number of results to insert in the database)</dd>
							<dt><strong>INTEGRATED_IN_ENVIRONMENT</strong></dt>
				<dd>in file comments.class.php, constant <a href="content/_content---comments.class.php.php#defineINTEGRATED_IN_ENVIRONMENT">INTEGRATED_IN_ENVIRONMENT</a></dd>
							<dt><strong>is_in_cache</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodis_in_cache">Search::is_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the module results are in cache, else, false.</dd>
							<dt><strong>is_loaded</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodis_loaded">Comments::is_loaded()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check if the comments system is correctly loaded.</dd>
							<dt><strong>is_search_id_in_cache</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodis_search_id_in_cache">Search::is_search_id_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the id_search is in cache, else, false.</dd>
							<dt><strong>$identifier</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$identifier">ContentEditor::$identifier</a></dd>
							<dt><strong>$id</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$id">FeedsCat::$id</a></dd>
							<dt><strong>$id_cat</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$id_cat">Feed::$id_cat</a></dd>
							<dt><strong>$image_url</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$image_url">FeedItem::$image_url</a></dd>
							<dt><strong>$items</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$items">FeedData::$items</a></dd>
							<dt><strong>is_in_cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodis_in_cache">Feed::is_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns true if the feed data are in the cache</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="k"></a>
	<div>
		<h2>k</h2>
		<dl>
							<dt><strong>KERNEL_SCRIPT</strong></dt>
				<dd>in file comments.class.php, constant <a href="content/_content---comments.class.php.php#defineKERNEL_SCRIPT">KERNEL_SCRIPT</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>$lock_com</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$lock_com">Comments::$lock_com</a></dd>
							<dt><strong>LOAD_CACHE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineLOAD_CACHE">LOAD_CACHE</a></dd>
							<dt><strong>lock</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodlock">Comments::lock()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Lock or unlock comments for an item.</dd>
							<dt><strong>$language_type</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$language_type">ContentEditor::$language_type</a></dd>
							<dt><strong>$language_type</strong></dt>
				<dd>in file content_formatting_factory.class.php, variable <a href="content/parser/ContentFormattingFactory.php#var$language_type">ContentFormattingFactory::$language_type</a></dd>
							<dt><strong>$last_modification_date</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$last_modification_date">SiteMapLink::$last_modification_date</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file site_map_section.class.php, variable <a href="content/sitemap/SiteMapSection.php#var$link">SiteMapSection::$link</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$link">SiteMapLink::$link</a></dd>
							<dt><strong>$link_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$link_file">SitemapExportConfig::$link_file</a></dd>
							<dt><strong>$lang</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$lang">FeedData::$lang</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$link">FeedData::$link</a></dd>
							<dt><strong>$link</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$link">FeedItem::$link</a></dd>
							<dt><strong>$list</strong></dt>
				<dd>in file feeds_list.class.php, variable <a href="content/syndication/FeedsList.php#var$list">FeedsList::$list</a></dd>
							<dt><strong>load_data</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodload_data">Feed::load_data()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a FeedData element</dd>
							<dt><strong>load_file</strong></dt>
				<dd>in file rss.class.php, method <a href="content/syndication/RSS.php#methodload_file">RSS::load_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a feed by its url</dd>
							<dt><strong>load_file</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodload_file">Feed::load_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a feed by its url</dd>
							<dt><strong>load_file</strong></dt>
				<dd>in file atom.class.php, method <a href="content/syndication/ATOM.php#methodload_file">ATOM::load_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a feed by its url</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>$modules</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$modules">Search::$modules</a></dd>
							<dt><strong>$modules_conditions</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$modules_conditions">Search::$modules_conditions</a></dd>
							<dt><strong>$module_folder</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$module_folder">Note::$module_folder</a></dd>
							<dt><strong>$module_folder</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$module_folder">Comments::$module_folder</a></dd>
							<dt><strong>modules_in_cache</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodmodules_in_cache">Search::modules_in_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the list of the modules ids present in the cache</dd>
							<dt><strong>move</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodmove">CategoriesManager::move()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Moves a category (makes it gone up or down)</dd>
							<dt><strong>MOVE_CATEGORY_DOWN</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineMOVE_CATEGORY_DOWN">MOVE_CATEGORY_DOWN</a></dd>
							<dt><strong>MOVE_CATEGORY_UP</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineMOVE_CATEGORY_UP">MOVE_CATEGORY_UP</a></dd>
							<dt><strong>move_into_another</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodmove_into_another">CategoriesManager::move_into_another()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Moves a category into another category. You can specify its future position in its future parent category.</dd>
							<dt><strong>$module_map_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$module_map_file">SitemapExportConfig::$module_map_file</a></dd>
							<dt><strong>module_map.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---module_map.class.php.php">module_map.class.php</a></dd>
							<dt><strong>ModuleMap</strong></dt>
				<dd>in file module_map.class.php, class <a href="content/sitemap/ModuleMap.php">ModuleMap</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The ModuleMap class represents the map of a module. It has a description (generally the module description) and contains some elements which can be some simple links or some sections (which can match the categories for example).</dd>
							<dt><strong>ModuleMap</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodModuleMap">ModuleMap::ModuleMap()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a ModuleMap object</dd>
							<dt><strong>$module_id</strong></dt>
				<dd>in file feeds_cat.class.php, variable <a href="content/syndication/FeedsCat.php#var$module_id">FeedsCat::$module_id</a></dd>
							<dt><strong>$module_id</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$module_id">Feed::$module_id</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>$nbr_com</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$nbr_com">Comments::$nbr_com</a></dd>
							<dt><strong>$notation_scale</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$notation_scale">Note::$notation_scale</a></dd>
							<dt><strong>note.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---note.class.php.php">note.class.php</a></dd>
							<dt><strong>NEW_CATEGORY_IS_IN_ITS_CHILDRENS</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNEW_CATEGORY_IS_IN_ITS_CHILDRENS">NEW_CATEGORY_IS_IN_ITS_CHILDRENS</a></dd>
							<dt><strong>NEW_PARENT_CATEGORY_DOES_NOT_EXIST</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNEW_PARENT_CATEGORY_DOES_NOT_EXIST">NEW_PARENT_CATEGORY_DOES_NOT_EXIST</a></dd>
							<dt><strong>NEW_STATUS_UNKNOWN</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNEW_STATUS_UNKNOWN">NEW_STATUS_UNKNOWN</a></dd>
							<dt><strong>NORMAL_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNORMAL_MODE">NORMAL_MODE</a></dd>
							<dt><strong>Note</strong></dt>
				<dd>in file note.class.php, method <a href="content/Note.php#methodNote">Note::Note()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Create an new object Note.</dd>
							<dt><strong>Note</strong></dt>
				<dd>in file note.class.php, class <a href="content/Note.php">Note</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides you an easy way to manage notation.</dd>
							<dt><strong>NOTE_DISPLAY_BLOCK</strong></dt>
				<dd>in file note.class.php, constant <a href="content/_content---note.class.php.php#defineNOTE_DISPLAY_BLOCK">NOTE_DISPLAY_BLOCK</a></dd>
							<dt><strong>NOTE_DISPLAY_NOTE</strong></dt>
				<dd>in file note.class.php, constant <a href="content/_content---note.class.php.php#defineNOTE_DISPLAY_NOTE">NOTE_DISPLAY_NOTE</a></dd>
							<dt><strong>NOTE_NODISPLAY_NBRNOTES</strong></dt>
				<dd>in file note.class.php, constant <a href="content/_content---note.class.php.php#defineNOTE_NODISPLAY_NBRNOTES">NOTE_NODISPLAY_NBRNOTES</a></dd>
							<dt><strong>NOT_RECURSIVE_EXPLORATION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineNOT_RECURSIVE_EXPLORATION">NOT_RECURSIVE_EXPLORATION</a></dd>
							<dt><strong>$name</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$name">SiteMapLink::$name</a></dd>
							<dt><strong>$name</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$name">Feed::$name</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="o"></a>
	<div>
		<h2>o</h2>
		<dl>
							<dt><strong>$options</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$options">Note::$options</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>$path</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$path">Note::$path</a></dd>
							<dt><strong>$path</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$path">Comments::$path</a></dd>
							<dt><strong>POP_UP_WINDOW</strong></dt>
				<dd>in file comments.class.php, constant <a href="content/_content---comments.class.php.php#definePOP_UP_WINDOW">POP_UP_WINDOW</a></dd>
							<dt><strong>PRODUCTION_MODE</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#definePRODUCTION_MODE">PRODUCTION_MODE</a></dd>
							<dt><strong>$page_path</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$page_path">Parser::$page_path</a></dd>
							<dt><strong>$path_to_root</strong></dt>
				<dd>in file parser.class.php, variable <a href="content/parser/Parser.php#var$path_to_root">Parser::$path_to_root</a></dd>
							<dt><strong>parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---parser.class.php.php">parser.class.php</a></dd>
							<dt><strong>parse</strong></dt>
				<dd>in file bbcode_highlighter.class.php, method <a href="content/parser/BBCodeHighlighter.php#methodparse">BBCodeHighlighter::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Highlights the content of the parser.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file tinymce_unparser.class.php, method <a href="content/parser/TinyMCEUnparser.php#methodparse">TinyMCEUnparser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unparses the content of the parser. It goes from the PHPBoost reference formatting syntax to the TinyMCE one.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file template_highlighter.class.php, method <a href="content/parser/TemplateHighlighter.php#methodparse">TemplateHighlighter::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Highlights the code. It uses the geshi HTML syntax highlighter and then it highlights the specific template syntax.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file tinymce_parser.class.php, method <a href="content/parser/TinyMCEParser.php#methodparse">TinyMCEParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the content of the parser. Translates the whole content from the TinyMCE syntax to the PHPBoost one.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file bbcode_parser.class.php, method <a href="content/parser/BBCodeParser.php#methodparse">BBCodeParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the parser content from BBCode to XHTML.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file bbcode_unparser.class.php, method <a href="content/parser/BBCodeUnparser.php#methodparse">BBCodeUnparser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unparses the content of the parser. Converts it from HTML syntax to BBcode syntax</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file content_second_parser.class.php, method <a href="content/parser/ContentSecondParser.php#methodparse">ContentSecondParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the content of the parser. The result will be ready to be displayed.</dd>
							<dt><strong>parse</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodparse">ContentParser::parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses the content of the parser</dd>
							<dt><strong>Parser</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodParser">Parser::Parser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Parser object.</dd>
							<dt><strong>Parser</strong></dt>
				<dd>in file parser.class.php, class <a href="content/parser/Parser.php">Parser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is the basis of all the formatting processings that exist in PHPBoost.</dd>
							<dt><strong>PARSER_DO_NOT_STRIP_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#definePARSER_DO_NOT_STRIP_SLASHES">PARSER_DO_NOT_STRIP_SLASHES</a></dd>
							<dt><strong>PARSER_STRIP_SLASHES</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#definePARSER_STRIP_SLASHES">PARSER_STRIP_SLASHES</a></dd>
							<dt><strong>PICK_UP</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#definePICK_UP">PICK_UP</a></dd>
							<dt><strong>$priority</strong></dt>
				<dd>in file site_map_link.class.php, variable <a href="content/sitemap/SiteMapLink.php#var$priority">SiteMapLink::$priority</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>RECURSIVE_EXPLORATION</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineRECURSIVE_EXPLORATION">RECURSIVE_EXPLORATION</a></dd>
							<dt><strong>REIMPLANT</strong></dt>
				<dd>in file parser.class.php, constant <a href="content/parser/_content---parser---parser.class.php.php#defineREIMPLANT">REIMPLANT</a></dd>
							<dt><strong>rss.class.php</strong></dt>
				<dd>procedural page <a href="content/syndication/_content---syndication---rss.class.php.php">rss.class.php</a></dd>
							<dt><strong>read</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodread">Feed::read()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads the feed data in cache and export it</dd>
							<dt><strong>RSS</strong></dt>
				<dd>in file rss.class.php, method <a href="content/syndication/RSS.php#methodRSS">RSS::RSS()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a new RSS object</dd>
							<dt><strong>RSS</strong></dt>
				<dd>in file rss.class.php, class <a href="content/syndication/RSS.php">RSS</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class could load a feed by its url or by a FeedData element and export it to the RSS format</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>$script</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$script">Comments::$script</a></dd>
							<dt><strong>$script</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$script">Note::$script</a></dd>
							<dt><strong>$script_path</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$script_path">Note::$script_path</a></dd>
							<dt><strong>$search</strong></dt>
				<dd>in file search.class.php, variable <a href="content/Search.php#var$search">Search::$search</a></dd>
							<dt><strong>$sql_table</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$sql_table">Comments::$sql_table</a></dd>
							<dt><strong>$sql_table</strong></dt>
				<dd>in file note.class.php, variable <a href="content/Note.php#var$sql_table">Note::$sql_table</a></dd>
							<dt><strong>search.class.php</strong></dt>
				<dd>procedural page <a href="content/_content---search.class.php.php">search.class.php</a></dd>
							<dt><strong>Search</strong></dt>
				<dd>in file search.class.php, method <a href="content/Search.php#methodSearch">Search::Search()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a search object. Query Complexity: 6 + k / 10 database queries. (k represent the number of module without search cache)</dd>
							<dt><strong>Search</strong></dt>
				<dd>in file search.class.php, class <a href="content/Search.php">Search</a></dd>
							<dt><strong>set_arg</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodset_arg">Comments::set_arg()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set argument for the comments system.</dd>
							<dt><strong>set_display_config</strong></dt>
				<dd>in file categories_manager.class.php, method <a href="content/CategoriesManager.php#methodset_display_config">CategoriesManager::set_display_config()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Method which sets the displaying configuration Config example $config = array(         'xmlhttprequest_file' =&gt; 'xmlhttprequest.php',         'administration_file_name' =&gt; 'admin_news_cats.php',         'url' =&gt; array(             'unrewrited' =&gt; PATH_TO_ROOT . '/news/news.php?id=%d',             'rewrited' =&gt; PATH_TO_ROOT . '/news-%d+%s.php'         ), );</dd>
							<dt><strong>STOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</strong></dt>
				<dd>in file categories_manager.class.php, constant <a href="content/_content---categories_manager.class.php.php#defineSTOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH">STOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH</a></dd>
							<dt><strong>set_forbidden_tags</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodset_forbidden_tags">ContentEditor::set_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the forbidden tags</dd>
							<dt><strong>set_identifier</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodset_identifier">ContentEditor::set_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set the html identifier of the textarea field which contain the content to edit.</dd>
							<dt><strong>set_template</strong></dt>
				<dd>in file editor.class.php, method <a href="content/editor/ContentEditor.php#methodset_template">ContentEditor::set_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set an alternative template for the editor.</dd>
							<dt><strong>set_content</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodset_content">Parser::set_content()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the content of the parser. When you will call a parse method, it will deal with this content.</dd>
							<dt><strong>set_forbidden_tags</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodset_forbidden_tags">ContentParser::set_forbidden_tags()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the tags which mustn't be parsed.</dd>
							<dt><strong>set_html_auth</strong></dt>
				<dd>in file content_parser.class.php, method <a href="content/parser/ContentParser.php#methodset_html_auth">ContentParser::set_html_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the required authorizations that are necessary to post some HTML code which will be displayed by the web browser.</dd>
							<dt><strong>set_language</strong></dt>
				<dd>in file content_formatting_factory.class.php, method <a href="content/parser/ContentFormattingFactory.php#methodset_language">ContentFormattingFactory::set_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Changes the language of the factory</dd>
							<dt><strong>set_page_path</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodset_page_path">Parser::set_page_path()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the page path</dd>
							<dt><strong>set_path_to_root</strong></dt>
				<dd>in file parser.class.php, method <a href="content/parser/Parser.php#methodset_path_to_root">Parser::set_path_to_root()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the reference path for relative URL</dd>
							<dt><strong>$section_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$section_file">SitemapExportConfig::$section_file</a></dd>
							<dt><strong>$site_map_file</strong></dt>
				<dd>in file site_map_export_config.class.php, variable <a href="content/sitemap/SitemapExportConfig.php#var$site_map_file">SitemapExportConfig::$site_map_file</a></dd>
							<dt><strong>$site_name</strong></dt>
				<dd>in file site_map.class.php, variable <a href="content/sitemap/SiteMap.php#var$site_name">SiteMap::$site_name</a></dd>
							<dt><strong>site_map.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map.class.php.php">site_map.class.php</a></dd>
							<dt><strong>site_map_element.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_element.class.php.php">site_map_element.class.php</a></dd>
							<dt><strong>site_map_export_config.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_export_config.class.php.php">site_map_export_config.class.php</a></dd>
							<dt><strong>site_map_link.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_link.class.php.php">site_map_link.class.php</a></dd>
							<dt><strong>site_map_section.class.php</strong></dt>
				<dd>procedural page <a href="content/sitemap/_content---sitemap---site_map_section.class.php.php">site_map_section.class.php</a></dd>
							<dt><strong>set_change_freq</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_change_freq">SiteMapLink::set_change_freq()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the change frequency</dd>
							<dt><strong>set_depth</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodset_depth">SiteMapSection::set_depth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the depth of the element</dd>
							<dt><strong>set_depth</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodset_depth">SiteMapElement::set_depth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the depth of the element</dd>
							<dt><strong>set_description</strong></dt>
				<dd>in file module_map.class.php, method <a href="content/sitemap/ModuleMap.php#methodset_description">ModuleMap::set_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the description of the module</dd>
							<dt><strong>set_last_modification_date</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_last_modification_date">SiteMapLink::set_last_modification_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the last modification date of the target page</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_link">SiteMapLink::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the URL of the link</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodset_link">SiteMapSection::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the link associated to the section</dd>
							<dt><strong>set_link_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_link_stream">SitemapExportConfig::set_link_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a SiteMapLink object.</dd>
							<dt><strong>set_module_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_module_map_stream">SitemapExportConfig::set_module_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a ModuleMap object.</dd>
							<dt><strong>set_name</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_name">SiteMapLink::set_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the name of the element</dd>
							<dt><strong>set_priority</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodset_priority">SiteMapLink::set_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the priority of the link</dd>
							<dt><strong>set_section_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_section_stream">SitemapExportConfig::set_section_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a SiteMapSection object.</dd>
							<dt><strong>set_site_map_stream</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodset_site_map_stream">SitemapExportConfig::set_site_map_stream()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the Template object to use while exporting a Site object.</dd>
							<dt><strong>set_site_name</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodset_site_name">SiteMap::set_site_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the name of the site. The default value is the name of the site taken from the site configuration.</dd>
							<dt><strong>SiteMap</strong></dt>
				<dd>in file site_map.class.php, class <a href="content/sitemap/SiteMap.php">SiteMap</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Describes the map of the site. Can be exported according to any text form by using a template configuration. A site map contains some links, some link sections and some module maps (which also contain links and sections).</dd>
							<dt><strong>SiteMap</strong></dt>
				<dd>in file site_map.class.php, method <a href="content/sitemap/SiteMap.php#methodSiteMap">SiteMap::SiteMap()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMap object with its elements</dd>
							<dt><strong>SiteMapElement</strong></dt>
				<dd>in file site_map_element.class.php, method <a href="content/sitemap/SiteMapElement.php#methodSiteMapElement">SiteMapElement::SiteMapElement()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapElement object</dd>
							<dt><strong>SiteMapElement</strong></dt>
				<dd>in file site_map_element.class.php, class <a href="content/sitemap/SiteMapElement.php">SiteMapElement</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This abstract is the root of every object which can be contained by a SiteMap object. Some SiteMapElements objects can contain one or many SiteMapElement objects therefore the elements can be represented by a tree an each element has a depth in the tree.</dd>
							<dt><strong>SitemapExportConfig</strong></dt>
				<dd>in file site_map_export_config.class.php, method <a href="content/sitemap/SitemapExportConfig.php#methodSitemapExportConfig">SitemapExportConfig::SitemapExportConfig()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapExportConfig object</dd>
							<dt><strong>SitemapExportConfig</strong></dt>
				<dd>in file site_map_export_config.class.php, class <a href="content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Configuration used to export a SiteMap. It contains some Template objects which are used to export each kind of elements of a sitemap. Using different configurations will enable you for example to export in HTML code to be displayed in a page of the web site (the site map) or to be written in the sitemap.xml file at the root of your site, this file will be read by the search engines to optimize the research of your site.</dd>
							<dt><strong>SitemapLink</strong></dt>
				<dd>in file site_map_link.class.php, method <a href="content/sitemap/SiteMapLink.php#methodSitemapLink">SiteMapLink::SitemapLink()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapLink object</dd>
							<dt><strong>SiteMapLink</strong></dt>
				<dd>in file site_map_link.class.php, class <a href="content/sitemap/SiteMapLink.php">SiteMapLink</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a link of a site map.</dd>
							<dt><strong>SiteMapSection</strong></dt>
				<dd>in file site_map_section.class.php, class <a href="content/sitemap/SiteMapSection.php">SiteMapSection</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class represents a section of a site map.</dd>
							<dt><strong>SiteMapSection</strong></dt>
				<dd>in file site_map_section.class.php, method <a href="content/sitemap/SiteMapSection.php#methodSiteMapSection">SiteMapSection::SiteMapSection()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a SiteMapSection object</dd>
							<dt><strong>SITE_MAP_AUTH_GUEST</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_AUTH_GUEST">SITE_MAP_AUTH_GUEST</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The site map will be seen by every body, only the public elements must appear</dd>
							<dt><strong>SITE_MAP_AUTH_USER</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_AUTH_USER">SITE_MAP_AUTH_USER</a><br>&nbsp;&nbsp;&nbsp;&nbsp;The site map is for the current user.</dd>
							<dt><strong>SITE_MAP_FREQ_ALWAYS</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_ALWAYS">SITE_MAP_FREQ_ALWAYS</a></dd>
							<dt><strong>SITE_MAP_FREQ_DAILY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_DAILY">SITE_MAP_FREQ_DAILY</a></dd>
							<dt><strong>SITE_MAP_FREQ_DEFAULT</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_DEFAULT">SITE_MAP_FREQ_DEFAULT</a></dd>
							<dt><strong>SITE_MAP_FREQ_HOURLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_HOURLY">SITE_MAP_FREQ_HOURLY</a></dd>
							<dt><strong>SITE_MAP_FREQ_MONTHLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_MONTHLY">SITE_MAP_FREQ_MONTHLY</a></dd>
							<dt><strong>SITE_MAP_FREQ_NEVER</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_NEVER">SITE_MAP_FREQ_NEVER</a></dd>
							<dt><strong>SITE_MAP_FREQ_WEEKLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_WEEKLY">SITE_MAP_FREQ_WEEKLY</a></dd>
							<dt><strong>SITE_MAP_FREQ_YEARLY</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_FREQ_YEARLY">SITE_MAP_FREQ_YEARLY</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_AVERAGE</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_AVERAGE">SITE_MAP_PRIORITY_AVERAGE</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_HIGH</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_HIGH">SITE_MAP_PRIORITY_HIGH</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_LOW</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_LOW">SITE_MAP_PRIORITY_LOW</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_MAX</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_MAX">SITE_MAP_PRIORITY_MAX</a></dd>
							<dt><strong>SITE_MAP_PRIORITY_MIN</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_PRIORITY_MIN">SITE_MAP_PRIORITY_MIN</a></dd>
							<dt><strong>SITE_MAP_SEARCH_ENGINE_MODE</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_SEARCH_ENGINE_MODE">SITE_MAP_SEARCH_ENGINE_MODE</a><br>&nbsp;&nbsp;&nbsp;&nbsp;It will be for the search engines (sitemap. can be forgotten in that case.</dd>
							<dt><strong>SITE_MAP_USER_MODE</strong></dt>
				<dd>in file site_map.class.php, constant <a href="content/sitemap/_content---sitemap---site_map.class.php.php#defineSITE_MAP_USER_MODE">SITE_MAP_USER_MODE</a><br>&nbsp;&nbsp;&nbsp;&nbsp;It will be a page of the site containing the site map</dd>
							<dt><strong>$str</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$str">Feed::$str</a></dd>
							<dt><strong>serialize</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodserialize">FeedData::serialize()</a></dd>
							<dt><strong>set_auth</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_auth">FeedItem::set_auth()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item auth, useful to check authorizations</dd>
							<dt><strong>set_auth_bit</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_auth_bit">FeedData::set_auth_bit()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed auth bit, useful to check authorizations</dd>
							<dt><strong>set_date</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_date">FeedItem::set_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item date</dd>
							<dt><strong>set_date</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_date">FeedData::set_date()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed data date</dd>
							<dt><strong>set_desc</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_desc">FeedData::set_desc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed description</dd>
							<dt><strong>set_desc</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_desc">FeedItem::set_desc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item description</dd>
							<dt><strong>set_guid</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_guid">FeedItem::set_guid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item guid</dd>
							<dt><strong>set_host</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_host">FeedData::set_host()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed host</dd>
							<dt><strong>set_image_url</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_image_url">FeedItem::set_image_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item picture</dd>
							<dt><strong>set_lang</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_lang">FeedData::set_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed language</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_link">FeedData::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item link</dd>
							<dt><strong>set_link</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_link">FeedItem::set_link()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item link</dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file feed_item.class.php, method <a href="content/syndication/FeedItem.php#methodset_title">FeedItem::set_title()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed item title</dd>
							<dt><strong>set_title</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodset_title">FeedData::set_title()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Sets the feed title</dd>
							<dt><strong>subitems</strong></dt>
				<dd>in file feed_data.class.php, method <a href="content/syndication/FeedData.php#methodsubitems">FeedData::subitems()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a items list containing $number items starting from the $begin_at one</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$table</strong></dt>
				<dd>in file categories_manager.class.php, variable <a href="content/CategoriesManager.php#var$table">CategoriesManager::$table</a></dd>
							<dt><strong>$template</strong></dt>
				<dd>in file editor.class.php, variable <a href="content/editor/ContentEditor.php#var$template">ContentEditor::$template</a></dd>
							<dt><strong>tinymce_editor.class.php</strong></dt>
				<dd>procedural page <a href="content/editor/_content---editor---tinymce_editor.class.php.php">tinymce_editor.class.php</a></dd>
							<dt><strong>TinyMCEEditor</strong></dt>
				<dd>in file tinymce_editor.class.php, method <a href="content/editor/TinyMCEEditor.php#methodTinyMCEEditor">TinyMCEEditor::TinyMCEEditor()</a></dd>
							<dt><strong>TinyMCEEditor</strong></dt>
				<dd>in file tinymce_editor.class.php, class <a href="content/editor/TinyMCEEditor.php">TinyMCEEditor</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class provides an interface editor for contents.</dd>
							<dt><strong>$tag</strong></dt>
				<dd>in file content_parser.class.php, variable <a href="content/parser/ContentParser.php#var$tag">ContentParser::$tag</a></dd>
							<dt><strong>template_highlighter.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---template_highlighter.class.php.php">template_highlighter.class.php</a></dd>
							<dt><strong>tinymce_parser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---tinymce_parser.class.php.php">tinymce_parser.class.php</a></dd>
							<dt><strong>tinymce_unparser.class.php</strong></dt>
				<dd>procedural page <a href="content/parser/_content---parser---tinymce_unparser.class.php.php">tinymce_unparser.class.php</a></dd>
							<dt><strong>TemplateHighlighter</strong></dt>
				<dd>in file template_highlighter.class.php, method <a href="content/parser/TemplateHighlighter.php#methodTemplateHighlighter">TemplateHighlighter::TemplateHighlighter()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Build a TemplateHighlighter object.</dd>
							<dt><strong>TemplateHighlighter</strong></dt>
				<dd>in file template_highlighter.class.php, class <a href="content/parser/TemplateHighlighter.php">TemplateHighlighter</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This is a syntax highlighter for the PHPBoost template syntax.</dd>
							<dt><strong>TinyMCEParser</strong></dt>
				<dd>in file tinymce_parser.class.php, class <a href="content/parser/TinyMCEParser.php">TinyMCEParser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables to use TinyMCE without breaking the compatibility with the BBCode formatting. PHPBoost has a reference syntax, it in HTML with specific CSS classes. The HTML code generated by TinyMCE must be modified to conform itself to this specific syntax. This class makes the translation from the TinyMCE HTML to the PHPBoost HTML.</dd>
							<dt><strong>TinyMCEParser</strong></dt>
				<dd>in file tinymce_parser.class.php, method <a href="content/parser/TinyMCEParser.php#methodTinyMCEParser">TinyMCEParser::TinyMCEParser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds this kind of parser</dd>
							<dt><strong>TinyMCEUnparser</strong></dt>
				<dd>in file tinymce_unparser.class.php, class <a href="content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class enables to translate the content formatting from the PHPBoost standard one to the TinyMCE one. The PHPBoost one is historically the one corresponding to the BBCode translation in HTML and is now the reference. TinyMCE has a particular syntax and it must be respected if we want to make a formatting which can be edited after having beeing written, enough what using a WYSIWYG editor hasn't any advantage.</dd>
							<dt><strong>TinyMCEUnparser</strong></dt>
				<dd>in file tinymce_unparser.class.php, method <a href="content/parser/TinyMCEUnparser.php#methodTinyMCEUnparser">TinyMCEUnparser::TinyMCEUnparser()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a TinyMCEUnparser object</dd>
							<dt><strong>TINYMCE_LANGUAGE</strong></dt>
				<dd>in file content_formatting_factory.class.php, constant <a href="content/parser/_content---parser---content_formatting_factory.class.php.php#defineTINYMCE_LANGUAGE">TINYMCE_LANGUAGE</a></dd>
							<dt><strong>TPL_BRACES_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_BRACES_STYLE">TPL_BRACES_STYLE</a></dd>
							<dt><strong>TPL_KEYWORD_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_KEYWORD_STYLE">TPL_KEYWORD_STYLE</a></dd>
							<dt><strong>TPL_NESTED_VARIABLE_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_NESTED_VARIABLE_STYLE">TPL_NESTED_VARIABLE_STYLE</a></dd>
							<dt><strong>TPL_SHARP_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_SHARP_STYLE">TPL_SHARP_STYLE</a></dd>
							<dt><strong>TPL_VARIABLE_STYLE</strong></dt>
				<dd>in file template_highlighter.class.php, constant <a href="content/parser/_content---parser---template_highlighter.class.php.php#defineTPL_VARIABLE_STYLE">TPL_VARIABLE_STYLE</a></dd>
							<dt><strong>$title</strong></dt>
				<dd>in file feed_item.class.php, variable <a href="content/syndication/FeedItem.php#var$title">FeedItem::$title</a></dd>
							<dt><strong>$title</strong></dt>
				<dd>in file feed_data.class.php, variable <a href="content/syndication/FeedData.php#var$title">FeedData::$title</a></dd>
							<dt><strong>$tpl</strong></dt>
				<dd>in file feed.class.php, variable <a href="content/syndication/Feed.php#var$tpl">Feed::$tpl</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>update</strong></dt>
				<dd>in file comments.class.php, method <a href="content/Comments.php#methodupdate">Comments::update()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Edit a comment</dd>
							<dt><strong>update_cache</strong></dt>
				<dd>in file feed.class.php, method <a href="content/syndication/Feed.php#methodupdate_cache">Feed::update_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the cache of the $module_id, $name, $idcat feed with $data</dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
  <hr />
	<a name="v"></a>
	<div>
		<h2>v</h2>
		<dl>
							<dt><strong>$vars</strong></dt>
				<dd>in file comments.class.php, variable <a href="content/Comments.php#var$vars">Comments::$vars</a></dd>
					</dl>
	</div>
	<a href="elementindex_content.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                        
                                                            <a href="classtrees_content.php" class="menu">class tree: content</a> -
            <a href="elementindex_content.php" class="menu">index: content</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:40 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>