<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'menu - Docs For Class Menu');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('menu', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">menu</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                
                                                                                                                <a href="../classtrees_menu.php" class="menu">class tree: menu</a> - 
                <a href="../elementindex_menu.php" class="menu">index: menu</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/contentmenu/ContentMenu.php">ContentMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/feedmenu/FeedMenu.php">FeedMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/linksmenu/LinksMenu.php">LinksMenu</a>            </li>
                    <li>
                <a href="../menu/linksmenu/LinksMenuElement.php">LinksMenuElement</a>            </li>
                    <li>
                <a href="../menu/linksmenu/LinksMenuLink.php">LinksMenuLink</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../menu/Menu.php">Menu</a>            </li>
                                        <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/minimenu/MiniMenu.php">MiniMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/modulesminimenu/ModuleMiniMenu.php">ModuleMiniMenu</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../menu/_menu---menu.class.php.php">                menu.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/contentmenu/_menu---content---content_menu.class.php.php">                content_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/feedmenu/_menu---feed---feed_menu.class.php.php">                feed_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/linksmenu/_menu---links---links_menu.class.php.php">                links_menu.class.php
                </a>            </li>
                    <li>
                <a href="../menu/linksmenu/_menu---links---links_menu_element.class.php.php">                links_menu_element.class.php
                </a>            </li>
                    <li>
                <a href="../menu/linksmenu/_menu---links---links_menu_link.class.php.php">                links_menu_link.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/minimenu/_menu---mini---mini_menu.class.php.php">                mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php">                module_mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Menu</h1><p>Source Location: /menu/menu.class.php [line 52]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class represents a menu element and is used to build any kind of menu</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



				

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../menu/Menu.php#methodMenu">Menu</a></li><li class="bb_li"><a href="../menu/Menu.php#methodadmin_display">admin_display</a></li><li class="bb_li"><a href="../menu/Menu.php#methodcache_export">cache_export</a></li><li class="bb_li"><a href="../menu/Menu.php#methodcache_export_begin">cache_export_begin</a></li><li class="bb_li"><a href="../menu/Menu.php#methodcache_export_end">cache_export_end</a></li><li class="bb_li"><a href="../menu/Menu.php#methoddisplay">display</a></li><li class="bb_li"><a href="../menu/Menu.php#methodenabled">enabled</a></li><li class="bb_li"><a href="../menu/Menu.php#methodget_auth">get_auth</a></li><li class="bb_li"><a href="../menu/Menu.php#methodget_block">get_block</a></li><li class="bb_li"><a href="../menu/Menu.php#methodget_block_position">get_block_position</a></li><li class="bb_li"><a href="../menu/Menu.php#methodget_id">get_id</a></li><li class="bb_li"><a href="../menu/Menu.php#methodget_title">get_title</a></li><li class="bb_li"><a href="../menu/Menu.php#methodid">id</a></li><li class="bb_li"><a href="../menu/Menu.php#methodis_enabled">is_enabled</a></li><li class="bb_li"><a href="../menu/Menu.php#methodset_auth">set_auth</a></li><li class="bb_li"><a href="../menu/Menu.php#methodset_block">set_block</a></li><li class="bb_li"><a href="../menu/Menu.php#methodset_block_position">set_block_position</a></li><li class="bb_li"><a href="../menu/Menu.php#methodset_title">set_title</a></li><li class="bb_li"><a href="../menu/Menu.php#method_assign">_assign</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../menu/Menu.php#var$auth">$auth</a></li><li class="bb_li"><a href="../menu/Menu.php#var$block">$block</a></li><li class="bb_li"><a href="../menu/Menu.php#var$enabled">$enabled</a></li><li class="bb_li"><a href="../menu/Menu.php#var$id">$id</a></li><li class="bb_li"><a href="../menu/Menu.php#var$position">$position</a></li><li class="bb_li"><a href="../menu/Menu.php#var$title">$title</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class represents a menu element and is used to build any kind of menu</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li><li><strong>abstract:</strong> </li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodMenu"></a>
    <h3>constructor Menu <span class="smalllinenumber">[line 60]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Menu Menu(
string
$title, int
$id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Build a Menu element.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$title</strong>&nbsp;&nbsp;</td>
        <td>the Menu title</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>its id in the database</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadmin_display"></a>
    <h3>method admin_display <span class="smalllinenumber">[line 130]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string admin_display(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Display the menu admin gui</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the menu parsed in xHTML</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcache_export"></a>
    <h3>method cache_export <span class="smalllinenumber">[line 140]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string cache_export(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the string the string to write in the cache file</li><li><strong>abstract:</strong> </li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../menu/modulesminimenu/ModuleMiniMenu.php#methodcache_export">ModuleMiniMenu::cache_export()</a></dt>
        <dd></dd>
    </dl>
        <dl>
    <dt><a href="../menu/feedmenu/FeedMenu.php#methodcache_export">FeedMenu::cache_export()</a></dt>
        <dd></dd>
    </dl>
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenuElement.php#methodcache_export">LinksMenuElement::cache_export()</a></dt>
        <dd>returns the string to write in the cache file</dd>
    </dl>
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenuLink.php#methodcache_export">LinksMenuLink::cache_export()</a></dt>
        <dd></dd>
    </dl>
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenu.php#methodcache_export">LinksMenu::cache_export()</a></dt>
        <dd></dd>
    </dl>
        <dl>
    <dt><a href="../menu/minimenu/MiniMenu.php#methodcache_export">MiniMenu::cache_export()</a></dt>
        <dd></dd>
    </dl>
        <dl>
    <dt><a href="../menu/contentmenu/ContentMenu.php#methodcache_export">ContentMenu::cache_export()</a></dt>
        <dd></dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcache_export_begin"></a>
    <h3>method cache_export_begin <span class="smalllinenumber">[line 145]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string cache_export_begin(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the string to write in the cache file at the beginning of the Menu element;</li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenuElement.php#methodcache_export_begin">LinksMenuElement::cache_export_begin()</a></dt>
        <dd>returns the string to write in the cache file at the beginning of the Menu element</dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcache_export_end"></a>
    <h3>method cache_export_end <span class="smalllinenumber">[line 155]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string cache_export_end(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the string to write in the cache file at the end of the Menu element</li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenuElement.php#methodcache_export_end">LinksMenuElement::cache_export_end()</a></dt>
        <dd>returns the string to write in the cache file at the end of the Menu element</dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 120]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string display(
[
$tpl = false], <a href="../io/Template.php">Template</a>
$template)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Display the menu</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the menu parsed in xHTML</li><li><strong>abstract:</strong> </li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../menu/feedmenu/FeedMenu.php#methoddisplay">FeedMenu::display()</a></dt>
        <dd></dd>
    </dl>
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenuElement.php#methoddisplay">LinksMenuElement::display()</a></dt>
        <dd>Displays the menu according to the given template</dd>
    </dl>
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenuLink.php#methoddisplay">LinksMenuLink::display()</a></dt>
        <dd>Display the menu</dd>
    </dl>
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenu.php#methoddisplay">LinksMenu::display()</a></dt>
        <dd>Display the menu</dd>
    </dl>
        <dl>
    <dt><a href="../menu/contentmenu/ContentMenu.php#methoddisplay">ContentMenu::display()</a></dt>
        <dd>Display the content menu.</dd>
    </dl>
    </p>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../io/Template.php">Template</a>&nbsp;&nbsp;</td>
        <td><strong>$template</strong>&nbsp;&nbsp;</td>
        <td>the template to use</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$tpl</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodenabled"></a>
    <h3>method enabled <span class="smalllinenumber">[line 77]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void enabled(
[bool
$enabled = MENU_ENABLED])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$enabled</strong>&nbsp;&nbsp;</td>
        <td>Enable or not the Menu</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_auth"></a>
    <h3>method get_auth <span class="smalllinenumber">[line 95]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>array get_auth(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the authorization array $auth</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_block"></a>
    <h3>method get_block <span class="smalllinenumber">[line 103]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_block(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the Menu $block position</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_block_position"></a>
    <h3>method get_block_position <span class="smalllinenumber">[line 107]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_block_position(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the Menu $position</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_id"></a>
    <h3>method get_id <span class="smalllinenumber">[line 99]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_id(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the $id of the menu in the database</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_title"></a>
    <h3>method get_title <span class="smalllinenumber">[line 91]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_title(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the link $title</li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../menu/modulesminimenu/ModuleMiniMenu.php#methodget_title">ModuleMiniMenu::get_title()</a></dt>
        <dd></dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodid"></a>
    <h3>method id <span class="smalllinenumber">[line 165]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void id(
int
$id)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Set the Menu database id</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_enabled"></a>
    <h3>method is_enabled <span class="smalllinenumber">[line 111]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool is_enabled(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the Menu is enabled, false otherwise</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_auth"></a>
    <h3>method set_auth <span class="smalllinenumber">[line 73]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_auth(

$auth, array
$url)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">array&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>the authorisation array to set</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$auth</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_block"></a>
    <h3>method set_block <span class="smalllinenumber">[line 81]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int set_block(

$block)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the Menu $block position</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$block</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_block_position"></a>
    <h3>method set_block_position <span class="smalllinenumber">[line 85]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_block_position(
int
$position)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$position</strong>&nbsp;&nbsp;</td>
        <td>the Menu position to set</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_title"></a>
    <h3>method set_title <span class="smalllinenumber">[line 69]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_title(

$title, string
$image)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$image</strong>&nbsp;&nbsp;</td>
        <td>the value to set</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$title</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="method_assign"></a>
    <h3>method _assign <span class="smalllinenumber">[line 174]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void _assign(

&$template, <a href="../io/Template.php">Template</a>
$template)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Assign tpl vars</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../menu/linksmenu/LinksMenuElement.php#method_assign">LinksMenuElement::_assign()</a></dt>
        <dd>Assign tpl vars</dd>
    </dl>
    </p>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../io/Template.php">Template</a>&nbsp;&nbsp;</td>
        <td><strong>$template</strong>&nbsp;&nbsp;</td>
        <td>the template on which we gonna assign vars</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$template</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                    <div class="var">
                            <a name="var_auth"></a>
                <span class="line-number">[line 205]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int[string]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$auth</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_block"></a>
                <span class="line-number">[line 215]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$block</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;BLOCK_POSITION__NOT_ENABLED</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_enabled"></a>
                <span class="line-number">[line 210]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">bool</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$enabled</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;MENU_NOT_ENABLED</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id"></a>
                <span class="line-number">[line 195]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_position"></a>
                <span class="line-number">[line 220]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$position</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;-1</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_title"></a>
                <span class="line-number">[line 200]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$title</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                    
                                                                                <a href="../classtrees_menu.php" class="menu">class tree: menu</a> -
            <a href="../elementindex_menu.php" class="menu">index: menu</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:50 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>