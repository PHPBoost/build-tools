<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'menu - Docs for page module_mini_menu.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('menu', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">menu</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                
                                                                                                                <a href="../../classtrees_menu.php" class="menu">class tree: menu</a> - 
                <a href="../../elementindex_menu.php" class="menu">index: menu</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/contentmenu/ContentMenu.php">ContentMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/feedmenu/FeedMenu.php">FeedMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/linksmenu/LinksMenu.php">LinksMenu</a>            </li>
                    <li>
                <a href="../../menu/linksmenu/LinksMenuElement.php">LinksMenuElement</a>            </li>
                    <li>
                <a href="../../menu/linksmenu/LinksMenuLink.php">LinksMenuLink</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../menu/Menu.php">Menu</a>            </li>
                                        <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/minimenu/MiniMenu.php">MiniMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/modulesminimenu/ModuleMiniMenu.php">ModuleMiniMenu</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../menu/_menu---menu.class.php.php">                menu.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/contentmenu/_menu---content---content_menu.class.php.php">                content_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/feedmenu/_menu---feed---feed_menu.class.php.php">                feed_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/linksmenu/_menu---links---links_menu.class.php.php">                links_menu.class.php
                </a>            </li>
                    <li>
                <a href="../../menu/linksmenu/_menu---links---links_menu_element.class.php.php">                links_menu_element.class.php
                </a>            </li>
                    <li>
                <a href="../../menu/linksmenu/_menu---links---links_menu_link.class.php.php">                links_menu_link.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/minimenu/_menu---mini---mini_menu.class.php.php">                mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php">                module_mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: module_mini_menu.class.php</h1><p>Source Location: /menu/module_mini/module_mini_menu.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../../menu/modulesminimenu/ModuleMiniMenu.php">ModuleMiniMenu</a></dt>
	<dd></dd>
</div><br /><br />

<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineMODULE_MINI_MENU__CLASS"></a>
	<h3>MODULE_MINI_MENU__CLASS <span class="smalllinenumber">[line 30]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>MODULE_MINI_MENU__CLASS = 'ModuleMiniMenu'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                    
                                                                                <a href="../../classtrees_menu.php" class="menu">class tree: menu</a> -
            <a href="../../elementindex_menu.php" class="menu">index: menu</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:36 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>