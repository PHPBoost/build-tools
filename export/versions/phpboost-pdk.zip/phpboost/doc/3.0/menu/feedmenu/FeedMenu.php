<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'menu - Docs For Class FeedMenu');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('menu', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">menu</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                
                                                                                                                <a href="../../classtrees_menu.php" class="menu">class tree: menu</a> - 
                <a href="../../elementindex_menu.php" class="menu">index: menu</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/contentmenu/ContentMenu.php">ContentMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/feedmenu/FeedMenu.php">FeedMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/linksmenu/LinksMenu.php">LinksMenu</a>            </li>
                    <li>
                <a href="../../menu/linksmenu/LinksMenuElement.php">LinksMenuElement</a>            </li>
                    <li>
                <a href="../../menu/linksmenu/LinksMenuLink.php">LinksMenuLink</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../menu/Menu.php">Menu</a>            </li>
                                        <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/minimenu/MiniMenu.php">MiniMenu</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/modulesminimenu/ModuleMiniMenu.php">ModuleMiniMenu</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../menu/_menu---menu.class.php.php">                menu.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>contentmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/contentmenu/_menu---content---content_menu.class.php.php">                content_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>feedmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/feedmenu/_menu---feed---feed_menu.class.php.php">                feed_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>linksmenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/linksmenu/_menu---links---links_menu.class.php.php">                links_menu.class.php
                </a>            </li>
                    <li>
                <a href="../../menu/linksmenu/_menu---links---links_menu_element.class.php.php">                links_menu_element.class.php
                </a>            </li>
                    <li>
                <a href="../../menu/linksmenu/_menu---links---links_menu_link.class.php.php">                links_menu_link.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>minimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/minimenu/_menu---mini---mini_menu.class.php.php">                mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>modulesminimenu</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../menu/modulesminimenu/_menu---module_mini---module_mini_menu.class.php.php">                module_mini_menu.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: FeedMenu</h1><p>Source Location: /menu/feed/feed_menu.class.php [line 39]</p>

<h2>Class Overview</a></h2>
<pre><a href="../../menu/Menu.php">Menu</a>
   |
   --FeedMenu</pre>
<div class="description"></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodFeedMenu">FeedMenu</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodcache_export">cache_export</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methoddisplay">display</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodget_module_id">get_module_id</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodget_template">get_template</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodget_url">get_url</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodset_cat">set_cat</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodset_module_id">set_module_id</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#methodset_name">set_name</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#var$begin_at">$begin_at</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#var$category">$category</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#var$module_id">$module_id</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#var$name">$name</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#var$number">$number</a></li><li class="bb_li"><a href="../../menu/feedmenu/FeedMenu.php#var$url">$url</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags">    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFeedMenu"></a>
    <h3>constructor FeedMenu <span class="smalllinenumber">[line 42]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>FeedMenu FeedMenu(

$title, 
$module_id, [
$category = 0], [
$name = DEFAULT_FEED_NAME], [
$number = 10], [
$begin_at = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$title</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$category</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$number</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$begin_at</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcache_export"></a>
    <h3>method cache_export <span class="smalllinenumber">[line 95]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void cache_export(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    Overrides <a href="../../menu/Menu.php#methodcache_export">Menu::cache_export()</a> (parent method not documented)
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 88]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void display(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    Overrides <a href="../../menu/Menu.php#methoddisplay">Menu::display()</a> (Display the menu)
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_module_id"></a>
    <h3>method get_module_id <span class="smalllinenumber">[line 56]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_module_id(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the feed menu module id</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_url"></a>
    <h3>method get_url <span class="smalllinenumber">[line 62]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Return get_url(
[bool
$relative = false])</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the absolute feed Url</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$relative</strong>&nbsp;&nbsp;</td>
        <td>If false, compute the absolute url, else, returns the relative one</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_cat"></a>
    <h3>method set_cat <span class="smalllinenumber">[line 82]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_cat(
int
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>the feed's category</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_module_id"></a>
    <h3>method set_module_id <span class="smalllinenumber">[line 78]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_module_id(
string
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>the feed's module_id</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_name"></a>
    <h3>method set_name <span class="smalllinenumber">[line 86]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_name(
string
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>the feed's name</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodget_template"></a>
	<h3>static method get_template <span class="smalllinenumber">[line 111]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static the get_template(
[string
$name = ''], [string
$block_position = BLOCK_POSITION__LEFT])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Returns the tpl to parse a feed</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> tpl to parse a feed</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td>The feed name</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$block_position</strong>&nbsp;&nbsp;</td>
        <td>The indentifier block position defined in the inherit class menu</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                    <div class="var">
                            <a name="var_begin_at"></a>
                <span class="line-number">[line 134]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$begin_at</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_category"></a>
                <span class="line-number">[line 132]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$category</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_module_id"></a>
                <span class="line-number">[line 130]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$module_id</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_name"></a>
                <span class="line-number">[line 131]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_number"></a>
                <span class="line-number">[line 133]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$number</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;10</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_url"></a>
                <span class="line-number">[line 129]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$url</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>

    <hr />
    <table width="100%" border="0">
        <tr>
                                                    <!--
                        <td valign="top">
                <h3>Inherited Variables</h3>
                                    <div class="tags">
                        <h4>Class: <a href="../../menu/Menu.php">Menu</a></h4>
                        <dl>
                                                        <dt><a href="../../menu/Menu.php#var$auth">Menu::$auth</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#var$block">Menu::$block</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#var$enabled">Menu::$enabled</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#var$id">Menu::$id</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#var$position">Menu::$position</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#var$title">Menu::$title</a></dt>
                            <dd></dd>
                                                    </dl>
                    </div>
                            </td>
                         -->
                            <td valign="top">
                    <h3>Inherited Methods</h3>
                                            <h4>Class: <a href="../../menu/Menu.php">Menu</a></h4>
                        <dl style="margin-left:10px;">
                                                        <dt><a href="../../menu/Menu.php#methodMenu">Menu::Menu()</a></dt>
                            <dd>Build a Menu element.</dd>
                                                        <dt><a href="../../menu/Menu.php#methodadmin_display">Menu::admin_display()</a></dt>
                            <dd>Display the menu admin gui</dd>
                                                        <dt><a href="../../menu/Menu.php#methodcache_export">Menu::cache_export()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodcache_export_begin">Menu::cache_export_begin()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodcache_export_end">Menu::cache_export_end()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methoddisplay">Menu::display()</a></dt>
                            <dd>Display the menu</dd>
                                                        <dt><a href="../../menu/Menu.php#methodenabled">Menu::enabled()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodget_auth">Menu::get_auth()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodget_block">Menu::get_block()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodget_block_position">Menu::get_block_position()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodget_id">Menu::get_id()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodget_title">Menu::get_title()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodid">Menu::id()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodis_enabled">Menu::is_enabled()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodset_auth">Menu::set_auth()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodset_block">Menu::set_block()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodset_block_position">Menu::set_block_position()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#methodset_title">Menu::set_title()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../menu/Menu.php#method_assign">Menu::_assign()</a></dt>
                            <dd>Assign tpl vars</dd>
                                                    </dl>
                        <br />
                                    </td>
                    </tr>
    </table>
    <hr />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                    
                                                                                <a href="../../classtrees_menu.php" class="menu">class tree: menu</a> -
            <a href="../../elementindex_menu.php" class="menu">index: menu</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:22 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>