<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'phpboost - Docs for page functions.inc.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('phpboost', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">phpboost</div>
        <div class="module_contents">
        <div>
            
                                                
                                                                                                                                                                                                                                                                                                                                                <a href="../classtrees_phpboost.php" class="menu">class tree: phpboost</a> - 
                <a href="../elementindex_phpboost.php" class="menu">index: phpboost</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../phpboost/_functions.inc.php.php">                functions.inc.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: functions.inc.php</h1><p>Source Location: /functions.inc.php [line ]</p>
<br />
<br />


<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineADDSLASHES_AUTO"></a>
	<h3>ADDSLASHES_AUTO <span class="smalllinenumber">[line 32]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ADDSLASHES_AUTO = 0</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineADDSLASHES_FORCE"></a>
	<h3>ADDSLASHES_FORCE <span class="smalllinenumber">[line 34]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ADDSLASHES_FORCE = 1</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineADDSLASHES_NONE"></a>
	<h3>ADDSLASHES_NONE <span class="smalllinenumber">[line 36]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ADDSLASHES_NONE = 2</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineCLASS_IMPORT"></a>
	<h3>CLASS_IMPORT <span class="smalllinenumber">[line 1190]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>CLASS_IMPORT = '.class.php'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineHTML_NO_PROTECT"></a>
	<h3>HTML_NO_PROTECT <span class="smalllinenumber">[line 29]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>HTML_NO_PROTECT = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineHTML_PROTECT"></a>
	<h3>HTML_PROTECT <span class="smalllinenumber">[line 30]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>HTML_PROTECT = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineINC_IMPORT"></a>
	<h3>INC_IMPORT <span class="smalllinenumber">[line 1191]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>INC_IMPORT = '.inc.php'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineLIB_IMPORT"></a>
	<h3>LIB_IMPORT <span class="smalllinenumber">[line 1192]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>LIB_IMPORT = '.lib.php'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineMAGIC_QUOTES_DISABLED"></a>
	<h3>MAGIC_QUOTES_DISABLED <span class="smalllinenumber">[line 37]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>MAGIC_QUOTES_DISABLED = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNO_EDITOR_UNPARSE"></a>
	<h3>NO_EDITOR_UNPARSE <span class="smalllinenumber">[line 40]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NO_EDITOR_UNPARSE = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNO_FATAL_ERROR"></a>
	<h3>NO_FATAL_ERROR <span class="smalllinenumber">[line 39]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NO_FATAL_ERROR = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNO_UPDATE_PAGES"></a>
	<h3>NO_UPDATE_PAGES <span class="smalllinenumber">[line 38]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NO_UPDATE_PAGES = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineTIMEZONE_SITE"></a>
	<h3>TIMEZONE_SITE <span class="smalllinenumber">[line 41]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>TIMEZONE_SITE = 1</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineTIMEZONE_SYSTEM"></a>
	<h3>TIMEZONE_SYSTEM <span class="smalllinenumber">[line 42]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>TIMEZONE_SYSTEM = 2</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineTIMEZONE_USER"></a>
	<h3>TIMEZONE_USER <span class="smalllinenumber">[line 43]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>TIMEZONE_USER = 3</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />
  <hr />
	<a name="functionarray_combine"></a>
	<h3>array_combine <span class="smalllinenumber">[line 1107]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void array_combine(
 $keys,  $values)</code>
    </td></tr></table>
    </td></tr></table><br />

		    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$keys</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$values</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functioncheck_mail"></a>
	<h3>check_mail <span class="smalllinenumber">[line 637]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>bool check_mail(
string $mail)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Checks if a string could match an email address form.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the form is correct, false otherwhise.</li><li><strong>see:</strong> Mail::check_validity</li><li><strong>deprecated:</strong> </li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mail</strong>&nbsp;&nbsp;</td>
        <td>String to check</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functioncheck_nbr_links"></a>
	<h3>check_nbr_links <span class="smalllinenumber">[line 614]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>bool check_nbr_links(
string $contents, int $max_nbr)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Checks if a string contains less than a defined number of links (used to prevent SPAM).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if there are no too much links, false otherwise.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$contents</strong>&nbsp;&nbsp;</td>
        <td>String in which you want to count the number of links</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$max_nbr</strong>&nbsp;&nbsp;</td>
        <td>Maximum number of links accepted.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functiondelete_file"></a>
	<h3>delete_file <span class="smalllinenumber">[line 943]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>bool delete_file(
string $file)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Deletes a file</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the file could be deleted, false if an error occured.</li><li><strong>deprecated:</strong> </li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>Path of the file to delete</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functiondisplay_comments"></a>
	<h3>display_comments <span class="smalllinenumber">[line 313]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>The display_comments(
string $script, int $idprov, string $vars, [string $module_folder = &#039;&#039;])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns the HTML code of the comments manager.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> HTML code of the commenting interface that you can directly display in a template.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$script</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idprov</strong>&nbsp;&nbsp;</td>
        <td>The data base id of the item for which you want to display the commenting interface.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$vars</strong>&nbsp;&nbsp;</td>
        <td>The URL of the curent page (the comments API will always redirect the user to the current page). You just have to add a 'com' HTTP parameter for which the value must be %s (it will be used by the comments API).</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_folder</strong>&nbsp;&nbsp;</td>
        <td>The identifier of your module (the name of its folder).</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functiondisplay_editor"></a>
	<h3>display_editor <span class="smalllinenumber">[line 291]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>The display_editor(
[string $field = &#039;contents&#039;], [string[] $forbidden_tags = array()])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns the HTML code of the user editor. It uses the ContentFormattingFactory class, it allows you to write less code lines.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> HTML code of the editor that you can directly display in a template.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$field</strong>&nbsp;&nbsp;</td>
        <td>The name of the HTTP parameter which you will retrieve the value entered by the user.</td>
      </tr>
		      <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$forbidden_tags</strong>&nbsp;&nbsp;</td>
        <td>The list of the tags you don't want to appear in the editor.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionfile_get_contents_emulate"></a>
	<h3>file_get_contents_emulate <span class="smalllinenumber">[line 1016]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string file_get_contents_emulate(
string $filename, [$incpath $incpath = false], [$resource_context $resource_context = null])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Emulates the PHP file_get_contents_emulate.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The file contents.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$filename</strong>&nbsp;&nbsp;</td>
        <td>File to read.</td>
      </tr>
		      <tr>
        <td class="type">$incpath&nbsp;&nbsp;</td>
        <td><strong>$incpath</strong>&nbsp;&nbsp;</td>
        <td>See the PHP documentation</td>
      </tr>
		      <tr>
        <td class="type">$resource_context&nbsp;&nbsp;</td>
        <td><strong>$resource_context</strong>&nbsp;&nbsp;</td>
        <td>See the PHP documentation</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionfind_require_dir"></a>
	<h3>find_require_dir <span class="smalllinenumber">[line 506]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string find_require_dir(
string $dir_path, string $require_dir, [string $fatal_error = true])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Finds a folder according to the user language. You find the file in a folder in which there is one folder per lang. If it doesn't exist, you want to choose the file in another language. This function returns the path of an existing file (if the required lang exists, it will be it, otherwise it will be one of the existing files).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The path of the folder you search.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$dir_path</strong>&nbsp;&nbsp;</td>
        <td>Path of the folder in which you want to search</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$require_dir</strong>&nbsp;&nbsp;</td>
        <td>Default folder</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fatal_error</strong>&nbsp;&nbsp;</td>
        <td>true if you want to throw a fatal error if no file could be found, false otherwise.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionget_ini_config"></a>
	<h3>get_ini_config <span class="smalllinenumber">[line 472]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string get_ini_config(
string $dir_path, string $require_dir, [string $ini_name = &#039;config.ini&#039;])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns the config field of a module configuration file. In fact, this field contains the default module configuration in which we can find some &quot; characters. To solve the problem, this field is considered as a comment and when we want to retrieve its value, we have to call this method which returns its value.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The config field value.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$dir_path</strong>&nbsp;&nbsp;</td>
        <td>Path in which is the file (stop just before the lang folder)</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$require_dir</strong>&nbsp;&nbsp;</td>
        <td>Lang folder in which must be the file</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$ini_name</strong>&nbsp;&nbsp;</td>
        <td>Config file name</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionget_module_name"></a>
	<h3>get_module_name <span class="smalllinenumber">[line 543]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string get_module_name(
)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Retrieves the identifier (name of the folder) of the module which is currently executed.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The module identifier.</li></ul>
    </div>
    <br /><br />
	
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionget_start_page"></a>
	<h3>get_start_page <span class="smalllinenumber">[line 600]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>The get_start_page(
)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Retrieves the site start page.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> absolute start page URL.</li></ul>
    </div>
    <br /><br />
	
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionget_uid"></a>
	<h3>get_uid <span class="smalllinenumber">[line 1184]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>int get_uid(
)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns a unique identifier (useful for example to generate some javascript ids)</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Id</li></ul>
    </div>
    <br /><br />
	
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionget_ulang"></a>
	<h3>get_ulang <span class="smalllinenumber">[line 242]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string get_ulang(
)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns the current user's language.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The lang identifier (name of its folder).</li></ul>
    </div>
    <br /><br />
	
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionget_utheme"></a>
	<h3>get_utheme <span class="smalllinenumber">[line 232]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string get_utheme(
)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns the current user's theme.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The theme identifier (name of its folder).</li></ul>
    </div>
    <br /><br />
	
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functiongmdate_format"></a>
	<h3>gmdate_format <span class="smalllinenumber">[line 786]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string gmdate_format(
string $format, [int $timestamp = false], [int $timezone_system = 0])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Formats a date according to a specific form.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The formatted date</li><li><strong>see:</strong> <a href="../util/Date.php#methodformat">Date::format()</a></li><li><strong>deprecated:</strong> </li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$format</strong>&nbsp;&nbsp;</td>
        <td>Formatting name (date_format, date_format_tiny, date_format_short, date_format_long)</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$timestamp</strong>&nbsp;&nbsp;</td>
        <td>Time to format (UNIX timestamp)</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$timezone_system</strong>&nbsp;&nbsp;</td>
        <td>Time zone (1 for the site time zone, 2 for the server time zone and 0 for the user timezone)</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionhtmlspecialchars_decode"></a>
	<h3>htmlspecialchars_decode <span class="smalllinenumber">[line 1070]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void htmlspecialchars_decode(
 $string, [ $quote_style = null])</code>
    </td></tr></table>
    </td></tr></table><br />

		    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$string</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$quote_style</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionhtml_entity_decode"></a>
	<h3>html_entity_decode <span class="smalllinenumber">[line 1044]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void html_entity_decode(
 $string, [ $quote_style = ENT_COMPAT], [ $charset = null])</code>
    </td></tr></table>
    </td></tr></table><br />

		    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$string</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$quote_style</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$charset</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionimport"></a>
	<h3>import <span class="smalllinenumber">[line 1201]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void import(
string $path, [string $import_type = CLASS_IMPORT])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Umports a class or a lib from the framework</div>    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>Path of the file to load without .class.php or .inc.php extension (for instance util/date)</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$import_type</strong>&nbsp;&nbsp;</td>
        <td>the import type. Default is CLASS_IMPORT, but you could also import a library by using LIB_IMPORT (file whose extension is .inc.php) or INC_IMPORT to include a .inc.php file (for example the current file, functions.inc.php).</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functioninc"></a>
	<h3>inc <span class="smalllinenumber">[line 1236]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>bool inc(
string $file, [bool $once = true])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Includes a file</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the file have been included with success else, false</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>the file to include with an absolute path from the website root</td>
      </tr>
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$once</strong>&nbsp;&nbsp;</td>
        <td>if false use include instead of include_once</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionload_ini_file"></a>
	<h3>load_ini_file <span class="smalllinenumber">[line 383]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string[] load_ini_file(
string $dir_path, string $require_dir, [string $ini_name = &#039;config.ini&#039;])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Loads a configuration file. You choose a bases path, and you specify a folder name in which you file should be found, if it doesn't exist, it will take a file in another folder. It's very interesting when you want to</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The configuration values contained in the file $dir_path/$require_dir/$ini_name.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$dir_path</strong>&nbsp;&nbsp;</td>
        <td>Path of the file (relative from this page).</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$require_dir</strong>&nbsp;&nbsp;</td>
        <td>The name of the folder in which the configuration file should be. This folder must be in the bases file ($dir_path). If this directory doesn't exist, another will be read.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$ini_name</strong>&nbsp;&nbsp;</td>
        <td>The name of the configuration file you want to know.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionload_menu_lang"></a>
	<h3>load_menu_lang <span class="smalllinenumber">[line 370]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void load_menu_lang(
string $menu_name)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Loads a menu lang file. It will load alone the file corresponding to the user lang, but if it doesn't exist, another lang will be choosen. An error will be displayed on the page and the script execution will be stopped if no lang file is found for this menu.</div>    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$menu_name</strong>&nbsp;&nbsp;</td>
        <td>The identifier of the menu for which you want to load the lang file.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionload_module_lang"></a>
	<h3>load_module_lang <span class="smalllinenumber">[line 327]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void load_module_lang(
string $module_name, [string $path = PATH_TO_ROOT])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Loads a module lang file. It will load alone the file corresponding to the user lang, but if it doesn't exist, another lang will be choosen. An error will be displayed on the page and the script execution will be stopped if no lang file is found for this module.</div>    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_name</strong>&nbsp;&nbsp;</td>
        <td>The identifier of the module for which you want to load the lang file.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>Path of the folder in which is the file. This path mustn't finish by the / character.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionnumber_round"></a>
	<h3>number_round <span class="smalllinenumber">[line 1004]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string number_round(
mixed $number, int $dec)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Rounds a number</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The rounded number.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$number</strong>&nbsp;&nbsp;</td>
        <td>Number to round</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$dec</strong>&nbsp;&nbsp;</td>
        <td>The number of decilam points</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionnumeric"></a>
	<h3>numeric <span class="smalllinenumber">[line 209]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>mixed numeric(
string $var, [string $type = &#039;int&#039;])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Converts a string to a numeric value.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The integer or floating value (according to the type you chose).</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$var</strong>&nbsp;&nbsp;</td>
        <td>The value you want to convert.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>'int' if you want to convert to an integer value, 'float' if you want a floating value.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionof_class"></a>
	<h3>of_class <span class="smalllinenumber">[line 1261]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>bool of_class(
 &$object, string $classname, object $object)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Tells if an object is an instance of a class</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the $object is an instance of the $classname class</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">object&nbsp;&nbsp;</td>
        <td><strong>$object</strong>&nbsp;&nbsp;</td>
        <td>the object to check its type</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$classname</strong>&nbsp;&nbsp;</td>
        <td>the classname you want to compare with</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$object</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionpages_displayed"></a>
	<h3>pages_displayed <span class="smalllinenumber">[line 965]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>int[] pages_displayed(
[bool $no_update = false])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">This function is called by the kernel on each displayed page to count the number of pages seen at each hour.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Map associating the hour to the number of seen pages. For instance 14 =&gt; 56 means that at between 14:00 and 15:00 56 pages were generated.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$no_update</strong>&nbsp;&nbsp;</td>
        <td>True if you just want to read the number of pages viewed, false if you want to increment it.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionparse_ini_array"></a>
	<h3>parse_ini_array <span class="smalllinenumber">[line 409]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string[] parse_ini_array(
string $links_format)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Parses a table written in a special syntax which is user-friendly and can be inserted in a ini file (PHP serialized arrays cannot be inserted because they contain the &quot; character). The syntax is very easy, it really looks like the PHP array declaration: key =&gt; value, key2 =&gt; value2 You can nest some elements: key =&gt; (key1 =&gt; value1, key2 =&gt; value2), key2 =&gt; value2</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The unserialized array.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$links_format</strong>&nbsp;&nbsp;</td>
        <td>Serialized array</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionphpboost_version"></a>
	<h3>phpboost_version <span class="smalllinenumber">[line 1322]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string phpboost_version(
)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns the full phpboost version with its build number</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the full phpboost version with its build number</li></ul>
    </div>
    <br /><br />
	
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionredirect"></a>
	<h3>redirect <span class="smalllinenumber">[line 556]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void redirect(
string $url)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Redirects the user to the URL and stops purely the script execution (database deconnexion...).</div>    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>URL at which you want to redirect the user.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionredirect_confirm"></a>
	<h3>redirect_confirm <span class="smalllinenumber">[line 580]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void redirect_confirm(
string $url_error, string $l_error, [int $delay_redirect = 3])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Displays a confirmation message during a defined delay and then redirects the user.</div>    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url_error</strong>&nbsp;&nbsp;</td>
        <td>Url at which you want to redirect him.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$l_error</strong>&nbsp;&nbsp;</td>
        <td>The message to show him</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$delay_redirect</strong>&nbsp;&nbsp;</td>
        <td>Number of seconds after which you want him to be redirected.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionreq"></a>
	<h3>req <span class="smalllinenumber">[line 1211]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>void req(
string $file, [bool $once = true])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Requires a file</div>    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>the file to require with an absolute path from the website root</td>
      </tr>
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$once</strong>&nbsp;&nbsp;</td>
        <td>if false use require instead of require_once</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionretrieve"></a>
	<h3>retrieve <span class="smalllinenumber">[line 72]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>mixed retrieve(
int $var_type, string $var_name, mixed $default_value, [string $force_type = NULL], [int $flags = 0])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Retrieves an input variable. You can retrieve any parameter of the HTTP request which launched the execution of this page.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The value of the variable you wanted to retrieve. Its type is either the same as the default value or the type you forced.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$var_type</strong>&nbsp;&nbsp;</td>
        <td>The origin of the variable: GET if it's a parameter in the request URL, POST if the variable was in a formulary, COOKIE if the variables come from a cookie and FILES if it's a file.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$var_name</strong>&nbsp;&nbsp;</td>
        <td>Name of a HTTP variable you want to retrieve.</td>
      </tr>
		      <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$default_value</strong>&nbsp;&nbsp;</td>
        <td>The value you want the variable you retrieve has if the HTTP parameter doesn't exist.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$force_type</strong>&nbsp;&nbsp;</td>
        <td>Type of the variable you want to retrieve. If you don't use this parameter, the returned variable will have the same type as the default value you imposed. When you force the variable type, a cast operation will be made from string (it's a string in the HTTP request) to the type you choosed. The types you can use are numerous: <ul><li>TINTEGER to retrieve an integer value.</li><li>TSTRING to retrieve a string. The HTML code in this string is protected (XSS protection) and the dangerous MySQL characters are escaped. You can use this variable directly in a MySQL query.
 It you want to use it now without inserting it in a data base, use the stripslashes PHP function.</li><li>TSTRING_UNCHANGE if you want to retrieve the value of a string without any processing (no quotes escaping and no HTML protection).</li><li>TSTRING_PARSE if you want to parse the value you retrieved. The HTML code is protected, it parses with the user parser and the quotes are escaped. Ready to be inserted in a MySQL query !</li><li>TBOOL to retrieve a boolean value.</li><li>TUNSIGNED_INT if you expect an unsigned integer.</li><li>TUNSIGNED_DOUBLE to retrieve an unsigned double value.</li><li>TSTRING_HTML if you don't want to protect the HTML code of the content but you want to escape the quotes.</li><li>TSTRING_AS_RECEIVED if you want to retrieve the string variable as it was in the HTTP request. Be careful, if the magic_quotes are enabled (use the MAGIC_QUOTES constant to know it), the quotes are escaped, otherwise they aren't.</li><li>TARRAY to retrieve an array. The values it contains aren't processed.</li><li>TDOUBLE to retrieve a double value</li><li>TNONE if you want to get the input variable as it has been recieved (the return value will be a string because HTTP parameters are all strings).</li></ul></td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$flags</strong>&nbsp;&nbsp;</td>
        <td>You can change the behaviour of this method: USE_DEFAULT_IF_EMPTY will allow you to retrieve the default value even if the parameter exists but its value is empty (to know if the var is empty, we use the empty() PHP function).</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionsecond_parse"></a>
	<h3>second_parse <span class="smalllinenumber">[line 699]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string second_parse(
 &$content, string $content, string[] $forbidden_tags, bool $addslashes)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Second parses a string with several default parameters. This methods exists to lighten the number of lines written.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The second parsed string.</li><li><strong>see:</strong> <a href="../content/parser/ContentSecondParser.php">ContentSecondParser</a></li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$content</strong>&nbsp;&nbsp;</td>
        <td>Content to second parse</td>
      </tr>
		      <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$forbidden_tags</strong>&nbsp;&nbsp;</td>
        <td>List of the forbidden formatting tags</td>
      </tr>
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$addslashes</strong>&nbsp;&nbsp;</td>
        <td>if true, the second parsed string will be escaped.</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$content</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionsecond_parse_url"></a>
	<h3>second_parse_url <span class="smalllinenumber">[line 716]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string second_parse_url(
 &$url, string $url)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Second parses relative urls to absolute urls.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The second parsed url.</li><li><strong>see:</strong> <a href="../util/Url.php">Url</a></li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>Url to second parse</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$url</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionset_subregex_multiplicity"></a>
	<h3>set_subregex_multiplicity <span class="smalllinenumber">[line 1295]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string set_subregex_multiplicity(
string $sub_regex,  $multiplicity_option, int $occurence)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Returns the sub-regex with its multiplicity option</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the subregex with its multiplicity option</li><li><strong>see:</strong> REGEX_MULTIPLICITY_NOT_USED</li><li><strong>see:</strong> REGEX_MULTIPLICITY_ALL</li><li><strong>see:</strong> REGEX_MULTIPLICITY_AT_LEAST_ONE</li><li><strong>see:</strong> REGEX_MULTIPLICITY_NEEDED</li><li><strong>see:</strong> REGEX_MULTIPLICITY_OPTIONNAL</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$sub_regex</strong>&nbsp;&nbsp;</td>
        <td>the sub-regex on which add the multiplicity</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$occurence</strong>&nbsp;&nbsp;</td>
        <td>REGEX_MULTIPLICITY_OPTION</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$multiplicity_option</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionstrhash"></a>
	<h3>strhash <span class="smalllinenumber">[line 1157]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string strhash(
string $str, [mixed $salt = true])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Return a SHA256 hash of the $str string [with a salt]</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> a SHA256 hash of the $str string [with a salt]</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$str</strong>&nbsp;&nbsp;</td>
        <td>the string to hash</td>
      </tr>
		      <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$salt</strong>&nbsp;&nbsp;</td>
        <td>If true, add the default salt : md5($str) if a string, use this string as the salt if false, do not use any salt</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionstrparse"></a>
	<h3>strparse <span class="smalllinenumber">[line 651]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string strparse(
 &$content, [string[] $forbidden_tags = array()], [bool $addslashes = true], string $content)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Parses a string with several default parameters. This methods exists to lighten the number of lines written.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The parsed string.</li><li><strong>see:</strong> <a href="../content/parser/ContentParser.php">ContentParser</a></li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$content</strong>&nbsp;&nbsp;</td>
        <td>Content to parse</td>
      </tr>
		      <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$forbidden_tags</strong>&nbsp;&nbsp;</td>
        <td>List of the forbidden formatting tags</td>
      </tr>
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$addslashes</strong>&nbsp;&nbsp;</td>
        <td>if true, the parsed string will be escaped.</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$content</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionstrprotect"></a>
	<h3>strprotect <span class="smalllinenumber">[line 168]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string strprotect(
string $var, [bool $html_protect = HTML_PROTECT], [int $addslashes = ADDSLASHES_AUTO])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Protects an input variable. Never trust user input!</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The protected string.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$var</strong>&nbsp;&nbsp;</td>
        <td>Variable to protect.</td>
      </tr>
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$html_protect</strong>&nbsp;&nbsp;</td>
        <td>HTML_PROTECT if you don't accept the HTML code (it will be transformed  by the corresponding HTML entities and won't be considerer by the web browsers). HTML_UNPROTECT if you want to let them.</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$addslashes</strong>&nbsp;&nbsp;</td>
        <td>If you want to escape the quotes in the string, use ADDSLASHES_FORCE, if you don't want, use the ADDSLASHES_NONE constant. If you want to escape them only if they have not been escaped automatically by the magic quotes option, use the ADDSLASHES_AUTO constant.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionstrtodate"></a>
	<h3>strtodate <span class="smalllinenumber">[line 903]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string strtodate(
string $str, string $date_format)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Converts a formatted date to the SQL date format.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The formatted date</li><li><strong>deprecated:</strong> </li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$str</strong>&nbsp;&nbsp;</td>
        <td>Formatted date</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$date_format</strong>&nbsp;&nbsp;</td>
        <td>Formatting pattern (DD for the day, MM for the month and YYYY for the year separated only by / characters).</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionstrtotimestamp"></a>
	<h3>strtotimestamp <span class="smalllinenumber">[line 852]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>int strtotimestamp(
string $str, string $date_format)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Parses a formatted date</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The timestamp corresponding to the parsed date or 0 if it couldn't be parsed.</li><li><strong>see:</strong> <a href="../util/Date.php#methodDate">Date::Date()</a></li><li><strong>deprecated:</strong> </li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$str</strong>&nbsp;&nbsp;</td>
        <td>String to parse</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$date_format</strong>&nbsp;&nbsp;</td>
        <td>Formatting pattern (d for day, m for month and y for year, for instance m/d/y)</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionsubstr_html"></a>
	<h3>substr_html <span class="smalllinenumber">[line 273]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string substr_html(
 &$str, int $start, [int $end = &#039;&#039;], string $str)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Cuts a string containing some HTML code which contains some HTML entities. The substr PHP function considers a HTML entity as several characters. This function allows you to consider them as only one character.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The sub string.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$str</strong>&nbsp;&nbsp;</td>
        <td>The string you want to cut.</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$start</strong>&nbsp;&nbsp;</td>
        <td>If start  is non-negative, the returned string will start at the start 'th position in string , counting from zero. For instance, in the string 'abcdef', the character at position 0 is 'a', the character at position 2 is 'c', and so forth. If start is negative, the returned string will start at the start 'th character from the end of string . If string is less than or equal to start characters long, FALSE will be returned.</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$end</strong>&nbsp;&nbsp;</td>
        <td>If length is given and is positive, the string returned will contain at most length  characters beginning from start  (depending on the length of string ).</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$str</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionto_js_string"></a>
	<h3>to_js_string <span class="smalllinenumber">[line 1277]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string to_js_string(
string $string)</code>
    </td></tr></table>
    </td></tr></table><br />

		    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The js equivalent string</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$string</strong>&nbsp;&nbsp;</td>
        <td>A PHP string to convert to a JS one</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionunparse"></a>
	<h3>unparse <span class="smalllinenumber">[line 681]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string unparse(
 &$content, string $content, string[] $forbidden_tags, bool $addslashes)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Unparses a string with several default parameters. This methods exists to lighten the number of lines written.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The unparsed string.</li><li><strong>see:</strong> <a href="../content/parser/ContentUnparser.php">ContentUnparser</a></li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$content</strong>&nbsp;&nbsp;</td>
        <td>Content to unparse</td>
      </tr>
		      <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$forbidden_tags</strong>&nbsp;&nbsp;</td>
        <td>List of the forbidden formatting tags</td>
      </tr>
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$addslashes</strong>&nbsp;&nbsp;</td>
        <td>if true, the unparsed string will be escaped.</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$content</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionurl"></a>
	<h3>url <span class="smalllinenumber">[line 731]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string url(
string $url, [string $mod_rewrite = &#039;&#039;], [string $ampersand = &#039;&amp;amp;amp;&#039;])</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Adds the session ID to an URL if the user doesn't accepts cookies. This functions allows you to generate an URL according to the site configuration concerning the URL rewriting.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The URL to use.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>URL if the URL rewriting is disabled</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mod_rewrite</strong>&nbsp;&nbsp;</td>
        <td>URL if the URL rewriting is enabled</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$ampersand</strong>&nbsp;&nbsp;</td>
        <td>In a redirection you mustn't put the &amp; HTML entity (&amp;amp;). In this case set that parameter to &amp;.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionurl_encode_rewrite"></a>
	<h3>url_encode_rewrite <span class="smalllinenumber">[line 766]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string url_encode_rewrite(
string $string)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Prepares a string for it to be used in an URL (with only a-z, 0-9 and - characters).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The encoded string.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$string</strong>&nbsp;&nbsp;</td>
        <td>String to encode.</td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>
  <hr />
	<a name="functionwordwrap_html"></a>
	<h3>wordwrap_html <span class="smalllinenumber">[line 257]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>string wordwrap_html(
 &$str, int $lenght, [string $cut_char = &#039;&amp;lt;br /&amp;gt;&#039;], [bool $cut = true], string $str)</code>
    </td></tr></table>
    </td></tr></table><br />

		<div class="description">Inserts a carriage return every $lenght characters. It's equivalent to wordwrap PHP function but it can deal with the HTML entities. An entity is coded on several characters and the wordwrap function counts several characters for an entity whereas it represents only one character.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The wrapped HTML string.</li></ul>
    </div>
    <br /><br />
	
    		<h4>Parameters</h4>
    <table border="0" cellspacing="0" cellpadding="0">
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$str</strong>&nbsp;&nbsp;</td>
        <td>The string to wrap.</td>
      </tr>
		      <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$lenght</strong>&nbsp;&nbsp;</td>
        <td>The number of characters you want in a line.</td>
      </tr>
		      <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$cut_char</strong>&nbsp;&nbsp;</td>
        <td>The character to insert every $lenght characters. The default value is '<br />', the HTML carriage return tag.</td>
      </tr>
		      <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$cut</strong>&nbsp;&nbsp;</td>
        <td>True if you accept that a word would be broken apart, false if you want to cut only on a blank character.</td>
      </tr>
		      <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$str</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
				</table>
    	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
	</div>

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                    
                                                                                                                                                                                                                                                <a href="../classtrees_phpboost.php" class="menu">class tree: phpboost</a> -
            <a href="../elementindex_phpboost.php" class="menu">index: phpboost</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:48 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>