<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'core - Docs For Class BreadCrumb');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('core', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">core</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                    
                                                                                                                                                                                                                                                            <a href="../classtrees_core.php" class="menu">class tree: core</a> - 
                <a href="../elementindex_core.php" class="menu">index: core</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/Application.php">Application</a>            </li>
                    <li>
                <a href="../core/BreadCrumb.php">BreadCrumb</a>            </li>
                    <li>
                <a href="../core/Cache.php">Cache</a>            </li>
                    <li>
                <a href="../core/Errors.php">Errors</a>            </li>
                    <li>
                <a href="../core/MenuService.php">MenuService</a>            </li>
                    <li>
                <a href="../core/Repository.php">Repository</a>            </li>
                    <li>
                <a href="../core/StatsSaver.php">StatsSaver</a>            </li>
                    <li>
                <a href="../core/Updates.php">Updates</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/_core---application.class.php.php">                application.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---breadcrumb.class.php.php">                breadcrumb.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---cache.class.php.php">                cache.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---errors.class.php.php">                errors.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---menu_service.class.php.php">                menu_service.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---repository.class.php.php">                repository.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---stats_saver.class.php.php">                stats_saver.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---updates.class.php.php">                updates.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: BreadCrumb</h1><p>Source Location: /core/breadcrumb.class.php [line 36]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class is used to represent the bread crumb displayed on each page of the website. It enables the user to locate himself in the whole site. A bread crumb can look like this: Home &gt;&gt; My module &gt;&gt; First level category &gt;&gt; Second level category &gt;&gt; Third level category &gt;&gt; .. &gt;&gt; My page &gt;&gt; Edition</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../core/BreadCrumb.php#methodBreadCrumb">BreadCrumb</a></li><li class="bb_li"><a href="../core/BreadCrumb.php#methodadd">add</a></li><li class="bb_li"><a href="../core/BreadCrumb.php#methodclean">clean</a></li><li class="bb_li"><a href="../core/BreadCrumb.php#methoddisplay">display</a></li><li class="bb_li"><a href="../core/BreadCrumb.php#methodremove_last">remove_last</a></li><li class="bb_li"><a href="../core/BreadCrumb.php#methodreverse">reverse</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../core/BreadCrumb.php#var$array_links">$array_links</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class is used to represent the bread crumb displayed on each page of the website. It enables the user to locate himself in the whole site. A bread crumb can look like this: Home &gt;&gt; My module &gt;&gt; First level category &gt;&gt; Second level category &gt;&gt; Third level category &gt;&gt; .. &gt;&gt; My page &gt;&gt; Edition</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodBreadCrumb"></a>
    <h3>constructor BreadCrumb <span class="smalllinenumber">[line 41]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>BreadCrumb BreadCrumb(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a BreadCrumb object.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadd"></a>
    <h3>method add <span class="smalllinenumber">[line 50]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void add(
string
$text, [string
$target = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Adds a link in the bread crumb. This link will be put at the end of the list.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$text</strong>&nbsp;&nbsp;</td>
        <td>Name of the page</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$target</strong>&nbsp;&nbsp;</td>
        <td>Link whose target is the page</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodclean"></a>
    <h3>method clean <span class="smalllinenumber">[line 113]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void clean(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Removes all the existing links.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 83]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void display(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Displays the bread crumb.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodremove_last"></a>
    <h3>method remove_last <span class="smalllinenumber">[line 75]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void remove_last(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Removes the last link of the list</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodreverse"></a>
    <h3>method reverse <span class="smalllinenumber">[line 67]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void reverse(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Reverses the whole list of the links. It's very useful when it's easier for you to make the list in the reverse way, at the end, you only need to reverse the list and it will be ok.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                <div class="var">
                            <a name="var_array_links"></a>
                <span class="line-number">[line 122]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$array_links</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                
                                                                                                                                                                                    <a href="../classtrees_core.php" class="menu">class tree: core</a> -
            <a href="../elementindex_core.php" class="menu">index: core</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:20 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>