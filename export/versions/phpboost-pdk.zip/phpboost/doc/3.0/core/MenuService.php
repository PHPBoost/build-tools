<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'core - Docs For Class MenuService');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('core', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">core</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                    
                                                                                                                                                                                                                                                            <a href="../classtrees_core.php" class="menu">class tree: core</a> - 
                <a href="../elementindex_core.php" class="menu">index: core</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/Application.php">Application</a>            </li>
                    <li>
                <a href="../core/BreadCrumb.php">BreadCrumb</a>            </li>
                    <li>
                <a href="../core/Cache.php">Cache</a>            </li>
                    <li>
                <a href="../core/Errors.php">Errors</a>            </li>
                    <li>
                <a href="../core/MenuService.php">MenuService</a>            </li>
                    <li>
                <a href="../core/Repository.php">Repository</a>            </li>
                    <li>
                <a href="../core/StatsSaver.php">StatsSaver</a>            </li>
                    <li>
                <a href="../core/Updates.php">Updates</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/_core---application.class.php.php">                application.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---breadcrumb.class.php.php">                breadcrumb.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---cache.class.php.php">                cache.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---errors.class.php.php">                errors.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---menu_service.class.php.php">                menu_service.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---repository.class.php.php">                repository.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---stats_saver.class.php.php">                stats_saver.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---updates.class.php.php">                updates.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: MenuService</h1><p>Source Location: /core/menu_service.class.php [line 46]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This service manage kernel menus by adding the persistance to menus objects. It also provides all moving and disabling methods to change the website appearance.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../core/MenuService.php#methodadd_mini_menu">add_mini_menu</a></li><li class="bb_li"><a href="../core/MenuService.php#methodadd_mini_module">add_mini_module</a></li><li class="bb_li"><a href="../core/MenuService.php#methodassign_positions_conditions">assign_positions_conditions</a></li><li class="bb_li"><a href="../core/MenuService.php#methodchange_position">change_position</a></li><li class="bb_li"><a href="../core/MenuService.php#methoddelete">delete</a></li><li class="bb_li"><a href="../core/MenuService.php#methoddelete_mini_menu">delete_mini_menu</a></li><li class="bb_li"><a href="../core/MenuService.php#methoddelete_mini_module">delete_mini_module</a></li><li class="bb_li"><a href="../core/MenuService.php#methoddelete_module_feeds_menus">delete_module_feeds_menus</a></li><li class="bb_li"><a href="../core/MenuService.php#methoddisable">disable</a></li><li class="bb_li"><a href="../core/MenuService.php#methodenable">enable</a></li><li class="bb_li"><a href="../core/MenuService.php#methodenable_all">enable_all</a></li><li class="bb_li"><a href="../core/MenuService.php#methodgenerate_cache">generate_cache</a></li><li class="bb_li"><a href="../core/MenuService.php#methodget_menus_map">get_menus_map</a></li><li class="bb_li"><a href="../core/MenuService.php#methodget_menu_list">get_menu_list</a></li><li class="bb_li"><a href="../core/MenuService.php#methodload">load</a></li><li class="bb_li"><a href="../core/MenuService.php#methodmove">move</a></li><li class="bb_li"><a href="../core/MenuService.php#methodsave">save</a></li><li class="bb_li"><a href="../core/MenuService.php#methodstr_to_location">str_to_location</a></li><li class="bb_li"><a href="../core/MenuService.php#methodupdate_mini_menus_list">update_mini_menus_list</a></li><li class="bb_li"><a href="../core/MenuService.php#methodupdate_mini_modules_list">update_mini_modules_list</a></li><li class="bb_li"><a href="../core/MenuService.php#methodwebsite_modules">website_modules</a></li></ul>
    </div>
    </td>
<!--
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This service manage kernel menus by adding the persistance to menus objects. It also provides all moving and disabling methods to change the website appearance.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodadd_mini_menu"></a>
    <h3>method add_mini_menu <span class="smalllinenumber">[line 396]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool add_mini_menu(
<a href="../io/filesystem/Folder.php">Folder</a>
$menu, 
&$installed_menus_names)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Add the menu named in the $menu folder</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the menu has been installed, else, false</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../io/filesystem/Folder.php">Folder</a>&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>the menu folder</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$installed_menus_names</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadd_mini_module"></a>
    <h3>method add_mini_module <span class="smalllinenumber">[line 490]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool add_mini_module(
string
$module, [
$generate_cache = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Add the module named $module mini modules</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the module has been installed, else, false</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td>the module name</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$generate_cache</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodassign_positions_conditions"></a>
    <h3>method assign_positions_conditions <span class="smalllinenumber">[line 678]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void assign_positions_conditions(
&Template
&$template, int
$position)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Assigns the positions conditions for different printing modes</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&Template&nbsp;&nbsp;</td>
        <td><strong>&$template</strong>&nbsp;&nbsp;</td>
        <td>the template to use</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$position</strong>&nbsp;&nbsp;</td>
        <td>the menu position</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodchange_position"></a>
    <h3>method change_position <span class="smalllinenumber">[line 269]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void change_position(

&$menu, [
$direction = MOVE_UP], <a href="../menu/Menu.php">Menu</a>
$menu, int
$diff)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Change the menu position in a block</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../menu/Menu.php">Menu</a>&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>The menu to move</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$diff</strong>&nbsp;&nbsp;</td>
        <td>the direction to move it. positives integers move down, negatives, up.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$menu</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$direction</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete"></a>
    <h3>method delete <span class="smalllinenumber">[line 191]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete(

&$menu, mixed
$menu)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Delete a Menu from the database</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>The (Menu) Menu or its (int) id to delete from the database</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$menu</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete_mini_menu"></a>
    <h3>method delete_mini_menu <span class="smalllinenumber">[line 427]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete_mini_menu(
string
$menu)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">delete the mini menu named $menu</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>the mini menu name</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete_mini_module"></a>
    <h3>method delete_mini_module <span class="smalllinenumber">[line 542]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete_mini_module(
string
$module)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">delete the mini module $module</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td>the mini module name</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete_module_feeds_menus"></a>
    <h3>method delete_module_feeds_menus <span class="smalllinenumber">[line 612]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete_module_feeds_menus(
string
$module_id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Delete all the feeds menus with the this module id</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>the module id</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisable"></a>
    <h3>method disable <span class="smalllinenumber">[line 219]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void disable(

&$menu, <a href="../menu/Menu.php">Menu</a>
$menu)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Disable a menu</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../menu/Menu.php">Menu</a>&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>the menu to disable</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$menu</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodenable"></a>
    <h3>method enable <span class="smalllinenumber">[line 209]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void enable(

&$menu, <a href="../menu/Menu.php">Menu</a>
$menu)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Enable a menu</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../menu/Menu.php">Menu</a>&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>the menu to enable</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$menu</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodenable_all"></a>
    <h3>method enable_all <span class="smalllinenumber">[line 323]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void enable_all(
[bool
$enable = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Enables or disables all menus</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$enable</strong>&nbsp;&nbsp;</td>
        <td>if true enables all menus otherwise, disables them</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_cache"></a>
    <h3>method generate_cache <span class="smalllinenumber">[line 345]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_cache(
[
$return_string = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Generate the cache</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$return_string</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_menus_map"></a>
    <h3>method get_menus_map <span class="smalllinenumber">[line 87]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>unknown_type get_menus_map(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_menu_list"></a>
    <h3>method get_menu_list <span class="smalllinenumber">[line 55]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>unknown_type get_menu_list(
[$block
$class = MENU__CLASS], [$enabled
$block = BLOCK_POSITION__ALL], [
$enabled = MENU_ENABLE_OR_NOT])</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$block&nbsp;&nbsp;</td>
        <td><strong>$class</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">$enabled&nbsp;&nbsp;</td>
        <td><strong>$block</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$enabled</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodload"></a>
    <h3>method load <span class="smalllinenumber">[line 123]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../menu/Menu.php">Menu</a> load(
int
$id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Retrieve a Menu Object from the database by its id</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the requested Menu if it exists else, null</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>the id of the Menu to retrieve from the database</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodmove"></a>
    <h3>method move <span class="smalllinenumber">[line 231]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void move(

&$menu, int
$block, [bool
$save = true], <a href="../menu/Menu.php">Menu</a>
$menu)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Move a menu into a block and save it. Enable or disable it according to the destination block</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../menu/Menu.php">Menu</a>&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>the menu to move</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$block</strong>&nbsp;&nbsp;</td>
        <td>the destination block</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$save</strong>&nbsp;&nbsp;</td>
        <td>if true, save also the menu</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$menu</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodsave"></a>
    <h3>method save <span class="smalllinenumber">[line 141]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool save(

&$menu, <a href="../menu/Menu.php">Menu</a>
$menu)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">save a Menu in the database</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the save have been correctly done</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../menu/Menu.php">Menu</a>&nbsp;&nbsp;</td>
        <td><strong>$menu</strong>&nbsp;&nbsp;</td>
        <td>The Menu to save</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$menu</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodstr_to_location"></a>
    <h3>method str_to_location <span class="smalllinenumber">[line 701]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int str_to_location(
string
$str_location)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Convert the string location the int location</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the corresponding location</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$str_location</strong>&nbsp;&nbsp;</td>
        <td>the location</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodupdate_mini_menus_list"></a>
    <h3>method update_mini_menus_list <span class="smalllinenumber">[line 444]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void update_mini_menus_list(
[bool
$update_cache = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Update the mini menus list by adding new ones and delete old ones</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$update_cache</strong>&nbsp;&nbsp;</td>
        <td>if true it will also regenerate the cache</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodupdate_mini_modules_list"></a>
    <h3>method update_mini_modules_list <span class="smalllinenumber">[line 559]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void update_mini_modules_list(
[bool
$update_cache = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Update the mini modules list by adding new ones and delete old ones</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$update_cache</strong>&nbsp;&nbsp;</td>
        <td>if true it will also regenerate the cache</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodwebsite_modules"></a>
    <h3>method website_modules <span class="smalllinenumber">[line 629]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../menu/linksmenu/LinksMenu.php">LinksMenu</a> website_modules(
[int
$menu_type = VERTICAL_MENU])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Return a menu with links to modules</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the menu with links to modules</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$menu_type</strong>&nbsp;&nbsp;</td>
        <td>the menu type</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>






            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                
                                                                                                                                                                                    <a href="../classtrees_core.php" class="menu">class tree: core</a> -
            <a href="../elementindex_core.php" class="menu">index: core</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:26 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>