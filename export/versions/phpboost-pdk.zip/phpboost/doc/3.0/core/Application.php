<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'core - Docs For Class Application');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('core', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">core</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                    
                                                                                                                                                                                                                                                            <a href="../classtrees_core.php" class="menu">class tree: core</a> - 
                <a href="../elementindex_core.php" class="menu">index: core</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/Application.php">Application</a>            </li>
                    <li>
                <a href="../core/BreadCrumb.php">BreadCrumb</a>            </li>
                    <li>
                <a href="../core/Cache.php">Cache</a>            </li>
                    <li>
                <a href="../core/Errors.php">Errors</a>            </li>
                    <li>
                <a href="../core/MenuService.php">MenuService</a>            </li>
                    <li>
                <a href="../core/Repository.php">Repository</a>            </li>
                    <li>
                <a href="../core/StatsSaver.php">StatsSaver</a>            </li>
                    <li>
                <a href="../core/Updates.php">Updates</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/_core---application.class.php.php">                application.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---breadcrumb.class.php.php">                breadcrumb.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---cache.class.php.php">                cache.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---errors.class.php.php">                errors.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---menu_service.class.php.php">                menu_service.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---repository.class.php.php">                repository.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---stats_saver.class.php.php">                stats_saver.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---updates.class.php.php">                updates.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Application</h1><p>Source Location: /core/application.class.php [line 40]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description"></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../core/Application.php#methodApplication">Application</a></li><li class="bb_li"><a href="../core/Application.php#methodcheck_compatibility">check_compatibility</a></li><li class="bb_li"><a href="../core/Application.php#methodget_authors">get_authors</a></li><li class="bb_li"><a href="../core/Application.php#methodget_bug_corrections">get_bug_corrections</a></li><li class="bb_li"><a href="../core/Application.php#methodget_compatibility_max">get_compatibility_max</a></li><li class="bb_li"><a href="../core/Application.php#methodget_compatibility_min">get_compatibility_min</a></li><li class="bb_li"><a href="../core/Application.php#methodget_description">get_description</a></li><li class="bb_li"><a href="../core/Application.php#methodget_download_url">get_download_url</a></li><li class="bb_li"><a href="../core/Application.php#methodget_id">get_id</a></li><li class="bb_li"><a href="../core/Application.php#methodget_identifier">get_identifier</a></li><li class="bb_li"><a href="../core/Application.php#methodget_improvments">get_improvments</a></li><li class="bb_li"><a href="../core/Application.php#methodget_language">get_language</a></li><li class="bb_li"><a href="../core/Application.php#methodget_localized_language">get_localized_language</a></li><li class="bb_li"><a href="../core/Application.php#methodget_name">get_name</a></li><li class="bb_li"><a href="../core/Application.php#methodget_new_features">get_new_features</a></li><li class="bb_li"><a href="../core/Application.php#methodget_priority">get_priority</a></li><li class="bb_li"><a href="../core/Application.php#methodget_pubdate">get_pubdate</a></li><li class="bb_li"><a href="../core/Application.php#methodget_repository">get_repository</a></li><li class="bb_li"><a href="../core/Application.php#methodget_security_improvments">get_security_improvments</a></li><li class="bb_li"><a href="../core/Application.php#methodget_security_update">get_security_update</a></li><li class="bb_li"><a href="../core/Application.php#methodget_type">get_type</a></li><li class="bb_li"><a href="../core/Application.php#methodget_update_url">get_update_url</a></li><li class="bb_li"><a href="../core/Application.php#methodget_version">get_version</a></li><li class="bb_li"><a href="../core/Application.php#methodget_warning">get_warning</a></li><li class="bb_li"><a href="../core/Application.php#methodget_warning_level">get_warning_level</a></li><li class="bb_li"><a href="../core/Application.php#methodload">load</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../core/Application.php#var$authors">$authors</a></li><li class="bb_li"><a href="../core/Application.php#var$bug_corrections">$bug_corrections</a></li><li class="bb_li"><a href="../core/Application.php#var$compatibility_max">$compatibility_max</a></li><li class="bb_li"><a href="../core/Application.php#var$compatibility_min">$compatibility_min</a></li><li class="bb_li"><a href="../core/Application.php#var$description">$description</a></li><li class="bb_li"><a href="../core/Application.php#var$download_url">$download_url</a></li><li class="bb_li"><a href="../core/Application.php#var$id">$id</a></li><li class="bb_li"><a href="../core/Application.php#var$improvments">$improvments</a></li><li class="bb_li"><a href="../core/Application.php#var$language">$language</a></li><li class="bb_li"><a href="../core/Application.php#var$localized_language">$localized_language</a></li><li class="bb_li"><a href="../core/Application.php#var$name">$name</a></li><li class="bb_li"><a href="../core/Application.php#var$new_features">$new_features</a></li><li class="bb_li"><a href="../core/Application.php#var$priority">$priority</a></li><li class="bb_li"><a href="../core/Application.php#var$pubdate">$pubdate</a></li><li class="bb_li"><a href="../core/Application.php#var$repository">$repository</a></li><li class="bb_li"><a href="../core/Application.php#var$security_improvments">$security_improvments</a></li><li class="bb_li"><a href="../core/Application.php#var$security_update">$security_update</a></li><li class="bb_li"><a href="../core/Application.php#var$type">$type</a></li><li class="bb_li"><a href="../core/Application.php#var$update_url">$update_url</a></li><li class="bb_li"><a href="../core/Application.php#var$version">$version</a></li><li class="bb_li"><a href="../core/Application.php#var$warning">$warning</a></li><li class="bb_li"><a href="../core/Application.php#var$warning_level">$warning_level</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags">    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodApplication"></a>
    <h3>constructor Application <span class="smalllinenumber">[line 50]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Application Application(
$id
$id, $language
$language, [$type
$type = APPLICATION_TYPE__MODULE], [$version
$version = 0], [$repository
$repository = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">constructor of the class</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$id&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">$language&nbsp;&nbsp;</td>
        <td><strong>$language</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">$type&nbsp;&nbsp;</td>
        <td><strong>$type</strong>&nbsp;&nbsp;</td>
        <td>see APPLICATION_TYPE_xxx constants</td>
      </tr>
          <tr>
        <td class="type">$version&nbsp;&nbsp;</td>
        <td><strong>$version</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">$repository&nbsp;&nbsp;</td>
        <td><strong>$repository</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcheck_compatibility"></a>
    <h3>method check_compatibility <span class="smalllinenumber">[line 175]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>boolean check_compatibility(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Checks compatibility with limits</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> TRUE if compatible FALSE if not</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_authors"></a>
    <h3>method get_authors <span class="smalllinenumber">[line 283]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_authors(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Authors</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_bug_corrections"></a>
    <h3>method get_bug_corrections <span class="smalllinenumber">[line 299]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_bug_corrections(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Bug Corrections Text</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_compatibility_max"></a>
    <h3>method get_compatibility_max <span class="smalllinenumber">[line 259]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_compatibility_max(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Compatibility Max value</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_compatibility_min"></a>
    <h3>method get_compatibility_min <span class="smalllinenumber">[line 255]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_compatibility_min(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Compatibility min value</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_description"></a>
    <h3>method get_description <span class="smalllinenumber">[line 287]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_description(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Description Text</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_download_url"></a>
    <h3>method get_download_url <span class="smalllinenumber">[line 275]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_download_url(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Download URL</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_id"></a>
    <h3>method get_id <span class="smalllinenumber">[line 227]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_id(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of id</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_identifier"></a>
    <h3>method get_identifier <span class="smalllinenumber">[line 167]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_identifier(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Gets an identifier of the application</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> identifier</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_improvments"></a>
    <h3>method get_improvments <span class="smalllinenumber">[line 295]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_improvments(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Improvments Text</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_language"></a>
    <h3>method get_language <span class="smalllinenumber">[line 235]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_language(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Language</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_localized_language"></a>
    <h3>method get_localized_language <span class="smalllinenumber">[line 239]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_localized_language(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Localized language</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_name"></a>
    <h3>method get_name <span class="smalllinenumber">[line 231]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of name</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_new_features"></a>
    <h3>method get_new_features <span class="smalllinenumber">[line 291]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_new_features(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of New Features Text</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_priority"></a>
    <h3>method get_priority <span class="smalllinenumber">[line 267]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_priority(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Priority</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_pubdate"></a>
    <h3>method get_pubdate <span class="smalllinenumber">[line 263]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_pubdate(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Publication Date</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_repository"></a>
    <h3>method get_repository <span class="smalllinenumber">[line 247]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_repository(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Repository</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_security_improvments"></a>
    <h3>method get_security_improvments <span class="smalllinenumber">[line 303]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_security_improvments(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Security Improvments</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_security_update"></a>
    <h3>method get_security_update <span class="smalllinenumber">[line 271]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_security_update(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Security Update</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_type"></a>
    <h3>method get_type <span class="smalllinenumber">[line 243]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_type(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Type</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_update_url"></a>
    <h3>method get_update_url <span class="smalllinenumber">[line 279]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_update_url(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Update URL</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_version"></a>
    <h3>method get_version <span class="smalllinenumber">[line 251]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_version(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Version</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_warning"></a>
    <h3>method get_warning <span class="smalllinenumber">[line 311]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_warning(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Warning</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_warning_level"></a>
    <h3>method get_warning_level <span class="smalllinenumber">[line 307]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_warning_level(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Accessor of Warning level</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodload"></a>
    <h3>method load <span class="smalllinenumber">[line 67]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void load(
$xml_desc
&$xml_desc)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Loads an XML description</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$xml_desc&nbsp;&nbsp;</td>
        <td><strong>&$xml_desc</strong>&nbsp;&nbsp;</td>
        <td>reference to xml description</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                                                                                    <div class="var">
                            <a name="var_authors"></a>
                <span class="line-number">[line 373]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$authors</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_bug_corrections"></a>
                <span class="line-number">[line 378]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$bug_corrections</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_compatibility_max"></a>
                <span class="line-number">[line 365]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$compatibility_max</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_compatibility_min"></a>
                <span class="line-number">[line 364]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$compatibility_min</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_description"></a>
                <span class="line-number">[line 375]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$description</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_download_url"></a>
                <span class="line-number">[line 370]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$download_url</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id"></a>
                <span class="line-number">[line 355]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_improvments"></a>
                <span class="line-number">[line 377]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$improvments</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_language"></a>
                <span class="line-number">[line 357]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$language</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_localized_language"></a>
                <span class="line-number">[line 358]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$localized_language</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_name"></a>
                <span class="line-number">[line 356]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_new_features"></a>
                <span class="line-number">[line 376]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$new_features</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_priority"></a>
                <span class="line-number">[line 367]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$priority</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_pubdate"></a>
                <span class="line-number">[line 366]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$pubdate</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_repository"></a>
                <span class="line-number">[line 361]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$repository</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_security_improvments"></a>
                <span class="line-number">[line 379]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$security_improvments</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_security_update"></a>
                <span class="line-number">[line 368]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$security_update</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;false</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_type"></a>
                <span class="line-number">[line 359]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$type</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_update_url"></a>
                <span class="line-number">[line 371]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$update_url</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_version"></a>
                <span class="line-number">[line 363]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$version</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_warning"></a>
                <span class="line-number">[line 382]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$warning</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_warning_level"></a>
                <span class="line-number">[line 381]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$warning_level</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                
                                                                                                                                                                                    <a href="../classtrees_core.php" class="menu">class tree: core</a> -
            <a href="../elementindex_core.php" class="menu">index: core</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:37 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>