<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'core - Docs For Class Updates');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('core', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">core</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                    
                                                                                                                                                                                                                                                            <a href="../classtrees_core.php" class="menu">class tree: core</a> - 
                <a href="../elementindex_core.php" class="menu">index: core</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/Application.php">Application</a>            </li>
                    <li>
                <a href="../core/BreadCrumb.php">BreadCrumb</a>            </li>
                    <li>
                <a href="../core/Cache.php">Cache</a>            </li>
                    <li>
                <a href="../core/Errors.php">Errors</a>            </li>
                    <li>
                <a href="../core/MenuService.php">MenuService</a>            </li>
                    <li>
                <a href="../core/Repository.php">Repository</a>            </li>
                    <li>
                <a href="../core/StatsSaver.php">StatsSaver</a>            </li>
                    <li>
                <a href="../core/Updates.php">Updates</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/_core---application.class.php.php">                application.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---breadcrumb.class.php.php">                breadcrumb.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---cache.class.php.php">                cache.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---errors.class.php.php">                errors.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---menu_service.class.php.php">                menu_service.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---repository.class.php.php">                repository.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---stats_saver.class.php.php">                stats_saver.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---updates.class.php.php">                updates.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Updates</h1><p>Source Location: /core/updates.class.php [line 45]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description"></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../core/Updates.php#methodUpdates">Updates</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../core/Updates.php#var$apps">$apps</a></li><li class="bb_li"><a href="../core/Updates.php#var$repositories">$repositories</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags">    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodUpdates"></a>
    <h3>constructor Updates <span class="smalllinenumber">[line 51]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Updates Updates(
[$checks
$checks = CHECK_ALL_UPDATES])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">constructor of the class</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$checks&nbsp;&nbsp;</td>
        <td><strong>$checks</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                    <div class="var">
                            <a name="var_apps"></a>
                <span class="line-number">[line 170]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$apps</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_repositories"></a>
                <span class="line-number">[line 169]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$repositories</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                
                                                                                                                                                                                    <a href="../classtrees_core.php" class="menu">class tree: core</a> -
            <a href="../elementindex_core.php" class="menu">index: core</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:54 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>