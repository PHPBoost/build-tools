<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'core - Docs For Class Cache');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('core', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">core</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                    
                                                                                                                                                                                                                                                            <a href="../classtrees_core.php" class="menu">class tree: core</a> - 
                <a href="../elementindex_core.php" class="menu">index: core</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/Application.php">Application</a>            </li>
                    <li>
                <a href="../core/BreadCrumb.php">BreadCrumb</a>            </li>
                    <li>
                <a href="../core/Cache.php">Cache</a>            </li>
                    <li>
                <a href="../core/Errors.php">Errors</a>            </li>
                    <li>
                <a href="../core/MenuService.php">MenuService</a>            </li>
                    <li>
                <a href="../core/Repository.php">Repository</a>            </li>
                    <li>
                <a href="../core/StatsSaver.php">StatsSaver</a>            </li>
                    <li>
                <a href="../core/Updates.php">Updates</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../core/_core---application.class.php.php">                application.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---breadcrumb.class.php.php">                breadcrumb.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---cache.class.php.php">                cache.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---errors.class.php.php">                errors.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---menu_service.class.php.php">                menu_service.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---repository.class.php.php">                repository.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---stats_saver.class.php.php">                stats_saver.class.php
                </a>            </li>
                    <li>
                <a href="../core/_core---updates.class.php.php">                updates.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Cache</h1><p>Source Location: /core/cache.class.php [line 39]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class is the cache manager of PHPBoost. Its functioning is very particular. Loading a file is equivalent to include the file. The cache file must define some PHP global variables. They will be usable in the execution context of the page. You should read on the PHPBoost website the documentation which explains you how to integrate a cache for you module, it's too much complex to be explained here.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../core/Cache.php#methodCache">Cache</a></li><li class="bb_li"><a href="../core/Cache.php#methoddelete_file">delete_file</a></li><li class="bb_li"><a href="../core/Cache.php#methodgenerate_all_files">generate_all_files</a></li><li class="bb_li"><a href="../core/Cache.php#methodgenerate_all_modules">generate_all_modules</a></li><li class="bb_li"><a href="../core/Cache.php#methodgenerate_file">generate_file</a></li><li class="bb_li"><a href="../core/Cache.php#methodgenerate_module_file">generate_module_file</a></li><li class="bb_li"><a href="../core/Cache.php#methodload">load</a></li><li class="bb_li"><a href="../core/Cache.php#methodwrite">write</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../core/Cache.php#var$files">$files</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class is the cache manager of PHPBoost. Its functioning is very particular. Loading a file is equivalent to include the file. The cache file must define some PHP global variables. They will be usable in the execution context of the page. You should read on the PHPBoost website the documentation which explains you how to integrate a cache for you module, it's too much complex to be explained here.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodCache"></a>
    <h3>constructor Cache <span class="smalllinenumber">[line 44]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Cache Cache(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a Cache object. Check if the directory in which the cache is written is writable.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete_file"></a>
    <h3>method delete_file <span class="smalllinenumber">[line 199]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>true delete_file(
string
$file)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes a cache file.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> if the file could be deleted, false otherwise.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>Name of the file to delete.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_all_files"></a>
    <h3>method generate_all_files <span class="smalllinenumber">[line 164]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_all_files(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Regenerates all the cache files managed by the PHPBoost cache manager. This method needs a lot of resource, call it only when you are sure you need it.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_all_modules"></a>
    <h3>method generate_all_modules <span class="smalllinenumber">[line 178]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_all_modules(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Generates all the module cache files.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_file"></a>
    <h3>method generate_file <span class="smalllinenumber">[line 133]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_file(
string
$file)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Generates a file according to the specified method.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>The name of the file to generate.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgenerate_module_file"></a>
    <h3>method generate_module_file <span class="smalllinenumber">[line 143]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void generate_module_file(
string
$module_name, [bool
$no_alert_on_error = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Generates a module file</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_name</strong>&nbsp;&nbsp;</td>
        <td>Name of the module for which you want to generate the cache.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$no_alert_on_error</strong>&nbsp;&nbsp;</td>
        <td>true if you want to display the generation error, false otherwise.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodload"></a>
    <h3>method load <span class="smalllinenumber">[line 61]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void load(
string
$file, [bool
$reload_cache = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Loads a file file.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file</strong>&nbsp;&nbsp;</td>
        <td>Identifier of the cache file (for example the name of your module).</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$reload_cache</strong>&nbsp;&nbsp;</td>
        <td>If the cache file may have been already loaded, RELOAD_CACHE force it to be reloaded, for example if the file has been updated since the first loading.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodwrite"></a>
    <h3>method write <span class="smalllinenumber">[line 216]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void write(
string
$module_name, 
&$cache_string, string
$cache_string)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Writes a cache file.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_name</strong>&nbsp;&nbsp;</td>
        <td>Name of the file to write</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$cache_string</strong>&nbsp;&nbsp;</td>
        <td>Content of the file to write</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$cache_string</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">            <div class="var">
                            <a name="var_files"></a>
                <span class="line-number">[line 658]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <strong>static</strong>
                <span class="var-type">string[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$files</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array('config',&nbsp;'debug',&nbsp;'modules',&nbsp;'menus',&nbsp;'htaccess',&nbsp;'themes',&nbsp;'langs',&nbsp;'css',&nbsp;'day',&nbsp;'groups',&nbsp;'member',&nbsp;'uploads',&nbsp;'com',&nbsp;'ranks',&nbsp;'writingpad',&nbsp;'smileys',&nbsp;'stats')</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                    <table border="0" cellspacing="0" cellpadding="0">
                                            </table>
                </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>        </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                
                                                                                                                                                                                    <a href="../classtrees_core.php" class="menu">class tree: core</a> -
            <a href="../elementindex_core.php" class="menu">index: core</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:28 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>