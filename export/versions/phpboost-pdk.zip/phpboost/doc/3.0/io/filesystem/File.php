<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Docs For Class File');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="../../elementindex_io.php" class="menu">index: io</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="../../io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="../../io/Template.php">Template</a>            </li>
                    <li>
                <a href="../../io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: File</h1><p>Source Location: /io/filesystem/file.class.php [line 47]</p>

<h2>Class Overview</a></h2>
<pre><a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a>
   |
   --File</pre>
<div class="description">This class represents a text file which can be read and written.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt; Nicolas Duhamel &lt;akhenathon2@gmail.com&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../io/filesystem/File.php#methodFile">File</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodclose">close</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methoddelete">delete</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodfinclude">finclude</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodflush">flush</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodfrequire">frequire</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodget_contents">get_contents</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodget_last_access_date">get_last_access_date</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodget_last_modification_date">get_last_modification_date</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodget_lines">get_lines</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodis_open">is_open</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodlock">lock</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodopen">open</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodunlock">unlock</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#methodwrite">write</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../io/filesystem/File.php#var$contents">$contents</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#var$fd">$fd</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#var$lines">$lines</a></li><li class="bb_li"><a href="../../io/filesystem/File.php#var$mode">$mode</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class represents a text file which can be read and written.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt; Nicolas Duhamel &lt;akhenathon2@gmail.com&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFile"></a>
    <h3>constructor File <span class="smalllinenumber">[line 55]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>File File(
string
$path, [int
$mode = READ_WRITE], [bool
$whenopen = OPEN_AFTER])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a File object.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>Path of the file you want to work with.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$mode</strong>&nbsp;&nbsp;</td>
        <td>If you want to open it only to read it, use the flag READ, if it's to write it use the WRITE flag, you also can use the READ_WRITE flag.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$whenopen</strong>&nbsp;&nbsp;</td>
        <td>If you want to open the file now, use the OPEN_NOW constant, if you want to open it only when you will need it, use the OPEN_AFTER constant.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodclose"></a>
    <h3>method close <span class="smalllinenumber">[line 215]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void close(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Closes a file and frees the allocated memory relative to the file.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete"></a>
    <h3>method delete <span class="smalllinenumber">[line 229]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes the file.</div>
    Overrides <a href="../../io/filesystem/FileSystemElement.php#methoddelete">FileSystemElement::delete()</a> (Deletes the element)
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodfinclude"></a>
    <h3>method finclude <span class="smalllinenumber">[line 294]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>true finclude(
[bool
$once = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Includes the file. Executes its PHP content here. Equivalent to the PHP include function.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> if the file has been successfully included</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$once</strong>&nbsp;&nbsp;</td>
        <td>true if you don't want to include it if it has already been included.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodflush"></a>
    <h3>method flush <span class="smalllinenumber">[line 280]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void flush(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">forces a write of all buffered output.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodfrequire"></a>
    <h3>method frequire <span class="smalllinenumber">[line 311]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>true frequire(
[bool
$once = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Requires the file. Executes its PHP content here. Equivalent to the PHP require function.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> if the file has been successfully included</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$once</strong>&nbsp;&nbsp;</td>
        <td>true if you don't want to include it if it has already been included.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_contents"></a>
    <h3>method get_contents <span class="smalllinenumber">[line 112]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_contents(
[int
$start = 0], [int
$len = -1])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the content of the file.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The read content.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$start</strong>&nbsp;&nbsp;</td>
        <td>Byte from which you want to start. 0 if you want to read the file from its begening, 1 to start with the second etc.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$len</strong>&nbsp;&nbsp;</td>
        <td>Number of bytes you want to read.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_last_access_date"></a>
    <h3>method get_last_access_date <span class="smalllinenumber">[line 331]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_last_access_date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the last access date of the file.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The UNIX timestamp corresponding to the last access date of the file.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_last_modification_date"></a>
    <h3>method get_last_modification_date <span class="smalllinenumber">[line 322]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_last_modification_date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the date of the last modification of the file.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The UNIX timestamp corresponding to the last modification date.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_lines"></a>
    <h3>method get_lines <span class="smalllinenumber">[line 143]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] get_lines(
[int
$start = 0], [
$n = -1], int
$len)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the content of the file grouped by lines.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the lines of the file.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$start</strong>&nbsp;&nbsp;</td>
        <td>Byte from which you want to start. 0 if you want to read the file from its begening, 1 to start with the second etc.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$len</strong>&nbsp;&nbsp;</td>
        <td>Number of bytes you want to read.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$n</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_open"></a>
    <h3>method is_open <span class="smalllinenumber">[line 245]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool is_open(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Allows you to know if the file is already open.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the file is open, false if it's closed.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodlock"></a>
    <h3>method lock <span class="smalllinenumber">[line 254]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void lock(
[bool
$blocking = true])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Locks the file (it won't be readable by another thread which could try to access it).</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$blocking</strong>&nbsp;&nbsp;</td>
        <td>if true, block the script, if false, non blocking operation</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodopen"></a>
    <h3>method open <span class="smalllinenumber">[line 84]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void open(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Opens the file. You cannot read or write a closed file, use this method to open it.</div>
    Overrides <a href="../../io/filesystem/FileSystemElement.php#methodopen">FileSystemElement::open()</a> (Opens the file system element.)
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodunlock"></a>
    <h3>method unlock <span class="smalllinenumber">[line 267]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void unlock(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Unlocks a file. The file must have been locked before you call this method.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodwrite"></a>
    <h3>method write <span class="smalllinenumber">[line 175]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool write(
string
$data, [
$how = ERASE], [bool
$mode = CLOSEFILE], bool
$what)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Writes some text in the file.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if it could write, false otherwise.</li></ul>
    </div>

    Overrides <a href="../../io/filesystem/FileSystemElement.php#methodwrite">FileSystemElement::write()</a> (Does the necessary treatment to apply at each writing operation)
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$data</strong>&nbsp;&nbsp;</td>
        <td>The text you want to write in the file.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$what</strong>&nbsp;&nbsp;</td>
        <td>ERASE if you want to erase the file, ADD if you want to write at the end of the file.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$mode</strong>&nbsp;&nbsp;</td>
        <td>CLOSEFILE if you want to close the file before to write in it, NOTCLOSEFILE otherwise.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$how</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                            <div class="var">
                            <a name="var_contents"></a>
                <span class="line-number">[line 345]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$contents</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fd"></a>
                <span class="line-number">[line 355]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type"><a href="../../io/filesystem/File.php">File</a></span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fd</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_lines"></a>
                <span class="line-number">[line 340]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$lines</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_mode"></a>
                <span class="line-number">[line 350]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$mode</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>

    <hr />
    <table width="100%" border="0">
        <tr>
                                                    <!--
                        <td valign="top">
                <h3>Inherited Variables</h3>
                                    <div class="tags">
                        <h4>Class: <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a></h4>
                        <dl>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#var$is_open">FileSystemElement::$is_open</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#var$path">FileSystemElement::$path</a></dt>
                            <dd></dd>
                                                    </dl>
                    </div>
                            </td>
                         -->
                            <td valign="top">
                    <h3>Inherited Methods</h3>
                                            <h4>Class: <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a></h4>
                        <dl style="margin-left:10px;">
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodFileSystemElement">FileSystemElement::FileSystemElement()</a></dt>
                            <dd>Builds a FileSystemElement object from the path of the element.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodchange_chmod">FileSystemElement::change_chmod()</a></dt>
                            <dd>Changes the chmod of the element.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methoddelete">FileSystemElement::delete()</a></dt>
                            <dd>Deletes the element</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodexists">FileSystemElement::exists()</a></dt>
                            <dd>Allows you to know if the file system element exists.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodget">FileSystemElement::get()</a></dt>
                            <dd>Initializes the file system element just before to be read.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodget_name">FileSystemElement::get_name()</a></dt>
                            <dd>Returns the element name.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodopen">FileSystemElement::open()</a></dt>
                            <dd>Opens the file system element.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodwrite">FileSystemElement::write()</a></dt>
                            <dd>Does the necessary treatment to apply at each writing operation</dd>
                                                    </dl>
                        <br />
                                    </td>
                    </tr>
    </table>
    <hr />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> -
            <a href="../../elementindex_io.php" class="menu">index: io</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:23 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>