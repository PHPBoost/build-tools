<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Docs For Class Folder');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="../../elementindex_io.php" class="menu">index: io</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="../../io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="../../io/Template.php">Template</a>            </li>
                    <li>
                <a href="../../io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Folder</h1><p>Source Location: /io/filesystem/folder.class.php [line 37]</p>

<h2>Class Overview</a></h2>
<pre><a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a>
   |
   --Folder</pre>
<div class="description">This class allows you to handle very easily a folder on the serveur.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt; Nicolas Duhamel &lt;akhenathon2@gmail.com&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../io/filesystem/Folder.php#methodFolder">Folder</a></li><li class="bb_li"><a href="../../io/filesystem/Folder.php#methoddelete">delete</a></li><li class="bb_li"><a href="../../io/filesystem/Folder.php#methodget_all_content">get_all_content</a></li><li class="bb_li"><a href="../../io/filesystem/Folder.php#methodget_files">get_files</a></li><li class="bb_li"><a href="../../io/filesystem/Folder.php#methodget_first_folder">get_first_folder</a></li><li class="bb_li"><a href="../../io/filesystem/Folder.php#methodget_folders">get_folders</a></li><li class="bb_li"><a href="../../io/filesystem/Folder.php#methodopen">open</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../io/filesystem/Folder.php#var$files">$files</a></li><li class="bb_li"><a href="../../io/filesystem/Folder.php#var$folders">$folders</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class allows you to handle very easily a folder on the serveur.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt; Nicolas Duhamel &lt;akhenathon2@gmail.com&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFolder"></a>
    <h3>constructor Folder <span class="smalllinenumber">[line 44]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Folder Folder(
string
$path, [bool
$whenopen = OPEN_AFTER])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a Folder object.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>Path of the folder.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$whenopen</strong>&nbsp;&nbsp;</td>
        <td>OPEN_AFTER if you want to synchronyse you with the folder only when it's necessary or OPEN_NOW if you want to open it now.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete"></a>
    <h3>method delete <span class="smalllinenumber">[line 190]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>True delete(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes the folder and all what it contains.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> if deleted successfully.</li></ul>
    </div>

    Overrides <a href="../../io/filesystem/FileSystemElement.php#methoddelete">FileSystemElement::delete()</a> (Deletes the element)
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_all_content"></a>
    <h3>method get_all_content <span class="smalllinenumber">[line 181]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>FileSystemElement[] get_all_content(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns all the file system elements contained by the folder.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the file system element contained in this folder.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_files"></a>
    <h3>method get_files <span class="smalllinenumber">[line 103]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>File[] get_files(
[string
$regex = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Lists the files contained in this folder.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The files list.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$regex</strong>&nbsp;&nbsp;</td>
        <td>PREG which describes the pattern the files you want to list must match. If you want all of them, don't use this parameter.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_first_folder"></a>
    <h3>method get_first_folder <span class="smalllinenumber">[line 163]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../../io/filesystem/Folder.php">Folder</a> get_first_folder(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the first folder present in this folder</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The first folder of this folder or null if it doesn't contain any folder.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_folders"></a>
    <h3>method get_folders <span class="smalllinenumber">[line 133]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Folder[] get_folders(
[string
$regex = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Lists the folders contained in this folder.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The folders list.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$regex</strong>&nbsp;&nbsp;</td>
        <td>PREG which describes the pattern the folders you want to list must match. If you want all of them, don't use this parameter.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodopen"></a>
    <h3>method open <span class="smalllinenumber">[line 71]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void open(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Opens the folder.</div>
    Overrides <a href="../../io/filesystem/FileSystemElement.php#methodopen">FileSystemElement::open()</a> (Opens the file system element.)
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                    <div class="var">
                            <a name="var_files"></a>
                <span class="line-number">[line 212]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">File[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$files</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_folders"></a>
                <span class="line-number">[line 217]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">Folder[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$folders</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>

    <hr />
    <table width="100%" border="0">
        <tr>
                                                    <!--
                        <td valign="top">
                <h3>Inherited Variables</h3>
                                    <div class="tags">
                        <h4>Class: <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a></h4>
                        <dl>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#var$is_open">FileSystemElement::$is_open</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#var$path">FileSystemElement::$path</a></dt>
                            <dd></dd>
                                                    </dl>
                    </div>
                            </td>
                         -->
                            <td valign="top">
                    <h3>Inherited Methods</h3>
                                            <h4>Class: <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a></h4>
                        <dl style="margin-left:10px;">
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodFileSystemElement">FileSystemElement::FileSystemElement()</a></dt>
                            <dd>Builds a FileSystemElement object from the path of the element.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodchange_chmod">FileSystemElement::change_chmod()</a></dt>
                            <dd>Changes the chmod of the element.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methoddelete">FileSystemElement::delete()</a></dt>
                            <dd>Deletes the element</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodexists">FileSystemElement::exists()</a></dt>
                            <dd>Allows you to know if the file system element exists.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodget">FileSystemElement::get()</a></dt>
                            <dd>Initializes the file system element just before to be read.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodget_name">FileSystemElement::get_name()</a></dt>
                            <dd>Returns the element name.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodopen">FileSystemElement::open()</a></dt>
                            <dd>Opens the file system element.</dd>
                                                        <dt><a href="../../io/filesystem/FileSystemElement.php#methodwrite">FileSystemElement::write()</a></dt>
                            <dd>Does the necessary treatment to apply at each writing operation</dd>
                                                    </dl>
                        <br />
                                    </td>
                    </tr>
    </table>
    <hr />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> -
            <a href="../../elementindex_io.php" class="menu">index: io</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:49 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>