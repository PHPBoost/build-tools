<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Docs For Class FileSystemElement');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="../../elementindex_io.php" class="menu">index: io</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="../../io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="../../io/Template.php">Template</a>            </li>
                    <li>
                <a href="../../io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: FileSystemElement</h1><p>Source Location: /io/filesystem/file_system_element.class.php [line 38]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class represents any file system element.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt; Nicolas Duhamel &lt;akhenathon2@gmail.com&gt;</li></ul>
	</div>



				

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methodFileSystemElement">FileSystemElement</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methodchange_chmod">change_chmod</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methoddelete">delete</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methodexists">exists</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methodget">get</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methodget_name">get_name</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methodopen">open</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#methodwrite">write</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#var$is_open">$is_open</a></li><li class="bb_li"><a href="../../io/filesystem/FileSystemElement.php#var$path">$path</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class represents any file system element.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt; Nicolas Duhamel &lt;akhenathon2@gmail.com&gt;</li><li><strong>abstract:</strong> </li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFileSystemElement"></a>
    <h3>constructor FileSystemElement <span class="smalllinenumber">[line 44]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>FileSystemElement FileSystemElement(
string
$path)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a FileSystemElement object from the path of the element.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td>Path of the element</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodchange_chmod"></a>
    <h3>method change_chmod <span class="smalllinenumber">[line 123]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void change_chmod(
int
$chmod)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Changes the chmod of the element.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$chmod</strong>&nbsp;&nbsp;</td>
        <td>The new chmod of the file. Put a 0 at the begening of the number to indicate to the PHP parser that it's an octal value.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete"></a>
    <h3>method delete <span class="smalllinenumber">[line 135]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes the element</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>abstract:</strong> </li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../../io/filesystem/Folder.php#methoddelete">Folder::delete()</a></dt>
        <dd>Deletes the folder and all what it contains.</dd>
    </dl>
        <dl>
    <dt><a href="../../io/filesystem/File.php#methoddelete">File::delete()</a></dt>
        <dd>Deletes the file.</dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodexists"></a>
    <h3>method exists <span class="smalllinenumber">[line 54]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool exists(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Allows you to know if the file system element exists.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if the file exists, else, false.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget"></a>
    <h3>method get <span class="smalllinenumber">[line 75]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Initializes the file system element just before to be read.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_name"></a>
    <h3>method get_name <span class="smalllinenumber">[line 100]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_name(
[bool
$full_path = false], [bool
$no_extension = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the element name.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The element name.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$full_path</strong>&nbsp;&nbsp;</td>
        <td>True if you want the full path or false if you just want a relative path.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$no_extension</strong>&nbsp;&nbsp;</td>
        <td>False if you want the name of the file with the extension and true without.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodopen"></a>
    <h3>method open <span class="smalllinenumber">[line 62]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void open(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Opens the file system element.</div>
    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../../io/filesystem/Folder.php#methodopen">Folder::open()</a></dt>
        <dd>Opens the folder.</dd>
    </dl>
        <dl>
    <dt><a href="../../io/filesystem/File.php#methodopen">File::open()</a></dt>
        <dd>Opens the file. You cannot read or write a closed file, use this method to open it.</dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodwrite"></a>
    <h3>method write <span class="smalllinenumber">[line 88]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>unknown_type write(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Does the necessary treatment to apply at each writing operation</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>abstract:</strong> </li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../../io/filesystem/File.php#methodwrite">File::write()</a></dt>
        <dd>Writes some text in the file.</dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                    <div class="var">
                            <a name="var_is_open"></a>
                <span class="line-number">[line 146]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">bool</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$is_open</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_path"></a>
                <span class="line-number">[line 141]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$path</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> -
            <a href="../../elementindex_io.php" class="menu">index: io</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:49 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>