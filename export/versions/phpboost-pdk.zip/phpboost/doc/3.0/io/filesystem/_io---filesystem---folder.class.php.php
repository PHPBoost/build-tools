<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Docs for page folder.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="../../elementindex_io.php" class="menu">index: io</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="../../io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="../../io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="../../io/Template.php">Template</a>            </li>
                    <li>
                <a href="../../io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="../../io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="../../io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: folder.class.php</h1><p>Source Location: /io/filesystem/folder.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../../io/filesystem/Folder.php">Folder</a></dt>
	<dd>This class allows you to handle very easily a folder on the serveur.</dd>
</div><br /><br />

<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="../../classtrees_io.php" class="menu">class tree: io</a> -
            <a href="../../elementindex_io.php" class="menu">index: io</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:46 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>