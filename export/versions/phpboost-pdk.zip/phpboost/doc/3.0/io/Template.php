<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Docs For Class Template');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="../classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="../elementindex_io.php" class="menu">index: io</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="../io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="../io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="../io/Template.php">Template</a>            </li>
                    <li>
                <a href="../io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="../io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="../io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="../io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="../io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Template</h1><p>Source Location: /io/template.class.php [line 80]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class allows you to handle a template file. Your template files should have the .tpl extension. &lt;h1&gt;The PHPBoost template syntax&lt;/h1&gt; &lt;h2&gt;Simple variables&lt;/h2&gt; A simple variable is accessible with the {NAME} syntax where NAME is its template name. If the variable is not assigned, nothing will be displayed (no error message). Simple variables are assigned by the assign_vars() method. &lt;h2&gt;Loops&lt;/h2&gt; You can make some loops to repeat a pattern, those loops can be nested. A loop has a name (name) and each iteration contains some variables, for example, the variable VAR.<ul><li>START name #</li></ul> My variable is {name.VAR}<ul><li>END name #</li></ul> To nest loops, here is an example:<ul><li>START loop1 #</li></ul> I write my loop1 var here: {loop1.VAR}.<ul><li>START loop1.loop2 #</li></ul> I can write my loop2 var here: {loop1.loop2.VAR} but also my loop1 var of the parent loop: {loop1.VAR}.<ul></ul><ul><li>END loop1 #</li></ul> To assign the variable, see the assign_block_vars() method which creates one iteration. &lt;h2&gt;Conditions&lt;/h2&gt; When you want to display something only in particular case, you can use some condition tests.<ul><li>IF C_MY_TEST #</li></ul> This text will be displayed only if the C_MY_TEST variable is true<ul><li>ENDIF #</li></ul> You can nest some conditions.&lt;/li&gt; &lt;/ul&gt; To be more efficient, this class uses a cache and parses each file only once. &lt;h1&gt;File paths&lt;/h1&gt; The web site can have several themes whose files aren't in the same folders. When you load a file, you just have to load the generic file and the good template file will be loaded dinamically. &lt;h2&gt;Kernel template file&lt;/h2&gt; When you want to load a kernel template file, the path you must indicate is only the name of the file, for example header.tpl loads /template/your_theme/header.tpl and if it doesn't exist, it will load /template/default/header.tpl. &lt;h2&gt;Module template file&lt;/h2&gt; When you want to load a module template file, you must indicate the name of you module and then the name of the file like this: module/file.tpl which will load the /module/templates/file.tpl. If the user themes redefines the file.tpl file for the module module, the file templates/your_theme/modules/module/file.tpl will be loaded. &lt;h2&gt;Menu template file&lt;/h2&gt; To load a file of a menu, use this kind of path: menus/my_menu/file.tpl which will load the /menus/my_menu/templates/file.tpl file. &lt;h2&gt;Framework template file&lt;/h2&gt; To load a framework file, use a path like this: framework/package/file.tpl which will load /templates/your_theme/framework/package/file.tpl if the theme overrides it, otherwise /templates/default/framework/package/file.tpl will be used.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt; R�gis Viarre &lt;crowkait@phpboost.com&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../io/Template.php#methodTemplate">Template</a></li><li class="bb_li"><a href="../io/Template.php#methodassign_block_vars">assign_block_vars</a></li><li class="bb_li"><a href="../io/Template.php#methodassign_vars">assign_vars</a></li><li class="bb_li"><a href="../io/Template.php#methodcopy">copy</a></li><li class="bb_li"><a href="../io/Template.php#methodget_module_data_path">get_module_data_path</a></li><li class="bb_li"><a href="../io/Template.php#methodparse">parse</a></li><li class="bb_li"><a href="../io/Template.php#methodpparse">pparse</a></li><li class="bb_li"><a href="../io/Template.php#methodset_filenames">set_filenames</a></li><li class="bb_li"><a href="../io/Template.php#methodunassign_block_vars">unassign_block_vars</a></li><li class="bb_li"><a href="../io/Template.php#method_check_cache_file">_check_cache_file</a></li><li class="bb_li"><a href="../io/Template.php#method_check_file">_check_file</a></li><li class="bb_li"><a href="../io/Template.php#method_include">_include</a></li><li class="bb_li"><a href="../io/Template.php#method_load">_load</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../io/Template.php#var$files">$files</a></li><li class="bb_li"><a href="../io/Template.php#var$module_data_path">$module_data_path</a></li><li class="bb_li"><a href="../io/Template.php#var$return_mode">$return_mode</a></li><li class="bb_li"><a href="../io/Template.php#var$template">$template</a></li><li class="bb_li"><a href="../io/Template.php#var$tpl">$tpl</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class allows you to handle a template file. Your template files should have the .tpl extension. &lt;h1&gt;The PHPBoost template syntax&lt;/h1&gt; &lt;h2&gt;Simple variables&lt;/h2&gt; A simple variable is accessible with the {NAME} syntax where NAME is its template name. If the variable is not assigned, nothing will be displayed (no error message). Simple variables are assigned by the assign_vars() method. &lt;h2&gt;Loops&lt;/h2&gt; You can make some loops to repeat a pattern, those loops can be nested. A loop has a name (name) and each iteration contains some variables, for example, the variable VAR.<ul><li>START name #</li></ul> My variable is {name.VAR}<ul><li>END name #</li></ul> To nest loops, here is an example:<ul><li>START loop1 #</li></ul> I write my loop1 var here: {loop1.VAR}.<ul><li>START loop1.loop2 #</li></ul> I can write my loop2 var here: {loop1.loop2.VAR} but also my loop1 var of the parent loop: {loop1.VAR}.<ul></ul><ul><li>END loop1 #</li></ul> To assign the variable, see the assign_block_vars() method which creates one iteration. &lt;h2&gt;Conditions&lt;/h2&gt; When you want to display something only in particular case, you can use some condition tests.<ul><li>IF C_MY_TEST #</li></ul> This text will be displayed only if the C_MY_TEST variable is true<ul><li>ENDIF #</li></ul> You can nest some conditions.&lt;/li&gt; &lt;/ul&gt; To be more efficient, this class uses a cache and parses each file only once. &lt;h1&gt;File paths&lt;/h1&gt; The web site can have several themes whose files aren't in the same folders. When you load a file, you just have to load the generic file and the good template file will be loaded dinamically. &lt;h2&gt;Kernel template file&lt;/h2&gt; When you want to load a kernel template file, the path you must indicate is only the name of the file, for example header.tpl loads /template/your_theme/header.tpl and if it doesn't exist, it will load /template/default/header.tpl. &lt;h2&gt;Module template file&lt;/h2&gt; When you want to load a module template file, you must indicate the name of you module and then the name of the file like this: module/file.tpl which will load the /module/templates/file.tpl. If the user themes redefines the file.tpl file for the module module, the file templates/your_theme/modules/module/file.tpl will be loaded. &lt;h2&gt;Menu template file&lt;/h2&gt; To load a file of a menu, use this kind of path: menus/my_menu/file.tpl which will load the /menus/my_menu/templates/file.tpl file. &lt;h2&gt;Framework template file&lt;/h2&gt; To load a framework file, use a path like this: framework/package/file.tpl which will load /templates/your_theme/framework/package/file.tpl if the theme overrides it, otherwise /templates/default/framework/package/file.tpl will be used.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt; R�gis Viarre &lt;crowkait@phpboost.com&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodTemplate"></a>
    <h3>constructor Template <span class="smalllinenumber">[line 88]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Template Template(
[string
$tpl = ''], [bool
$auto_load_vars = AUTO_LOAD_FREQUENT_VARS])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a Template object.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$tpl</strong>&nbsp;&nbsp;</td>
        <td>Path of your TPL file. See the class description to know you you have to write this path.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$auto_load_vars</strong>&nbsp;&nbsp;</td>
        <td>AUTO_LOAD_FREQUENT_VARS if you want to assign the frequent vars (user lang, user theme, CSRF token, current path to root, user logged in or not...). DO_NOT_AUTO_LOAD_FREQUENT_VARS if you don't want.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodassign_block_vars"></a>
    <h3>method assign_block_vars <span class="smalllinenumber">[line 163]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void assign_block_vars(
string
$block_name, string[]
$array_vars)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Assigns a template block. A block represents a loop and has a name which be used in your template file to indicate which loop you want to browse. To know what syntax to use to browse a loop, see the class description, there are examples.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$block_name</strong>&nbsp;&nbsp;</td>
        <td>Block name.</td>
      </tr>
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$array_vars</strong>&nbsp;&nbsp;</td>
        <td>A map var_name =&gt; var_value. Generally, var_name is written in caps characters.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodassign_vars"></a>
    <h3>method assign_vars <span class="smalllinenumber">[line 149]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void assign_vars(
string[]
$array_vars)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Assigns some simple template vars.  Those variables will be accessed in your template with the {var_name} syntax.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$array_vars</strong>&nbsp;&nbsp;</td>
        <td>A map var_name =&gt; var_value. Generally, var_name is written in caps characters.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcopy"></a>
    <h3>method copy <span class="smalllinenumber">[line 265]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../io/Template.php">Template</a> copy(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Clones this object.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> A clone of this object.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_module_data_path"></a>
    <h3>method get_module_data_path <span class="smalllinenumber">[line 136]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_module_data_path(
string
$module)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Retrieves the path of the module. This path will be used to write the relative paths in your templates.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The relative path.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module</strong>&nbsp;&nbsp;</td>
        <td>Name of the module for which you want to know the data path.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodparse"></a>
    <h3>method parse <span class="smalllinenumber">[line 202]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string parse(
[bool
$return_mode = TEMPLATE_WRITE_MODE])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Parses the file. It will use the variables you assigned.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The parsed content if you used the TEMPLATE_STRING_MODE, otherwise it doesn't return anything.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$return_mode</strong>&nbsp;&nbsp;</td>
        <td>In its default behaviour (TEMPLATE_WRITE_MODE), this class write what it parses in the PHP standard output. If you want to retrieve the parsed content and not to write it, use the TEMPLATE_STRING_MODE variable.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodpparse"></a>
    <h3>method pparse <span class="smalllinenumber">[line 222]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string pparse(
string
$parse_name, [bool
$return_mode = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Parses the file whose name is $parse_name and which has been declared with the set_filenames_method. It uses the variables you assigned (when you assign a variable it will be usable in every file handled by this object).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The parsed content if you used the TEMPLATe_STRING_MODE, otherwise it doesn't return anything.</li><li><strong>deprecated:</strong> </li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$parse_name</strong>&nbsp;&nbsp;</td>
        <td>The identifier of the file you want to parse.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$return_mode</strong>&nbsp;&nbsp;</td>
        <td>In its default behaviour (TEMPLATE_WRITE_MODE), this class write what it parses in the PHP standard output.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_filenames"></a>
    <h3>method set_filenames <span class="smalllinenumber">[line 118]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_filenames(
string[]
$array_tpl)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Loads several files in the same Template instance.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>deprecated:</strong> </li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$array_tpl</strong>&nbsp;&nbsp;</td>
        <td>A map file_identifier =&gt; file_path where file_identifier is the name you give to your file and file_path its path. See the class description to learn how to write the path.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodunassign_block_vars"></a>
    <h3>method unassign_block_vars <span class="smalllinenumber">[line 188]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void unassign_block_vars(
string
$block_name)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes a block. It won't be browsable any more in your template.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$block_name</strong>&nbsp;&nbsp;</td>
        <td>The name of your block.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="method_check_cache_file"></a>
    <h3>method _check_cache_file <span class="smalllinenumber">[line 422]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool _check_cache_file(
string
$tpl_path, string
$file_cache_path)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Allows you to know if the cache file is still valid or if it has to be removed because the source file has been updated.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if the cache file is still correct, false if the cache file doesn't exist or is not up to date.</li><li><strong>access:</strong> protected</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$tpl_path</strong>&nbsp;&nbsp;</td>
        <td>File path to control.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$file_cache_path</strong>&nbsp;&nbsp;</td>
        <td>Cache file path corresponding.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="method_check_file"></a>
    <h3>method _check_file <span class="smalllinenumber">[line 289]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string _check_file(
string
$filename)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Computes the path of the file to load dinamycally according to the user theme and the kind of file (kernel, module, menu or framework file).</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The path to load.</li><li><strong>access:</strong> protected</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$filename</strong>&nbsp;&nbsp;</td>
        <td>The file path. See the class description to know what path to use.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="method_include"></a>
    <h3>method _include <span class="smalllinenumber">[line 471]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string _include(
string
$parse_name)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Include a file in another file. You can access to the same variables in the two variables, it's just as if you had copied the content of the included file in the includer.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> If the file is parsed in the string mode (returns and writes) or nothing if it writes the result in the PHP standard output.</li><li><strong>deprecated:</strong> </li><li><strong>access:</strong> protected</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$parse_name</strong>&nbsp;&nbsp;</td>
        <td>The identifier of the file to load. The two files must have been declared in the same template object.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="method_load"></a>
    <h3>method _load <span class="smalllinenumber">[line 445]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool _load(
string
$parse_name)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Loads a template file.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the file could be loaded, false otherwise. If it encounters a fatal problem, an error will be displayed and the script execution will be stopped.</li><li><strong>access:</strong> protected</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$parse_name</strong>&nbsp;&nbsp;</td>
        <td>Path of the file to load (relative to the current file).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                <div class="var">
                            <a name="var_files"></a>
                <span class="line-number">[line 745]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$files</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_module_data_path"></a>
                <span class="line-number">[line 750]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$module_data_path</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_return_mode"></a>
                <span class="line-number">[line 755]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">bool</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$return_mode</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_template"></a>
                <span class="line-number">[line 740]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$template</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_tpl"></a>
                <span class="line-number">[line 735]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$tpl</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="../classtrees_io.php" class="menu">class tree: io</a> -
            <a href="../elementindex_io.php" class="menu">index: io</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:29 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>