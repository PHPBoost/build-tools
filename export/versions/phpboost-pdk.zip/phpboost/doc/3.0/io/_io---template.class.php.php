<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Docs for page template.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="../classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="../elementindex_io.php" class="menu">index: io</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="../io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="../io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="../io/Template.php">Template</a>            </li>
                    <li>
                <a href="../io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="../io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="../io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="../io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="../io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: template.class.php</h1><p>Source Location: /io/template.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../io/Template.php">Template</a></dt>
	<dd>This class allows you to handle a template file. Your template files should have the .tpl extension. &lt;h1&gt;The PHPBoost template syntax&lt;/h1&gt; &lt;h2&gt;Simple variables&lt;/h2&gt; A simple variable is accessible with the {NAME} syntax where NAME is its template name. If the variable is not assigned, nothing will be displayed (no error message). Simple variables are assigned by the assign_vars() method. &lt;h2&gt;Loops&lt;/h2&gt; You can make some loops to repeat a pattern, those loops can be nested. A loop has a name (name) and each iteration contains some variables, for example, the variable VAR.<ul><li>START name #</li></ul> My variable is {name.VAR}<ul><li>END name #</li></ul> To nest loops, here is an example:<ul><li>START loop1 #</li></ul> I write my loop1 var here: {loop1.VAR}.<ul><li>START loop1.loop2 #</li></ul> I can write my loop2 var here: {loop1.loop2.VAR} but also my loop1 var of the parent loop: {loop1.VAR}.<ul></ul><ul><li>END loop1 #</li></ul> To assign the variable, see the assign_block_vars() method which creates one iteration. &lt;h2&gt;Conditions&lt;/h2&gt; When you want to display something only in particular case, you can use some condition tests.<ul><li>IF C_MY_TEST #</li></ul> This text will be displayed only if the C_MY_TEST variable is true<ul><li>ENDIF #</li></ul> You can nest some conditions.&lt;/li&gt; &lt;/ul&gt; To be more efficient, this class uses a cache and parses each file only once. &lt;h1&gt;File paths&lt;/h1&gt; The web site can have several themes whose files aren't in the same folders. When you load a file, you just have to load the generic file and the good template file will be loaded dinamically. &lt;h2&gt;Kernel template file&lt;/h2&gt; When you want to load a kernel template file, the path you must indicate is only the name of the file, for example header.tpl loads /template/your_theme/header.tpl and if it doesn't exist, it will load /template/default/header.tpl. &lt;h2&gt;Module template file&lt;/h2&gt; When you want to load a module template file, you must indicate the name of you module and then the name of the file like this: module/file.tpl which will load the /module/templates/file.tpl. If the user themes redefines the file.tpl file for the module module, the file templates/your_theme/modules/module/file.tpl will be loaded. &lt;h2&gt;Menu template file&lt;/h2&gt; To load a file of a menu, use this kind of path: menus/my_menu/file.tpl which will load the /menus/my_menu/templates/file.tpl file. &lt;h2&gt;Framework template file&lt;/h2&gt; To load a framework file, use a path like this: framework/package/file.tpl which will load /templates/your_theme/framework/package/file.tpl if the theme overrides it, otherwise /templates/default/framework/package/file.tpl will be used.</dd>
</div><br /><br />

<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineAUTO_LOAD_FREQUENT_VARS"></a>
	<h3>AUTO_LOAD_FREQUENT_VARS <span class="smalllinenumber">[line 31]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>AUTO_LOAD_FREQUENT_VARS = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineDO_NOT_AUTO_LOAD_FREQUENT_VARS"></a>
	<h3>DO_NOT_AUTO_LOAD_FREQUENT_VARS <span class="smalllinenumber">[line 32]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>DO_NOT_AUTO_LOAD_FREQUENT_VARS = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineTEMPLATE_STRING_MODE"></a>
	<h3>TEMPLATE_STRING_MODE <span class="smalllinenumber">[line 29]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>TEMPLATE_STRING_MODE = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineTEMPLATE_WRITE_MODE"></a>
	<h3>TEMPLATE_WRITE_MODE <span class="smalllinenumber">[line 30]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>TEMPLATE_WRITE_MODE = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="../classtrees_io.php" class="menu">class tree: io</a> -
            <a href="../elementindex_io.php" class="menu">index: io</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:54 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>