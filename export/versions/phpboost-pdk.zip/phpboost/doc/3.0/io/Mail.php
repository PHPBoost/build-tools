<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'io - Docs For Class Mail');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('io', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">io</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                        
                                                                                                                                                                        <a href="../classtrees_io.php" class="menu">class tree: io</a> - 
                <a href="../elementindex_io.php" class="menu">index: io</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../io/filesystem/File.php">File</a>            </li>
                    <li>
                <a href="../io/filesystem/FileSystemElement.php">FileSystemElement</a>            </li>
                    <li>
                <a href="../io/filesystem/Folder.php">Folder</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../io/Mail.php">Mail</a>            </li>
                    <li>
                <a href="../io/Template.php">Template</a>            </li>
                    <li>
                <a href="../io/Upload.php">Upload</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../io/_io---mail.class.php.php">                mail.class.php
                </a>            </li>
                    <li>
                <a href="../io/_io---template.class.php.php">                template.class.php
                </a>            </li>
                    <li>
                <a href="../io/_io---upload.class.php.php">                upload.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>filesystem</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../io/filesystem/_io---filesystem---file.class.php.php">                file.class.php
                </a>            </li>
                    <li>
                <a href="../io/filesystem/_io---filesystem---file_system_element.class.php.php">                file_system_element.class.php
                </a>            </li>
                    <li>
                <a href="../io/filesystem/_io---filesystem---folder.class.php.php">                folder.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Mail</h1><p>Source Location: /io/mail.class.php [line 38]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class allows you to send mails without having to deal with the mail headers and parameters.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Régis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../io/Mail.php#methodMail">Mail</a></li><li class="bb_li"><a href="../io/Mail.php#methodcheck_validity">check_validity</a></li><li class="bb_li"><a href="../io/Mail.php#methodget_content">get_content</a></li><li class="bb_li"><a href="../io/Mail.php#methodget_headers">get_headers</a></li><li class="bb_li"><a href="../io/Mail.php#methodget_mime">get_mime</a></li><li class="bb_li"><a href="../io/Mail.php#methodget_object">get_object</a></li><li class="bb_li"><a href="../io/Mail.php#methodget_recipients">get_recipients</a></li><li class="bb_li"><a href="../io/Mail.php#methodget_sender_mail">get_sender_mail</a></li><li class="bb_li"><a href="../io/Mail.php#methodget_sender_name">get_sender_name</a></li><li class="bb_li"><a href="../io/Mail.php#methodsend">send</a></li><li class="bb_li"><a href="../io/Mail.php#methodsend_from_properties">send_from_properties</a></li><li class="bb_li"><a href="../io/Mail.php#methodset_content">set_content</a></li><li class="bb_li"><a href="../io/Mail.php#methodset_headers">set_headers</a></li><li class="bb_li"><a href="../io/Mail.php#methodset_mime">set_mime</a></li><li class="bb_li"><a href="../io/Mail.php#methodset_object">set_object</a></li><li class="bb_li"><a href="../io/Mail.php#methodset_recipients">set_recipients</a></li><li class="bb_li"><a href="../io/Mail.php#methodset_sender">set_sender</a></li><li class="bb_li"><a href="../io/Mail.php#method_generate_headers">_generate_headers</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../io/Mail.php#var$content">$content</a></li><li class="bb_li"><a href="../io/Mail.php#var$format">$format</a></li><li class="bb_li"><a href="../io/Mail.php#var$headers">$headers</a></li><li class="bb_li"><a href="../io/Mail.php#var$object">$object</a></li><li class="bb_li"><a href="../io/Mail.php#var$recipients">$recipients</a></li><li class="bb_li"><a href="../io/Mail.php#var$sender_mail">$sender_mail</a></li><li class="bb_li"><a href="../io/Mail.php#var$sender_name">$sender_name</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class allows you to send mails without having to deal with the mail headers and parameters.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Régis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodMail"></a>
    <h3>constructor Mail <span class="smalllinenumber">[line 43]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Mail Mail(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a Mail object.</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_content"></a>
    <h3>method get_content <span class="smalllinenumber">[line 167]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_content(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the mail content.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The mail content.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_headers"></a>
    <h3>method get_headers <span class="smalllinenumber">[line 176]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_headers(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the mail headers.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The mail headers.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_mime"></a>
    <h3>method get_mime <span class="smalllinenumber">[line 194]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_mime(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the MIME type of the mail content</div><div class="description"><p>Returns the MIME type of the mail content</p></div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the MIME type</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_object"></a>
    <h3>method get_object <span class="smalllinenumber">[line 158]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_object(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the mail object.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The mail object.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_recipients"></a>
    <h3>method get_recipients <span class="smalllinenumber">[line 149]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_recipients(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the mail recipients' addresses. They are separated by a comma.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The mail recipients.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_sender_mail"></a>
    <h3>method get_sender_mail <span class="smalllinenumber">[line 131]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_sender_mail(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the mail address of the sender.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the sender's mail address</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_sender_name"></a>
    <h3>method get_sender_name <span class="smalllinenumber">[line 140]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_sender_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the mail sender's name.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The mail sender's name.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodsend"></a>
    <h3>method send <span class="smalllinenumber">[line 233]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool send(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sends the mail.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if the mail could be sent, false otherwise.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodsend_from_properties"></a>
    <h3>method send_from_properties <span class="smalllinenumber">[line 210]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool send_from_properties(
string
$mail_to, string
$mail_object, string
$mail_content, string
$mail_from, [string
$mail_header = null], [string
$sender_name = 'admin'])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sends the mail.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if the mail could be sent, false otherwise.</li><li><strong>deprecated:</strong> </li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mail_to</strong>&nbsp;&nbsp;</td>
        <td>The mail recipients' address.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mail_object</strong>&nbsp;&nbsp;</td>
        <td>The mail object.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mail_content</strong>&nbsp;&nbsp;</td>
        <td>content of the mail</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mail_from</strong>&nbsp;&nbsp;</td>
        <td>The mail sender's address.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mail_header</strong>&nbsp;&nbsp;</td>
        <td>The header you want to specify (it you don't specify it, it will be generated automatically).</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$sender_name</strong>&nbsp;&nbsp;</td>
        <td>The mail sender's name. If you don't use this parameter, the name of the site administrator will be taken.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_content"></a>
    <h3>method set_content <span class="smalllinenumber">[line 113]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_content(
string
$content)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">The mail content.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$content</strong>&nbsp;&nbsp;</td>
        <td>The mail content</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_headers"></a>
    <h3>method set_headers <span class="smalllinenumber">[line 122]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_headers(
string
$headers)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the headers. Forces them, they won't be generated automatically.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$headers</strong>&nbsp;&nbsp;</td>
        <td>The mail headers.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_mime"></a>
    <h3>method set_mime <span class="smalllinenumber">[line 185]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_mime(
string
$mime)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the MIME type of the mail content</div><div class="description"><p>Sets the MIME type of the mail content</p></div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$mime</strong>&nbsp;&nbsp;</td>
        <td>MIME_FORMAT_TEXT or MIME_FORMAT_HTML</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_object"></a>
    <h3>method set_object <span class="smalllinenumber">[line 104]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_object(
string
$object)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the mail object</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$object</strong>&nbsp;&nbsp;</td>
        <td>Mail object</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_recipients"></a>
    <h3>method set_recipients <span class="smalllinenumber">[line 73]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_recipients(
string
$recipients)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the recipient(s) of the mail.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$recipients</strong>&nbsp;&nbsp;</td>
        <td>Recipients of the mail. It they are more than one, use the comma to separate their addresses.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_sender"></a>
    <h3>method set_sender <span class="smalllinenumber">[line 53]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool set_sender(
string
$sender, [string
$sender_name = 'admin'])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the mail sender.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True, if the mail sender address is correct, false otherwise.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$sender</strong>&nbsp;&nbsp;</td>
        <td>The mail sender address.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$sender_name</strong>&nbsp;&nbsp;</td>
        <td>'admin' if the mail is sent by the administrator, 'user' otherwise.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="method_generate_headers"></a>
    <h3>method _generate_headers <span class="smalllinenumber">[line 260]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void _generate_headers(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Generates the mail headers.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodcheck_validity"></a>
	<h3>static method check_validity <span class="smalllinenumber">[line 249]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static bool check_validity(

$mail_address)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Checks that an email address has a correct form.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if it's valid, false otherwise.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$mail_address</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                        <div class="var">
                            <a name="var_content"></a>
                <span class="line-number">[line 304]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$content</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_format"></a>
                <span class="line-number">[line 329]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$format</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;MIME_FORMAT_TEXT</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_headers"></a>
                <span class="line-number">[line 319]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">The</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$headers</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_object"></a>
                <span class="line-number">[line 299]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">sting</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$object</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_recipients"></a>
                <span class="line-number">[line 324]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$recipients</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_sender_mail"></a>
                <span class="line-number">[line 309]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$sender_mail</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_sender_name"></a>
                <span class="line-number">[line 314]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$sender_name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                            
                                                                                                                        <a href="../classtrees_io.php" class="menu">class tree: io</a> -
            <a href="../elementindex_io.php" class="menu">index: io</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:50 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>