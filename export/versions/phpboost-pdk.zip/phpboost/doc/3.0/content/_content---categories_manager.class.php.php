<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs for page categories_manager.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: categories_manager.class.php</h1><p>Source Location: /content/categories_manager.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../content/CategoriesManager.php">CategoriesManager</a></dt>
	<dd>This class enables you to manage easily the administration of categories for your modules. It's as generic as possible, if you want to complete some actions to specialize them for you module, you can create a new class inheritating of it in which you call its methods using the syntax parent::method(). <br /> /!\ Warning : /!\ <ul><li>Your DB table must respect some rules :
         <ul><li>You must have an integer attribute whose name is id and which represents the identifier of each category. It must be a primary key.</li><li>You also must have an integer attribute named id_parent which represents the identifier of the parent category (it will be 0 if its parent category is the root of the tree).</li><li>To maintain order, you must have a field containing the rank of the category which be an integer named c_order.</li><li>A field visible boolean (tynint 1 sur mysql)</li><li>A field name containing the category name</li></ul></li><li>In this class the user are supposed to be an administrator, no checking of his auth is done.</li><li>To be correctly displayed, you must supply to functions a variable extracted from a file cache. Use the Cache class to build your file cache. Your variable must be an array in which keys are categories identifiers, an values are still arrays which are as this :
      <ul><li>key id_parent containing the id_parent field of the database</li><li>key name containing the name of the category</li><li>key order</li><li>key visible which is a boolean</li></ul></li><li>You can also have other fields such as auth level, description, visible, that class won't modify them.</li><li>To display the list of categories and actions you can do on them, you may want to customize it. For that you must build an array that you will give to set_display_config() containing your choices :
      <ul><li>Key 'xmlhttprequest_file' which corresponds to the name of the file which will treat the AJAX requests. We usually call it xmlhttprequest.php.</li><li>Key 'url' which represents the url of the category (it won't display any link up to categories if you don't give this field). Its structure is the following :
              <ul><li>key 'unrewrited' =&gt; string containing unrewrited urls (let %d where you want to display the category identifier)</li><li>Key administration_file_name which represents the file which allows you to update category</li><li>rewrited url (optionnal) 'rewrited' =&gt; string containing rewrited urls (let %d where you want to display the category identifier and %s the category name if you need it)</li></ul></li></ul></li></ul>  If you need more informations to use this class, we advise you to look at the wiki of PHPBoost, in which there is a tutorial explaining how to use it step by step.</dd>
</div><br /><br />

<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineADD_THIS_CATEGORY_IN_LIST"></a>
	<h3>ADD_THIS_CATEGORY_IN_LIST <span class="smalllinenumber">[line 41]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ADD_THIS_CATEGORY_IN_LIST = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineAJAX_MODE"></a>
	<h3>AJAX_MODE <span class="smalllinenumber">[line 32]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>AJAX_MODE = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineCATEGORY_DOES_NOT_EXIST"></a>
	<h3>CATEGORY_DOES_NOT_EXIST <span class="smalllinenumber">[line 50]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>CATEGORY_DOES_NOT_EXIST = 0x08</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineCAT_UNVISIBLE"></a>
	<h3>CAT_UNVISIBLE <span class="smalllinenumber">[line 40]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>CAT_UNVISIBLE = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineCAT_VISIBLE"></a>
	<h3>CAT_VISIBLE <span class="smalllinenumber">[line 39]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>CAT_VISIBLE = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineDEBUG_MODE"></a>
	<h3>DEBUG_MODE <span class="smalllinenumber">[line 29]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>DEBUG_MODE = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineDISPLAYING_CONFIGURATION_NOT_SET"></a>
	<h3>DISPLAYING_CONFIGURATION_NOT_SET <span class="smalllinenumber">[line 52]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>DISPLAYING_CONFIGURATION_NOT_SET = 0x20</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineDO_NOT_ADD_THIS_CATEGORY_IN_LIST"></a>
	<h3>DO_NOT_ADD_THIS_CATEGORY_IN_LIST <span class="smalllinenumber">[line 42]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>DO_NOT_ADD_THIS_CATEGORY_IN_LIST = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineDO_NOT_LOAD_CACHE"></a>
	<h3>DO_NOT_LOAD_CACHE <span class="smalllinenumber">[line 37]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>DO_NOT_LOAD_CACHE = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineERROR_CAT_IS_AT_BOTTOM"></a>
	<h3>ERROR_CAT_IS_AT_BOTTOM <span class="smalllinenumber">[line 49]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ERROR_CAT_IS_AT_BOTTOM = 0x04</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineERROR_CAT_IS_AT_TOP"></a>
	<h3>ERROR_CAT_IS_AT_TOP <span class="smalllinenumber">[line 48]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ERROR_CAT_IS_AT_TOP = 0x02</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineERROR_UNKNOWN_MOTION"></a>
	<h3>ERROR_UNKNOWN_MOTION <span class="smalllinenumber">[line 47]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ERROR_UNKNOWN_MOTION = 0x01</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineIGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH"></a>
	<h3>IGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH <span class="smalllinenumber">[line 44]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>IGNORE_AND_CONTINUE_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH = 2</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineINCORRECT_DISPLAYING_CONFIGURATION"></a>
	<h3>INCORRECT_DISPLAYING_CONFIGURATION <span class="smalllinenumber">[line 53]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>INCORRECT_DISPLAYING_CONFIGURATION = 0x40</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineLOAD_CACHE"></a>
	<h3>LOAD_CACHE <span class="smalllinenumber">[line 38]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>LOAD_CACHE = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineMOVE_CATEGORY_DOWN"></a>
	<h3>MOVE_CATEGORY_DOWN <span class="smalllinenumber">[line 36]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>MOVE_CATEGORY_DOWN = 'down'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineMOVE_CATEGORY_UP"></a>
	<h3>MOVE_CATEGORY_UP <span class="smalllinenumber">[line 35]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>MOVE_CATEGORY_UP = 'up'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNEW_CATEGORY_IS_IN_ITS_CHILDRENS"></a>
	<h3>NEW_CATEGORY_IS_IN_ITS_CHILDRENS <span class="smalllinenumber">[line 54]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NEW_CATEGORY_IS_IN_ITS_CHILDRENS = 0x80</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNEW_PARENT_CATEGORY_DOES_NOT_EXIST"></a>
	<h3>NEW_PARENT_CATEGORY_DOES_NOT_EXIST <span class="smalllinenumber">[line 51]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NEW_PARENT_CATEGORY_DOES_NOT_EXIST = 0x10</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNEW_STATUS_UNKNOWN"></a>
	<h3>NEW_STATUS_UNKNOWN <span class="smalllinenumber">[line 55]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NEW_STATUS_UNKNOWN = 0x100</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNORMAL_MODE"></a>
	<h3>NORMAL_MODE <span class="smalllinenumber">[line 31]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NORMAL_MODE = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineNOT_RECURSIVE_EXPLORATION"></a>
	<h3>NOT_RECURSIVE_EXPLORATION <span class="smalllinenumber">[line 34]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>NOT_RECURSIVE_EXPLORATION = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="definePRODUCTION_MODE"></a>
	<h3>PRODUCTION_MODE <span class="smalllinenumber">[line 30]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>PRODUCTION_MODE = false</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineRECURSIVE_EXPLORATION"></a>
	<h3>RECURSIVE_EXPLORATION <span class="smalllinenumber">[line 33]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>RECURSIVE_EXPLORATION = true</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineSTOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH"></a>
	<h3>STOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH <span class="smalllinenumber">[line 43]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>STOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH = 1</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../elementindex_content.php" class="menu">index: content</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:29 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>