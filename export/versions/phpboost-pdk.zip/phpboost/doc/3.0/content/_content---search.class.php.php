<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs for page search.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: search.class.php</h1><p>Source Location: /content/search.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../content/Search.php">Search</a></dt>
	<dd></dd>
</div><br /><br />

<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineCACHE_TIME"></a>
	<h3>CACHE_TIME <span class="smalllinenumber">[line 31]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>CACHE_TIME = $CONFIG['search_cache_time']</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineCACHE_TIMES_USED"></a>
	<h3>CACHE_TIMES_USED <span class="smalllinenumber">[line 32]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>CACHE_TIMES_USED = $CONFIG['search_max_use']</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../elementindex_content.php" class="menu">index: content</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:53 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>