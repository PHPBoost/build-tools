<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs For Class FeedItem');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: FeedItem</h1><p>Source Location: /content/syndication/feed_item.class.php [line 36]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">Contains meta-informations and informations about a feed entry / item</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodFeedItem">FeedItem</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_auth">get_auth</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_date">get_date</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_date_rfc822">get_date_rfc822</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_date_rfc3339">get_date_rfc3339</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_desc">get_desc</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_guid">get_guid</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_image_url">get_image_url</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_link">get_link</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodget_title">get_title</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodset_auth">set_auth</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodset_date">set_date</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodset_desc">set_desc</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodset_guid">set_guid</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodset_image_url">set_image_url</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodset_link">set_link</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#methodset_title">set_title</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../content/syndication/FeedItem.php#var$auth">$auth</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#var$date">$date</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#var$desc">$desc</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#var$guid">$guid</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#var$image_url">$image_url</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#var$link">$link</a></li><li class="bb_li"><a href="../../content/syndication/FeedItem.php#var$title">$title</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">Contains meta-informations and informations about a feed entry / item</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFeedItem"></a>
    <h3>constructor FeedItem <span class="smalllinenumber">[line 42]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>FeedItem FeedItem(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a FeedItem element</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_auth"></a>
    <h3>method get_auth <span class="smalllinenumber">[line 107]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_auth(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_date"></a>
    <h3>method get_date <span class="smalllinenumber">[line 102]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_date(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_date_rfc822"></a>
    <h3>method get_date_rfc822 <span class="smalllinenumber">[line 103]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_date_rfc822(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_date_rfc3339"></a>
    <h3>method get_date_rfc3339 <span class="smalllinenumber">[line 104]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_date_rfc3339(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_desc"></a>
    <h3>method get_desc <span class="smalllinenumber">[line 105]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_desc(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_guid"></a>
    <h3>method get_guid <span class="smalllinenumber">[line 101]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_guid(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_image_url"></a>
    <h3>method get_image_url <span class="smalllinenumber">[line 106]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_image_url(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_link"></a>
    <h3>method get_link <span class="smalllinenumber">[line 100]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_link(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_title"></a>
    <h3>method get_title <span class="smalllinenumber">[line 99]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_title(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_auth"></a>
    <h3>method set_auth <span class="smalllinenumber">[line 69]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_auth(

$auth, int[string]
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the feed item auth, useful to check authorizations</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int[string]&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>the item authorizations array</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$auth</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_date"></a>
    <h3>method set_date <span class="smalllinenumber">[line 54]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_date(
<a href="../../util/Date.php">Date</a>
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the feed item date</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../../util/Date.php">Date</a>&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>a date object representing the item date</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_desc"></a>
    <h3>method set_desc <span class="smalllinenumber">[line 59]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_desc(
string
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the feed item description</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>the feed item description</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_guid"></a>
    <h3>method set_guid <span class="smalllinenumber">[line 86]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_guid(
mixed
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the feed item guid</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>a string url or an Url object</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_image_url"></a>
    <h3>method set_image_url <span class="smalllinenumber">[line 64]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_image_url(
string
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the feed item picture</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>the picture url</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_link"></a>
    <h3>method set_link <span class="smalllinenumber">[line 74]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_link(
mixed
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the feed item link</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>a string url or an Url object</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_title"></a>
    <h3>method set_title <span class="smalllinenumber">[line 49]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_title(
string
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the feed item title</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>The title</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                        <div class="var">
                            <a name="var_auth"></a>
                <span class="line-number">[line 117]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$auth</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_date"></a>
                <span class="line-number">[line 113]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$date</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_desc"></a>
                <span class="line-number">[line 114]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$desc</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_guid"></a>
                <span class="line-number">[line 115]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$guid</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_image_url"></a>
                <span class="line-number">[line 116]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$image_url</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_link"></a>
                <span class="line-number">[line 112]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$link</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_title"></a>
                <span class="line-number">[line 111]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$title</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../../elementindex_content.php" class="menu">index: content</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:48 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>