<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs For Class Feed');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Feed</h1><p>Source Location: /content/syndication/feed.class.php [line 42]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class could be used to export feeds</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



				

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../content/syndication/Feed.php#methodFeed">Feed</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodcache">cache</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodclear_cache">clear_cache</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodexport">export</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodget_cache_file_name">get_cache_file_name</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodget_feed_menu">get_feed_menu</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodget_parsed">get_parsed</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodis_in_cache">is_in_cache</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodload_data">load_data</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodload_file">load_file</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodread">read</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#methodupdate_cache">update_cache</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../content/syndication/Feed.php#var$data">$data</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#var$id_cat">$id_cat</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#var$module_id">$module_id</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#var$name">$name</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#var$str">$str</a></li><li class="bb_li"><a href="../../content/syndication/Feed.php#var$tpl">$tpl</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class could be used to export feeds</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li><li><strong>abstract:</strong> Do not use this class, but one of its children like RSS or ATOM</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFeed"></a>
    <h3>constructor Feed <span class="smalllinenumber">[line 52]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Feed Feed(
string
$module_id, [string
$name = DEFAULT_FEED_NAME], [int
$id_cat = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a new feed object</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>its module_id</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td>the feeds name / type. default is DEFAULT_FEED_NAME</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_cat</strong>&nbsp;&nbsp;</td>
        <td>the feed category id</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcache"></a>
    <h3>method cache <span class="smalllinenumber">[line 150]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void cache(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Send the feed data in the cache</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodexport"></a>
    <h3>method export <span class="smalllinenumber">[line 79]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string export(
[mixed
$template = false], [int
$number = 10], [int
$begin_at = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Exports the feed as a string parsed by the &lt;$tpl&gt; template</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The exported feed</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$template</strong>&nbsp;&nbsp;</td>
        <td>If false, uses de default tpl. If an associative array, uses the default tpl but assigns it the array vars first. It could also be a Template object</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$number</strong>&nbsp;&nbsp;</td>
        <td>the number of item to display</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$begin_at</strong>&nbsp;&nbsp;</td>
        <td>the first item to display</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_cache_file_name"></a>
    <h3>method get_cache_file_name <span class="smalllinenumber">[line 165]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_cache_file_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the feed data cache filename</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the feed data cache filename</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_in_cache"></a>
    <h3>method is_in_cache <span class="smalllinenumber">[line 159]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool is_in_cache(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns true if the feed data are in the cache</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the feed data are in the cache</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodload_data"></a>
    <h3>method load_data <span class="smalllinenumber">[line 63]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void load_data(
<a href="../../content/syndication/FeedData.php">FeedData</a>
$data)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Loads a FeedData element</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../../content/syndication/FeedData.php">FeedData</a>&nbsp;&nbsp;</td>
        <td><strong>$data</strong>&nbsp;&nbsp;</td>
        <td>the element to load</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodload_file"></a>
    <h3>method load_file <span class="smalllinenumber">[line 68]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void load_file(
string
$url)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Loads a feed by its url</div>
    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../../content/syndication/RSS.php#methodload_file">RSS::load_file()</a></dt>
        <dd>Loads a feed by its url</dd>
    </dl>
        <dl>
    <dt><a href="../../content/syndication/ATOM.php#methodload_file">ATOM::load_file()</a></dt>
        <dd>Loads a feed by its url</dd>
    </dl>
    </p>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$url</strong>&nbsp;&nbsp;</td>
        <td>the feed url</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodread"></a>
    <h3>method read <span class="smalllinenumber">[line 133]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string read(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Loads the feed data in cache and export it</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the exported feed</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodclear_cache"></a>
	<h3>static method clear_cache <span class="smalllinenumber">[line 186]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static void clear_cache(
[mixed
$module_id = false])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Clear the cache of the specified module_id.</div>
	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>the module module_id or false. If false, Clear all feeds data from the cache</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_feed_menu"></a>
	<h3>static method get_feed_menu <span class="smalllinenumber">[line 302]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string get_feed_menu(
string
$feed_url)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Generates the code which shows all the feeds formats.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The HTML code to display.</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$feed_url</strong>&nbsp;&nbsp;</td>
        <td>Feed URL</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodget_parsed"></a>
	<h3>static method get_parsed <span class="smalllinenumber">[line 234]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string get_parsed(
string
$module_id, [string
$name = DEFAULT_FEED_NAME], [int
$idcat = 0], [mixed
$tpl = false], [int
$number = 10], [int
$begin_at = 0])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Export a feed</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The exported feed</li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>the module id</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td>the feed name / type</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idcat</strong>&nbsp;&nbsp;</td>
        <td>the feed data category</td>
      </tr>
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$tpl</strong>&nbsp;&nbsp;</td>
        <td>If false, uses de default tpl. If an associative array, uses the default tpl but assigns it the array vars first. It could also be a Template object</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$number</strong>&nbsp;&nbsp;</td>
        <td>the number of item to display</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$begin_at</strong>&nbsp;&nbsp;</td>
        <td>the first item to display</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methodupdate_cache"></a>
	<h3>static method update_cache <span class="smalllinenumber">[line 213]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static void update_cache(
string
$module_id, string
$name, 
&$data, [int
$idcat = 0], &FeedData
$data)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Update the cache of the $module_id, $name, $idcat feed with $data</div>
	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>the module id</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td>the feed name / type</td>
      </tr>
          <tr>
        <td class="type">&FeedData&nbsp;&nbsp;</td>
        <td><strong>$data</strong>&nbsp;&nbsp;</td>
        <td>the data to put in the cache</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idcat</strong>&nbsp;&nbsp;</td>
        <td>the feed data category</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$data</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                    <div class="var">
                            <a name="var_data"></a>
                <span class="line-number">[line 174]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$data</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id_cat"></a>
                <span class="line-number">[line 170]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id_cat</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_module_id"></a>
                <span class="line-number">[line 169]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$module_id</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_name"></a>
                <span class="line-number">[line 171]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_str"></a>
                <span class="line-number">[line 172]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$str</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_tpl"></a>
                <span class="line-number">[line 173]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$tpl</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;null</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../../elementindex_content.php" class="menu">index: content</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Thu, 07 Apr 2011 21:48:22 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>