<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs For Class Search');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Search</h1><p>Source Location: /content/search.class.php [line 39]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description"></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../content/Search.php#methodSearch">Search</a></li><li class="bb_li"><a href="../content/Search.php#methodget_ids">get_ids</a></li><li class="bb_li"><a href="../content/Search.php#methodget_results">get_results</a></li><li class="bb_li"><a href="../content/Search.php#methodget_results_by_id">get_results_by_id</a></li><li class="bb_li"><a href="../content/Search.php#methodinsert_results">insert_results</a></li><li class="bb_li"><a href="../content/Search.php#methodis_in_cache">is_in_cache</a></li><li class="bb_li"><a href="../content/Search.php#methodis_search_id_in_cache">is_search_id_in_cache</a></li><li class="bb_li"><a href="../content/Search.php#methodmodules_in_cache">modules_in_cache</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../content/Search.php#var$errors">$errors</a></li><li class="bb_li"><a href="../content/Search.php#var$id_search">$id_search</a></li><li class="bb_li"><a href="../content/Search.php#var$id_user">$id_user</a></li><li class="bb_li"><a href="../content/Search.php#var$modules">$modules</a></li><li class="bb_li"><a href="../content/Search.php#var$modules_conditions">$modules_conditions</a></li><li class="bb_li"><a href="../content/Search.php#var$search">$search</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags">    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodSearch"></a>
    <h3>constructor Search <span class="smalllinenumber">[line 53]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Search Search(
[string
$search = ''], [mixed[]
$modules = array()])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a search object. Query Complexity: 6 + k / 10 database queries. (k represent the number of module without search cache)</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$search</strong>&nbsp;&nbsp;</td>
        <td>the string to search</td>
      </tr>
          <tr>
        <td class="type">mixed[]&nbsp;&nbsp;</td>
        <td><strong>$modules</strong>&nbsp;&nbsp;</td>
        <td>Modules in which we gonna search with their search params. This argument is an array which keys are module id's and values are arrays containing the specialized search arguments for a particular module.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_ids"></a>
    <h3>method get_ids <span class="smalllinenumber">[line 411]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_ids(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the search id</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the search id</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_results"></a>
    <h3>method get_results <span class="smalllinenumber">[line 229]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_results(
string[]
&$results, string[]
&$module_ids, [int
$nb_lines = 0], [int
$offset = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Puts results from the search results in the $results parameter and returns the number of results. Query complexity: 1 query.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The number of results</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>&$results</strong>&nbsp;&nbsp;</td>
        <td>the results returned</td>
      </tr>
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>&$module_ids</strong>&nbsp;&nbsp;</td>
        <td>the modules ids from which retrieve results</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$nb_lines</strong>&nbsp;&nbsp;</td>
        <td>the number of lines to return</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$offset</strong>&nbsp;&nbsp;</td>
        <td>the offset from which return results</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_results_by_id"></a>
    <h3>method get_results_by_id <span class="smalllinenumber">[line 191]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_results_by_id(
string[]
&$results, [int
$id_search = 0], [int
$nb_lines = 0], [int
$offset = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Puts results from the search results identified by the $id_search parameter in the $results parameter and returns the number of results. Query complexity: 2 queries.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The number of results</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>&$results</strong>&nbsp;&nbsp;</td>
        <td>the results returned</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_search</strong>&nbsp;&nbsp;</td>
        <td>the search id</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$nb_lines</strong>&nbsp;&nbsp;</td>
        <td>the number of lines to return</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$offset</strong>&nbsp;&nbsp;</td>
        <td>the offset from which return results</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodinsert_results"></a>
    <h3>method insert_results <span class="smalllinenumber">[line 287]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void insert_results(
mixed[]
&$requestAndResults)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Inserts search results in the database cache in order to speed up next searches. Query complexity: 1 + k / 10 queries. (k represent the number of results to insert in the database)</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">mixed[]&nbsp;&nbsp;</td>
        <td><strong>&$requestAndResults</strong>&nbsp;&nbsp;</td>
        <td>This parameters is an array with keys that are modules ids and values that could be both a SQL query or a results array.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_in_cache"></a>
    <h3>method is_in_cache <span class="smalllinenumber">[line 392]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool is_in_cache(
string
$module_id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns true if the module results are in cache, else, false.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the module results are in cache, else, false.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>the module to check.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_search_id_in_cache"></a>
    <h3>method is_search_id_in_cache <span class="smalllinenumber">[line 365]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool is_search_id_in_cache(
int
$id_search)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns true if the id_search is in cache, else, false.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the id_search is in cache, else, false.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_search</strong>&nbsp;&nbsp;</td>
        <td>the search id to check.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodmodules_in_cache"></a>
    <h3>method modules_in_cache <span class="smalllinenumber">[line 402]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string[] modules_in_cache(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the list of the modules ids present in the cache</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the list of the modules present in the cache</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                    <div class="var">
                            <a name="var_errors"></a>
                <span class="line-number">[line 460]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$errors</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id_search"></a>
                <span class="line-number">[line 455]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id_search</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id_user"></a>
                <span class="line-number">[line 459]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id_user</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_modules"></a>
                <span class="line-number">[line 457]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$modules</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_modules_conditions"></a>
                <span class="line-number">[line 458]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$modules_conditions</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_search"></a>
                <span class="line-number">[line 456]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$search</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../elementindex_content.php" class="menu">index: content</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:49:02 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>