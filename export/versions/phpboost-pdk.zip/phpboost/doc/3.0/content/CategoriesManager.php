<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs For Class CategoriesManager');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: CategoriesManager</h1><p>Source Location: /content/categories_manager.class.php [line 101]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class enables you to manage easily the administration of categories for your modules. It's as generic as possible, if you want to complete some actions to specialize them for you module, you can create a new class inheritating of it in which you call its methods using the syntax parent::method(). <br /> /!\ Warning : /!\ <ul><li>Your DB table must respect some rules :
         <ul><li>You must have an integer attribute whose name is id and which represents the identifier of each category. It must be a primary key.</li><li>You also must have an integer attribute named id_parent which represents the identifier of the parent category (it will be 0 if its parent category is the root of the tree).</li><li>To maintain order, you must have a field containing the rank of the category which be an integer named c_order.</li><li>A field visible boolean (tynint 1 sur mysql)</li><li>A field name containing the category name</li></ul></li><li>In this class the user are supposed to be an administrator, no checking of his auth is done.</li><li>To be correctly displayed, you must supply to functions a variable extracted from a file cache. Use the Cache class to build your file cache. Your variable must be an array in which keys are categories identifiers, an values are still arrays which are as this :
      <ul><li>key id_parent containing the id_parent field of the database</li><li>key name containing the name of the category</li><li>key order</li><li>key visible which is a boolean</li></ul></li><li>You can also have other fields such as auth level, description, visible, that class won't modify them.</li><li>To display the list of categories and actions you can do on them, you may want to customize it. For that you must build an array that you will give to set_display_config() containing your choices :
      <ul><li>Key 'xmlhttprequest_file' which corresponds to the name of the file which will treat the AJAX requests. We usually call it xmlhttprequest.php.</li><li>Key 'url' which represents the url of the category (it won't display any link up to categories if you don't give this field). Its structure is the following :
              <ul><li>key 'unrewrited' =&gt; string containing unrewrited urls (let %d where you want to display the category identifier)</li><li>Key administration_file_name which represents the file which allows you to update category</li><li>rewrited url (optionnal) 'rewrited' =&gt; string containing rewrited urls (let %d where you want to display the category identifier and %s the category name if you need it)</li></ul></li></ul></li></ul>  If you need more informations to use this class, we advise you to look at the wiki of PHPBoost, in which there is a tutorial explaining how to use it step by step.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../content/CategoriesManager.php#methodCategoriesManager">CategoriesManager</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodadd">add</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodbuild_administration_interface">build_administration_interface</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodbuild_children_id_list">build_children_id_list</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodbuild_parents_id_list">build_parents_id_list</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodbuild_select_form">build_select_form</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodchange_visibility">change_visibility</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodcheck_display_config">check_display_config</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodcheck_error">check_error</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodcompute_heritated_auth">compute_heritated_auth</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methoddelete">delete</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodget_feeds_list">get_feeds_list</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodmove">move</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodmove_into_another">move_into_another</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#methodset_display_config">set_display_config</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../content/CategoriesManager.php#var$cache_file_name">$cache_file_name</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#var$cache_var">$cache_var</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#var$display_config">$display_config</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#var$errors">$errors</a></li><li class="bb_li"><a href="../content/CategoriesManager.php#var$table">$table</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class enables you to manage easily the administration of categories for your modules. It's as generic as possible, if you want to complete some actions to specialize them for you module, you can create a new class inheritating of it in which you call its methods using the syntax parent::method(). <br /> /!\ Warning : /!\ <ul><li>Your DB table must respect some rules :
         <ul><li>You must have an integer attribute whose name is id and which represents the identifier of each category. It must be a primary key.</li><li>You also must have an integer attribute named id_parent which represents the identifier of the parent category (it will be 0 if its parent category is the root of the tree).</li><li>To maintain order, you must have a field containing the rank of the category which be an integer named c_order.</li><li>A field visible boolean (tynint 1 sur mysql)</li><li>A field name containing the category name</li></ul></li><li>In this class the user are supposed to be an administrator, no checking of his auth is done.</li><li>To be correctly displayed, you must supply to functions a variable extracted from a file cache. Use the Cache class to build your file cache. Your variable must be an array in which keys are categories identifiers, an values are still arrays which are as this :
      <ul><li>key id_parent containing the id_parent field of the database</li><li>key name containing the name of the category</li><li>key order</li><li>key visible which is a boolean</li></ul></li><li>You can also have other fields such as auth level, description, visible, that class won't modify them.</li><li>To display the list of categories and actions you can do on them, you may want to customize it. For that you must build an array that you will give to set_display_config() containing your choices :
      <ul><li>Key 'xmlhttprequest_file' which corresponds to the name of the file which will treat the AJAX requests. We usually call it xmlhttprequest.php.</li><li>Key 'url' which represents the url of the category (it won't display any link up to categories if you don't give this field). Its structure is the following :
              <ul><li>key 'unrewrited' =&gt; string containing unrewrited urls (let %d where you want to display the category identifier)</li><li>Key administration_file_name which represents the file which allows you to update category</li><li>rewrited url (optionnal) 'rewrited' =&gt; string containing rewrited urls (let %d where you want to display the category identifier and %s the category name if you need it)</li></ul></li></ul></li></ul>  If you need more informations to use this class, we advise you to look at the wiki of PHPBoost, in which there is a tutorial explaining how to use it step by step.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodCategoriesManager"></a>
    <h3>constructor CategoriesManager <span class="smalllinenumber">[line 110]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>CategoriesManager CategoriesManager(
string
$table, string
$cache_file_name, &array[]
&$cache_var)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a CategoriesManager object</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$table</strong>&nbsp;&nbsp;</td>
        <td>Table name of the database which contains the require fields (explained in the class description)</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$cache_file_name</strong>&nbsp;&nbsp;</td>
        <td>Name of the cache file (usefull to regenerate the cache after a modification of the categories tree)</td>
      </tr>
          <tr>
        <td class="type">&array[]&nbsp;&nbsp;</td>
        <td><strong>&$cache_var</strong>&nbsp;&nbsp;</td>
        <td>Array containing the correct data, descripted in the description of the class.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadd"></a>
    <h3>method add <span class="smalllinenumber">[line 127]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int add(
int
$id_parent, string
$name, [bool
$visible = CAT_VISIBLE], [int
$order = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Adds a category. We can decide if it will be visible and what its position will be</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The id of the category which has been added and 0 if it couldn't be added (the error will be explained in the check_error method). The error can be only NEW_PARENT_CATEGORY_DOES_NOT_EXIST, which means that its parent category doesn't exist.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id_parent</strong>&nbsp;&nbsp;</td>
        <td>Id of the category in which this category will be added</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td>Name of the category to add</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$visible</strong>&nbsp;&nbsp;</td>
        <td>Is the category visible? CAT_VISIBLE if visible, CAT_UNVISIBLE else</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$order</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodbuild_administration_interface"></a>
    <h3>method build_administration_interface <span class="smalllinenumber">[line 437]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>mixed build_administration_interface(
[bool
$ajax_mode = NORMAL_MODE], [<a href="../io/Template.php">Template</a>
$category_template = NULL])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds the list of categories and links to makes operations to administrate them (delete, move, add...), it supplies a string ready to be displayed. It uses AJAX, read the class description to understand this user interface.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> If there was no error, it returns the HTML code which integrates the whole management of the category tree that you just have to display. If there is an error, it will return false and you will be able to know the error by using the wheck_error method. The raised erros can be INCORRECT_DISPLAYING_CONFIGURATION if the displaying configuration hasn't be established or is not correct.</li><li><strong>warning:</strong> You must have defined a displaying configuration before calling this method. You must do it with the set_display_config method.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$ajax_mode</strong>&nbsp;&nbsp;</td>
        <td>Set this parameter to NORMAL_MODE if it's the global display and AJAX_MODE if it's called in the AJAX handler.</td>
      </tr>
          <tr>
        <td class="type"><a href="../io/Template.php">Template</a>&nbsp;&nbsp;</td>
        <td><strong>$category_template</strong>&nbsp;&nbsp;</td>
        <td>Use this parameter if you want to use a particular template. The default theme is framework/content/category.tpl.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodbuild_children_id_list"></a>
    <h3>method build_children_id_list <span class="smalllinenumber">[line 521]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int[] build_children_id_list(
int
$category_id, &int[]
&$list, [bool
$recursive_exploration = RECURSIVE_EXPLORATION], [bool
$add_this = DO_NOT_ADD_THIS_CATEGORY_IN_LIST], [int
$num_auth = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds the list of all the children of a category</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the ids of the subcategories.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$category_id</strong>&nbsp;&nbsp;</td>
        <td>Id of the category for which we want to know the children</td>
      </tr>
          <tr>
        <td class="type">&int[]&nbsp;&nbsp;</td>
        <td><strong>&$list</strong>&nbsp;&nbsp;</td>
        <td>Array in which the result will be written.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$recursive_exploration</strong>&nbsp;&nbsp;</td>
        <td>Sets if you want to explorer only the current sublevel of the tree or the whole subtree. Use RECURSIVE_EXPLORATION to make a recursive exploration, NOT_RECURSIVE_EXPLORATION otherwise.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$add_this</strong>&nbsp;&nbsp;</td>
        <td>If you want to add the current category to the list use ADD_THIS_CATEGORY_IN_LIST, DO_NOT_ADD_THIS_CATEGORY_IN_LIST otherwise.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$num_auth</strong>&nbsp;&nbsp;</td>
        <td>If you want to filter the category according to an authorization bit, put its value here</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodbuild_parents_id_list"></a>
    <h3>method build_parents_id_list <span class="smalllinenumber">[line 558]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int[] build_parents_id_list(
int
$category_id, [bool
$add_this = DO_NOT_ADD_THIS_CATEGORY_IN_LIST])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds the list of the parent categories of a category</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list of the ids of the parent categories.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$category_id</strong>&nbsp;&nbsp;</td>
        <td>Id of the category of which you want the list of parents categories.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$add_this</strong>&nbsp;&nbsp;</td>
        <td>If you want to add the current cat at the list. Use ADD_THIS_CATEGORY_IN_LIST if you want, DO_NOT_ADD_THIS_CATEGORY_IN_LIST otherwise.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodbuild_select_form"></a>
    <h3>method build_select_form <span class="smalllinenumber">[line 488]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string build_select_form(
int
$selected_id, string
$form_id, string
$form_name, [int
$current_id_cat = 0], [int
$num_auth = 0], [mixed[]
$array_auth = array()], [bool
$recursion_mode = STOP_BROWSING_IF_A_CATEGORY_DOES_NOT_MATCH], [<a href="../io/Template.php">Template</a>
$template = NULL])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a formulary which allows user to choose a category in a select form.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The HTML code which displays the select form.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$selected_id</strong>&nbsp;&nbsp;</td>
        <td>Current category id (the id of the category selected in default displaying).</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_id</strong>&nbsp;&nbsp;</td>
        <td>HTML identifier of the object (id of the DOM Document Objet Model).t'</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_name</strong>&nbsp;&nbsp;</td>
        <td>HTML name of the select form in which you will manage to retrieve the selected category.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$current_id_cat</strong>&nbsp;&nbsp;</td>
        <td>This parameter is to use when for instance you want to move a category in another, it will not display the children categories of the current category because you cannot move it into one of its subcategories.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$num_auth</strong>&nbsp;&nbsp;</td>
        <td>If you don't want to display the categories which can not be chosen by the user, you can supply an authorization number which will be used on the $array_auth parameter</td>
      </tr>
          <tr>
        <td class="type">mixed[]&nbsp;&nbsp;</td>
        <td><strong>$array_auth</strong>&nbsp;&nbsp;</td>
        <td>Authorization array which is used if a category hasn't special authorizations</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$recursion_mode</strong>&nbsp;&nbsp;</td>
        <td>Sets whether you want to display only the current category or its whole subcategories. Use the constant RECURSIVE_EXPLORATION if you want to explore the whole tree, NOT_RECURSIVE_EXPLORATION otherwise.</td>
      </tr>
          <tr>
        <td class="type"><a href="../io/Template.php">Template</a>&nbsp;&nbsp;</td>
        <td><strong>$template</strong>&nbsp;&nbsp;</td>
        <td>If you want to customize the displaying, you can give the method a template objet in which variables will be assigned. The default template is framework/content/categories_select_form.tpl.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodchange_visibility"></a>
    <h3>method change_visibility <span class="smalllinenumber">[line 345]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool change_visibility(
int
$category_id, bool
$visibility, [bool
$generate_cache = LOAD_CACHE])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Changes the visibility of a category</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the visibility has been changed, false otherwise. If it fails, you can check the error with the method check_method, it can raise the following errors: <ul><li>NEW_STATUS_UNKNOWN when the new status you want to give to the category is not supported (if it's neither CAT_VISIBLE nor CAT_UNVISIBLE)</li><li>CATEGORY_DOES_NOT_EXIST when the category for which you want to change the visibility doesn't exist</li></ul></li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$category_id</strong>&nbsp;&nbsp;</td>
        <td>id of the category whose property must be changed</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$visibility</strong>&nbsp;&nbsp;</td>
        <td>set to visible or unvisible (use constants CAT_VISIBLE and CAT_UNVISIBLE)</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$generate_cache</strong>&nbsp;&nbsp;</td>
        <td>if you want that the system regenerate the cache file of the module. Use the constants LOAD_CACHE to regenerate and reload the cache or DO_NOT_LOAD_CACHE else.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcheck_display_config"></a>
    <h3>method check_display_config <span class="smalllinenumber">[line 400]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool check_display_config(
[bool
$debug = PRODUCTION_MODE])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Checks if display configuration is good</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the configuration is correct, false otherwise.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$debug</strong>&nbsp;&nbsp;</td>
        <td>DEBUG_MODE if you want to display the errors, or PRODUCTION_MODE to return false if it fails.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcheck_error"></a>
    <h3>method check_error <span class="smalllinenumber">[line 580]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool check_error(
int
$error)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Checks if an error has been raised on the last reported error. At each call of a method of this class which can raise an error, the last error is erased.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the error has been raised and false else.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$error</strong>&nbsp;&nbsp;</td>
        <td>Constant corresponding to the error to check. Use the constant corresponding to the error (detailed in each method description).</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodcompute_heritated_auth"></a>
    <h3>method compute_heritated_auth <span class="smalllinenumber">[line 592]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>mixed[] compute_heritated_auth(
int
$category_id, int
$bit, int
$mode)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Computes the global authorization level of the whole parent categories. The result corresponds to all the category's parents merged.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The merged array that you can use only for the bit $bit.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$category_id</strong>&nbsp;&nbsp;</td>
        <td>Id of the category for which you want to know what is the global authorization</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$bit</strong>&nbsp;&nbsp;</td>
        <td>The autorization bit you want to check</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$mode</strong>&nbsp;&nbsp;</td>
        <td>Merge mode. If it corresponds to a read autorization, use AUTH_PARENT_PRIORITY which will disallow for example all the subcategories of a category to which you can't access, or AUTH_CHILD_PRIORITY if you want to work in write mode, each child will be able to redifine the authorization.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete"></a>
    <h3>method delete <span class="smalllinenumber">[line 308]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool delete(
int
$id)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Deletes a category.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the category has been deleted successfully and false otherwise, and in this case you can find the error in the check_error method. The error CATEGORY_DOES_NOT_EXIST is raised if the category to delete doesn't exist.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Id of the category to delete.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_feeds_list"></a>
    <h3>method get_feeds_list <span class="smalllinenumber">[line 614]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../content/syndication/FeedsList.php">FeedsList</a> get_feeds_list(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Computes the list of the feeds corresponding to each category of the category tree.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The list.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodmove"></a>
    <h3>method move <span class="smalllinenumber">[line 171]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool move(
int
$id, string
$way)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Moves a category (makes it gone up or down)</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true whether the category could be moved, false otherwise. If it's false, you will be able to know what was the error by using check_error method. The error will be: <ul><li>CATEGORY_DOES_NOT_EXIST when the category to move doesn't exist</li><li>ERROR_CAT_IS_AT_BOTTOM when you want to move down a category whereas it's already at the bottom of the parent category</li><li>ERROR_CAT_IS_AT_TOP when you want to move up a categoty whereas it's already at the top of the parent category</li><li>ERROR_UNKNOWN_MOTION if the motion you asked is neither MOVE_CATEGORY_UP nor MOVE_CATEGORY_DOWN</li></ul></li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Id of the category to move</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$way</strong>&nbsp;&nbsp;</td>
        <td>The way according to which the category has to be moved. It must be either MOVE_CATEGORY_UP or MOVE_CATEGORY_DOWN.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodmove_into_another"></a>
    <h3>method move_into_another <span class="smalllinenumber">[line 248]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool move_into_another(
int
$id, int
$new_id_cat, [int
$position = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Moves a category into another category. You can specify its future position in its future parent category.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the category has been moved successfully, false otherwise, in this case you will be able to know the error by using the check_error method. The errors can be <ul><li>NEW_CATEGORY_IS_IN_ITS_CHILDRENS if you tried to move the category into one of its children. It's not possible because the structure won't be anymore a tree.</li><li>NEW_PARENT_CATEGORY_DOES_NOT_EXIST when the category in which you want it to be moved doesn't exist.</li><li>CATEGORY_DOES_NOT_EXIST when the category you want to move doesn't exist</li></ul></li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$id</strong>&nbsp;&nbsp;</td>
        <td>Id of the category to move</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$new_id_cat</strong>&nbsp;&nbsp;</td>
        <td>Id of the parent category in which the category will be moved.</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$position</strong>&nbsp;&nbsp;</td>
        <td>Position (number) that the category has to take in its new parent category. If not specified, it will be placed at the end of the category.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_display_config"></a>
    <h3>method set_display_config <span class="smalllinenumber">[line 387]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>unknown_type set_display_config(
$config
$config)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Method which sets the displaying configuration Config example $config = array(         'xmlhttprequest_file' =&gt; 'xmlhttprequest.php',         'administration_file_name' =&gt; 'admin_news_cats.php',         'url' =&gt; array(             'unrewrited' =&gt; PATH_TO_ROOT . '/news/news.php?id=%d',             'rewrited' =&gt; PATH_TO_ROOT . '/news-%d+%s.php'         ), );</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$config&nbsp;&nbsp;</td>
        <td><strong>$config</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                <div class="var">
                            <a name="var_cache_file_name"></a>
                <span class="line-number">[line 853]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$cache_file_name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_cache_var"></a>
                <span class="line-number">[line 868]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$cache_var</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_display_config"></a>
                <span class="line-number">[line 863]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$display_config</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_errors"></a>
                <span class="line-number">[line 858]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$errors</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_table"></a>
                <span class="line-number">[line 848]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$table</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../elementindex_content.php" class="menu">index: content</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:42 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>