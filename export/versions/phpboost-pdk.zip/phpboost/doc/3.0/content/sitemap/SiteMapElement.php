<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs For Class SiteMapElement');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: SiteMapElement</h1><p>Source Location: /content/sitemap/site_map_element.class.php [line 38]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This abstract is the root of every object which can be contained by a SiteMap object. Some SiteMapElements objects can contain one or many SiteMapElement objects therefore the elements can be represented by a tree an each element has a depth in the tree.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



				

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../content/sitemap/SiteMapElement.php#methodSiteMapElement">SiteMapElement</a></li><li class="bb_li"><a href="../../content/sitemap/SiteMapElement.php#methodexport">export</a></li><li class="bb_li"><a href="../../content/sitemap/SiteMapElement.php#methodget_depth">get_depth</a></li><li class="bb_li"><a href="../../content/sitemap/SiteMapElement.php#methodget_name">get_name</a></li><li class="bb_li"><a href="../../content/sitemap/SiteMapElement.php#methodset_depth">set_depth</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../content/sitemap/SiteMapElement.php#var$depth">$depth</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This abstract is the root of every object which can be contained by a SiteMap object. Some SiteMapElements objects can contain one or many SiteMapElement objects therefore the elements can be represented by a tree an each element has a depth in the tree.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Beno�t Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li><li><strong>abstract:</strong> </li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodSiteMapElement"></a>
    <h3>constructor SiteMapElement <span class="smalllinenumber">[line 44]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>SiteMapElement SiteMapElement(
string
$name)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a SiteMapElement object</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$name</strong>&nbsp;&nbsp;</td>
        <td>Name of the object</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodexport"></a>
    <h3>method export <span class="smalllinenumber">[line 89]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string export(

&$export_config, SiteMapExportConfig
$export_config, int
$depth)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Exports the element</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The exported code</li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../../content/sitemap/SiteMapSection.php#methodexport">SiteMapSection::export()</a></dt>
        <dd>Exports the section according to the given configuration. You will use the following template variables: <ul><li>SECTION_NAME which contains the name of the section</li><li>SECTION_URL which contains the URL of the link associated to the section</li><li>DEPTH which contains the depth of the section in the site map tree (useful for CSS classes names)</li><li>LINK_CODE which contains the code got by the associated link export</li><li>C_SECTION, boolean meaning that it's a section (useful if you want to use a sigle template for the whole export configuration)</li><li>A loop &quot;element&quot; containing evert element of the section (their code is available in the CODE variable of the loop)</li></ul></dd>
    </dl>
        <dl>
    <dt><a href="../../content/sitemap/ModuleMap.php#methodexport">ModuleMap::export()</a></dt>
        <dd>Exports the sitemap (according to a configuration of templates). In your template, you will be able to use the following variables: <ul><li>MODULE_NAME which contains the name of the module</li><li>MODULE_DESCRIPTION which contains the description of the module</li><li>MODULE_URL which contains the URL of the module root page</li><li>DEPTH which is the depth of the module map in the sitemap (generally 1).
  It might be usefull to apply different CSS styles to each level of depth.</li><li>LINK_CODE which contains the code of the link associated to the module root exported with the same configuration.</li><li>C_MODULE_MAP which is a boolean whose value is true, this will enable you to use a single template for the whole export configuration</li><li>The loop &quot;element&quot; for which the variable CODE contains the code of each sub element of the module (for example categories)</li></ul></dd>
    </dl>
        <dl>
    <dt><a href="../../content/sitemap/SiteMapLink.php#methodexport">SiteMapLink::export()</a></dt>
        <dd>Exports the section according to the given configuration. You will use the following template variables: <ul><li>LOC containing the URL of the link</li><li>TEXT containing the name of the target page</li><li>C_DISPLAY_DATE indicating if the date is not empty</li><li>DATE containing the date of the last modification of the target page, formatted for the sitemap.xml file</li><li>ACTUALIZATION_FREQUENCY corresponding to the code needed in the sitemap.xml file</li><li>PRIORITY corresponding to the code needed in the sitemap.xml file to indicate the priority of the target page.</li><li>C_LINK indicating that we are displaying a link (useful if you want to use a signe template export configuration)</li></ul></dd>
    </dl>
    </p>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">SiteMapExportConfig&nbsp;&nbsp;</td>
        <td><strong>$export_config</strong>&nbsp;&nbsp;</td>
        <td>Export configuration</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$depth</strong>&nbsp;&nbsp;</td>
        <td>Depth of the element</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>&$export_config</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_depth"></a>
    <h3>method get_depth <span class="smalllinenumber">[line 53]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_depth(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the depth of the element in the tree</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> depth</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_name"></a>
    <h3>method get_name <span class="smalllinenumber">[line 62]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the name of the menu</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> name</li></ul>
    </div>

    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../../content/sitemap/SiteMapLink.php#methodget_name">SiteMapLink::get_name()</a></dt>
        <dd>Returns the name of the target page</dd>
    </dl>
    </p>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_depth"></a>
    <h3>method set_depth <span class="smalllinenumber">[line 78]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_depth(
int
$depth)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Sets the depth of the element</div>
    <p>Overridden in child classes as:
        <dl>
    <dt><a href="../../content/sitemap/SiteMapSection.php#methodset_depth">SiteMapSection::set_depth()</a></dt>
        <dd>Sets the depth of the element</dd>
    </dl>
    </p>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$depth</strong>&nbsp;&nbsp;</td>
        <td>the depth of the element</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                <div class="var">
                            <a name="var_depth"></a>
                <span class="line-number">[line 97]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$depth</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;1</span>                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../../elementindex_content.php" class="menu">index: content</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:53 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>