<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'content - Docs For Class Comments');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('content', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">content</div>
        <div class="module_contents">
        <div>
            
                                                                                                        
                                                                                                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> - 
                <a href="../elementindex_content.php" class="menu">index: content</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/ATOM.php">ATOM</a>            </li>
                    <li>
                <a href="../content/syndication/Feed.php">Feed</a>            </li>
                    <li>
                <a href="../content/syndication/FeedData.php">FeedData</a>            </li>
                    <li>
                <a href="../content/syndication/FeedItem.php">FeedItem</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsCat.php">FeedsCat</a>            </li>
                    <li>
                <a href="../content/syndication/FeedsList.php">FeedsList</a>            </li>
                    <li>
                <a href="../content/syndication/RSS.php">RSS</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/BBCodeEditor.php">BBCodeEditor</a>            </li>
                    <li>
                <a href="../content/editor/ContentEditor.php">ContentEditor</a>            </li>
                    <li>
                <a href="../content/editor/TinyMCEEditor.php">TinyMCEEditor</a>            </li>
                                </ul>
            </li>
                                <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/BBCodeHighlighter.php">BBCodeHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeParser.php">BBCodeParser</a>            </li>
                    <li>
                <a href="../content/parser/BBCodeUnparser.php">BBCodeUnparser</a>            </li>
                    <li>
                <a href="../content/parser/ContentFormattingFactory.php">ContentFormattingFactory</a>            </li>
                    <li>
                <a href="../content/parser/ContentParser.php">ContentParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentSecondParser.php">ContentSecondParser</a>            </li>
                    <li>
                <a href="../content/parser/ContentUnparser.php">ContentUnparser</a>            </li>
                    <li>
                <a href="../content/parser/Parser.php">Parser</a>            </li>
                    <li>
                <a href="../content/parser/TemplateHighlighter.php">TemplateHighlighter</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEParser.php">TinyMCEParser</a>            </li>
                    <li>
                <a href="../content/parser/TinyMCEUnparser.php">TinyMCEUnparser</a>            </li>
                                </ul>
            </li>
                                        <li>
                <a href="../content/CategoriesManager.php">CategoriesManager</a>            </li>
                    <li>
                <a href="../content/Comments.php">Comments</a>            </li>
                    <li>
                <a href="../content/Note.php">Note</a>            </li>
                    <li>
                <a href="../content/Search.php">Search</a>            </li>
                                        <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/ModuleMap.php">ModuleMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMap.php">SiteMap</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapElement.php">SiteMapElement</a>            </li>
                    <li>
                <a href="../content/sitemap/SitemapExportConfig.php">SitemapExportConfig</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapLink.php">SiteMapLink</a>            </li>
                    <li>
                <a href="../content/sitemap/SiteMapSection.php">SiteMapSection</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../content/_content---categories_manager.class.php.php">                categories_manager.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---comments.class.php.php">                comments.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---note.class.php.php">                note.class.php
                </a>            </li>
                    <li>
                <a href="../content/_content---search.class.php.php">                search.class.php
                </a>            </li>
            </li>
                            <li>
                <strong>editor</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/editor/_content---editor---bbcode_editor.class.php.php">                bbcode_editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---editor.class.php.php">                editor.class.php
                </a>            </li>
                    <li>
                <a href="../content/editor/_content---editor---tinymce_editor.class.php.php">                tinymce_editor.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>parser</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/parser/_content---parser---bbcode_highlighter.class.php.php">                bbcode_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_parser.class.php.php">                bbcode_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---bbcode_unparser.class.php.php">                bbcode_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_formatting_factory.class.php.php">                content_formatting_factory.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_parser.class.php.php">                content_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_second_parser.class.php.php">                content_second_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---content_unparser.class.php.php">                content_unparser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---parser.class.php.php">                parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---template_highlighter.class.php.php">                template_highlighter.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_parser.class.php.php">                tinymce_parser.class.php
                </a>            </li>
                    <li>
                <a href="../content/parser/_content---parser---tinymce_unparser.class.php.php">                tinymce_unparser.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>sitemap</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/sitemap/_content---sitemap---module_map.class.php.php">                module_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map.class.php.php">                site_map.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_element.class.php.php">                site_map_element.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_export_config.class.php.php">                site_map_export_config.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_link.class.php.php">                site_map_link.class.php
                </a>            </li>
                    <li>
                <a href="../content/sitemap/_content---sitemap---site_map_section.class.php.php">                site_map_section.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
                            <li>
                <strong>syndication</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../content/syndication/_content---syndication---atom.class.php.php">                atom.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed.class.php.php">                feed.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_cat.class.php.php">                feeds_cat.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feeds_list.class.php.php">                feeds_list.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_data.class.php.php">                feed_data.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---feed_item.class.php.php">                feed_item.class.php
                </a>            </li>
                    <li>
                <a href="../content/syndication/_content---syndication---rss.class.php.php">                rss.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: Comments</h1><p>Source Location: /content/comments.class.php [line 40]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class manages comments everywhere in phpboost Simplyfied use with the display_comments function: //news is the name of the modue, $idnews is the id in database for this item. display_comments('news', $idnews, url('news.php?id=' . $idnews . '&amp;amp;com=%s', 'news-0-' . $idnews . '.php?com=%s'))</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�vis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../content/Comments.php#methodComments">Comments</a></li><li class="bb_li"><a href="../content/Comments.php#methodadd">add</a></li><li class="bb_li"><a href="../content/Comments.php#methodcom_display_link">com_display_link</a></li><li class="bb_li"><a href="../content/Comments.php#methoddel">del</a></li><li class="bb_li"><a href="../content/Comments.php#methoddelete_all">delete_all</a></li><li class="bb_li"><a href="../content/Comments.php#methoddisplay">display</a></li><li class="bb_li"><a href="../content/Comments.php#methodget_attribute">get_attribute</a></li><li class="bb_li"><a href="../content/Comments.php#methodis_loaded">is_loaded</a></li><li class="bb_li"><a href="../content/Comments.php#methodlock">lock</a></li><li class="bb_li"><a href="../content/Comments.php#methodset_arg">set_arg</a></li><li class="bb_li"><a href="../content/Comments.php#methodupdate">update</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../content/Comments.php#var$idcom">$idcom</a></li><li class="bb_li"><a href="../content/Comments.php#var$idprov">$idprov</a></li><li class="bb_li"><a href="../content/Comments.php#var$is_kernel_script">$is_kernel_script</a></li><li class="bb_li"><a href="../content/Comments.php#var$lock_com">$lock_com</a></li><li class="bb_li"><a href="../content/Comments.php#var$module_folder">$module_folder</a></li><li class="bb_li"><a href="../content/Comments.php#var$nbr_com">$nbr_com</a></li><li class="bb_li"><a href="../content/Comments.php#var$path">$path</a></li><li class="bb_li"><a href="../content/Comments.php#var$script">$script</a></li><li class="bb_li"><a href="../content/Comments.php#var$sql_table">$sql_table</a></li><li class="bb_li"><a href="../content/Comments.php#var$vars">$vars</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class manages comments everywhere in phpboost Simplyfied use with the display_comments function: //news is the name of the modue, $idnews is the id in database for this item. display_comments('news', $idnews, url('news.php?id=' . $idnews . '&amp;amp;com=%s', 'news-0-' . $idnews . '.php?com=%s'))</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�vis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodComments"></a>
    <h3>constructor Comments <span class="smalllinenumber">[line 51]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>Comments Comments(
string
$script, string
$idprov, string
$vars, [string
$module_folder = ''], [string
$is_kernel_script = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Display comments form.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$script</strong>&nbsp;&nbsp;</td>
        <td>Module's name</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$idprov</strong>&nbsp;&nbsp;</td>
        <td>Id field in the database. related to item where the comments are posted.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$vars</strong>&nbsp;&nbsp;</td>
        <td>Link for the module, it has to include com=%s in the link for the comments system.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_folder</strong>&nbsp;&nbsp;</td>
        <td>Module's folder</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$is_kernel_script</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadd"></a>
    <h3>method add <span class="smalllinenumber">[line 65]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int add(
string
$contents, string
$login)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Add a comment</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the inserted identifier.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$contents</strong>&nbsp;&nbsp;</td>
        <td>Comment content</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$login</strong>&nbsp;&nbsp;</td>
        <td>Poster's login</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddel"></a>
    <h3>method del <span class="smalllinenumber">[line 93]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int del(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Delete a comment</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the previous comment identifier.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddelete_all"></a>
    <h3>method delete_all <span class="smalllinenumber">[line 118]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void delete_all(
int
$idprov)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Delete all comments for the specified item.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idprov</strong>&nbsp;&nbsp;</td>
        <td>The id field of the item in the database.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 182]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string display(
[int
$integrated_in_environment = INTEGRATED_IN_ENVIRONMENT], [<a href="../io/Template.php">Template</a>
$Template = false], [string
$page_path_to_root = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Display comments form.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The parsed template</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$integrated_in_environment</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type"><a href="../io/Template.php">Template</a>&nbsp;&nbsp;</td>
        <td><strong>$Template</strong>&nbsp;&nbsp;</td>
        <td>Optional template.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$page_path_to_root</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_attribute"></a>
    <h3>method get_attribute <span class="smalllinenumber">[line 170]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_attribute(

$varname)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$varname</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_loaded"></a>
    <h3>method is_loaded <span class="smalllinenumber">[line 140]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>boolean is_loaded(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Check if the comments system is correctly loaded.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if loaded correctly, false otherwise.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodlock"></a>
    <h3>method lock <span class="smalllinenumber">[line 129]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void lock(
boolean
$lock)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Lock or unlock comments for an item.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">boolean&nbsp;&nbsp;</td>
        <td><strong>$lock</strong>&nbsp;&nbsp;</td>
        <td>true for locking, false otherwise</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_arg"></a>
    <h3>method set_arg <span class="smalllinenumber">[line 155]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_arg(
int
$idcom, [string
$path = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Set argument for the comments system.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idcom</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodupdate"></a>
    <h3>method update <span class="smalllinenumber">[line 83]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void update(
string
$contents, string
$login)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Edit a comment</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$contents</strong>&nbsp;&nbsp;</td>
        <td>Comment content</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$login</strong>&nbsp;&nbsp;</td>
        <td>Poster's login</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


  <div class="list">
	<a name="methodcom_display_link"></a>
	<h3>static method com_display_link <span class="smalllinenumber">[line 688]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static string com_display_link(
int
$nbr_com, string
$path, int
$idprov, string
$script, [int
$options = 0])</code>
    </td></tr></table>
    </td></tr></table>
	
		
	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$nbr_com</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$path</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$idprov</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$script</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$options</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>


    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                                    <div class="var">
                            <a name="var_idcom"></a>
                <span class="line-number">[line 739]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$idcom</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_idprov"></a>
                <span class="line-number">[line 738]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$idprov</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_is_kernel_script"></a>
                <span class="line-number">[line 746]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$is_kernel_script</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;false</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_lock_com"></a>
                <span class="line-number">[line 745]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$lock_com</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_module_folder"></a>
                <span class="line-number">[line 742]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$module_folder</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_nbr_com"></a>
                <span class="line-number">[line 744]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$nbr_com</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;0</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_path"></a>
                <span class="line-number">[line 740]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$path</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_script"></a>
                <span class="line-number">[line 737]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$script</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_sql_table"></a>
                <span class="line-number">[line 743]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$sql_table</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_vars"></a>
                <span class="line-number">[line 741]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$vars</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                            
                                                                                                                                                                                                        <a href="../classtrees_content.php" class="menu">class tree: content</a> -
            <a href="../elementindex_content.php" class="menu">index: content</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:43 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>