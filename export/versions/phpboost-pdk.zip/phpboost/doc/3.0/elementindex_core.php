<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'core - Package core Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('core', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">core</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                            
                                                                                                                                                                                                    <a href="classtrees_core.php" class="menu">class tree: core</a> - 
                <a href="elementindex_core.php" class="menu">index: core</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="core/Application.php">Application</a>            </li>
                    <li>
                <a href="core/BreadCrumb.php">BreadCrumb</a>            </li>
                    <li>
                <a href="core/Cache.php">Cache</a>            </li>
                    <li>
                <a href="core/Errors.php">Errors</a>            </li>
                    <li>
                <a href="core/MenuService.php">MenuService</a>            </li>
                    <li>
                <a href="core/Repository.php">Repository</a>            </li>
                    <li>
                <a href="core/StatsSaver.php">StatsSaver</a>            </li>
                    <li>
                <a href="core/Updates.php">Updates</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="core/_core---application.class.php.php">                application.class.php
                </a>            </li>
                    <li>
                <a href="core/_core---breadcrumb.class.php.php">                breadcrumb.class.php
                </a>            </li>
                    <li>
                <a href="core/_core---cache.class.php.php">                cache.class.php
                </a>            </li>
                    <li>
                <a href="core/_core---errors.class.php.php">                errors.class.php
                </a>            </li>
                    <li>
                <a href="core/_core---menu_service.class.php.php">                menu_service.class.php
                </a>            </li>
                    <li>
                <a href="core/_core---repository.class.php.php">                repository.class.php
                </a>            </li>
                    <li>
                <a href="core/_core---stats_saver.class.php.php">                stats_saver.class.php
                </a>            </li>
                    <li>
                <a href="core/_core---updates.class.php.php">                updates.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package core</h1>
	[ <a href="elementindex_core.php#a">a</a> ]
	[ <a href="elementindex_core.php#b">b</a> ]
	[ <a href="elementindex_core.php#c">c</a> ]
	[ <a href="elementindex_core.php#d">d</a> ]
	[ <a href="elementindex_core.php#e">e</a> ]
	[ <a href="elementindex_core.php#f">f</a> ]
	[ <a href="elementindex_core.php#g">g</a> ]
	[ <a href="elementindex_core.php#h">h</a> ]
	[ <a href="elementindex_core.php#i">i</a> ]
	[ <a href="elementindex_core.php#l">l</a> ]
	[ <a href="elementindex_core.php#m">m</a> ]
	[ <a href="elementindex_core.php#n">n</a> ]
	[ <a href="elementindex_core.php#p">p</a> ]
	[ <a href="elementindex_core.php#r">r</a> ]
	[ <a href="elementindex_core.php#s">s</a> ]
	[ <a href="elementindex_core.php#t">t</a> ]
	[ <a href="elementindex_core.php#u">u</a> ]
	[ <a href="elementindex_core.php#v">v</a> ]
	[ <a href="elementindex_core.php#w">w</a> ]
	[ <a href="elementindex_core.php#x">x</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>$apps</strong></dt>
				<dd>in file updates.class.php, variable <a href="core/Updates.php#var$apps">Updates::$apps</a></dd>
							<dt><strong>$archive_all</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$archive_all">Errors::$archive_all</a></dd>
							<dt><strong>$array_links</strong></dt>
				<dd>in file breadcrumb.class.php, variable <a href="core/BreadCrumb.php#var$array_links">BreadCrumb::$array_links</a></dd>
							<dt><strong>$authors</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$authors">Application::$authors</a></dd>
							<dt><strong>add</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodadd">BreadCrumb::add()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds a link in the bread crumb. This link will be put at the end of the list.</dd>
							<dt><strong>add_mini_menu</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodadd_mini_menu">MenuService::add_mini_menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add the menu named in the $menu folder</dd>
							<dt><strong>add_mini_module</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodadd_mini_module">MenuService::add_mini_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Add the module named $module mini modules</dd>
							<dt><strong>Application</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodApplication">Application::Application()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor of the class</dd>
							<dt><strong>Application</strong></dt>
				<dd>in file application.class.php, class <a href="core/Application.php">Application</a></dd>
							<dt><strong>APPLICATION_TYPE__KERNEL</strong></dt>
				<dd>in file application.class.php, constant <a href="core/_core---application.class.php.php#defineAPPLICATION_TYPE__KERNEL">APPLICATION_TYPE__KERNEL</a></dd>
							<dt><strong>APPLICATION_TYPE__MODULE</strong></dt>
				<dd>in file application.class.php, constant <a href="core/_core---application.class.php.php#defineAPPLICATION_TYPE__MODULE">APPLICATION_TYPE__MODULE</a></dd>
							<dt><strong>APPLICATION_TYPE__TEMPLATE</strong></dt>
				<dd>in file application.class.php, constant <a href="core/_core---application.class.php.php#defineAPPLICATION_TYPE__TEMPLATE">APPLICATION_TYPE__TEMPLATE</a></dd>
							<dt><strong>ARCHIVE_ALL_ERRORS</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineARCHIVE_ALL_ERRORS">ARCHIVE_ALL_ERRORS</a></dd>
							<dt><strong>ARCHIVE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineARCHIVE_ERROR">ARCHIVE_ERROR</a></dd>
							<dt><strong>assign_positions_conditions</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodassign_positions_conditions">MenuService::assign_positions_conditions()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Assigns the positions conditions for different printing modes</dd>
							<dt><strong>application.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---application.class.php.php">application.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="b"></a>
	<div>
		<h2>b</h2>
		<dl>
							<dt><strong>$bug_corrections</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$bug_corrections">Application::$bug_corrections</a></dd>
							<dt><strong>BreadCrumb</strong></dt>
				<dd>in file breadcrumb.class.php, class <a href="core/BreadCrumb.php">BreadCrumb</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is used to represent the bread crumb displayed on each page of the website. It enables the user to locate himself in the whole site. A bread crumb can look like this: Home &gt;&gt; My module &gt;&gt; First level category &gt;&gt; Second level category &gt;&gt; Third level category &gt;&gt; .. &gt;&gt; My page &gt;&gt; Edition</dd>
							<dt><strong>BreadCrumb</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodBreadCrumb">BreadCrumb::BreadCrumb()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a BreadCrumb object.</dd>
							<dt><strong>breadcrumb.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---breadcrumb.class.php.php">breadcrumb.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>$compatibility_max</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$compatibility_max">Application::$compatibility_max</a></dd>
							<dt><strong>$compatibility_min</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$compatibility_min">Application::$compatibility_min</a></dd>
							<dt><strong>Cache</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodCache">Cache::Cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Builds a Cache object. Check if the directory in which the cache is written is writable.</dd>
							<dt><strong>Cache</strong></dt>
				<dd>in file cache.class.php, class <a href="core/Cache.php">Cache</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is the cache manager of PHPBoost. Its functioning is very particular. Loading a file is equivalent to include the file. The cache file must define some PHP global variables. They will be usable in the execution context of the page. You should read on the PHPBoost website the documentation which explains you how to integrate a cache for you module, it's too much complex to be explained here.</dd>
							<dt><strong>change_position</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodchange_position">MenuService::change_position()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Change the menu position in a block</dd>
							<dt><strong>check</strong></dt>
				<dd>in file repository.class.php, method <a href="core/Repository.php#methodcheck">Repository::check()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Check Application</dd>
							<dt><strong>CHECK_ALL_UPDATES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_ALL_UPDATES">CHECK_ALL_UPDATES</a></dd>
							<dt><strong>check_compatibility</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodcheck_compatibility">Application::check_compatibility()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks compatibility with limits</dd>
							<dt><strong>CHECK_KERNEL</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_KERNEL">CHECK_KERNEL</a></dd>
							<dt><strong>CHECK_MODULES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_MODULES">CHECK_MODULES</a></dd>
							<dt><strong>CHECK_THEMES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#defineCHECK_THEMES">CHECK_THEMES</a></dd>
							<dt><strong>clean</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodclean">BreadCrumb::clean()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Removes all the existing links.</dd>
							<dt><strong>compute_referer</strong></dt>
				<dd>in file stats_saver.class.php, method <a href="core/StatsSaver.php#methodcompute_referer">StatsSaver::compute_referer()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Compute Stats of Site Referers</dd>
							<dt><strong>compute_users</strong></dt>
				<dd>in file stats_saver.class.php, method <a href="core/StatsSaver.php#methodcompute_users">StatsSaver::compute_users()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Compute Stats of Site Users</dd>
							<dt><strong>cache.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---cache.class.php.php">cache.class.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>$description</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$description">Application::$description</a></dd>
							<dt><strong>$download_url</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$download_url">Application::$download_url</a></dd>
							<dt><strong>delete</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete">MenuService::delete()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete a Menu from the database</dd>
							<dt><strong>delete_file</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methoddelete_file">Cache::delete_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a cache file.</dd>
							<dt><strong>delete_mini_menu</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete_mini_menu">MenuService::delete_mini_menu()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;delete the mini menu named $menu</dd>
							<dt><strong>delete_mini_module</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete_mini_module">MenuService::delete_mini_module()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;delete the mini module $module</dd>
							<dt><strong>delete_module_feeds_menus</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddelete_module_feeds_menus">MenuService::delete_module_feeds_menus()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Delete all the feeds menus with the this module id</dd>
							<dt><strong>disable</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methoddisable">MenuService::disable()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Disable a menu</dd>
							<dt><strong>display</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methoddisplay">Errors::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exception handler for developper, return the error.</dd>
							<dt><strong>display</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methoddisplay">BreadCrumb::display()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays the bread crumb.</dd>
							<dt><strong>DISPLAY_ALL_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineDISPLAY_ALL_ERROR">DISPLAY_ALL_ERROR</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="e"></a>
	<div>
		<h2>e</h2>
		<dl>
							<dt><strong>errors.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---errors.class.php.php">errors.class.php</a></dd>
							<dt><strong>enable</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodenable">MenuService::enable()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Enable a menu</dd>
							<dt><strong>enable_all</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodenable_all">MenuService::enable_all()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Enables or disables all menus</dd>
							<dt><strong>Errors</strong></dt>
				<dd>in file errors.class.php, class <a href="core/Errors.php">Errors</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This class is the error manager of PHPBoost. It is designed to collect and store all errors occurs in the projet.</dd>
							<dt><strong>Errors</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodErrors">Errors::Errors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor</dd>
							<dt><strong>E_STRICT</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineE_STRICT">E_STRICT</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>$files</strong></dt>
				<dd>in file cache.class.php, variable <a href="core/Cache.php#var$files">Cache::$files</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>generate_all_files</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_all_files">Cache::generate_all_files()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Regenerates all the cache files managed by the PHPBoost cache manager. This method needs a lot of resource, call it only when you are sure you need it.</dd>
							<dt><strong>generate_all_modules</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_all_modules">Cache::generate_all_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates all the module cache files.</dd>
							<dt><strong>generate_cache</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodgenerate_cache">MenuService::generate_cache()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generate the cache</dd>
							<dt><strong>generate_file</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_file">Cache::generate_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates a file according to the specified method.</dd>
							<dt><strong>generate_module_file</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodgenerate_module_file">Cache::generate_module_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Generates a module file</dd>
							<dt><strong>get_authors</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_authors">Application::get_authors()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Authors</dd>
							<dt><strong>get_bug_corrections</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_bug_corrections">Application::get_bug_corrections()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Bug Corrections Text</dd>
							<dt><strong>get_compatibility_max</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_compatibility_max">Application::get_compatibility_max()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Compatibility Max value</dd>
							<dt><strong>get_compatibility_min</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_compatibility_min">Application::get_compatibility_min()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Compatibility min value</dd>
							<dt><strong>get_description</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_description">Application::get_description()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Description Text</dd>
							<dt><strong>get_download_url</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_download_url">Application::get_download_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Download URL</dd>
							<dt><strong>get_errno_class</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodget_errno_class">Errors::get_errno_class()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get Error type</dd>
							<dt><strong>get_id</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_id">Application::get_id()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of id</dd>
							<dt><strong>get_identifier</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_identifier">Application::get_identifier()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Gets an identifier of the application</dd>
							<dt><strong>get_improvments</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_improvments">Application::get_improvments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Improvments Text</dd>
							<dt><strong>get_language</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_language">Application::get_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Language</dd>
							<dt><strong>get_last__error_log</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodget_last__error_log">Errors::get_last__error_log()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Get last error informations</dd>
							<dt><strong>get_localized_language</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_localized_language">Application::get_localized_language()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Localized language</dd>
							<dt><strong>get_menus_map</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodget_menus_map">MenuService::get_menus_map()</a></dd>
							<dt><strong>get_menu_list</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodget_menu_list">MenuService::get_menu_list()</a></dd>
							<dt><strong>get_name</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_name">Application::get_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of name</dd>
							<dt><strong>get_new_features</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_new_features">Application::get_new_features()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of New Features Text</dd>
							<dt><strong>get_priority</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_priority">Application::get_priority()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Priority</dd>
							<dt><strong>get_pubdate</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_pubdate">Application::get_pubdate()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Publication Date</dd>
							<dt><strong>get_repository</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_repository">Application::get_repository()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Repository</dd>
							<dt><strong>get_security_improvments</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_security_improvments">Application::get_security_improvments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Security Improvments</dd>
							<dt><strong>get_security_update</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_security_update">Application::get_security_update()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Security Update</dd>
							<dt><strong>get_type</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_type">Application::get_type()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Type</dd>
							<dt><strong>get_update_url</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_update_url">Application::get_update_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Update URL</dd>
							<dt><strong>get_url</strong></dt>
				<dd>in file repository.class.php, method <a href="core/Repository.php#methodget_url">Repository::get_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of url</dd>
							<dt><strong>get_version</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_version">Application::get_version()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Version</dd>
							<dt><strong>get_warning</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_warning">Application::get_warning()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Warning</dd>
							<dt><strong>get_warning_level</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodget_warning_level">Application::get_warning_level()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Accessor of Warning level</dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>handler</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodhandler">Errors::handler()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Exception handler for developper.</dd>
							<dt><strong>handler_php</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodhandler_php">Errors::handler_php()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;PHP exceptions handler</dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>$id</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$id">Application::$id</a></dd>
							<dt><strong>$improvments</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$improvments">Application::$improvments</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>$language</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$language">Application::$language</a></dd>
							<dt><strong>$localized_language</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$localized_language">Application::$localized_language</a></dd>
							<dt><strong>load</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodload">MenuService::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieve a Menu Object from the database by its id</dd>
							<dt><strong>load</strong></dt>
				<dd>in file application.class.php, method <a href="core/Application.php#methodload">Application::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads an XML description</dd>
							<dt><strong>load</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodload">Cache::load()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a file file.</dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>menu_service.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---menu_service.class.php.php">menu_service.class.php</a></dd>
							<dt><strong>MenuService</strong></dt>
				<dd>in file menu_service.class.php, class <a href="core/MenuService.php">MenuService</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This service manage kernel menus by adding the persistance to menus objects. It also provides all moving and disabling methods to change the website appearance.</dd>
							<dt><strong>move</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodmove">MenuService::move()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Move a menu into a block and save it. Enable or disable it according to the destination block</dd>
							<dt><strong>MOVE_DOWN</strong></dt>
				<dd>in file menu_service.class.php, constant <a href="core/_core---menu_service.class.php.php#defineMOVE_DOWN">MOVE_DOWN</a></dd>
							<dt><strong>MOVE_UP</strong></dt>
				<dd>in file menu_service.class.php, constant <a href="core/_core---menu_service.class.php.php#defineMOVE_UP">MOVE_UP</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>$name</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$name">Application::$name</a></dd>
							<dt><strong>$new_features</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$new_features">Application::$new_features</a></dd>
							<dt><strong>NO_ARCHIVE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineNO_ARCHIVE_ERROR">NO_ARCHIVE_ERROR</a></dd>
							<dt><strong>NO_FATAL_ERROR_CACHE</strong></dt>
				<dd>in file cache.class.php, constant <a href="core/_core---cache.class.php.php#defineNO_FATAL_ERROR_CACHE">NO_FATAL_ERROR_CACHE</a></dd>
							<dt><strong>NO_FILE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineNO_FILE_ERROR">NO_FILE_ERROR</a></dd>
							<dt><strong>NO_LINE_ERROR</strong></dt>
				<dd>in file errors.class.php, constant <a href="core/_core---errors.class.php.php#defineNO_LINE_ERROR">NO_LINE_ERROR</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>$personal_tpl</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$personal_tpl">Errors::$personal_tpl</a></dd>
							<dt><strong>$priority</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$priority">Application::$priority</a></dd>
							<dt><strong>$pubdate</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$pubdate">Application::$pubdate</a></dd>
							<dt><strong>PHPBOOST_OFFICIAL_REPOSITORY</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#definePHPBOOST_OFFICIAL_REPOSITORY">PHPBOOST_OFFICIAL_REPOSITORY</a></dd>
							<dt><strong>PHP_MIN_VERSION_UPDATES</strong></dt>
				<dd>in file updates.class.php, constant <a href="core/_core---updates.class.php.php#definePHP_MIN_VERSION_UPDATES">PHP_MIN_VERSION_UPDATES</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>$redirect</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$redirect">Errors::$redirect</a></dd>
							<dt><strong>$repositories</strong></dt>
				<dd>in file updates.class.php, variable <a href="core/Updates.php#var$repositories">Updates::$repositories</a></dd>
							<dt><strong>$repository</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$repository">Application::$repository</a></dd>
							<dt><strong>repository.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---repository.class.php.php">repository.class.php</a></dd>
							<dt><strong>RELOAD_CACHE</strong></dt>
				<dd>in file cache.class.php, constant <a href="core/_core---cache.class.php.php#defineRELOAD_CACHE">RELOAD_CACHE</a></dd>
							<dt><strong>remove_last</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodremove_last">BreadCrumb::remove_last()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Removes the last link of the list</dd>
							<dt><strong>Repository</strong></dt>
				<dd>in file repository.class.php, method <a href="core/Repository.php#methodRepository">Repository::Repository()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor of the class</dd>
							<dt><strong>Repository</strong></dt>
				<dd>in file repository.class.php, class <a href="core/Repository.php">Repository</a></dd>
							<dt><strong>reverse</strong></dt>
				<dd>in file breadcrumb.class.php, method <a href="core/BreadCrumb.php#methodreverse">BreadCrumb::reverse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Reverses the whole list of the links. It's very useful when it's easier for you to make the list in the reverse way, at the end, you only need to reverse the list and it will be ok.</dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>$security_improvments</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$security_improvments">Application::$security_improvments</a></dd>
							<dt><strong>$security_update</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$security_update">Application::$security_update</a></dd>
							<dt><strong>stats_saver.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---stats_saver.class.php.php">stats_saver.class.php</a></dd>
							<dt><strong>save</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodsave">MenuService::save()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;save a Menu in the database</dd>
							<dt><strong>set_default_template</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodset_default_template">Errors::set_default_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set default template for the handler methods.</dd>
							<dt><strong>set_template</strong></dt>
				<dd>in file errors.class.php, method <a href="core/Errors.php#methodset_template">Errors::set_template()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Set a personnal template for the handler methods.</dd>
							<dt><strong>StatsSaver</strong></dt>
				<dd>in file stats_saver.class.php, class <a href="core/StatsSaver.php">StatsSaver</a></dd>
							<dt><strong>str_to_location</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodstr_to_location">MenuService::str_to_location()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Convert the string location the int location</dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>$template</strong></dt>
				<dd>in file errors.class.php, variable <a href="core/Errors.php#var$template">Errors::$template</a></dd>
							<dt><strong>$type</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$type">Application::$type</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>$update_url</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$update_url">Application::$update_url</a></dd>
							<dt><strong>$url</strong></dt>
				<dd>in file repository.class.php, variable <a href="core/Repository.php#var$url">Repository::$url</a></dd>
							<dt><strong>updates.class.php</strong></dt>
				<dd>procedural page <a href="core/_core---updates.class.php.php">updates.class.php</a></dd>
							<dt><strong>Updates</strong></dt>
				<dd>in file updates.class.php, method <a href="core/Updates.php#methodUpdates">Updates::Updates()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;constructor of the class</dd>
							<dt><strong>Updates</strong></dt>
				<dd>in file updates.class.php, class <a href="core/Updates.php">Updates</a></dd>
							<dt><strong>update_mini_menus_list</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodupdate_mini_menus_list">MenuService::update_mini_menus_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the mini menus list by adding new ones and delete old ones</dd>
							<dt><strong>update_mini_modules_list</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodupdate_mini_modules_list">MenuService::update_mini_modules_list()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Update the mini modules list by adding new ones and delete old ones</dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="v"></a>
	<div>
		<h2>v</h2>
		<dl>
							<dt><strong>$version</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$version">Application::$version</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="w"></a>
	<div>
		<h2>w</h2>
		<dl>
							<dt><strong>$warning</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$warning">Application::$warning</a></dd>
							<dt><strong>$warning_level</strong></dt>
				<dd>in file application.class.php, variable <a href="core/Application.php#var$warning_level">Application::$warning_level</a></dd>
							<dt><strong>website_modules</strong></dt>
				<dd>in file menu_service.class.php, method <a href="core/MenuService.php#methodwebsite_modules">MenuService::website_modules()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return a menu with links to modules</dd>
							<dt><strong>write</strong></dt>
				<dd>in file cache.class.php, method <a href="core/Cache.php#methodwrite">Cache::write()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Writes a cache file.</dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
  <hr />
	<a name="x"></a>
	<div>
		<h2>x</h2>
		<dl>
							<dt><strong>$xml</strong></dt>
				<dd>in file repository.class.php, variable <a href="core/Repository.php#var$xml">Repository::$xml</a></dd>
					</dl>
	</div>
	<a href="elementindex_core.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                        
                                                                                                                                            <a href="classtrees_core.php" class="menu">class tree: core</a> -
            <a href="elementindex_core.php" class="menu">index: core</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:39 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>