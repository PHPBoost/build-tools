<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'modules - Docs for page module_interface.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('modules', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">modules</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                            
                                                                                    <a href="../classtrees_modules.php" class="menu">class tree: modules</a> - 
                <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/ModuleInterface.php">ModuleInterface</a>            </li>
                    <li>
                <a href="../modules/ModulesDiscoveryService.php">ModulesDiscoveryService</a>            </li>
                    <li>
                <a href="../modules/PackagesManager.php">PackagesManager</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/_modules---modules_discovery_service.class.php.php">                modules_discovery_service.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---module_interface.class.php.php">                module_interface.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---packages_manager.class.php.php">                packages_manager.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: module_interface.class.php</h1><p>Source Location: /modules/module_interface.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../modules/ModuleInterface.php">ModuleInterface</a></dt>
	<dd>This Class allow you to call methods on a ModuleInterface extended class that you're not sure of the method's availality. It also provides a set of generic methods that you could use to integrate your module with others, or allow your module to share services.</dd>
</div><br /><br />

<h2>Page Details:</h2>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineACCES_DENIED"></a>
	<h3>ACCES_DENIED <span class="smalllinenumber">[line 31]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>ACCES_DENIED = 2</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineFUNCTIONNALITY_NOT_IMPLEMENTED"></a>
	<h3>FUNCTIONNALITY_NOT_IMPLEMENTED <span class="smalllinenumber">[line 33]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FUNCTIONNALITY_NOT_IMPLEMENTED = 8</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineMODULE_ATTRIBUTE_DOES_NOT_EXIST"></a>
	<h3>MODULE_ATTRIBUTE_DOES_NOT_EXIST <span class="smalllinenumber">[line 34]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>MODULE_ATTRIBUTE_DOES_NOT_EXIST = 16</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineMODULE_NOT_AVAILABLE"></a>
	<h3>MODULE_NOT_AVAILABLE <span class="smalllinenumber">[line 30]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>MODULE_NOT_AVAILABLE = 1</code>
    </td></tr></table>
    </td></tr></table>

    <div class="description">module_interface.                            -------------------   begin                : January 15, 2008   copyright            : (C) 2008 Lo�c Rouchon   email                : horn@phpboost.
###################################################
   This program is free software; you can redistribute it and/or modify   it under the terms of the GNU General Public License as published by   the Free Software Foundation; either version 2 of the License, or   (at your option) any later version.</div><div class="description"><p>module_interface.class.php                            -------------------   begin                : January 15, 2008   copyright            : (C) 2008 Lo�c Rouchon   email                : horn@phpboost.com
###################################################
   This program is free software; you can redistribute it and/or modify   it under the terms of the GNU General Public License as published by   the Free Software Foundation; either version 2 of the License, or   (at your option) any later version.
 This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
###################################################</p></div>    <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineMODULE_NOT_YET_IMPLEMENTED"></a>
	<h3>MODULE_NOT_YET_IMPLEMENTED <span class="smalllinenumber">[line 32]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>MODULE_NOT_YET_IMPLEMENTED = 4</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                        
                                                            <a href="../classtrees_modules.php" class="menu">class tree: modules</a> -
            <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:51 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>