<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'modules - Docs For Class ModuleInterface');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('modules', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">modules</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                            
                                                                                    <a href="../classtrees_modules.php" class="menu">class tree: modules</a> - 
                <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/ModuleInterface.php">ModuleInterface</a>            </li>
                    <li>
                <a href="../modules/ModulesDiscoveryService.php">ModulesDiscoveryService</a>            </li>
                    <li>
                <a href="../modules/PackagesManager.php">PackagesManager</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/_modules---modules_discovery_service.class.php.php">                modules_discovery_service.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---module_interface.class.php.php">                module_interface.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---packages_manager.class.php.php">                packages_manager.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: ModuleInterface</h1><p>Source Location: /modules/module_interface.class.php [line 44]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This Class allow you to call methods on a ModuleInterface extended class that you're not sure of the method's availality. It also provides a set of generic methods that you could use to integrate your module with others, or allow your module to share services.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../modules/ModuleInterface.php#methodModuleInterface">ModuleInterface</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodfunctionality">functionality</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodget_attribute">get_attribute</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodget_errors">get_errors</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodget_id">get_id</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodget_infos">get_infos</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodget_name">get_name</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodgot_error">got_error</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodhas_functionalities">has_functionalities</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodhas_functionality">has_functionality</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodis_enabled">is_enabled</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodset_attribute">set_attribute</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodset_error">set_error</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#methodunset_attribute">unset_attribute</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../modules/ModuleInterface.php#var$attributes">$attributes</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#var$enabled">$enabled</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#var$errors">$errors</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#var$functionalities">$functionalities</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#var$id">$id</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#var$infos">$infos</a></li><li class="bb_li"><a href="../modules/ModuleInterface.php#var$name">$name</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This Class allow you to call methods on a ModuleInterface extended class that you're not sure of the method's availality. It also provides a set of generic methods that you could use to integrate your module with others, or allow your module to share services.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodModuleInterface"></a>
    <h3>constructor ModuleInterface <span class="smalllinenumber">[line 52]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>ModuleInterface ModuleInterface(
[string
$moduleId = ''], [int
$error = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">ModuleInterface constructor</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$moduleId</strong>&nbsp;&nbsp;</td>
        <td>the module id. It's the name of the folder in witch the module is</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$error</strong>&nbsp;&nbsp;</td>
        <td>allow you to instanciate your module with an error code</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodfunctionality"></a>
    <h3>method functionality <span class="smalllinenumber">[line 198]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>mixed functionality(
string
$functionality, [mixed
$args = null])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Check the existance of the functionality and if exists call it.  If she's not available, the FUNCTIONNALITY_NOT_IMPLEMENTED flag is raised.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the $functionality returns or if non-existing, false</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$functionality</strong>&nbsp;&nbsp;</td>
        <td>the name of the method you want to call</td>
      </tr>
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$args</strong>&nbsp;&nbsp;</td>
        <td>the args you want to pass to the $functionality method</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_attribute"></a>
    <h3>method get_attribute <span class="smalllinenumber">[line 139]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>mixed get_attribute(
$attribute
$attribute)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The value of the attribute identified by the string $attribute  in the intern dictionary if existing. Else, the MODULE_ATTRIBUTE_DOES_NOT_EXIST flag is raised and it  returns -1</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">$attribute&nbsp;&nbsp;</td>
        <td><strong>$attribute</strong>&nbsp;&nbsp;</td>
        <td>the attribute identifier in the dictionary</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_errors"></a>
    <h3>method get_errors <span class="smalllinenumber">[line 186]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>int get_errors(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Returns the current errors flags</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_id"></a>
    <h3>method get_id <span class="smalllinenumber">[line 100]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_id(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Return the id of the module</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_infos"></a>
    <h3>method get_infos <span class="smalllinenumber">[line 124]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>mixed[] get_infos(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> All informations that you could find in the .ini file of the module,  his functionalities and his name</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_name"></a>
    <h3>method get_name <span class="smalllinenumber">[line 116]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Return the name of the module</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodgot_error"></a>
    <h3>method got_error <span class="smalllinenumber">[line 175]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>returns got_error(
[int
$error = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the last error. If called with no arguments, returns true if an error has occured  otherwise, false. If the method got an argument,</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the specified $error has occured otherwise, false.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$error</strong>&nbsp;&nbsp;</td>
        <td>to check a specific error, 0 otherwise</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodhas_functionalities"></a>
    <h3>method has_functionalities <span class="smalllinenumber">[line 222]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool has_functionalities(
string[]
$functionalities)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Check the availability of the functionalities (hook)</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if all functionalities exist, false otherwise</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string[]&nbsp;&nbsp;</td>
        <td><strong>$functionalities</strong>&nbsp;&nbsp;</td>
        <td>the names of the methods you want to check the availability</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodhas_functionality"></a>
    <h3>method has_functionality <span class="smalllinenumber">[line 212]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool has_functionality(
string
$functionality)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Check the availability of the functionality (hook)</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> true if the functionality exists, false otherwise</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$functionality</strong>&nbsp;&nbsp;</td>
        <td>the name of the method you want to check the availability</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodis_enabled"></a>
    <h3>method is_enabled <span class="smalllinenumber">[line 108]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>bool is_enabled(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> Return the true if the module is enabled</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_attribute"></a>
    <h3>method set_attribute <span class="smalllinenumber">[line 155]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_attribute(
string
$attribute, mixed
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Set the $value of the attribute identified by the string $attribute.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$attribute</strong>&nbsp;&nbsp;</td>
        <td>the attribute identifier</td>
      </tr>
          <tr>
        <td class="type">mixed&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>the value to set</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_error"></a>
    <h3>method set_error <span class="smalllinenumber">[line 235]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_error(
[int
$error = 0])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Set the flag error.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$error</strong>&nbsp;&nbsp;</td>
        <td>the error flag to raised</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodunset_attribute"></a>
    <h3>method unset_attribute <span class="smalllinenumber">[line 164]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void unset_attribute(
string
$attribute)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Delete the attribute and free its memory.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$attribute</strong>&nbsp;&nbsp;</td>
        <td>the attribute identifier</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                        <div class="var">
                            <a name="var_attributes"></a>
                <span class="line-number">[line 282]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed[string]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$attributes</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_enabled"></a>
                <span class="line-number">[line 284]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$enabled</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;false</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_errors"></a>
                <span class="line-number">[line 277]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">int</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$errors</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_functionalities"></a>
                <span class="line-number">[line 272]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string[]</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$functionalities</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_id"></a>
                <span class="line-number">[line 257]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$id</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_infos"></a>
                <span class="line-number">[line 267]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$infos</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_name"></a>
                <span class="line-number">[line 262]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">string</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$name</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>access:</strong> protected</li></ul>
    </div>
                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                        
                                                            <a href="../classtrees_modules.php" class="menu">class tree: modules</a> -
            <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:59 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>