<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'modules - Docs For Class ModulesDiscoveryService');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('modules', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">modules</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                            
                                                                                    <a href="../classtrees_modules.php" class="menu">class tree: modules</a> - 
                <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/ModuleInterface.php">ModuleInterface</a>            </li>
                    <li>
                <a href="../modules/ModulesDiscoveryService.php">ModulesDiscoveryService</a>            </li>
                    <li>
                <a href="../modules/PackagesManager.php">PackagesManager</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/_modules---modules_discovery_service.class.php.php">                modules_discovery_service.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---module_interface.class.php.php">                module_interface.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---packages_manager.class.php.php">                packages_manager.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: ModulesDiscoveryService</h1><p>Source Location: /modules/modules_discovery_service.class.php [line 38]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class is a ModuleInterface factory providing some services like mass operations (on several modules at the same time) or identifications methods to get all modules that provide a given functionality</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../modules/ModulesDiscoveryService.php#methodModulesDiscoveryService">ModulesDiscoveryService</a></li><li class="bb_li"><a href="../modules/ModulesDiscoveryService.php#methodfunctionality">functionality</a></li><li class="bb_li"><a href="../modules/ModulesDiscoveryService.php#methodget_all_modules">get_all_modules</a></li><li class="bb_li"><a href="../modules/ModulesDiscoveryService.php#methodget_available_modules">get_available_modules</a></li><li class="bb_li"><a href="../modules/ModulesDiscoveryService.php#methodget_module">get_module</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../modules/ModulesDiscoveryService.php#var$available_modules">$available_modules</a></li><li class="bb_li"><a href="../modules/ModulesDiscoveryService.php#var$loaded_modules">$loaded_modules</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class is a ModuleInterface factory providing some services like mass operations (on several modules at the same time) or identifications methods to get all modules that provide a given functionality</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Lo�c Rouchon &lt;<a href="mailto:horn@phpboost.com">horn@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodModulesDiscoveryService"></a>
    <h3>constructor ModulesDiscoveryService <span class="smalllinenumber">[line 43]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>ModulesDiscoveryService ModulesDiscoveryService(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Builds a new ModuleInterface factory</div>
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodfunctionality"></a>
    <h3>method functionality <span class="smalllinenumber">[line 68]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>mixed[string] functionality(
string
$functionality, mixed[string]
$modules)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Call the method call functionality on each speficied modules</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The results of the functionality method on all modules. This array has keys that are the modules ids and the associated value is the return value for this particular module.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$functionality</strong>&nbsp;&nbsp;</td>
        <td>The method name to call on ModuleInterfaces</td>
      </tr>
          <tr>
        <td class="type">mixed[string]&nbsp;&nbsp;</td>
        <td><strong>$modules</strong>&nbsp;&nbsp;</td>
        <td>The modules arguments in an array which keys are modules ids and values specifics arguments for those modules.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_all_modules"></a>
    <h3>method get_all_modules <span class="smalllinenumber">[line 92]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>ModuleInterface[] get_all_modules(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns a list with all the modules in it, even with those that have no ModuleInterface. Useful to do generic operations on modules.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the ModuleInterface list.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_available_modules"></a>
    <h3>method get_available_modules <span class="smalllinenumber">[line 107]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>ModuleInterface[] get_available_modules(
[string
$functionality = 'none'], [ModuleInterface[]
$modulesList = array()])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the ModuleInterface list.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> the ModuleInterface list.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$functionality</strong>&nbsp;&nbsp;</td>
        <td>the functionality name. By default, returns all availables modules interfaces.</td>
      </tr>
          <tr>
        <td class="type">ModuleInterface[]&nbsp;&nbsp;</td>
        <td><strong>$modulesList</strong>&nbsp;&nbsp;</td>
        <td>If specified, only keep modules interfaces having the requested functionality. Else, search in all availables modules interfaces.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_module"></a>
    <h3>method get_module <span class="smalllinenumber">[line 141]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code><a href="../modules/ModuleInterface.php">ModuleInterface</a> get_module(
[string
$module_id = ''])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Returns the ModuleInterface of the module which id is $module_id.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The corresponding ModuleInterface.</li></ul>
    </div>

    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>The module id.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                    <div class="var">
                            <a name="var_available_modules"></a>
                <span class="line-number">[line 192]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$available_modules</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_loaded_modules"></a>
                <span class="line-number">[line 191]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$loaded_modules</span><span class="tabulation">&nbsp;</span>
                                                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                        
                                                            <a href="../classtrees_modules.php" class="menu">class tree: modules</a> -
            <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:51 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>