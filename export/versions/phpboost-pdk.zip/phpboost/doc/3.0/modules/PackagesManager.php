<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'modules - Docs For Class PackagesManager');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('modules', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">modules</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                            
                                                                                    <a href="../classtrees_modules.php" class="menu">class tree: modules</a> - 
                <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                        <a href="../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../li_builder.php">builder</a></li>
                                                                <li><a href="../li_content.php">content</a></li>
                                                                <li><a href="../li_core.php">core</a></li>
                                                                <li><a href="../li_db.php">db</a></li>
                                                                <li><a href="../li_events.php">events</a></li>
                                                                <li><a href="../li_io.php">io</a></li>
                                                                <li><a href="../li_members.php">members</a></li>
                                                                <li><a href="../li_menu.php">menu</a></li>
                                                                <li><a href="../li_modules.php">modules</a></li>
                                                                <li><a href="../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/ModuleInterface.php">ModuleInterface</a>            </li>
                    <li>
                <a href="../modules/ModulesDiscoveryService.php">ModulesDiscoveryService</a>            </li>
                    <li>
                <a href="../modules/PackagesManager.php">PackagesManager</a>            </li>
                    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="../modules/_modules---modules_discovery_service.class.php.php">                modules_discovery_service.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---module_interface.class.php.php">                module_interface.class.php
                </a>            </li>
                    <li>
                <a href="../modules/_modules---packages_manager.class.php.php">                packages_manager.class.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: PackagesManager</h1><p>Source Location: /modules/packages_manager.class.php [line 48]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description">This class enables you to manages the PHPBoost packages which are nothing else than the modules.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">Benoit Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../modules/PackagesManager.php#methodinstall_module">install_module</a></li><li class="bb_li"><a href="../modules/PackagesManager.php#methoduninstall_module">uninstall_module</a></li></ul>
    </div>
    </td>
<!--
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class enables you to manages the PHPBoost packages which are nothing else than the modules.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> Benoit Sautel &lt;<a href="mailto:ben.popeye@phpboost.com">ben.popeye@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	


  <div class="list">
	<a name="methodinstall_module"></a>
	<h3>static method install_module <span class="smalllinenumber">[line 65]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static int install_module(
string
$module_identifier, [bool
$enable_module = true], [bool
$generate_cache = GENERATE_CACHE_AFTER_THE_OPERATION])</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Installs a module.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> One of the following error codes: <ul><li>MODULE_INSTALLED: the installation succeded</li><li>MODULE_ALREADY_INSTALLED: the module is already installed</li><li>UNEXISTING_MODULE: the module you want to install doesn't exist</li><li>PHP_VERSION_CONFLICT: the server PHP version is two old to be able to run the module code (config set in the config.ini module file)</li><li>CONFIG_CONFLICT: the configuration field is already used&lt;/i&gt;</li></ul></li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$module_identifier</strong>&nbsp;&nbsp;</td>
        <td>Module identifier (name of its folder)</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$enable_module</strong>&nbsp;&nbsp;</td>
        <td>true if you want the module to be enabled, otherwise false.</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$generate_cache</strong>&nbsp;&nbsp;</td>
        <td>GENERATE_CACHE_AFTER_THE_OPERATION if you want to regenerate the cache after the installation or DO_NOT_GENERATE_CACHE_AFTER_THE_OPERATION if you want to go on a new package operation.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
	<a name="methoduninstall_module"></a>
	<h3>static method uninstall_module <span class="smalllinenumber">[line 191]</span></h3>
	<div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>static int uninstall_module(
int
$module_id, bool
$drop_files)</code>
    </td></tr></table>
    </td></tr></table>
	
		<div class="description">Uninstalls a module.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> One of the following error codes: <ul><li>MODULE_FILES_COULD_NOT_BE_DROPPED: the module files couldn't be deleted (probably due to an authorization issue) but it has been uninstalled .</li><li>MODULE_UNINSTALLED: the module was successfully uninstalled.</li><li>NOT_INSTALLED_MODULE: the module to uninstall doesn't exist!</li></ul></li></ul>
    </div>

	
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$module_id</strong>&nbsp;&nbsp;</td>
        <td>Module id (in the DB_TABLE_MODULES table)</td>
      </tr>
          <tr>
        <td class="type">bool&nbsp;&nbsp;</td>
        <td><strong>$drop_files</strong>&nbsp;&nbsp;</td>
        <td>true if you want the module files to be dropped, otherwise false.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                        
                                                            <a href="../classtrees_modules.php" class="menu">class tree: modules</a> -
            <a href="../elementindex_modules.php" class="menu">index: modules</a> -
                <a href="../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:52 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>