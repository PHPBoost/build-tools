<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'builder - Docs for page form_builder.class.php');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('builder', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">builder</div>
        <div class="module_contents">
        <div>
            
                                                                            
                                                                                                                                                                                                                                                                                                                    <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> - 
                <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/FormBuilder.php">FormBuilder</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckbox.php">FormCheckbox</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckboxOption.php">FormCheckboxOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormField.php">FormField</a>            </li>
                    <li>
                <a href="../../builder/form/FormFieldset.php">FormFieldset</a>            </li>
                    <li>
                <a href="../../builder/form/FormFileUploader.php">FormFileUploader</a>            </li>
                    <li>
                <a href="../../builder/form/FormHiddenField.php">FormHiddenField</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoice.php">FormRadioChoice</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelect.php">FormSelect</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelectOption.php">FormSelectOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextarea.php">FormTextarea</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextEdit.php">FormTextEdit</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/_builder---form---form_builder.class.php.php">                form_builder.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox.class.php.php">                form_checkbox.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox_option.class.php.php">                form_checkbox_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_field.class.php.php">                form_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_fieldset.class.php.php">                form_fieldset.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_file_uploader.class.php.php">                form_file_uploader.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_hidden_field.class.php.php">                form_hidden_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice.class.php.php">                form_radio_choice.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice_option.class.php.php">                form_radio_choice_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select.class.php.php">                form_select.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select_option.class.php.php">                form_select_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_textarea.class.php.php">                form_textarea.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_text_edit.class.php.php">                form_text_edit.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Procedural File: form_builder.class.php</h1><p>Source Location: /builder/form/form_builder.class.php [line ]</p>
<br />
<br />

<div class="contents">
<h2>Classes:</h2>
<dt><a href="../../builder/form/FormBuilder.php">FormBuilder</a></dt>
	<dd></dd>
</div><br /><br />

<h2>Page Details:</h2>
<div class="description">This class allows you to manage easily the forms in your modules. A lot of fields and options are supported, for further details refer yourself to each field class.
 Example of use :<ol><li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<a href="../../phpboost/_functions.inc.php.php#functionimport">import</a><span class="src-sym">(</span><span class="src-str">'builder/form/form_builder'</span><span class="src-sym">)</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$form&nbsp;</span>=&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormBuilder.php">FormBuilder</a></span><span class="src-sym">(</span><span class="src-str">'test'</span><span class="src-sym">,&nbsp;</span><span class="src-str">''</span><span class="src-sym">)</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;</div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//#######&nbsp;First&nbsp;fieldset&nbsp;######//</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset&nbsp;</span>=&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormFieldset.php">FormFieldset</a></span><span class="src-sym">(</span><span class="src-str">'Form&nbsp;Test'</span><span class="src-sym">)</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;</div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormTextEdit.php">FormTextEdit</a></span><span class="src-sym">(</span><span class="src-str">'login'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'title'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Login'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'subtitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Enter&nbsp;your&nbsp;login'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'class'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'text'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'required'&nbsp;</span>=&gt;&nbsp;<span class="src-id">true</span><span class="src-sym">,&nbsp;</span><span class="src-str">'required_alert'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Login&nbsp;field&nbsp;has&nbsp;to&nbsp;be&nbsp;filled'</span><span class="src-sym">)))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//Textarea&nbsp;field</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormTextarea.php">FormTextarea</a></span><span class="src-sym">(</span><span class="src-str">'contents'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'title'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Description'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'subtitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Enter&nbsp;a&nbsp;description'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'rows'&nbsp;</span>=&gt;&nbsp;<span class="src-num">10</span><span class="src-sym">,&nbsp;</span><span class="src-str">'cols'&nbsp;</span>=&gt;&nbsp;<span class="src-num">10</span><span class="src-sym">,&nbsp;</span><span class="src-str">'required'&nbsp;</span>=&gt;&nbsp;<span class="src-id">true</span><span class="src-sym">,&nbsp;</span><span class="src-str">'required_alert'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Content&nbsp;field&nbsp;has&nbsp;to&nbsp;be&nbsp;filled'</span><span class="src-sym">)))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormTextarea.php">FormTextarea</a></span><span class="src-sym">(</span><span class="src-str">'comments'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'title'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Comments'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'subtitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">''</span><span class="src-sym">,&nbsp;</span><span class="src-str">'rows'&nbsp;</span>=&gt;&nbsp;<span class="src-num">4</span><span class="src-sym">,&nbsp;</span><span class="src-str">'cols'&nbsp;</span>=&gt;&nbsp;<span class="src-num">5</span><span class="src-sym">,&nbsp;</span><span class="src-str">'editor'&nbsp;</span>=&gt;&nbsp;<span class="src-id">false</span><span class="src-sym">)))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//Radio&nbsp;button&nbsp;field</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormRadioChoice.php">FormRadioChoice</a></span><span class="src-sym">(</span><span class="src-str">'choice'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'title'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Answer'</span><span class="src-sym">)</span><span class="src-sym">,</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a></span><span class="src-sym">(</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'optiontitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Choix1'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;<span class="src-num">1</span><span class="src-sym">))</span><span class="src-sym">,</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a></span><span class="src-sym">(</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'optiontitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Choix2'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;<span class="src-num">2</span><span class="src-sym">,&nbsp;</span><span class="src-str">'checked'&nbsp;</span>=&gt;&nbsp;<span class="src-id">true</span><span class="src-sym">))</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-sym">))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;</div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//Checkbox&nbsp;button&nbsp;field</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormCheckbox.php">FormCheckbox</a></span><span class="src-sym">(</span><span class="src-str">'multiplechoice'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'title'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Answer2'</span><span class="src-sym">)</span><span class="src-sym">,</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormCheckboxOption.php">FormCheckboxOption</a></span><span class="src-sym">(</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'optiontitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Choix3'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;<span class="src-num">1</span><span class="src-sym">))</span><span class="src-sym">,</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormCheckboxOption.php">FormCheckboxOption</a></span><span class="src-sym">(</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'optiontitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Choix4'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;<span class="src-num">2</span><span class="src-sym">,&nbsp;</span><span class="src-str">'checked'&nbsp;</span>=&gt;&nbsp;<span class="src-id">true</span><span class="src-sym">))</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-sym">))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//Select&nbsp;field</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormSelect.php">FormSelect</a></span><span class="src-sym">(</span><span class="src-str">'sex'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'title'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Sex'</span><span class="src-sym">)</span><span class="src-sym">,</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormSelectOption.php">FormSelectOption</a></span><span class="src-sym">(</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'optiontitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Men'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;<span class="src-num">1</span><span class="src-sym">))</span><span class="src-sym">,</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormSelectOption.php">FormSelectOption</a></span><span class="src-sym">(</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'optiontitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Women'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;<span class="src-num">2</span><span class="src-sym">))</span><span class="src-sym">,</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormSelectOption.php">FormSelectOption</a></span><span class="src-sym">(</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'optiontitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'?'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;-<span class="src-num">1</span><span class="src-sym">,&nbsp;</span><span class="src-str">'selected'&nbsp;</span>=&gt;&nbsp;<span class="src-id">true</span><span class="src-sym">))</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-sym">))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;</div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$form</span><span class="src-sym">-&gt;</span><span class="src-id">add_fieldset</span><span class="src-sym">(</span><span class="src-var">$fieldset</span><span class="src-sym">)</span><span class="src-sym">;&nbsp;&nbsp;</span><span class="src-comm">//Add&nbsp;fieldset&nbsp;to&nbsp;the&nbsp;form.</span></div></li>
<li><div class="src-line">&nbsp;</div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//#######&nbsp;Second&nbsp;fieldset&nbsp;#######//</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset_up&nbsp;</span>=&nbsp;<span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormFieldset.php">FormFieldset</a></span><span class="src-sym">(</span><span class="src-str">'Upload&nbsp;file'</span><span class="src-sym">)</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//File&nbsp;field</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset_up</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormFileUploader.php">FormFileUploader</a></span><span class="src-sym">(</span><span class="src-str">'avatar'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'title'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Avatar'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'subtitle'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'Upload&nbsp;a&nbsp;file'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'class'&nbsp;</span>=&gt;&nbsp;<span class="src-str">'file'</span><span class="src-sym">,&nbsp;</span><span class="src-str">'size'&nbsp;</span>=&gt;&nbsp;<span class="src-num">30</span><span class="src-sym">)))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-comm">//Radio&nbsp;button&nbsp;field</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$fieldset_up</span><span class="src-sym">-&gt;</span><span class="src-id">add_field</span><span class="src-sym">(</span><span class="src-key">new&nbsp;</span><span class="src-id"><a href="../../builder/form/FormHiddenField.php">FormHiddenField</a></span><span class="src-sym">(</span><span class="src-str">'test'</span><span class="src-sym">,&nbsp;</span><span class="src-key">array</span><span class="src-sym">(</span><span class="src-str">'value'&nbsp;</span>=&gt;&nbsp;<span class="src-num">1</span><span class="src-sym">)))</span><span class="src-sym">;</span></div></li>
<li><div class="src-line">&nbsp;</div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$form</span><span class="src-sym">-&gt;</span><span class="src-id">add_fieldset</span><span class="src-sym">(</span><span class="src-var">$fieldset_up</span><span class="src-sym">)</span><span class="src-sym">;&nbsp;&nbsp;</span><span class="src-comm">//Add&nbsp;fieldset&nbsp;to&nbsp;the&nbsp;form.</span></div></li>
<li><div class="src-line">&nbsp;</div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;<span class="src-var">$form</span><span class="src-sym">-&gt;</span><span class="src-id">display_preview_button</span><span class="src-sym">(</span><span class="src-str">'contents'</span><span class="src-sym">)</span><span class="src-sym">;&nbsp;</span><span class="src-comm">//Display&nbsp;a&nbsp;preview&nbsp;button&nbsp;for&nbsp;the&nbsp;textarea&nbsp;field(ajax).</span></div></li>
<li><div class="src-line">&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;<span class="src-var">$form</span><span class="src-sym">-&gt;</span><span class="src-id">display</span><span class="src-sym">(</span><span class="src-sym">)</span><span class="src-sym">;&nbsp;</span><span class="src-comm">//Display&nbsp;form.</span></div></li>
</ol></div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
    </div>
<br /><br />
<br /><br />
<br /><br />
  <hr />
	<a name="defineFIELD_INPUT__CHECKBOX"></a>
	<h3>FIELD_INPUT__CHECKBOX <span class="smalllinenumber">[line 82]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FIELD_INPUT__CHECKBOX = 'checkbox'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineFIELD_INPUT__FILE"></a>
	<h3>FIELD_INPUT__FILE <span class="smalllinenumber">[line 84]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FIELD_INPUT__FILE = 'file'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineFIELD_INPUT__HIDDEN"></a>
	<h3>FIELD_INPUT__HIDDEN <span class="smalllinenumber">[line 83]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FIELD_INPUT__HIDDEN = 'hidden'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineFIELD_INPUT__RADIO"></a>
	<h3>FIELD_INPUT__RADIO <span class="smalllinenumber">[line 81]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FIELD_INPUT__RADIO = 'radio'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineFIELD_INPUT__TEXT"></a>
	<h3>FIELD_INPUT__TEXT <span class="smalllinenumber">[line 80]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FIELD_INPUT__TEXT = 'text'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineFIELD__SELECT"></a>
	<h3>FIELD__SELECT <span class="smalllinenumber">[line 86]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FIELD__SELECT = 'select'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
  <hr />
	<a name="defineFIELD__TEXTAREA"></a>
	<h3>FIELD__TEXTAREA <span class="smalllinenumber">[line 85]</span></h3>
	<div class="tags">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
		<code>FIELD__TEXTAREA = 'textarea'</code>
    </td></tr></table>
    </td></tr></table>

        <br />
		</div>
	<div class="top">[ <a href="#top">Top</a> ]</div><br /><br />
<br />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                        
                                                                                                                                                                                                                            <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> -
            <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:49 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>