<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'builder - Docs For Class FormFieldset');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('builder', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">builder</div>
        <div class="module_contents">
        <div>
            
                                                                            
                                                                                                                                                                                                                                                                                                                    <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> - 
                <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/FormBuilder.php">FormBuilder</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckbox.php">FormCheckbox</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckboxOption.php">FormCheckboxOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormField.php">FormField</a>            </li>
                    <li>
                <a href="../../builder/form/FormFieldset.php">FormFieldset</a>            </li>
                    <li>
                <a href="../../builder/form/FormFileUploader.php">FormFileUploader</a>            </li>
                    <li>
                <a href="../../builder/form/FormHiddenField.php">FormHiddenField</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoice.php">FormRadioChoice</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelect.php">FormSelect</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelectOption.php">FormSelectOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextarea.php">FormTextarea</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextEdit.php">FormTextEdit</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/_builder---form---form_builder.class.php.php">                form_builder.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox.class.php.php">                form_checkbox.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox_option.class.php.php">                form_checkbox_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_field.class.php.php">                form_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_fieldset.class.php.php">                form_fieldset.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_file_uploader.class.php.php">                form_file_uploader.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_hidden_field.class.php.php">                form_hidden_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice.class.php.php">                form_radio_choice.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice_option.class.php.php">                form_radio_choice_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select.class.php.php">                form_select.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select_option.class.php.php">                form_select_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_textarea.class.php.php">                form_textarea.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_text_edit.class.php.php">                form_text_edit.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: FormFieldset</h1><p>Source Location: /builder/form/form_fieldset.class.php [line 37]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description"></div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�gis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
	</div>



				

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodFormFieldset">FormFieldset</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodadd_field">add_field</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methoddisplay">display</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methoddisplay_preview_button">display_preview_button</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodget_display_required">get_display_required</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodget_fields">get_fields</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodget_title">get_title</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodset_display_required">set_display_required</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodset_title">set_title</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#methodthrow_error">throw_error</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../builder/form/FormFieldset.php#var$fieldset_display_required">$fieldset_display_required</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#var$fieldset_errors">$fieldset_errors</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#var$fieldset_fields">$fieldset_fields</a></li><li class="bb_li"><a href="../../builder/form/FormFieldset.php#var$fieldset_title">$fieldset_title</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags">    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li><li><strong>abstract:</strong> </li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFormFieldset"></a>
    <h3>constructor FormFieldset <span class="smalllinenumber">[line 45]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>FormFieldset FormFieldset(

$fieldset_title, string
$form_name, string
$form_title, string
$form_action)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">constructor</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_name</strong>&nbsp;&nbsp;</td>
        <td>The name of the form.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_title</strong>&nbsp;&nbsp;</td>
        <td>The tite displayed for the form.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_action</strong>&nbsp;&nbsp;</td>
        <td>The url where the form send the data.</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$fieldset_title</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadd_field"></a>
    <h3>method add_field <span class="smalllinenumber">[line 54]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void add_field(
<a href="../../builder/form/FormField.php">FormField</a>
$form_field)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Store fields in the fieldset.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../../builder/form/FormField.php">FormField</a>&nbsp;&nbsp;</td>
        <td><strong>$form_field</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 67]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string display(
[<a href="../../io/Template.php">Template</a>
$Template = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Return the form</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../../io/Template.php">Template</a>&nbsp;&nbsp;</td>
        <td><strong>$Template</strong>&nbsp;&nbsp;</td>
        <td>Optionnal template</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay_preview_button"></a>
    <h3>method display_preview_button <span class="smalllinenumber">[line 120]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void display_preview_button(

$field_identifier_preview, string
$fieldset_title)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Display a preview button for the specified field.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fieldset_title</strong>&nbsp;&nbsp;</td>
        <td>The fieldset title</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$field_identifier_preview</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_display_required"></a>
    <h3>method get_display_required <span class="smalllinenumber">[line 145]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>boolean get_display_required(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> True if the fieldset has to display a warning for required fields.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_fields"></a>
    <h3>method get_fields <span class="smalllinenumber">[line 140]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>array get_fields(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> All fields in the fieldset.</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_title"></a>
    <h3>method get_title <span class="smalllinenumber">[line 135]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string get_title(
)</code>
    </td></tr></table>
    </td></tr></table>
    
            <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>return:</strong> The fieldset title</li></ul>
    </div>

    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_display_required"></a>
    <h3>method set_display_required <span class="smalllinenumber">[line 130]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_display_required(
boolean
$fieldset_display_required)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">boolean&nbsp;&nbsp;</td>
        <td><strong>$fieldset_display_required</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_title"></a>
    <h3>method set_title <span class="smalllinenumber">[line 125]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_title(
string
$fieldset_title)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fieldset_title</strong>&nbsp;&nbsp;</td>
        <td>The fieldset title</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodthrow_error"></a>
    <h3>method throw_error <span class="smalllinenumber">[line 111]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void throw_error(
string
$errstr, int
$errno)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Store all erros in the field construct process.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$errstr</strong>&nbsp;&nbsp;</td>
        <td>Error message description</td>
      </tr>
          <tr>
        <td class="type">int&nbsp;&nbsp;</td>
        <td><strong>$errno</strong>&nbsp;&nbsp;</td>
        <td>Error type, use php constants.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                            <div class="var">
                            <a name="var_fieldset_display_required"></a>
                <span class="line-number">[line 150]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fieldset_display_required</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;false</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fieldset_errors"></a>
                <span class="line-number">[line 149]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fieldset_errors</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fieldset_fields"></a>
                <span class="line-number">[line 148]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fieldset_fields</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_fieldset_title"></a>
                <span class="line-number">[line 147]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$fieldset_title</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                        
                                                                                                                                                                                                                            <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> -
            <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 05 Nov 2011 22:13:47 +0100 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>