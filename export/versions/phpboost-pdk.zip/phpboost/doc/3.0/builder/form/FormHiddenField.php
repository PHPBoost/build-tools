<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'builder - Docs For Class FormHiddenField');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('builder', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">builder</div>
        <div class="module_contents">
        <div>
            
                                                                            
                                                                                                                                                                                                                                                                                                                    <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> - 
                <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/FormBuilder.php">FormBuilder</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckbox.php">FormCheckbox</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckboxOption.php">FormCheckboxOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormField.php">FormField</a>            </li>
                    <li>
                <a href="../../builder/form/FormFieldset.php">FormFieldset</a>            </li>
                    <li>
                <a href="../../builder/form/FormFileUploader.php">FormFileUploader</a>            </li>
                    <li>
                <a href="../../builder/form/FormHiddenField.php">FormHiddenField</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoice.php">FormRadioChoice</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelect.php">FormSelect</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelectOption.php">FormSelectOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextarea.php">FormTextarea</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextEdit.php">FormTextEdit</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/_builder---form---form_builder.class.php.php">                form_builder.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox.class.php.php">                form_checkbox.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox_option.class.php.php">                form_checkbox_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_field.class.php.php">                form_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_fieldset.class.php.php">                form_fieldset.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_file_uploader.class.php.php">                form_file_uploader.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_hidden_field.class.php.php">                form_hidden_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice.class.php.php">                form_radio_choice.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice_option.class.php.php">                form_radio_choice_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select.class.php.php">                form_select.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select_option.class.php.php">                form_select_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_textarea.class.php.php">                form_textarea.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_text_edit.class.php.php">                form_text_edit.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: FormHiddenField</h1><p>Source Location: /builder/form/form_hidden_field.class.php [line 35]</p>

<h2>Class Overview</a></h2>
<pre><a href="../../builder/form/FormField.php">FormField</a>
   |
   --FormHiddenField</pre>
<div class="description">This class manage hidden input fields.</div>
		<div class="list">
	    <h4>Author(s):</h4>
	    <ul class="bb_ul"><li class="bb_li">R�gis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
	</div>



		

<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../builder/form/FormHiddenField.php#methodFormHiddenField">FormHiddenField</a></li><li class="bb_li"><a href="../../builder/form/FormHiddenField.php#methoddisplay">display</a></li></ul>
    </div>
    </td>
<!--
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"><div class="description">This class manage hidden input fields.</div>    <h4>Tags:</h4>
    <div class="tags">
        <ul><li><strong>author:</strong> R�gis Viarre &lt;<a href="mailto:crowkait@phpboost.com">crowkait@phpboost.com</a>&gt;</li></ul>
    </div>
</div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFormHiddenField"></a>
    <h3>constructor FormHiddenField <span class="smalllinenumber">[line 37]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>FormHiddenField FormHiddenField(

$fieldId, 
$field_options)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$fieldId</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$field_options</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 42]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void display(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>





    <hr />
    <table width="100%" border="0">
        <tr>
                                                    <!--
                        <td valign="top">
                <h3>Inherited Variables</h3>
                                    <div class="tags">
                        <h4>Class: <a href="../../builder/form/FormField.php">FormField</a></h4>
                        <dl>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_css_class">FormField::$field_css_class</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_errors">FormField::$field_errors</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_id">FormField::$field_id</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_name">FormField::$field_name</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_on_blur">FormField::$field_on_blur</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_required">FormField::$field_required</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_required_alert">FormField::$field_required_alert</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_sub_title">FormField::$field_sub_title</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_title">FormField::$field_title</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#var$field_value">FormField::$field_value</a></dt>
                            <dd></dd>
                                                    </dl>
                    </div>
                            </td>
                         -->
                            <td valign="top">
                    <h3>Inherited Methods</h3>
                                            <h4>Class: <a href="../../builder/form/FormField.php">FormField</a></h4>
                        <dl style="margin-left:10px;">
                                                        <dt><a href="../../builder/form/FormField.php#methodFormField">FormField::FormField()</a></dt>
                            <dd>constructor</dd>
                                                        <dt><a href="../../builder/form/FormField.php#methodadd_errors">FormField::add_errors()</a></dt>
                            <dd>Merge errors.</dd>
                                                        <dt><a href="../../builder/form/FormField.php#methodget_errors">FormField::get_errors()</a></dt>
                            <dd>Get all errors occured in the field construct process.</dd>
                                                        <dt><a href="../../builder/form/FormField.php#methodget_id">FormField::get_id()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#methodget_required_alert">FormField::get_required_alert()</a></dt>
                            <dd></dd>
                                                        <dt><a href="../../builder/form/FormField.php#methodthrow_error">FormField::throw_error()</a></dt>
                            <dd>Store all erros in the field construct process.</dd>
                                                    </dl>
                        <br />
                                    </td>
                    </tr>
    </table>
    <hr />

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                        
                                                                                                                                                                                                                            <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> -
            <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:33 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>