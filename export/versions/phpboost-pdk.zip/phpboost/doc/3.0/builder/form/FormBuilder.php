<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'builder - Docs For Class FormBuilder');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('builder', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">builder</div>
        <div class="module_contents">
        <div>
            
                                                                            
                                                                                                                                                                                                                                                                                                                    <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> - 
                <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                        <a href="../../elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="../../li_phpboost.php">phpboost</a></li>
                                                                <li><a href="../../li_builder.php">builder</a></li>
                                                                <li><a href="../../li_content.php">content</a></li>
                                                                <li><a href="../../li_core.php">core</a></li>
                                                                <li><a href="../../li_db.php">db</a></li>
                                                                <li><a href="../../li_events.php">events</a></li>
                                                                <li><a href="../../li_io.php">io</a></li>
                                                                <li><a href="../../li_members.php">members</a></li>
                                                                <li><a href="../../li_menu.php">menu</a></li>
                                                                <li><a href="../../li_modules.php">modules</a></li>
                                                                <li><a href="../../li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/FormBuilder.php">FormBuilder</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckbox.php">FormCheckbox</a>            </li>
                    <li>
                <a href="../../builder/form/FormCheckboxOption.php">FormCheckboxOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormField.php">FormField</a>            </li>
                    <li>
                <a href="../../builder/form/FormFieldset.php">FormFieldset</a>            </li>
                    <li>
                <a href="../../builder/form/FormFileUploader.php">FormFileUploader</a>            </li>
                    <li>
                <a href="../../builder/form/FormHiddenField.php">FormHiddenField</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoice.php">FormRadioChoice</a>            </li>
                    <li>
                <a href="../../builder/form/FormRadioChoiceOption.php">FormRadioChoiceOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelect.php">FormSelect</a>            </li>
                    <li>
                <a href="../../builder/form/FormSelectOption.php">FormSelectOption</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextarea.php">FormTextarea</a>            </li>
                    <li>
                <a href="../../builder/form/FormTextEdit.php">FormTextEdit</a>            </li>
                                </ul>
            </li>
            </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                        <li>
                <strong>form</strong>
                <ul class="bb_ul">
                            <li>
                <a href="../../builder/form/_builder---form---form_builder.class.php.php">                form_builder.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox.class.php.php">                form_checkbox.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_checkbox_option.class.php.php">                form_checkbox_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_field.class.php.php">                form_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_fieldset.class.php.php">                form_fieldset.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_file_uploader.class.php.php">                form_file_uploader.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_hidden_field.class.php.php">                form_hidden_field.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice.class.php.php">                form_radio_choice.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_radio_choice_option.class.php.php">                form_radio_choice_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select.class.php.php">                form_select.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_select_option.class.php.php">                form_select_option.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_textarea.class.php.php">                form_textarea.class.php
                </a>            </li>
                    <li>
                <a href="../../builder/form/_builder---form---form_text_edit.class.php.php">                form_text_edit.class.php
                </a>            </li>
            </li>
                </ul>
        </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class: FormBuilder</h1><p>Source Location: /builder/form/form_builder.class.php [line 97]</p>

<h2>Class Overview</a></h2>
<pre></pre>
<div class="description"></div>
	




<hr />
<table>
    <tr>
    <td>
    <div class="list">
        <h3><a href="#class_methods">Methods</a></h3>
        <ul class="bb_ul"><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodFormBuilder">FormBuilder</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodadd_fieldset">add_fieldset</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methoddisplay">display</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methoddisplay_preview_button">display_preview_button</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methoddisplay_reset">display_reset</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodget_form_action">get_form_action</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodget_form_class">get_form_class</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodget_form_name">get_form_name</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodget_form_submit">get_form_submit</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodset_form_action">set_form_action</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodset_form_class">set_form_class</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodset_form_name">set_form_name</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#methodset_form_submit">set_form_submit</a></li></ul>
    </div>
    </td>
<!--
    <div class="list">
        <h3><a href="#class_vars">Variables</a></h3>
        <ul class="inline"><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$display_preview">$display_preview</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$display_reset">$display_reset</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$field_identifier_preview">$field_identifier_preview</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$form_action">$form_action</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$form_class">$form_class</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$form_fieldsets">$form_fieldsets</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$form_name">$form_name</a></li><li class="bb_li"><a href="../../builder/form/FormBuilder.php#var$form_submit">$form_submit</a></li></ul>
    </div>
 -->
</tr>
</table>

<hr />

<a name="class_details"></a>
<h2>Class Details</h2>
<div class="tags"></div>
<div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div><br />

	<hr /><a name="class_methods"></a>
	<h3>Class Methods</h3>
	
  <div class="list">
    <a name="methodFormBuilder"></a>
    <h3>constructor FormBuilder <span class="smalllinenumber">[line 105]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>FormBuilder FormBuilder(
string
$form_name, [string
$form_action = ''], string
$form_title)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">constructor</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_name</strong>&nbsp;&nbsp;</td>
        <td>The name of the form.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_title</strong>&nbsp;&nbsp;</td>
        <td>The tite displayed for the form.</td>
      </tr>
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$form_action</strong>&nbsp;&nbsp;</td>
        <td>The url where the form send the data.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodadd_fieldset"></a>
    <h3>method add_fieldset <span class="smalllinenumber">[line 118]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void add_fieldset(
<a href="../../builder/form/FormFieldset.php">FormFieldset</a>
$fieldset)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Add fieldset in the form.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../../builder/form/FormFieldset.php">FormFieldset</a>&nbsp;&nbsp;</td>
        <td><strong>$fieldset</strong>&nbsp;&nbsp;</td>
        <td>The fieldset object.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay"></a>
    <h3>method display <span class="smalllinenumber">[line 128]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>string display(
[<a href="../../io/Template.php">Template</a>
$Template = false])</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Return the form</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type"><a href="../../io/Template.php">Template</a>&nbsp;&nbsp;</td>
        <td><strong>$Template</strong>&nbsp;&nbsp;</td>
        <td>Optionnal template</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay_preview_button"></a>
    <h3>method display_preview_button <span class="smalllinenumber">[line 173]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void display_preview_button(

$field_identifier_preview, string
$fieldset_title)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Display a preview button for the specified field.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">string&nbsp;&nbsp;</td>
        <td><strong>$fieldset_title</strong>&nbsp;&nbsp;</td>
        <td>The fieldset title</td>
      </tr>
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$field_identifier_preview</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methoddisplay_reset"></a>
    <h3>method display_reset <span class="smalllinenumber">[line 183]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void display_reset(
boolean
$value)</code>
    </td></tr></table>
    </td></tr></table>
    
        <div class="description">Display a reset button for the form.</div>
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">boolean&nbsp;&nbsp;</td>
        <td><strong>$value</strong>&nbsp;&nbsp;</td>
        <td>True to display, false to hide.</td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_form_action"></a>
    <h3>method get_form_action <span class="smalllinenumber">[line 197]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_form_action(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_form_class"></a>
    <h3>method get_form_class <span class="smalllinenumber">[line 198]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_form_class(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_form_name"></a>
    <h3>method get_form_name <span class="smalllinenumber">[line 195]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_form_name(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodget_form_submit"></a>
    <h3>method get_form_submit <span class="smalllinenumber">[line 196]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void get_form_submit(
)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_form_action"></a>
    <h3>method set_form_action <span class="smalllinenumber">[line 191]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_form_action(

$form_action)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$form_action</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_form_class"></a>
    <h3>method set_form_class <span class="smalllinenumber">[line 192]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_form_class(

$form_class)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$form_class</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_form_name"></a>
    <h3>method set_form_name <span class="smalllinenumber">[line 189]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_form_name(

$form_name)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$form_name</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>
  <div class="list">
    <a name="methodset_form_submit"></a>
    <h3>method set_form_submit <span class="smalllinenumber">[line 190]</span></h3>
    <div class="function">
    <table width="90%" border="0" cellspacing="0" cellpadding="1"><tr><td class="code_border">
    <table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td class="code">
        <code>void set_form_submit(

$form_submit)</code>
    </td></tr></table>
    </td></tr></table>
    
        
    
        <h4>Parameters:</h4>
    <div class="tags">
    <table border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td class="type">&nbsp;&nbsp;</td>
        <td><strong>$form_submit</strong>&nbsp;&nbsp;</td>
        <td></td>
      </tr>
        </table>
    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    <br />
  </div>
  </div>




    <hr /><a name="class_vars"></a>
    <h3>Class Variables</h3>
    <div class="list">                                            <div class="var">
                            <a name="var_display_preview"></a>
                <span class="line-number">[line 205]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$display_preview</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;false</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_display_reset"></a>
                <span class="line-number">[line 208]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$display_reset</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;true</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_field_identifier_preview"></a>
                <span class="line-number">[line 206]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$field_identifier_preview</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;'contents'</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_form_action"></a>
                <span class="line-number">[line 203]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$form_action</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_form_class"></a>
                <span class="line-number">[line 204]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$form_class</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;'fieldset_mini'</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_form_fieldsets"></a>
                <span class="line-number">[line 200]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$form_fieldsets</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">array()</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_form_name"></a>
                <span class="line-number">[line 201]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$form_name</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>                <div class="var">
                            <a name="var_form_submit"></a>
                <span class="line-number">[line 202]</span><span class="tabulation">&nbsp;</span><span class="tabulation">&nbsp;</span>
                <span class="var-type">mixed</span><span class="tabulation">&nbsp;</span>
                <span class="var-name">$form_submit</span><span class="tabulation">&nbsp;</span>
                                 = <span class="value">&nbsp;''</span>                <hr />
                                <div class="tags">
                                    </div>
                    </div>
        <div class="top">[ <a href="#top">Top</a> ] - [ <a href="#class_details">Class Details</a> ] - [ <a href="#class_methods">Methods</a> ] - [ <a href="#class_vars">Variables</a> ]</div>    </div>


            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                        
                                                                                                                                                                                                                            <a href="../../classtrees_builder.php" class="menu">class tree: builder</a> -
            <a href="../../elementindex_builder.php" class="menu">index: builder</a> -
                <a href="../../elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:32 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>