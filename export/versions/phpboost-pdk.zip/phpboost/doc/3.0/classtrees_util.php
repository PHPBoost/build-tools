<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'util - Class Trees for Package util');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('util', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">util</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                                                                                                        
                                                        <a href="classtrees_util.php" class="menu">class tree: util</a> - 
                <a href="elementindex_util.php" class="menu">index: util</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                    </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <h1>Class Trees for Package util</h1>
<hr />
<br />
<div class="classtree">Root class Bench</div><br />
<ul>
<li><a href="util/Bench.php">Bench</a></li></ul>

<hr />
<br />
<div class="classtree">Root class Captcha</div><br />
<ul>
<li><a href="util/Captcha.php">Captcha</a></li></ul>

<hr />
<br />
<div class="classtree">Root class Date</div><br />
<ul>
<li><a href="util/Date.php">Date</a></li></ul>

<hr />
<br />
<div class="classtree">Root class MiniCalendar</div><br />
<ul>
<li><a href="util/MiniCalendar.php">MiniCalendar</a></li></ul>

<hr />
<br />
<div class="classtree">Root class Pagination</div><br />
<ul>
<li><a href="util/Pagination.php">Pagination</a></li></ul>

<hr />
<br />
<div class="classtree">Root class Stats</div><br />
<ul>
<li><a href="util/Stats.php">Stats</a></li></ul>

<hr />
<br />
<div class="classtree">Root class Url</div><br />
<ul>
<li><a href="util/Url.php">Url</a></li></ul>

            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                                                                            
                                        <a href="classtrees_util.php" class="menu">class tree: util</a> -
            <a href="elementindex_util.php" class="menu">index: util</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Sat, 26 Jun 2010 19:48:36 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>