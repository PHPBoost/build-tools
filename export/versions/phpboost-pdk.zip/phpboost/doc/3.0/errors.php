<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'members - phpDocumentor Parser Errors and Warnings');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('members', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">members</div>
        <div class="module_contents">
        <div>
            
                                                                                                                                                                                                                                                    
                                                                                                                                            <a href="classtrees_members.php" class="menu">class tree: members</a> - 
                <a href="elementindex_members.php" class="menu">index: members</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                    </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a href="#Post-parsing">Post-parsing</a><br />
<a href="#administrator_alert_service.class.php">administrator_alert_service.class.php</a><br />
<a href="#application.class.php">application.class.php</a><br />
<a href="#atom.class.php">atom.class.php</a><br />
<a href="#authorizations.class.php">authorizations.class.php</a><br />
<a href="#backup.class.php">backup.class.php</a><br />
<a href="#bbcode_editor.class.php">bbcode_editor.class.php</a><br />
<a href="#bbcode_highlighter.class.php">bbcode_highlighter.class.php</a><br />
<a href="#bbcode_parser.class.php">bbcode_parser.class.php</a><br />
<a href="#bbcode_unparser.class.php">bbcode_unparser.class.php</a><br />
<a href="#bench.class.php">bench.class.php</a><br />
<a href="#breadcrumb.class.php">breadcrumb.class.php</a><br />
<a href="#cache.class.php">cache.class.php</a><br />
<a href="#captcha.class.php">captcha.class.php</a><br />
<a href="#categories_manager.class.php">categories_manager.class.php</a><br />
<a href="#comments.class.php">comments.class.php</a><br />
<a href="#content_formatting_factory.class.php">content_formatting_factory.class.php</a><br />
<a href="#content_menu.class.php">content_menu.class.php</a><br />
<a href="#content_parser.class.php">content_parser.class.php</a><br />
<a href="#content_second_parser.class.php">content_second_parser.class.php</a><br />
<a href="#content_unparser.class.php">content_unparser.class.php</a><br />
<a href="#contribution.class.php">contribution.class.php</a><br />
<a href="#contribution_service.class.php">contribution_service.class.php</a><br />
<a href="#date.class.php">date.class.php</a><br />
<a href="#editor.class.php">editor.class.php</a><br />
<a href="#errors.class.php">errors.class.php</a><br />
<a href="#event.class.php">event.class.php</a><br />
<a href="#feed.class.php">feed.class.php</a><br />
<a href="#feeds_cat.class.php">feeds_cat.class.php</a><br />
<a href="#feeds_list.class.php">feeds_list.class.php</a><br />
<a href="#feed_data.class.php">feed_data.class.php</a><br />
<a href="#feed_item.class.php">feed_item.class.php</a><br />
<a href="#feed_menu.class.php">feed_menu.class.php</a><br />
<a href="#file.class.php">file.class.php</a><br />
<a href="#file_system_element.class.php">file_system_element.class.php</a><br />
<a href="#folder.class.php">folder.class.php</a><br />
<a href="#form_builder.class.php">form_builder.class.php</a><br />
<a href="#form_checkbox.class.php">form_checkbox.class.php</a><br />
<a href="#form_checkbox_option.class.php">form_checkbox_option.class.php</a><br />
<a href="#form_field.class.php">form_field.class.php</a><br />
<a href="#form_fieldset.class.php">form_fieldset.class.php</a><br />
<a href="#form_file_uploader.class.php">form_file_uploader.class.php</a><br />
<a href="#form_hidden_field.class.php">form_hidden_field.class.php</a><br />
<a href="#form_radio_choice.class.php">form_radio_choice.class.php</a><br />
<a href="#form_radio_choice_option.class.php">form_radio_choice_option.class.php</a><br />
<a href="#form_select.class.php">form_select.class.php</a><br />
<a href="#form_select_option.class.php">form_select_option.class.php</a><br />
<a href="#form_textarea.class.php">form_textarea.class.php</a><br />
<a href="#form_text_edit.class.php">form_text_edit.class.php</a><br />
<a href="#functions.inc.php">functions.inc.php</a><br />
<a href="#groups.class.php">groups.class.php</a><br />
<a href="#images_stats.class.php">images_stats.class.php</a><br />
<a href="#links_menu.class.php">links_menu.class.php</a><br />
<a href="#links_menu_element.class.php">links_menu_element.class.php</a><br />
<a href="#links_menu_link.class.php">links_menu_link.class.php</a><br />
<a href="#mail.class.php">mail.class.php</a><br />
<a href="#menu.class.php">menu.class.php</a><br />
<a href="#menu_service.class.php">menu_service.class.php</a><br />
<a href="#mini_calendar.class.php">mini_calendar.class.php</a><br />
<a href="#mini_menu.class.php">mini_menu.class.php</a><br />
<a href="#modules_discovery_service.class.php">modules_discovery_service.class.php</a><br />
<a href="#module_interface.class.php">module_interface.class.php</a><br />
<a href="#module_map.class.php">module_map.class.php</a><br />
<a href="#module_mini_menu.class.php">module_mini_menu.class.php</a><br />
<a href="#mysql.class.php">mysql.class.php</a><br />
<a href="#note.class.php">note.class.php</a><br />
<a href="#packages_manager.class.php">packages_manager.class.php</a><br />
<a href="#pagination.class.php">pagination.class.php</a><br />
<a href="#parser.class.php">parser.class.php</a><br />
<a href="#pm.class.php">pm.class.php</a><br />
<a href="#repository.class.php">repository.class.php</a><br />
<a href="#rss.class.php">rss.class.php</a><br />
<a href="#search.class.php">search.class.php</a><br />
<a href="#session.class.php">session.class.php</a><br />
<a href="#site_map.class.php">site_map.class.php</a><br />
<a href="#site_map_element.class.php">site_map_element.class.php</a><br />
<a href="#site_map_export_config.class.php">site_map_export_config.class.php</a><br />
<a href="#site_map_link.class.php">site_map_link.class.php</a><br />
<a href="#site_map_section.class.php">site_map_section.class.php</a><br />
<a href="#stats_saver.class.php">stats_saver.class.php</a><br />
<a href="#template.class.php">template.class.php</a><br />
<a href="#template_highlighter.class.php">template_highlighter.class.php</a><br />
<a href="#tinymce_editor.class.php">tinymce_editor.class.php</a><br />
<a href="#tinymce_parser.class.php">tinymce_parser.class.php</a><br />
<a href="#tinymce_unparser.class.php">tinymce_unparser.class.php</a><br />
<a href="#updates.class.php">updates.class.php</a><br />
<a href="#upload.class.php">upload.class.php</a><br />
<a href="#uploads.class.php">uploads.class.php</a><br />
<a href="#url.class.php">url.class.php</a><br />
<a href="#user.class.php">user.class.php</a><br />
<a name="administrator_alert.class.php"></a>
<h1>administrator_alert.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 192</strong> - File "/tmp/phpboost/export/build/kernel/framework/events/administrator_alert.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="administrator_alert_service.class.php"></a>
<h1>administrator_alert_service.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 282</strong> - File "/tmp/phpboost/export/build/kernel/framework/events/administrator_alert_service.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="application.class.php"></a>
<h1>application.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 329</strong> - method "Application::_get_attribute()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 350</strong> - method "Application::_get_installed_version()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 385</strong> - File "/tmp/phpboost/export/build/kernel/framework/core/application.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="atom.class.php"></a>
<h1>atom.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 98</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/syndication/atom.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="authorizations.class.php"></a>
<h1>authorizations.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 428</strong> - method "Authorizations::_get_auth_array()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 434</strong> - method "Authorizations::_add_auth_group()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 441</strong> - method "Authorizations::_remove_auth_group()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 444</strong> - File "/tmp/phpboost/export/build/kernel/framework/members/authorizations.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="backup.class.php"></a>
<h1>backup.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 33</strong> - DocBlock would be page-level, but precedes class "Backup", use another DocBlock to document the file<br />
<a name="bbcode_editor.class.php"></a>
<h1>bbcode_editor.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "BBCodeEditor", use another DocBlock to document the file<br />
<a name="bbcode_highlighter.class.php"></a>
<h1>bbcode_highlighter.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 137</strong> - method "BBCodeHighlighter::_highlight_bbcode_tag_with_many_parameters()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 139</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/parser/bbcode_highlighter.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="bbcode_parser.class.php"></a>
<h1>bbcode_parser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 38</strong> - DocBlock would be page-level, but precedes class "BBCodeParser", use another DocBlock to document the file<br />
<strong>Warning on line 143</strong> - method "BBCodeParser::_protect_content()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 161</strong> - method "BBCodeParser::_parse_smilies()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 316</strong> - method "BBCodeParser::_parse_simple_tags()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 371</strong> - method "BBCodeParser::_parse_imbricated_table()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 383</strong> - method "BBCodeParser::_parse_table()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 390</strong> - Unknown tag "@descSerializes" used<br />
<strong>Warning on line 429</strong> - method "BBCodeParser::_parse_imbricated_list()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 443</strong> - method "BBCodeParser::_parse_list()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 457</strong> - method "BBCodeParser::_parse_title()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 476</strong> - method "BBCodeParser::_parse_wikipedia_links()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<a name="bbcode_unparser.class.php"></a>
<h1>bbcode_unparser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 37</strong> - DocBlock would be page-level, but precedes class "BBCodeUnparser", use another DocBlock to document the file<br />
<strong>Warning on line 94</strong> - method "BBCodeUnparser::_unparse_smilies()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 192</strong> - method "BBCodeUnparser::_unparse_simple_tags()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 208</strong> - method "BBCodeUnparser::_unparse_table()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 222</strong> - method "BBCodeUnparser::_unparse_list()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 244</strong> - method "BBCodeUnparser::_unparse_fieldset()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 268</strong> - method "BBCodeUnparser::_unparse_wikipedia_link()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<a name="bench.class.php"></a>
<h1>bench.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 32</strong> - DocBlock would be page-level, but precedes class "Bench", use another DocBlock to document the file<br />
<a name="breadcrumb.class.php"></a>
<h1>breadcrumb.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "BreadCrumb", use another DocBlock to document the file<br />
<a name="cache.class.php"></a>
<h1>cache.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 276</strong> - method "Cache::_get_modules()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 286</strong> - method "Cache::_get_menus()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 306</strong> - method "Cache::_get_config()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 319</strong> - method "Cache::_get_debug()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 386</strong> - method "Cache::_get_htaccess()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 419</strong> - method "Cache::_get_css()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 442</strong> - method "Cache::_get_themes()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 463</strong> - method "Cache::_get_langs()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 472</strong> - method "Cache::_get_day()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 494</strong> - method "Cache::_get_groups()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 519</strong> - method "Cache::_get_member()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 542</strong> - method "Cache::_get_ranks()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 569</strong> - method "Cache::_get_uploads()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 590</strong> - method "Cache::_get_com()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 604</strong> - method "Cache::_get_writingpad()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 625</strong> - method "Cache::_get_smileys()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 650</strong> - method "Cache::_get_stats()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 660</strong> - File "/tmp/phpboost/export/build/kernel/framework/core/cache.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="captcha.class.php"></a>
<h1>captcha.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 353</strong> - method "Captcha::_generate_code()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 371</strong> - method "Captcha::_save_user()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 386</strong> - method "Captcha::_update_code()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 405</strong> - method "Captcha::_image_color_allocate_dark()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 417</strong> - File "/tmp/phpboost/export/build/kernel/framework/util/captcha.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="categories_manager.class.php"></a>
<h1>categories_manager.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 703</strong> - method "CategoriesManager::_create_row_interface()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 790</strong> - method "CategoriesManager::_create_select_row()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 799</strong> - method "CategoriesManager::_add_error()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 815</strong> - method "CategoriesManager::_clear_error()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 841</strong> - method "CategoriesManager::_build_feeds_sub_list()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 870</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/categories_manager.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="comments.class.php"></a>
<h1>comments.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 723</strong> - method "Comments::_get_info_module()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 733</strong> - method "Comments::_get_info_kernel_script()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 748</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/comments.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="content_formatting_factory.class.php"></a>
<h1>content_formatting_factory.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 252</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/parser/content_formatting_factory.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="content_menu.class.php"></a>
<h1>content_menu.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 105</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/content/content_menu.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="content_parser.class.php"></a>
<h1>content_parser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "ContentParser", use another DocBlock to document the file<br />
<strong>Warning on line 125</strong> - method "ContentParser::_split_imbricated_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 201</strong> - method "ContentParser::_preg_split_safe_recurse()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 234</strong> - method "ContentParser::_index_tags()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 276</strong> - method "ContentParser::_pick_up_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 301</strong> - method "ContentParser::_reimplant_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<a name="content_second_parser.class.php"></a>
<h1>content_second_parser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 40</strong> - DocBlock would be page-level, but precedes class "ContentSecondParser", use another DocBlock to document the file<br />
<strong>Warning on line 166</strong> - method "ContentSecondParser::_highlight_code()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 194</strong> - method "ContentSecondParser::_callback_highlight_code()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 208</strong> - method "ContentSecondParser::_math_code()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 221</strong> - method "ContentSecondParser::_process_media_insertion()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 240</strong> - method "ContentSecondParser::_process_swf_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 254</strong> - method "ContentSecondParser::_process_movie_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 274</strong> - method "ContentSecondParser::_process_sound_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<a name="content_unparser.class.php"></a>
<h1>content_unparser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "ContentUnparser", use another DocBlock to document the file<br />
<strong>Warning on line 102</strong> - method "ContentUnparser::_unparse_html()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 156</strong> - method "ContentUnparser::_unparse_code()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<a name="contribution.class.php"></a>
<h1>contribution.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 355</strong> - File "/tmp/phpboost/export/build/kernel/framework/events/contribution.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="contribution_service.class.php"></a>
<h1>contribution_service.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 286</strong> - File "/tmp/phpboost/export/build/kernel/framework/events/contribution_service.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="date.class.php"></a>
<h1>date.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 389</strong> - method "Date::_compute_server_user_difference()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 396</strong> - File "/tmp/phpboost/export/build/kernel/framework/util/date.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="editor.class.php"></a>
<h1>editor.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 34</strong> - DocBlock would be page-level, but precedes class "ContentEditor", use another DocBlock to document the file<br />
<a name="errors.class.php"></a>
<h1>errors.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 399</strong> - method "Errors::_error_log()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 409</strong> - method "Errors::_clean_error_string()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 419</strong> - File "/tmp/phpboost/export/build/kernel/framework/core/errors.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="event.class.php"></a>
<h1>event.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 346</strong> - File "/tmp/phpboost/export/build/kernel/framework/events/event.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="feed.class.php"></a>
<h1>feed.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 322</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/syndication/feed.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="feeds_cat.class.php"></a>
<h1>feeds_cat.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "FeedsCat", use another DocBlock to document the file<br />
<a name="feeds_list.class.php"></a>
<h1>feeds_list.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 37</strong> - DocBlock would be page-level, but precedes class "FeedsList", use another DocBlock to document the file<br />
<a name="feed_data.class.php"></a>
<h1>feed_data.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 172</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/syndication/feed_data.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="feed_item.class.php"></a>
<h1>feed_item.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "FeedItem", use another DocBlock to document the file<br />
<a name="feed_menu.class.php"></a>
<h1>feed_menu.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 137</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/feed/feed_menu.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="file.class.php"></a>
<h1>file.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 357</strong> - File "/tmp/phpboost/export/build/kernel/framework/io/filesystem/file.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="file_system_element.class.php"></a>
<h1>file_system_element.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 149</strong> - File "/tmp/phpboost/export/build/kernel/framework/io/filesystem/file_system_element.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="folder.class.php"></a>
<h1>folder.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 37</strong> - DocBlock would be page-level, but precedes class "Folder", use another DocBlock to document the file<br />
<a name="form_builder.class.php"></a>
<h1>form_builder.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 79</strong> - Page-level DocBlock precedes "define FIELD_INPUT__TEXT", use another DocBlock to document the source element<br />
<strong>Warning on line 97</strong> - no @package tag was used in a DocBlock for class FormBuilder<br />
<a name="form_checkbox.class.php"></a>
<h1>form_checkbox.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "FormCheckbox", use another DocBlock to document the file<br />
<a name="form_checkbox_option.class.php"></a>
<h1>form_checkbox_option.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 40</strong> - DocBlock would be page-level, but precedes class "FormCheckboxOption", use another DocBlock to document the file<br />
<a name="form_field.class.php"></a>
<h1>form_field.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 43</strong> - DocBlock would be page-level, but precedes class "FormField", use another DocBlock to document the file<br />
<a name="form_fieldset.class.php"></a>
<h1>form_fieldset.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 37</strong> - DocBlock would be page-level, but precedes class "FormFieldset", use another DocBlock to document the file<br />
<a name="form_file_uploader.class.php"></a>
<h1>form_file_uploader.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 39</strong> - DocBlock would be page-level, but precedes class "FormFileUploader", use another DocBlock to document the file<br />
<a name="form_hidden_field.class.php"></a>
<h1>form_hidden_field.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 35</strong> - DocBlock would be page-level, but precedes class "FormHiddenField", use another DocBlock to document the file<br />
<a name="form_radio_choice.class.php"></a>
<h1>form_radio_choice.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "FormRadioChoice", use another DocBlock to document the file<br />
<a name="form_radio_choice_option.class.php"></a>
<h1>form_radio_choice_option.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 40</strong> - DocBlock would be page-level, but precedes class "FormRadioChoiceOption", use another DocBlock to document the file<br />
<a name="form_select.class.php"></a>
<h1>form_select.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 40</strong> - DocBlock would be page-level, but precedes class "FormSelect", use another DocBlock to document the file<br />
<a name="form_select_option.class.php"></a>
<h1>form_select_option.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 35</strong> - DocBlock would be page-level, but precedes class "FormSelectOption", use another DocBlock to document the file<br />
<a name="form_textarea.class.php"></a>
<h1>form_textarea.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 35</strong> - DocBlock would be page-level, but precedes class "FormTextarea", use another DocBlock to document the file<br />
<a name="form_text_edit.class.php"></a>
<h1>form_text_edit.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 41</strong> - DocBlock would be page-level, but precedes class "FormTextEdit", use another DocBlock to document the file<br />
<a name="functions.inc.php"></a>
<h1>functions.inc.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 1276</strong> - Unknown tag "@Exports" used<br />
<strong>Warning on line 1330</strong> - File "/tmp/phpboost/export/build/kernel/framework/functions.inc.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="groups.class.php"></a>
<h1>groups.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 139</strong> - File "/tmp/phpboost/export/build/kernel/framework/members/groups.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="images_stats.class.php"></a>
<h1>images_stats.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 468</strong> - method "Stats::_value_to_angle()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 495</strong> - method "Stats::_image_color_allocate_dark()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 515</strong> - method "Stats::_generate_scale()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 548</strong> - method "Stats::_number_round_dozen()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 577</strong> - method "Stats::_create_pics_error()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 588</strong> - method "Stats::_number_round()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 600</strong> - File "/tmp/phpboost/export/build/kernel/framework/util/images_stats.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="links_menu.class.php"></a>
<h1>links_menu.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 251</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/links/links_menu.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="links_menu_element.class.php"></a>
<h1>links_menu_element.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 129</strong> - method "LinksMenuElement::_get_url()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 239</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/links/links_menu_element.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="links_menu_link.class.php"></a>
<h1>links_menu_link.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 89</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/links/links_menu_link.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="mail.class.php"></a>
<h1>mail.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 292</strong> - method "Mail::_add_header_field()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 331</strong> - File "/tmp/phpboost/export/build/kernel/framework/io/mail.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="menu.class.php"></a>
<h1>menu.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 187</strong> - method "Menu::_check_auth()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 222</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/menu.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="menu_service.class.php"></a>
<h1>menu_service.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 771</strong> - File "/tmp/phpboost/export/build/kernel/framework/core/menu_service.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="mini_calendar.class.php"></a>
<h1>mini_calendar.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 37</strong> - DocBlock would be page-level, but precedes class "MiniCalendar", use another DocBlock to document the file<br />
<a name="mini_menu.class.php"></a>
<h1>mini_menu.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 57</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/mini/mini_menu.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="modules_discovery_service.class.php"></a>
<h1>modules_discovery_service.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 38</strong> - DocBlock would be page-level, but precedes class "ModulesDiscoveryService", use another DocBlock to document the file<br />
<a name="module_interface.class.php"></a>
<h1>module_interface.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 249</strong> - method "ModuleInterface::_clear_error()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 288</strong> - File "/tmp/phpboost/export/build/kernel/framework/modules/module_interface.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="module_map.class.php"></a>
<h1>module_map.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 39</strong> - DocBlock would be page-level, but precedes class "ModuleMap", use another DocBlock to document the file<br />
<a name="module_mini_menu.class.php"></a>
<h1>module_mini_menu.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 68</strong> - File "/tmp/phpboost/export/build/kernel/framework/menu/module_mini/module_mini_menu.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="mysql.class.php"></a>
<h1>mysql.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 705</strong> - method "Sql::_error()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 737</strong> - File "/tmp/phpboost/export/build/kernel/framework/db/mysql.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="note.class.php"></a>
<h1>note.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 248</strong> - method "Note::_note_loaded()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 272</strong> - method "Note::_get_table_module()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 285</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/note.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="packages_manager.class.php"></a>
<h1>packages_manager.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 278</strong> - File "/tmp/phpboost/export/build/kernel/framework/modules/packages_manager.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="pagination.class.php"></a>
<h1>pagination.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 165</strong> - method "Pagination::_get_var_page()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 186</strong> - method "Pagination::_check_page()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 195</strong> - File "/tmp/phpboost/export/build/kernel/framework/util/pagination.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="parser.class.php"></a>
<h1>parser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 147</strong> - method "Parser::_parse_imbricated()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 160</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/parser/parser.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="pm.class.php"></a>
<h1>pm.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 211</strong> - File "/tmp/phpboost/export/build/kernel/framework/members/pm.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="repository.class.php"></a>
<h1>repository.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 35</strong> - DocBlock would be page-level, but precedes class "Repository", use another DocBlock to document the file<br />
<a name="rss.class.php"></a>
<h1>rss.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 98</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/syndication/rss.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="search.class.php"></a>
<h1>search.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 451</strong> - method "Search::_get_modules_conditions()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 463</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/search.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="session.class.php"></a>
<h1>session.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 479</strong> - method "Session::_get_id()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 539</strong> - method "Session::_autoconnect()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 650</strong> - method "Session::_check_bot()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 736</strong> - method "Session::_check_referer()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 751</strong> - method "Session::_csrf_attack()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 754</strong> - File "/tmp/phpboost/export/build/kernel/framework/members/session.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="site_map.class.php"></a>
<h1>site_map.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 237</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/sitemap/site_map.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="site_map_element.class.php"></a>
<h1>site_map_element.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 38</strong> - DocBlock would be page-level, but precedes class "SiteMapElement", use another DocBlock to document the file<br />
<a name="site_map_export_config.class.php"></a>
<h1>site_map_export_config.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 41</strong> - DocBlock would be page-level, but precedes class "SitemapExportConfig", use another DocBlock to document the file<br />
<a name="site_map_link.class.php"></a>
<h1>site_map_link.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 39</strong> - DocBlock would be page-level, but precedes class "SiteMapLink", use another DocBlock to document the file<br />
<a name="site_map_section.class.php"></a>
<h1>site_map_section.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 37</strong> - DocBlock would be page-level, but precedes class "SiteMapSection", use another DocBlock to document the file<br />
<a name="stats_saver.class.php"></a>
<h1>stats_saver.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 251</strong> - method "StatsSaver::_write_stats()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 257</strong> - File "/tmp/phpboost/export/build/kernel/framework/core/stats_saver.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="template.class.php"></a>
<h1>template.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 535</strong> - method "Template::_parse()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 540</strong> - method "Template::_accept_php_block()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 550</strong> - method "Template::_protect_from_inject()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 575</strong> - method "Template::_parse_blocks_vars()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 614</strong> - method "Template::_parse_blocks()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 654</strong> - method "Template::_parse_conditionnal_blocks()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 686</strong> - method "Template::_parse_conditionnal_blocks_bis()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 711</strong> - method "Template::_clean()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 727</strong> - method "Template::_save()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 759</strong> - class variable "Template::$_var" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 764</strong> - class variable "Template::$_block" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 767</strong> - File "/tmp/phpboost/export/build/kernel/framework/io/template.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="template_highlighter.class.php"></a>
<h1>template_highlighter.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 104</strong> - File "/tmp/phpboost/export/build/kernel/framework/content/parser/template_highlighter.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="tinymce_editor.class.php"></a>
<h1>tinymce_editor.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 36</strong> - DocBlock would be page-level, but precedes class "TinyMCEEditor", use another DocBlock to document the file<br />
<a name="tinymce_parser.class.php"></a>
<h1>tinymce_parser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 40</strong> - DocBlock would be page-level, but precedes class "TinyMCEParser", use another DocBlock to document the file<br />
<strong>Warning on line 129</strong> - method "TinyMCEParser::_prepare_content()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 180</strong> - method "TinyMCEParser::_parse_table_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 211</strong> - method "TinyMCEParser::_parse_row_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 257</strong> - method "TinyMCEParser::_parse_col_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 479</strong> - method "TinyMCEParser::_parse_tinymce_formatting()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 508</strong> - method "TinyMCEParser::_parse_tables()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 531</strong> - method "TinyMCEParser::_parse_smilies()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 635</strong> - method "TinyMCEParser::_parse_bbcode_tags()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 656</strong> - method "TinyMCEParser::_parse_wikipedia_links()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 678</strong> - method "TinyMCEParser::_parse_indent_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 727</strong> - method "TinyMCEParser::_parse_size_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 766</strong> - method "TinyMCEParser::_parse_font_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 780</strong> - method "TinyMCEParser::_clear_html_and_code_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 827</strong> - method "TinyMCEParser::_correct()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<a name="tinymce_unparser.class.php"></a>
<h1>tinymce_unparser.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 41</strong> - DocBlock would be page-level, but precedes class "TinyMCEUnparser", use another DocBlock to document the file<br />
<strong>Warning on line 135</strong> - method "TinyMCEUnparser::_unparse_smilies()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 199</strong> - method "TinyMCEUnparser::_unparse_tinymce_formatting()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 258</strong> - method "TinyMCEUnparser::_unparse_bbcode_tags()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 269</strong> - method "TinyMCEUnparser::_clear_html_and_code_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 300</strong> - method "TinyMCEUnparser::_unparse_fieldset()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 333</strong> - method "TinyMCEUnparser::_unparse_wikipedia_link()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 359</strong> - method "TinyMCEUnparser::_unparse_font()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 404</strong> - method "TinyMCEUnparser::_unparse_size_tag()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<a name="updates.class.php"></a>
<h1>updates.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 103</strong> - method "Updates::_load_apps()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 119</strong> - method "Updates::_load_repositories()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 137</strong> - method "Updates::_check_repositories()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 166</strong> - method "Updates::_add_update_alert()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 172</strong> - File "/tmp/phpboost/export/build/kernel/framework/core/updates.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="upload.class.php"></a>
<h1>upload.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 141</strong> - method "Upload::_check_file()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 157</strong> - method "Upload::_clean_filename()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 194</strong> - method "Upload::_generate_file_info()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 222</strong> - method "Upload::_error_manager()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 231</strong> - File "/tmp/phpboost/export/build/kernel/framework/io/upload.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="uploads.class.php"></a>
<h1>uploads.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 373</strong> - File "/tmp/phpboost/export/build/kernel/framework/members/uploads.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="url.class.php"></a>
<h1>url.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 309</strong> - method "Url::_convert_url_to_absolute()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 322</strong> - method "Url::_convert_url_to_root_relative()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 338</strong> - method "Url::_convert_url_to_relative()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 392</strong> - method "Url::_build_html_match_regex()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 529</strong> - File "/tmp/phpboost/export/build/kernel/framework/util/url.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
<a name="user.class.php"></a>
<h1>user.class.php</h1>
<h2>Warnings:</h2><br />
<strong>Warning on line 233</strong> - method "User::_sum_auth_groups()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 265</strong> - method "User::_array_group_intersect()" is assumed to be @access private because its name starts with _, but has no @access tag<br />
<strong>Warning on line 274</strong> - File "/tmp/phpboost/export/build/kernel/framework/members/user.class.php" has no page-level DocBlock, use @package in the first DocBlock to create one<br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                                                                                                                                                
                                                                                                    <a href="classtrees_members.php" class="menu">class tree: members</a> -
            <a href="elementindex_members.php" class="menu">index: members</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:40 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>