<?php
$folders = array_reverse(explode('/', $_SERVER['REQUEST_URI']));
$path_to_root = '';
foreach ($folders as $folder)
{
    if ($folder == 'doc')
    {
        break;
    }
    $path_to_root .= '../';
}
define('PATH_TO_ROOT', trim($path_to_root, '/'));
require_once PATH_TO_ROOT . '/kernel/begin.php';
define('TITLE', 'phpboost - Package phpboost Element Index');
$Bread_crumb->add('Documentation', PATH_TO_ROOT . '/doc/3.0/index.php');
$Bread_crumb->add('phpboost', '');
require_once PATH_TO_ROOT . '/kernel/header.php';
?>
<div class="module_position">                                   
        <div class="module_top_l"></div>                
        <div class="module_top_r"></div>
        <div class="module_top">phpboost</div>
        <div class="module_contents">
        <div>
            
                                                                            
                                                                                                                                                                                                                                                                                                                    <a href="classtrees_phpboost.php" class="menu">class tree: phpboost</a> - 
                <a href="elementindex_phpboost.php" class="menu">index: phpboost</a> -
                        <a href="elementindex.php" class="menu">all elements</a>
        </div>
        
        <table>
            <tr>
                <td style="vertical-align:top;">
                                                            <fieldset>
                        <legend>Packages</legend>
                        <ul class="bb_ul">
                                                                <li><a href="li_members.php">members</a></li>
                                                                <li><a href="li_phpboost.php">phpboost</a></li>
                                                                <li><a href="li_core.php">core</a></li>
                                                                <li><a href="li_menu.php">menu</a></li>
                                                                <li><a href="li_db.php">db</a></li>
                                                                <li><a href="li_builder.php">builder</a></li>
                                                                <li><a href="li_modules.php">modules</a></li>
                                                                <li><a href="li_content.php">content</a></li>
                                                                <li><a href="li_events.php">events</a></li>
                                                                <li><a href="li_io.php">io</a></li>
                                                                <li><a href="li_util.php">util</a></li>
                                                    </ul>
                    </fieldset>
                                                                                                                                    <fieldset>
                                        <legend>Interfaces</legend>
                                        <ul class="bb_ul">
    </ul>
                                    </fieldset>
                                                        
                                                            <fieldset>
                                    <legend>Classes</legend>
                                    <ul class="bb_ul">
    </ul>
                                </fieldset>
                                                                
                                                            <fieldset>
                                    <legend>Files</legend>
                                    <ul class="bb_ul">
                                <li>
                <a href="phpboost/_functions.inc.php.php">                functions.inc.php
                </a>            </li>
            </li>
        </ul>
                                </fieldset>
                                                                </td>
                <td style="vertical-align:top; padding-left:20px;">
                                        <a name="top"></a>
<h1>Element index for package phpboost</h1>
	[ <a href="elementindex_phpboost.php#a">a</a> ]
	[ <a href="elementindex_phpboost.php#c">c</a> ]
	[ <a href="elementindex_phpboost.php#d">d</a> ]
	[ <a href="elementindex_phpboost.php#f">f</a> ]
	[ <a href="elementindex_phpboost.php#g">g</a> ]
	[ <a href="elementindex_phpboost.php#h">h</a> ]
	[ <a href="elementindex_phpboost.php#i">i</a> ]
	[ <a href="elementindex_phpboost.php#l">l</a> ]
	[ <a href="elementindex_phpboost.php#m">m</a> ]
	[ <a href="elementindex_phpboost.php#n">n</a> ]
	[ <a href="elementindex_phpboost.php#o">o</a> ]
	[ <a href="elementindex_phpboost.php#p">p</a> ]
	[ <a href="elementindex_phpboost.php#r">r</a> ]
	[ <a href="elementindex_phpboost.php#s">s</a> ]
	[ <a href="elementindex_phpboost.php#t">t</a> ]
	[ <a href="elementindex_phpboost.php#u">u</a> ]
	[ <a href="elementindex_phpboost.php#w">w</a> ]

  <hr />
	<a name="a"></a>
	<div>
		<h2>a</h2>
		<dl>
							<dt><strong>ADDSLASHES_AUTO</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineADDSLASHES_AUTO">ADDSLASHES_AUTO</a></dd>
							<dt><strong>ADDSLASHES_FORCE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineADDSLASHES_FORCE">ADDSLASHES_FORCE</a></dd>
							<dt><strong>ADDSLASHES_NONE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineADDSLASHES_NONE">ADDSLASHES_NONE</a></dd>
							<dt><strong>array_combine</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionarray_combine">array_combine()</a></dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="c"></a>
	<div>
		<h2>c</h2>
		<dl>
							<dt><strong>check_mail</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functioncheck_mail">check_mail()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if a string could match an email address form.</dd>
							<dt><strong>check_nbr_links</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functioncheck_nbr_links">check_nbr_links()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Checks if a string contains less than a defined number of links (used to prevent SPAM).</dd>
							<dt><strong>CLASS_IMPORT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineCLASS_IMPORT">CLASS_IMPORT</a></dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="d"></a>
	<div>
		<h2>d</h2>
		<dl>
							<dt><strong>delete_file</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiondelete_file">delete_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Deletes a file</dd>
							<dt><strong>display_comments</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiondisplay_comments">display_comments()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML code of the comments manager.</dd>
							<dt><strong>display_editor</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiondisplay_editor">display_editor()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the HTML code of the user editor. It uses the ContentFormattingFactory class, it allows you to write less code lines.</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="f"></a>
	<div>
		<h2>f</h2>
		<dl>
							<dt><strong>file_get_contents_emulate</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionfile_get_contents_emulate">file_get_contents_emulate()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Emulates the PHP file_get_contents_emulate.</dd>
							<dt><strong>find_require_dir</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionfind_require_dir">find_require_dir()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Finds a folder according to the user language. You find the file in a folder in which there is one folder per lang. If it doesn't exist, you want to choose the file in another language. This function returns the path of an existing file (if the required lang exists, it will be it, otherwise it will be one of the existing files).</dd>
							<dt><strong>functions.inc.php</strong></dt>
				<dd>procedural page <a href="phpboost/_functions.inc.php.php">functions.inc.php</a></dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="g"></a>
	<div>
		<h2>g</h2>
		<dl>
							<dt><strong>get_ini_config</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_ini_config">get_ini_config()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the config field of a module configuration file. In fact, this field contains the default module configuration in which we can find some &quot; characters. To solve the problem, this field is considered as a comment and when we want to retrieve its value, we have to call this method which returns its value.</dd>
							<dt><strong>get_module_name</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_module_name">get_module_name()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the identifier (name of the folder) of the module which is currently executed.</dd>
							<dt><strong>get_start_page</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_start_page">get_start_page()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves the site start page.</dd>
							<dt><strong>get_uid</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_uid">get_uid()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns a unique identifier (useful for example to generate some javascript ids)</dd>
							<dt><strong>get_ulang</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_ulang">get_ulang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current user's language.</dd>
							<dt><strong>get_utheme</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionget_utheme">get_utheme()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the current user's theme.</dd>
							<dt><strong>gmdate_format</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functiongmdate_format">gmdate_format()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Formats a date according to a specific form.</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="h"></a>
	<div>
		<h2>h</h2>
		<dl>
							<dt><strong>htmlspecialchars_decode</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionhtmlspecialchars_decode">htmlspecialchars_decode()</a></dd>
							<dt><strong>html_entity_decode</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionhtml_entity_decode">html_entity_decode()</a></dd>
							<dt><strong>HTML_NO_PROTECT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineHTML_NO_PROTECT">HTML_NO_PROTECT</a></dd>
							<dt><strong>HTML_PROTECT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineHTML_PROTECT">HTML_PROTECT</a></dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="i"></a>
	<div>
		<h2>i</h2>
		<dl>
							<dt><strong>import</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionimport">import()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Umports a class or a lib from the framework</dd>
							<dt><strong>inc</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functioninc">inc()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Includes a file</dd>
							<dt><strong>INC_IMPORT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineINC_IMPORT">INC_IMPORT</a></dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="l"></a>
	<div>
		<h2>l</h2>
		<dl>
							<dt><strong>LIB_IMPORT</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineLIB_IMPORT">LIB_IMPORT</a></dd>
							<dt><strong>load_ini_file</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionload_ini_file">load_ini_file()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a configuration file. You choose a bases path, and you specify a folder name in which you file should be found, if it doesn't exist, it will take a file in another folder. It's very interesting when you want to</dd>
							<dt><strong>load_menu_lang</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionload_menu_lang">load_menu_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a menu lang file. It will load alone the file corresponding to the user lang, but if it doesn't exist, another lang will be choosen. An error will be displayed on the page and the script execution will be stopped if no lang file is found for this menu.</dd>
							<dt><strong>load_module_lang</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionload_module_lang">load_module_lang()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Loads a module lang file. It will load alone the file corresponding to the user lang, but if it doesn't exist, another lang will be choosen. An error will be displayed on the page and the script execution will be stopped if no lang file is found for this module.</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="m"></a>
	<div>
		<h2>m</h2>
		<dl>
							<dt><strong>MAGIC_QUOTES_DISABLED</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineMAGIC_QUOTES_DISABLED">MAGIC_QUOTES_DISABLED</a></dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="n"></a>
	<div>
		<h2>n</h2>
		<dl>
							<dt><strong>NO_EDITOR_UNPARSE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineNO_EDITOR_UNPARSE">NO_EDITOR_UNPARSE</a></dd>
							<dt><strong>NO_FATAL_ERROR</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineNO_FATAL_ERROR">NO_FATAL_ERROR</a></dd>
							<dt><strong>NO_UPDATE_PAGES</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineNO_UPDATE_PAGES">NO_UPDATE_PAGES</a></dd>
							<dt><strong>number_round</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionnumber_round">number_round()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Rounds a number</dd>
							<dt><strong>numeric</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionnumeric">numeric()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Converts a string to a numeric value.</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="o"></a>
	<div>
		<h2>o</h2>
		<dl>
							<dt><strong>of_class</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionof_class">of_class()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Tells if an object is an instance of a class</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="p"></a>
	<div>
		<h2>p</h2>
		<dl>
							<dt><strong>pages_displayed</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionpages_displayed">pages_displayed()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;This function is called by the kernel on each displayed page to count the number of pages seen at each hour.</dd>
							<dt><strong>parse_ini_array</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionparse_ini_array">parse_ini_array()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a table written in a special syntax which is user-friendly and can be inserted in a ini file (PHP serialized arrays cannot be inserted because they contain the &quot; character). The syntax is very easy, it really looks like the PHP array declaration: key =&gt; value, key2 =&gt; value2 You can nest some elements: key =&gt; (key1 =&gt; value1, key2 =&gt; value2), key2 =&gt; value2</dd>
							<dt><strong>phpboost_version</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionphpboost_version">phpboost_version()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the full phpboost version with its build number</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="r"></a>
	<div>
		<h2>r</h2>
		<dl>
							<dt><strong>redirect</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionredirect">redirect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Redirects the user to the URL and stops purely the script execution (database deconnexion...).</dd>
							<dt><strong>redirect_confirm</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionredirect_confirm">redirect_confirm()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Displays a confirmation message during a defined delay and then redirects the user.</dd>
							<dt><strong>req</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionreq">req()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Requires a file</dd>
							<dt><strong>retrieve</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionretrieve">retrieve()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Retrieves an input variable. You can retrieve any parameter of the HTTP request which launched the execution of this page.</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="s"></a>
	<div>
		<h2>s</h2>
		<dl>
							<dt><strong>second_parse</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionsecond_parse">second_parse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Second parses a string with several default parameters. This methods exists to lighten the number of lines written.</dd>
							<dt><strong>second_parse_url</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionsecond_parse_url">second_parse_url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Second parses relative urls to absolute urls.</dd>
							<dt><strong>set_subregex_multiplicity</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionset_subregex_multiplicity">set_subregex_multiplicity()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Returns the sub-regex with its multiplicity option</dd>
							<dt><strong>strhash</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrhash">strhash()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Return a SHA256 hash of the $str string [with a salt]</dd>
							<dt><strong>strparse</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrparse">strparse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a string with several default parameters. This methods exists to lighten the number of lines written.</dd>
							<dt><strong>strprotect</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrprotect">strprotect()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Protects an input variable. Never trust user input!</dd>
							<dt><strong>strtodate</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrtodate">strtodate()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Converts a formatted date to the SQL date format.</dd>
							<dt><strong>strtotimestamp</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionstrtotimestamp">strtotimestamp()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Parses a formatted date</dd>
							<dt><strong>substr_html</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionsubstr_html">substr_html()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Cuts a string containing some HTML code which contains some HTML entities. The substr PHP function considers a HTML entity as several characters. This function allows you to consider them as only one character.</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="t"></a>
	<div>
		<h2>t</h2>
		<dl>
							<dt><strong>TIMEZONE_SITE</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineTIMEZONE_SITE">TIMEZONE_SITE</a></dd>
							<dt><strong>TIMEZONE_SYSTEM</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineTIMEZONE_SYSTEM">TIMEZONE_SYSTEM</a></dd>
							<dt><strong>TIMEZONE_USER</strong></dt>
				<dd>in file functions.inc.php, constant <a href="phpboost/_functions.inc.php.php#defineTIMEZONE_USER">TIMEZONE_USER</a></dd>
							<dt><strong>to_js_string</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionto_js_string">to_js_string()</a></dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="u"></a>
	<div>
		<h2>u</h2>
		<dl>
							<dt><strong>unparse</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionunparse">unparse()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Unparses a string with several default parameters. This methods exists to lighten the number of lines written.</dd>
							<dt><strong>url</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionurl">url()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Adds the session ID to an URL if the user doesn't accepts cookies. This functions allows you to generate an URL according to the site configuration concerning the URL rewriting.</dd>
							<dt><strong>url_encode_rewrite</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionurl_encode_rewrite">url_encode_rewrite()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Prepares a string for it to be used in an URL (with only a-z, 0-9 and - characters).</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
  <hr />
	<a name="w"></a>
	<div>
		<h2>w</h2>
		<dl>
							<dt><strong>wordwrap_html</strong></dt>
				<dd>in file functions.inc.php, function <a href="phpboost/_functions.inc.php.php#functionwordwrap_html">wordwrap_html()</a><br>&nbsp;&nbsp;&nbsp;&nbsp;Inserts a carriage return every $lenght characters. It's equivalent to wordwrap PHP function but it can deal with the HTML entities. An entity is coded on several characters and the wordwrap function counts several characters for an entity whereas it represents only one character.</dd>
					</dl>
	</div>
	<a href="elementindex_phpboost.php#top">top</a><br />
            </td>
        </tr>
            </table>
    <div style="text-align:center;">
        
                                                        
                                                                                                                                                                                                                            <a href="classtrees_phpboost.php" class="menu">class tree: phpboost</a> -
            <a href="elementindex_phpboost.php" class="menu">index: phpboost</a> -
                <a href="elementindex.php" class="menu">all elements</a>
    </div>
    <div class="module_bottom_l"></div>         
    <div class="module_bottom_r"></div>
    <div class="module_bottom">Documentation generated on Mon, 11 Jun 2012 22:15:26 +0200 by <a href="http://www.phpdoc.org">phpDocumentor 1.4.1</a></div>
</div>
<?php
require_once PATH_TO_ROOT . '/kernel/footer.php';
?>